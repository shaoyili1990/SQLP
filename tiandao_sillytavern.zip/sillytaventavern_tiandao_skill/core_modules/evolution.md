# 演化生成器核心模块 (evolution.py)

## 模块职责

作为天道演化系统的"行为链生成引擎"，负责：
1. 基于心理档案生成多轮行为序列
2. 每轮行为验证（是否符合角色本质）
3. 动机链计算（四层动机→具体行为）
4. 冲突检测与处理
5. 演化链管理与输出

## 一、核心设计理念

### 1.1 核心矛盾

SillyTavern的问题是"时间戳之间的空白"：
```
玩家: [戳] → [角色响应] → [空白等待] → [戳] → [角色响应]
问题: 空白期间角色内心再活跃，也没有真实行动
```

天道解决思路：
```
玩家: [戳] → [角色响应] 
           ↓
      [天道演化层启动]
           ↓
    [第1轮自主行为] → [验证] → [输出]
           ↓
    [第2轮自主行为] → [验证] → [输出]
           ↓
    [第N轮自主行为] → [验证] → [输出]
           ↓
      [等待玩家注入或下一时间戳]
```

### 1.2 演化粒度

| 粒度 | 说明 | 适用场景 |
|------|------|----------|
| 微观 | 一个动作/表情/语气变化 | 单轮内的行为细节 |
| 介观 | 一句话+动作+情绪反应 | 默认单轮输出 |
| 宏观 | 一个完整的"场景片段" | 玩家视角的一个"感受单元" |

**默认采用介观粒度**：每轮输出一个完整的"角色行为片段"。

## 二、行为链生成器

```python
class EvolutionChain:
    """演化链管理"""
    
    def __init__(self, profile: dict, max_rounds: int = 3):
        self.profile = profile
        self.max_rounds = max_rounds
        self.current_round = 0
        self.chain = []  # 演化行为列表
        self.paused = False
        self.injected_thoughts = []
        
    def generate_next_round(self) -> dict:
        """
        生成下一轮演化行为
        
        返回: {
            "round": int,
            "behavior": str,  # 行为描述
            "action_type": str,  # "internal" | "external" | "verbal" | "mixed"
            "emotional_state": str,
            "y_value": int,
            "motivation_chain": str,
            "validation_passed": bool,
            "validation_notes": str
        }
        """
```

## 三、行为生成算法

### 3.1 输入条件

```python
def prepare_generation_input(profile: dict, scene_context: dict) -> dict:
    """
    准备生成输入条件
    
    scene_context: {
        "type": "singleton" | "couple" | "group",
        "other_characters": [str],  # 场景中其他角色名
        "location": str,
        "time": str,
        "ongoing_events": [str]
    }
    """
    return {
        "name": profile["name"],
        "mbti": profile["mbti"],
        "current_y": profile["current_y"],
        "base_y": profile.get("base_y", 50),
        "memory": profile["memory"],
        "motivation_chain": profile.get("motivation_chain", {}),
        "scene_context": scene_context,
        # 计算本能权重
        "instinct_weights": calculate_instinct_weights(profile["mbti"])
    }
```

### 3.2 行为生成核心算法

```python
def generate_behavior(input_data: dict) -> dict:
    """
    核心行为生成算法
    
    遵循: 动机链 → 心理状态 → 行为选择的顺序
    """
    
    # === 第一步：确定当前心理状态 ===
    psychological_state = determine_psychological_state(
        input_data["current_y"],
        input_data["base_y"]
    )
    # 返回: "stable" | "vulnerable" | "aggressive" | "chaotic"
    
    # === 第二步：激活最高优先级本能 ===
    dominant_instinct = get_dominant_instinct(
        input_data["instinct_weights"],
        input_data["scene_context"]
    )
    
    # === 第三步：构建表层动机 ===
    surface_motivation = build_surface_motivation(
        dominant_instinct,
        psychological_state,
        input_data["scene_context"]
    )
    
    # === 第四步：推导深层动机 ===
    deep_motivation = derive_deep_motivation(
        surface_motivation,
        input_data["memory"],
        input_data["motivation_chain"]
    )
    
    # === 第五步：选择行为 ===
    behavior = select_behavior(
        psychological_state,
        surface_motivation,
        deep_motivation,
        input_data["scene_context"]
    )
    
    # === 第六步：生成行为描述 ===
    behavior_text = render_behavior_description(
        behavior,
        psychological_state,
        input_data["name"]
    )
    
    return {
        "psychological_state": psychological_state,
        "dominant_instinct": dominant_instinct,
        "surface_motivation": surface_motivation,
        "deep_motivation": deep_motivation,
        "behavior": behavior_text,
        "action_type": behavior["action_type"]
    }
```

### 3.3 心理状态判定

```python
def determine_psychological_state(current_y: int, base_y: int) -> str:
    """
    根据Y值与基线的差值判定心理状态
    """
    delta = current_y - base_y
    
    if delta >= 15:
        return "aggressive"  # 防御性冲高
    elif delta <= -15:
        return "vulnerable"   # 崩溃性下落
    elif abs(delta) <= 5:
        return "stable"       # 稳定
    else:
        return "chaotic"      # 偏离状态
```

### 3.4 行为类型选择

```python
ACTION_TYPES = {
    "internal": "内心活动（想、感受、回忆）",
    "external": "肢体动作（行为、表情、姿态）",
    "verbal": "语言表达（说话、语气、措辞）",
    "mixed": "综合行为（动作+语言+情绪）"
}

def select_behavior(state: str, surface: str, deep: str, scene: dict) -> dict:
    """
    根据心理状态和动机选择行为类型
    """
    # 基础选择矩阵
    state_action_map = {
        "stable": ["internal", "external", "verbal", "mixed"],
        "vulnerable": ["internal", "verbal"],
        "aggressive": ["external", "verbal"],
        "chaotic": ["mixed"]
    }
    
    candidates = state_action_map.get(state, ["mixed"])
    
    # 根据场景过滤
    if scene["type"] == "singleton":
        # 单人场景：优先internal和external
        candidates = ["internal", "external"]
    elif scene["type"] == "couple":
        # 双人场景：优先verbal和mixed
        candidates = ["verbal", "mixed", "external"]
    
    return {
        "action_type": random.choice(candidates),
        "surface_motivation": surface,
        "deep_motivation": deep
    }
```

## 四、行为验证

```python
def validate_behavior(behavior: dict, profile: dict) -> tuple[bool, str]:
    """
    验证生成的行为是否符合角色本质
    
    验证维度：
    1. MBTI一致性：行为是否与MBTI描述一致？
    2. Y值合理性：当前Y值下是否会产生这种行为？
    3. 记忆一致性：是否与角色记忆矛盾？
    4. 动机链一致性：是否可追溯到动机链？
    5. 冲突检测：是否与场景冲突？
    
    返回: (是否通过, 验证说明)
    """
    checks = []
    
    # 1. MBTI一致性检查
    mbti_check = check_mbti_consistency(
        behavior, profile["mbti"]
    )
    checks.append(("MBTI一致性", mbti_check))
    
    # 2. Y值合理性检查
    y_check = check_y_consistency(
        behavior, profile["current_y"], profile["base_y"]
    )
    checks.append(("Y值合理性", y_check))
    
    # 3. 记忆一致性检查
    memory_check = check_memory_consistency(
        behavior, profile["memory"]
    )
    checks.append(("记忆一致性", memory_check))
    
    # 4. 动机链一致性
    motivation_check = check_motivation_consistency(
        behavior, profile.get("motivation_chain", {})
    )
    checks.append(("动机链一致性", motivation_check))
    
    # 全部通过才算通过
    all_passed = all(result for _, result in checks)
    notes = "; ".join([f"{name}: {'✓' if r else '✗'}" for name, r in checks])
    
    return all_passed, notes

def check_mbti_consistency(behavior: dict, mbti: str) -> bool:
    """MBTI一致性检查"""
    # 简化版：检查行为类型与MBTI的匹配度
    mbti_action_preference = {
        "I": ["internal", "external"],    # 内向型偏内省
        "E": ["verbal", "mixed"],         # 外向型偏表达
        "S": ["external"],                 # 实感型偏具体行为
        "N": ["internal", "verbal"],      # 直觉型偏抽象思考
        "T": ["verbal"],                   # 思考型偏理性表达
        "F": ["internal", "mixed"]         # 情感型偏情感反应
    }
    
    # 如果行为类型与MBTI偏好不冲突，返回True
    return True  # 简化：默认通过，详细实现需结合实际行为内容
```

## 五、冲突处理

```python
def detect_conflicts(chain: list, new_behavior: dict) -> list:
    """
    检测新行为与现有演化链的冲突
    
    冲突类型：
    1. 逻辑冲突：行为A和B在逻辑上矛盾
    2. 时间冲突：行为发生时间重叠
    3. 情绪矛盾：相邻行为情绪跳跃过大（正常人是渐变）
    4. 角色矛盾：与角色设定矛盾
    """
    conflicts = []
    
    if not chain:
        return conflicts
    
    last = chain[-1]
    
    # 情绪跳跃检测（相邻行为情绪差异不能超过2档）
    if abs(new_behavior.get("emotion_level", 5) - last.get("emotion_level", 5)) > 2:
        conflicts.append({
            "type": "emotion_jump",
            "severity": "warning",
            "description": f"情绪跳跃过大：{last.get('emotion_level')} → {new_behavior.get('emotion_level')}"
        })
    
    # 行为重复检测
    for existing in chain[-3:]:  # 检查最近3轮
        if new_behavior.get("behavior") == existing.get("behavior"):
            conflicts.append({
                "type": "duplicate",
                "severity": "info",
                "description": "行为重复，建议生成不同行为"
            })
    
    return conflicts

def resolve_conflict(chain: list, conflict: dict) -> list:
    """
    解决冲突
    
    策略：
    1. 情绪跳跃：插入情绪过渡行为
    2. 行为重复：重新生成行为
    3. 逻辑冲突：回溯修正早期行为
    """
    if conflict["type"] == "emotion_jump":
        # 插入过渡行为
        middle_behavior = generate_transition_behavior(
            chain[-1], chain[-1].get("emotion_level", 5),
            chain[-1].get("emotion_level", 5)
        )
        chain.append(middle_behavior)
    elif conflict["type"] == "duplicate":
        # 标记但保留（有时角色确实会重复动作）
        pass
    
    return chain
```

## 六、完整演化流程

```python
def run_evolution(profile: dict, scene_context: dict, max_rounds: int = 3) -> list:
    """
    运行完整演化流程
    
    流程：
    1. 初始化输入
    2. 循环生成N轮行为
    3. 每轮验证
    4. 检测冲突
    5. 解决冲突
    6. 返回演化链
    """
    chain = []
    input_data = prepare_generation_input(profile, scene_context)
    
    for round_num in range(1, max_rounds + 1):
        # 生成行为
        behavior_data = generate_behavior(input_data)
        
        # 验证
        passed, notes = validate_behavior(behavior_data, profile)
        
        # 构建行为对象
        behavior_obj = {
            "round": round_num,
            "behavior": behavior_data["behavior"],
            "action_type": behavior_data["action_type"],
            "psychological_state": behavior_data["psychological_state"],
            "dominant_instinct": behavior_data["dominant_instinct"],
            "validation_passed": passed,
            "validation_notes": notes
        }
        
        # 检测冲突
        conflicts = detect_conflicts(chain, behavior_obj)
        if conflicts:
            chain = resolve_conflicts(chain, conflicts)
        
        chain.append(behavior_obj)
        
        # 更新输入数据（供下一轮使用）
        input_data["current_y"] = profile["current_y"]
    
    return chain
```

## 七、玩家注入处理

```python
def handle_player_injection(
    chain: list, 
    injection: str, 
    profile: dict
) -> dict:
    """
    处理玩家注入
    
    注入格式：玩家以角色视角写下的想法/行为/对话
    
    处理流程：
    1. 解析注入内容 → 提取"事件"
    2. 计算Y值影响
    3. 更新心理档案
    4. 继续演化
    """
    # 解析注入
    parsed = parse_injection(injection)
    
    # 触发心理引擎处理
    transition_result = execute_y_transition(profile, {
        "type": "player_injection",
        "impact": parsed.get("impact", "moderate"),
        "description": injection
    })
    
    # 更新档案
    profile["current_y"] = transition_result["new_y"]
    
    # 记录到演化链
    injection_record = {
        "type": "player_injection",
        "round": len(chain) + 1,
        "content": injection,
        "parsed": parsed,
        "y_change": transition_result["new_y"],
        "chain_resume_point": len(chain)
    }
    
    return {
        "profile_updated": profile,
        "injection_record": injection_record,
        "suggested_next_action": "continue_evolution"
    }
```
