# 角色卡解析器模块 (parser.py)

## 模块职责

将SillyTavern角色卡（Jinja2格式/JSON格式）解析为标准JSON心理档案。

## 一、支持的角色卡格式

```python
SUPPORTED_FORMATS = {
    "sillytavern_json": "标准SillyTavern JSON格式",
    "sillytavern_jinja2": "SillyTavern Jinja2模板格式（需预处理）",
    "tavernai_json": " TavernAI兼容JSON格式",
    "agnaistic": "Agnaistic格式"
}
```

## 二、解析器核心

```python
def parse_character_card(raw_data: str, format_type: str = "auto") -> dict:
    """
    解析角色卡为标准心理档案
    
    format_type: "auto" | "sillytavern_json" | "sillytavern_jinja2" | "tavernai"
    
    返回: 角色心理档案字典
    """
    
    if format_type == "auto":
        format_type = detect_format(raw_data)
    
    if format_type == "sillytavern_jinja2":
        data = parse_jinja2_card(raw_data)
    elif format_type == "sillytavern_json":
        data = json.loads(raw_data)
    else:
        data = json.loads(raw_data)
    
    # 提取关键字段
    profile = {
        "name": extract_name(data),
        "mbti": extract_mbti(data),
        "description": extract_description(data),
        "personality": extract_personality(data),
        "first_message": extract_first_message(data),
        "avatar": extract_avatar(data),
        "chat_history": extract_chat_history(data)
    }
    
    return profile

def detect_format(raw_data: str) -> str:
    """自动检测角色卡格式"""
    if raw_data.strip().startswith("{{"):
        return "sillytavern_jinja2"
    elif raw_data.strip().startswith("{"):
        return "sillytavern_json"
    else:
        return "unknown"
```

## 三、字段提取函数

```python
def extract_name(data: dict) -> str:
    """提取角色名"""
    return data.get("name", data.get("char_name", "Unknown"))

def extract_mbti(data: dict) -> str:
    """
    提取MBTI类型
    
    策略：
    1. 直接从字段提取（mbti字段）
    2. 从personality描述中推断
    3. 默认推断为INFJ
    """
    
    # 策略1：直接提取
    if "mbti" in data:
        mbti = data["mbti"].upper()
        if is_valid_mbti(mbti):
            return mbti
    
    # 策略2：从personality推断
    if "personality" in data:
        inferred = infer_mbti_from_text(data["personality"])
        if inferred:
            return inferred
    
    # 策略3：默认
    return "INFJ"

def infer_mbti_from_text(text: str) -> str:
    """
    从性格描述文本推断MBTI
    
    推断规则（简化版，基于关键词）：
    """
    text_lower = text.lower()
    
    # E/I 判断
    e_indicators = ["外向", "活泼", "开朗", "社交", "朋友多", "健谈", "热情"]
    i_indicators = ["内向", "安静", "沉默", "独处", "害羞", "冷淡", "不善交际"]
    
    e_score = sum(1 for w in e_indicators if w in text_lower)
    i_score = sum(1 for w in i_indicators if w in text_lower)
    
    ei = "E" if e_score > i_score else "I"
    
    # N/S 判断
    n_indicators = ["直觉", "创意", "想象", "抽象", "理想", "哲学", "未来"]
    s_indicators = ["实际", "务实", "具体", "现实", "现在", "传统", "细节"]
    
    n_score = sum(1 for w in n_indicators if w in text_lower)
    s_score = sum(1 for w in s_indicators if w in text_lower)
    
    ns = "N" if n_score > s_score else "S"
    
    # T/F 判断
    t_indicators = ["理性", "逻辑", "思考", "分析", "公正", "原则", "冷淡"]
    f_indicators = ["感性", "情感", "共情", "感受", "温暖", "关系", "心软"]
    
    t_score = sum(1 for w in t_indicators if w in text_lower)
    f_score = sum(1 for w in f_indicators if w in text_lower)
    
    tf = "T" if t_score > f_score else "F"
    
    # J/P 判断
    j_indicators = ["计划", "条理", "组织", "果断", "决断", "确定", "控制"]
    p_indicators = ["灵活", "适应", "开放", "随意", "好奇", "探索", "变通"]
    
    j_score = sum(1 for w in j_indicators if w in text_lower)
    p_score = sum(1 for w in p_indicators if w in text_lower)
    
    jp = "J" if j_score > p_score else "P"
    
    return ei + ns + tf + jp

def extract_personality(data: dict) -> str:
    """提取性格描述"""
    return data.get("personality", data.get("description", ""))

def extract_description(data: dict) -> str:
    """提取角色描述"""
    return data.get("description", data.get("personality", ""))

def extract_first_message(data: dict) -> str:
    """提取首条消息"""
    return data.get("first_message", data.get("greeting", ""))
```

## 四、心理档案构建

```python
def build_full_profile(card_profile: dict) -> dict:
    """
    将解析后的角色卡数据构建为完整JSON心理档案
    
    包含：
    1. 基础信息（name, mbti, base_y）
    2. 记忆系统（5类记忆）
    3. 演化状态（当前演化链）
    4. 动机链（四层）
    5. 场景状态
    """
    
    # 计算基础Y值（根据MBTI）
    base_y = calculate_base_y_from_mbti(card_profile["mbti"])
    
    profile = {
        # === 基础信息 ===
        "name": card_profile["name"],
        "mbti": card_profile["mbti"],
        "description": card_profile["description"],
        "avatar": card_profile.get("avatar", ""),
        
        # === Y值系统 ===
        "base_y": base_y,
        "y_min": base_y - 5,
        "y_max": base_y + 5,
        "current_y": base_y,
        "trauma_offset": 0,
        
        # === 记忆系统 ===
        "memory": {
            "total": [],
            "normal": {
                "habits": [],
                "routines": []
            },
            "abnormal": [],
            "long_term": [],
            "short_term": []
        },
        
        # === 记忆索引（用于快速查询）===
        "memory_index": {
            "by_emotion": {},
            "by_instinct": {},
            "by_event_type": {}
        },
        
        # === 演化状态 ===
        "evolution_state": {
            "active": False,
            "current_round": 0,
            "max_rounds": 3,
            "chain": [],
            "paused_at": None
        },
        
        # === 动机链 ===
        "motivation_chain": {
            "surface": "",
            "deep": "",
            "core": "",
            "soul": ""
        },
        
        # === 情绪日志 ===
        "emotion_log": [],
        
        # === 场景状态 ===
        "scene_state": {
            "type": "couple",
            "location": "",
            "time": "",
            "other_characters": []
        },
        
        # === 事件日志 ===
        "event_log": []
    }
    
    # 从描述中提取记忆
    if card_profile["description"]:
        extract_memories_from_description(profile, card_profile["description"])
    
    # 从首条消息中提取
    if card_profile.get("first_message"):
        extract_memories_from_text(profile, card_profile["first_message"])
    
    return profile

def calculate_base_y_from_mbti(mbti: str) -> int:
    """
    根据MBTI计算基础Y值
    
    规则：
    - T/J型 → Y偏高（理性、意志坚定）
    - F/P型 → Y偏低（感性、易受影响）
    - 混合类型取中间值
    """
    base_map = {
        "INTJ": 65, "INTP": 60, "ENTJ": 70, "ENTP": 65,
        "INFJ": 55, "INFP": 50, "ENFJ": 60, "ENFP": 55,
        "ISTJ": 60, "ISFJ": 55, "ESTJ": 65, "ESFJ": 55,
        "ISTP": 55, "ISFP": 50, "ESTP": 60, "ESFP": 55
    }
    
    return base_map.get(mbti, 55)

def extract_memories_from_description(profile: dict, text: str):
    """从角色描述中提取记忆"""
    # 检测创伤关键词
    trauma_keywords = ["曾经", "过去", "经历", "失去", "创伤", "痛苦", "失败"]
    for keyword in trauma_keywords:
        if keyword in text:
            # 简化为一条异常记忆
            profile["memory"]["abnormal"].append({
                "type": "character_background",
                "content": text[:200],
                "source": "description"
            })
            break

def extract_memories_from_text(profile: dict, text: str):
    """从文本中提取记忆"""
    # 类似实现
    pass
```

## 五、档案持久化

```python
import json
import os

def save_profile(profile: dict, save_dir: str = "./profiles"):
    """保存心理档案到文件"""
    os.makedirs(save_dir, exist_ok=True)
    filename = f"{profile['name']}_profile.json"
    filepath = os.path.join(save_dir, filename)
    
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    
    return filepath

def load_profile(name: str, save_dir: str = "./profiles") -> dict:
    """加载心理档案"""
    filename = f"{name}_profile.json"
    filepath = os.path.join(save_dir, filename)
    
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)
```
