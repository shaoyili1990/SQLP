# 演化追踪器模块 (tracker.py)

## 模块职责

管理演化链的状态持久化，支持：
1. 演化链记录与回溯
2. 状态快照保存
3. 演化历史查询
4. 分支管理

## 一、追踪器核心

```python
import json
import os
from datetime import datetime

class EvolutionTracker:
    """演化追踪器"""
    
    def __init__(self, save_dir: str = "./evolution_history"):
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)
        self.sessions = {}
    
    def start_session(self, session_id: str, initial_profile: dict) -> dict:
        """启动新的演化会话"""
        session = {
            "session_id": session_id,
            "started_at": datetime.now().isoformat(),
            "profile_snapshot": json.loads(json.dumps(initial_profile)),
            "chains": [],  # 演化链记录
            "injections": [],  # 注入记录
            "y_transitions": [],  # Y值跃迁记录
            "status": "active",
            "rounds_completed": 0,
            "branch_count": 1,
            "current_branch": 0
        }
        self.sessions[session_id] = session
        return session
    
    def record_round(
        self,
        session_id: str,
        round_num: int,
        behavior: dict,
        y_value: int
    ):
        """记录一轮演化"""
        session = self.sessions.get(session_id)
        if not session:
            return
        
        record = {
            "round": round_num,
            "timestamp": datetime.now().isoformat(),
            "behavior": behavior,
            "y_value": y_value,
            "branch": session["current_branch"]
        }
        session["chains"].append(record)
        session["rounds_completed"] += 1
    
    def record_injection(
        self,
        session_id: str,
        injection: str,
        parsed: dict,
        fusion_result: dict
    ):
        """记录玩家注入"""
        session = self.sessions.get(session_id)
        if not session:
            return
        
        record = {
            "timestamp": datetime.now().isoformat(),
            "injection": injection,
            "parsed": parsed,
            "fusion_result": fusion_result,
            "branch": session["current_branch"],
            "round_at_injection": session["rounds_completed"]
        }
        session["injections"].append(record)
    
    def record_y_transition(
        self,
        session_id: str,
        from_y: int,
        to_y: int,
        mechanism: str,
        trigger: str
    ):
        """记录Y值跃迁"""
        session = self.sessions.get(session_id)
        if not session:
            return
        
        record = {
            "timestamp": datetime.now().isoformat(),
            "from_y": from_y,
            "to_y": to_y,
            "mechanism": mechanism,
            "trigger": trigger,
            "branch": session["current_branch"]
        }
        session["y_transitions"].append(record)
    
    def pause_session(self, session_id: str):
        """暂停会话"""
        session = self.sessions.get(session_id)
        if session:
            session["status"] = "paused"
            session["paused_at"] = datetime.now().isoformat()
    
    def resume_session(self, session_id: str):
        """恢复会话"""
        session = self.sessions.get(session_id)
        if session:
            session["status"] = "active"
            session["resumed_at"] = datetime.now().isoformat()
    
    def create_branch(self, session_id: str, branch_point: int) -> int:
        """
        创建分支（用于玩家注入后产生分支的情况）
        
        返回新分支ID
        """
        session = self.sessions.get(session_id)
        if not session:
            return -1
        
        # 深拷贝当前状态到新分支
        new_branch = session["current_branch"] + 1
        session["branch_count"] += 1
        session["current_branch"] = new_branch
        
        # 记录分支点
        if "branches" not in session:
            session["branches"] = {}
        
        session["branches"][new_branch] = {
            "branch_id": new_branch,
            "branched_from": branch_point,
            "created_at": datetime.now().isoformat(),
            "chains_copy": json.loads(json.dumps(session["chains"]))
        }
        
        return new_branch
    
    def get_session_summary(self, session_id: str) -> dict:
        """获取会话摘要"""
        session = self.sessions.get(session_id)
        if not session:
            return {}
        
        return {
            "session_id": session_id,
            "status": session["status"],
            "started_at": session["started_at"],
            "rounds_completed": session["rounds_completed"],
            "injection_count": len(session["injections"]),
            "y_transition_count": len(session["y_transitions"]),
            "branches": session["branch_count"],
            "current_branch": session["current_branch"],
            "current_y": session["chains"][-1]["y_value"] if session["chains"] else None
        }
    
    def save_session(self, session_id: str):
        """保存会话到文件"""
        session = self.sessions.get(session_id)
        if not session:
            return
        
        filepath = os.path.join(self.save_dir, f"{session_id}.json")
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(session, f, ensure_ascii=False, indent=2)
    
    def load_session(self, session_id: str) -> dict:
        """从文件加载会话"""
        filepath = os.path.join(self.save_dir, f"{session_id}.json")
        if not os.path.exists(filepath):
            return None
        
        with open(filepath, "r", encoding="utf-8") as f:
            session = json.load(f)
            self.sessions[session_id] = session
            return session
    
    def get_full_chain(self, session_id: str, branch: int = None) -> list:
        """获取完整演化链"""
        session = self.sessions.get(session_id)
        if not session:
            return []
        
        if branch is None:
            branch = session["current_branch"]
        
        if "branches" in session and branch in session["branches"]:
            return session["branches"][branch]["chains_copy"]
        
        return [r for r in session["chains"] if r["branch"] == branch]
```

## 二、状态快照

```python
    def create_snapshot(self, session_id: str, snapshot_name: str = None) -> str:
        """创建当前状态快照"""
        session = self.sessions.get(session_id)
        if not session:
            return ""
        
        snapshot_id = snapshot_name or f"snapshot_{len(session.get('snapshots', []))}"
        
        if "snapshots" not in session:
            session["snapshots"] = {}
        
        snapshot = {
            "snapshot_id": snapshot_id,
            "timestamp": datetime.now().isoformat(),
            "rounds_completed": session["rounds_completed"],
            "current_y": session["chains"][-1]["y_value"] if session["chains"] else None,
            "profile_snapshot": json.loads(json.dumps(session["profile_snapshot"])),
            "chain_length": len(session["chains"])
        }
        
        session["snapshots"][snapshot_id] = snapshot
        return snapshot_id
    
    def restore_snapshot(self, session_id: str, snapshot_id: str):
        """恢复到指定快照"""
        session = self.sessions.get(session_id)
        if not session or "snapshots" not in session:
            return
        
        snapshot = session["snapshots"].get(snapshot_id)
        if not snapshot:
            return
        
        # 截断chains到快照长度
        session["chains"] = [
            r for r in session["chains"]
            if r["round"] <= snapshot["rounds_completed"]
        ]
        session["rounds_completed"] = snapshot["rounds_completed"]
```

## 三、历史查询

```python
    def query_by_emotion(self, session_id: str, emotion: str) -> list:
        """查询包含特定情绪的演化记录"""
        session = self.sessions.get(session_id)
        if not session:
            return []
        
        results = []
        for record in session["chains"]:
            behavior = record.get("behavior", {})
            if behavior.get("emotion_tags") and emotion in behavior["emotion_tags"]:
                results.append(record)
        
        return results
    
    def query_y_transitions(self, session_id: str) -> list:
        """查询所有Y值跃迁"""
        session = self.sessions.get(session_id)
        if not session:
            return []
        return session.get("y_transitions", [])
    
    def export_as_markdown(self, session_id: str) -> str:
        """导出为Markdown格式"""
        session = self.sessions.get(session_id)
        if not session:
            return ""
        
        md = f"# 演化会话报告\n\n"
        md += f"**会话ID**: {session_id}\n"
        md += f"**状态**: {session['status']}\n"
        md += f"**开始时间**: {session['started_at']}\n"
        md += f"**完成轮次**: {session['rounds_completed']}\n"
        md += f"**当前Y值**: {session['chains'][-1]['y_value'] if session['chains'] else 'N/A'}\n\n"
        
        md += "## 演化链\n\n"
        for record in session["chains"]:
            md += f"### 轮次 {record['round']}\n"
            md += f"Y值: {record['y_value']}\n"
            md += f"行为: {record['behavior'].get('behavior', '')}\n\n"
        
        if session.get("injections"):
            md += "## 玩家注入\n\n"
            for inj in session["injections"]:
                md += f"- **{inj['timestamp']}**: {inj['injection']}\n"
        
        return md
```
