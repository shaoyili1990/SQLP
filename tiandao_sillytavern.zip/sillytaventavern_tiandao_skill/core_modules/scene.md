# 场景适配器模块 (scene.py)

## 模块职责

处理不同场景类型下的演化逻辑：
- **单人场景 (singleton)**: 角色独处，演化以内省为主
- **双人场景 (couple)**: 两角色互动，需要处理人际气场
- **群像场景 (group)**: 多角色共存，辐射影响+暴走化

## 一、场景类型定义

```python
SCENE_TYPES = {
    "singleton": {
        "description": "单人独处场景",
        "behavior_bias": ["internal", "external"],
        "interaction_needed": False,
        "evolution_focus": "内心独白、自我对话、回忆片段"
    },
    "couple": {
        "description": "双人互动场景",
        "behavior_bias": ["verbal", "mixed", "external"],
        "interaction_needed": True,
        "evolution_focus": "对话张力、肢体语言、情绪共振/对撞"
    },
    "group": {
        "description": "群像多角色场景",
        "behavior_bias": ["verbal", "mixed", "external"],
        "interaction_needed": True,
        "evolution_focus": "角色辐射、群像暴走、信息差博弈"
    }
}
```

## 二、场景管理器

```python
class SceneManager:
    """场景管理器"""
    
    def __init__(self):
        self.scenes = {}  # scene_id -> SceneState
        self.active_scene = None
        
    def create_scene(self, scene_id: str, scene_type: str, characters: list) -> dict:
        """
        创建场景
        """
        scene = {
            "scene_id": scene_id,
            "type": scene_type,
            "characters": characters,  # 角色名列表
            "character_profiles": {},  # name -> profile
            "evolution_states": {},     # name -> evolution_state
            "interaction_matrix": {},   # (char_a, char_b) -> relationship_state
            "events": [],              # 场景事件序列
            "status": "active"
        }
        self.scenes[scene_id] = scene
        self.active_scene = scene_id
        return scene
    
    def add_character_to_scene(self, scene_id: str, char_name: str, profile: dict):
        """添加角色到场景"""
        scene = self.scenes[scene_id]
        if char_name not in scene["characters"]:
            scene["characters"].append(char_name)
        scene["character_profiles"][char_name] = profile
        scene["evolution_states"][char_name] = {
            "active": False,
            "chain": []
        }
    
    def remove_character_from_scene(self, scene_id: str, char_name: str):
        """从场景移除角色"""
        scene = self.scenes[scene_id]
        scene["characters"].remove(char_name)
        del scene["character_profiles"][char_name]
        del scene["evolution_states"][char_name]
```

## 三、单人场景演化

```python
def evolve_singleton(char_profile: dict, scene_context: dict) -> list:
    """
    单人场景演化
    
    特点：
    - 行为以内省为主（回忆、思考、情绪波动）
    - 外部动作有限（独处时的小动作）
    - 可触发内心独白
    """
    
    chain = []
    
    # 确定当前心理状态
    state = determine_psychological_state(
        char_profile["current_y"],
        char_profile["base_y"]
    )
    
    # 单人场景行为选择
    if state == "stable":
        # 稳定状态：日常行为、回忆、思绪飘散
        behaviors = [
            generate_internal_monologue(char_profile),
            generate_habitual_action(char_profile),
            generate_memory_recall(char_profile)
        ]
    elif state == "vulnerable":
        # 脆弱状态：自我怀疑、回忆创伤、情绪低落
        behaviors = [
            generate_self_doubt(char_profile),
            generate_trauma_recall(char_profile),
            generate_defensive_action(char_profile)
        ]
    elif state == "aggressive":
        # 冲高状态：自言自语计划、思考如何行动
        behaviors = [
            generate_determined_thought(char_profile),
            generate_planning_action(char_profile),
            generate_frustration_action(char_profile)
        ]
    else:
        # 混乱状态：思绪混乱、行为无序
        behaviors = [
            generate_chaotic_thought(char_profile),
            generate_restless_action(char_profile),
            generate_ambiguous_emotion(char_profile)
        ]
    
    for i, behavior in enumerate(behaviors):
        chain.append({
            "round": i + 1,
            "scene_type": "singleton",
            "behavior": behavior,
            "action_type": "internal" if i < 2 else "external"
        })
    
    return chain

def generate_internal_monologue(profile: dict) -> str:
    """生成内心独白"""
    name = profile["name"]
    mbti = profile["mbti"]
    
    templates = {
        "INTJ": [
            f"{name}的视线落在远处，脑海里飞速运转着各种可能性。",
            f"即使在这个独处的时刻，{name}的思维也没有停止计算。",
            f"没有人看见，但{name}的嘴角微微上扬——又一个计划成形了。"
        ],
        "INFP": [
            f"{name}轻轻叹了口气，手指无意识地摩挲着某样东西。",
            f"房间里很安静，{name}任由思绪飘向那些遥远的、柔软的角落。",
            f"即使一个人，{name}的内心也有一整个世界在运转。"
        ],
        "default": [
            f"只有自己的呼吸声。{name}在这片刻的寂静中与自己相处。",
            f"独处的时光，{name}任由思绪流淌。",
            f"没有观众的时候，{name}才会有这样的表情。"
        ]
    }
    
    import random
    pool = templates.get(mbti, templates["default"])
    return random.choice(pool)
```

## 四、双人场景演化

```python
def evolve_couple(
    char_a_profile: dict,
    char_b_profile: dict,
    scene_context: dict
) -> dict:
    """
    双人场景演化
    
    特点：
    - 处理Y值差（ΔY）对行为的影响
    - 检测击穿可能性
    - 双方行为需要联动
    - 对话张力与肢体语言
    """
    
    # 计算ΔY
    delta_y = char_b_profile["current_y"] - char_a_profile["current_y"]
    
    # 检测击穿
    threshold = get_breakthrough_threshold(char_a_profile["current_y"])
    breakthrough_triggered = delta_y >= threshold
    
    # 分别生成演化链
    chain_a = []
    chain_b = []
    
    # 基础行为生成
    for round_num in range(1, 4):
        # A的行为
        behavior_a = generate_couple_behavior(
            char_a_profile, char_b_profile, delta_y, round_num
        )
        chain_a.append(behavior_a)
        
        # B的行为（受A影响）
        behavior_b = generate_couple_behavior(
            char_b_profile, char_a_profile, -delta_y, round_num
        )
        chain_b.append(behavior_b)
        
        # 如果击穿，插入击穿反应
        if breakthrough_triggered and round_num == 1:
            chain_a.append({
                "round": "1.5",
                "type": "breakthrough_reaction",
                "behavior": generate_breakthrough_reaction(char_a_profile),
                "y_change": "triggered"
            })
    
    return {
        "character_a": {
            "name": char_a_profile["name"],
            "chain": chain_a
        },
        "character_b": {
            "name": char_b_profile["name"],
            "chain": chain_b
        },
        "delta_y": delta_y,
        "breakthrough": breakthrough_triggered,
        "interaction_tension": calculate_interaction_tension(delta_y)
    }

def generate_couple_behavior(
    self_profile: dict,
    other_profile: dict,
    delta_y: int,
    round_num: int
) -> dict:
    """生成双人场景中的角色行为"""
    
    name = self_profile["name"]
    other_name = other_profile["name"]
    
    # 根据ΔY确定行为倾向
    if delta_y > 20:
        # 我方Y远高于对方 → 主动、引导
        behavior_text = f"{name}的视线落在{other_name}身上，带着某种笃定。"
    elif delta_y < -20:
        # 我方Y远低于对方 → 被动、受压
        behavior_text = f"{name}下意识地避开{other_name}的目光。"
    else:
        # 势均力敌 → 对等互动
        behavior_text = f"{name}与{other_name}之间流动着某种难以言说的张力。"
    
    return {
        "round": round_num,
        "behavior": behavior_text,
        "action_type": "mixed",
        "delta_y_at_moment": delta_y
    }
```

## 五、群像场景演化

```python
def evolve_group(
    character_profiles: dict,
    scene_context: dict
) -> dict:
    """
    群像场景演化
    
    核心原则（来自天道系统）：
    1. 主要角色为中心进行辐射
    2. 被影响角色根据其内在逻辑自行调整行为
    3. 群像暴走化：每个角色都可能产生超出预期的行为
    4. 信息差博弈
    """
    
    # 排序角色（按Y值降序，找中心角色）
    sorted_chars = sorted(
        character_profiles.items(),
        key=lambda x: x[1]["current_y"],
        reverse=True
    )
    
    center_char = sorted_chars[0]  # Y值最高的角色
    peripheral_chars = sorted_chars[1:]
    
    all_chains = {}
    
    # 中心角色演化
    all_chains[center_char[0]] = evolve_as_center(
        center_char[1], peripheral_chars
    )
    
    # 周边角色演化（受中心角色辐射影响）
    for char_name, char_profile in peripheral_chars:
        # 计算与中心角色的ΔY
        delta_y = center_char[1]["current_y"] - char_profile["current_y"]
        
        # 判定辐射效果
        if delta_y >= get_breakthrough_threshold(char_profile["current_y"]):
            # 被辐射击穿 → 暴走化
            all_chains[char_name] = evolve_as_radiated(
                char_profile, center_char, delta_y, mode="breakthrough"
            )
        else:
            # 正常辐射
            all_chains[char_name] = evolve_as_radiated(
                char_profile, center_char, delta_y, mode="normal"
            )
    
    return {
        "center_character": center_char[0],
        "all_chains": all_chains,
        "radiation_effects": calculate_radiation_effects(
            center_char, peripheral_chars
        ),
        "emergent_behaviors": detect_emergent_behaviors(all_chains)
    }

def detect_emergent_behaviors(all_chains: dict) -> list:
    """
    检测群像暴走产生的"涌现行为"
    
    涌现行为：非中心角色自发产生的、不在预期内的行为
    来自角色内在逻辑的"超脱性"
    """
    
    emergent = []
    
    for char_name, chain in all_chains.items():
        for behavior in chain:
            if behavior.get("is_emergent"):
                emergent.append({
                    "character": char_name,
                    "behavior": behavior["behavior"],
                    "reason": behavior.get("emergent_reason", "")
                })
    
    return emergent
```
