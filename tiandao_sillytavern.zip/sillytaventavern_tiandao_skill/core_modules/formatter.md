# 输出格式化器模块 (formatter.py)

## 模块职责

将演化结果转换为SillyTavern可读的格式，并提供多种输出模式。

## 一、输出模式

```python
OUTPUT_MODES = {
    "narrative": {
        "description": "叙事模式：将演化行为以叙述文本输出",
        "format": "纯文本叙述，可直接作为角色回复或场景描述",
        "use_case": "单人/群像场景的内心描述"
    },
    "dialogue": {
        "description": "对话模式：将演化行为以对话格式输出",
        "format": "角色名 + 对话内容",
        "use_case": "双人/群像场景的对话"
    },
    "mixed": {
        "description": "混合模式：叙述+对话混合输出",
        "format": "动作描述 + 对话内容交替",
        "use_case": "一般场景的默认输出"
    },
    "internal": {
        "description": "内心模式：仅输出内心活动",
        "format": "第一人称内心独白",
        "use_case": "SillyTavern的'思考'功能"
    },
    "minimal": {
        "description": "极简模式：仅输出关键行为片段",
        "format": "简短行为描述",
        "use_case": "快速推进剧情"
    }
}
```

## 二、格式化器核心

```python
class EvolutionFormatter:
    """演化结果格式化器"""
    
    def __init__(self, default_mode: str = "mixed"):
        self.default_mode = default_mode
    
    def format_chain(
        self,
        chain: list,
        profile: dict,
        mode: str = None,
        include_metadata: bool = False
    ) -> str:
        """
        格式化演化链为可读文本
        
        mode: "narrative" | "dialogue" | "mixed" | "internal" | "minimal"
        """
        
        mode = mode or self.default_mode
        
        if mode == "narrative":
            return self._format_narrative(chain, profile, include_metadata)
        elif mode == "dialogue":
            return self._format_dialogue(chain, profile, include_metadata)
        elif mode == "mixed":
            return self._format_mixed(chain, profile, include_metadata)
        elif mode == "internal":
            return self._format_internal(chain, profile, include_metadata)
        elif mode == "minimal":
            return self._format_minimal(chain, profile)
        else:
            return self._format_mixed(chain, profile, include_metadata)
    
    def _format_narrative(self, chain: list, profile: dict, include_metadata: bool) -> str:
        """叙事模式格式化"""
        name = profile["name"]
        lines = []
        
        for item in chain:
            behavior = item.get("behavior", "")
            round_num = item.get("round", "?")
            
            # 构建叙述文本
            if include_metadata:
                lines.append(f"[Round {round_num}] {behavior}")
            else:
                lines.append(behavior)
        
        return "\n".join(lines)
    
    def _format_dialogue(self, chain: list, profile: dict, include_metadata: bool) -> str:
        """对话模式格式化"""
        name = profile["name"]
        lines = []
        
        for item in chain:
            behavior = item.get("behavior", "")
            action_type = item.get("action_type", "mixed")
            
            if action_type in ["verbal", "mixed"]:
                # 对话内容
                if include_metadata:
                    lines.append(f"{name}: {behavior}")
                else:
                    lines.append(f"「{behavior}」")
            elif include_metadata:
                lines.append(f"[{action_type}] {behavior}")
            else:
                lines.append(behavior)
        
        return "\n".join(lines)
    
    def _format_mixed(self, chain: list, profile: dict, include_metadata: bool) -> str:
        """混合模式格式化"""
        name = profile["name"]
        lines = []
        
        for item in chain:
            behavior = item.get("behavior", "")
            action_type = item.get("action_type", "mixed")
            
            if action_type == "internal":
                prefix = f"*{name}的内心：*"
            elif action_type == "verbal":
                prefix = f"*{name}说：*"
            elif action_type == "external":
                prefix = f"*{name}*"
            else:
                prefix = f"*{name}*"
            
            if include_metadata:
                lines.append(f"[{action_type}] {prefix}{behavior}")
            else:
                lines.append(f"{prefix}{behavior}")
        
        return "\n".join(lines)
    
    def _format_internal(self, chain: list, profile: dict, include_metadata: bool) -> str:
        """内心模式格式化"""
        name = profile["name"]
        lines = []
        
        for item in chain:
            if item.get("action_type") == "internal":
                behavior = item.get("behavior", "")
                lines.append(f"({behavior})")
        
        return "\n".join(lines) if lines else ""
    
    def _format_minimal(self, chain: list, profile: dict) -> str:
        """极简模式格式化"""
        if not chain:
            return ""
        
        # 只输出最后一个行为
        last = chain[-1]
        return last.get("behavior", "")
    
    def format_group_scene(
        self,
        group_result: dict,
        profiles: dict,
        mode: str = "mixed"
    ) -> str:
        """
        格式化群像场景演化结果
        
        格式：每个角色的行为分段展示
        """
        
        output = []
        center_char = group_result["center_character"]
        all_chains = group_result["all_chains"]
        
        output.append(f"【场景：{center_char}为中心的群像】\n")
        
        for char_name, chain in all_chains.items():
            profile = profiles.get(char_name, {})
            output.append(f"--- {char_name} ---")
            
            for item in chain:
                action_type = item.get("action_type", "mixed")
                behavior = item.get("behavior", "")
                output.append(f"  {behavior}")
            
            output.append("")
        
        return "\n".join(output)
    
    def format_injection_response(
        self,
        injection: str,
        fusion_result: dict,
        profile: dict
    ) -> str:
        """
        格式化玩家注入后的系统响应
        """
        
        fusion_notes = fusion_result.get("fusion_notes", "")
        chain_modification = fusion_result.get("chain_modification", "")
        
        output = []
        output.append(f"【系统】已接收玩家注入")
        output.append(f"注入内容：{injection}")
        output.append(f"融合结果：{fusion_notes}")
        output.append(f"演化链修改：{chain_modification}")
        output.append(f"当前Y值：{profile['current_y']}")
        
        return "\n".join(output)
    
    def format_session_summary(self, summary: dict) -> str:
        """格式化会话摘要"""
        
        lines = [
            "【演化会话状态】",
            f"会话ID: {summary.get('session_id', 'N/A')}",
            f"状态: {summary.get('status', 'N/A')}",
            f"完成轮次: {summary.get('rounds_completed', 0)}",
            f"注入次数: {summary.get('injection_count', 0)}",
            f"Y值跃迁次数: {summary.get('y_transition_count', 0)}",
            f"分支数: {summary.get('branches', 1)}",
            f"当前分支: {summary.get('current_branch', 0)}",
            f"当前Y值: {summary.get('current_y', 'N/A')}"
        ]
        
        return "\n".join(lines)
```

## 三、SillyTavern集成输出

```python
    def to_sillytavern_format(
        self,
        chain: list,
        profile: dict,
        as_thought: bool = False
    ) -> str:
        """
        转换为SillyTavern可读格式
        
        as_thought: True = 输出为角色内心想法（*包裹）
                    False = 输出为角色对话/行为
        """
        
        if as_thought:
            # 内心想法格式
            return self._format_internal(chain, profile, include_metadata=False)
        else:
            # 标准行为格式
            return self._format_mixed(chain, profile, include_metadata=False)
    
    def to_slash_command(self, chain: list, profile: dict) -> str:
        """
        生成SillyTavern可用的/命令响应格式
        """
        
        output = []
        for item in chain:
            output.append(item.get("behavior", ""))
        
        return "/".join(output)
```
