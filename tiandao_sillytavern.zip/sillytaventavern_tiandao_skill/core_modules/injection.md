# 注入融合器核心模块 (injection.py)

## 模块职责

处理玩家在演化过程中注入的想法，实现"暂停-融合-继续"的循环。

## 一、注入类型分类

```python
INJECTION_TYPES = {
    # 强注入：直接改变角色状态或剧情走向
    "strong": {
        "description": "玩家直接写明角色的行为/对话/决定",
        "impact": "high",
        "handling": "完全采纳，强制覆盖当前演化链预期"
    },
    
    # 中注入：提供新信息或触发事件
    "medium": {
        "description": "玩家提供新的场景信息、背景揭露、关系变化",
        "impact": "moderate",
        "handling": "将信息注入心理档案，触发相应心理反应"
    },
    
    # 弱注入：提供想法/感受但不改变行为
    "weak": {
        "description": "玩家以角色视角描写内心想法、情绪波动",
        "impact": "low",
        "handling": "更新情绪状态，但保持行为演化链不变"
    }
}
```

## 二、注入解析器

```python
def parse_injection(raw_injection: str, character_name: str) -> dict:
    """
    解析玩家注入内容
    
    目标：从玩家文本中提取：
    1. 注入类型（strong/medium/weak）
    2. 行为内容（action_description）
    3. 情绪标签（emotion_tags）
    4. 涉及的本能（instincts）
    5. 建议的Y值影响（y_impact）
    
    返回: {
        "type": str,
        "action_description": str,
        "emotion_tags": [str],
        "instincts": [str],
        "y_impact": str,  # "high" | "moderate" | "low"
        "confidence": float  # 解析置信度
    }
    """
    
    result = {
        "type": "weak",
        "action_description": raw_injection,
        "emotion_tags": [],
        "instincts": [],
        "y_impact": "low",
        "confidence": 0.5
    }
    
    # === 检测强注入信号 ===
    strong_signals = [
        "我决定", "我选择", "我要", "我会", "我立刻",
        "他/她", "转身", "开口说", "拿出", "站起来"
    ]
    
    # === 检测中注入信号 ===
    medium_signals = [
        "突然", "原来", "发现", "得知", "原来如此",
        "原来", "原来如此", "想起来", "记起"
    ]
    
    # === 情绪关键词映射 ===
    emotion_keywords = {
        "愤怒": ["愤怒", "生气", "火", "怒"],
        "悲伤": ["悲伤", "难过", "哭", "痛"],
        "恐惧": ["害怕", "恐惧", "发抖", "寒"],
        "惊讶": ["惊讶", "震惊", "愣", "呆"],
        "喜悦": ["开心", "高兴", "笑", "快乐"],
        "愧疚": ["愧疚", "自责", "对不起", "后悔"],
        "思虑": ["思考", "想", "纠结", "犹豫"]
    }
    
    # === 本能关键词映射 ===
    instinct_keywords = {
        "求存": ["活", "安全", "保护", "逃跑", "危险"],
        "求知": ["为什么", "真相", "知道", "好奇"],
        "表现": ["展示", "证明", "告诉", "表现"],
        "舒适": ["休息", "放松", "舒服", "想走"],
        "情欲": ["想见", "想念", "爱", "在意", "心"],
        "表达": ["说", "告诉", "解释", "倾诉"],
        "母性": ["保护", "照顾", "不让", "担忧"]
    }
    
    # 检测类型
    strong_count = sum(1 for s in strong_signals if s in raw_injection)
    medium_count = sum(1 for s in medium_signals if s in raw_injection)
    
    if strong_count >= 2:
        result["type"] = "strong"
        result["y_impact"] = "high"
        result["confidence"] = 0.9
    elif medium_count >= 1 or strong_count >= 1:
        result["type"] = "medium"
        result["y_impact"] = "moderate"
        result["confidence"] = 0.7
    else:
        result["type"] = "weak"
        result["y_impact"] = "low"
        result["confidence"] = 0.5
    
    # 提取情绪标签
    for emotion, keywords in emotion_keywords.items():
        if any(kw in raw_injection for kw in keywords):
            result["emotion_tags"].append(emotion)
    
    # 提取本能
    for instinct, keywords in instinct_keywords.items():
        if any(kw in raw_injection for kw in keywords):
            result["instincts"].append(instinct)
    
    return result
```

## 三、融合算法

```python
def fuse_injection(
    profile: dict,
    parsed_injection: dict,
    current_chain: list,
    evolution_state: dict
) -> dict:
    """
    将玩家注入融合到当前演化状态
    
    融合策略：
    1. Strong注入 → 重置演化链，从注入点继续
    2. Medium注入 → 中断当前行为，在注入点触发心理反应
    3. Weak注入 → 追加到当前行为，不打断演化
    
    返回: {
        "new_profile": dict,
        "chain_modification": str,
        "fusion_notes": str,
        "continue_from": int  # 从第几轮继续
    }
    """
    
    inj_type = parsed_injection["type"]
    chain_len = len(current_chain)
    
    # === 强注入处理 ===
    if inj_type == "strong":
        # 完全采纳玩家内容
        # 重置演化链，以注入内容为起点
        
        # 记录注入前的状态
        pre_injection_state = {
            "chain_snapshot": current_chain.copy(),
            "y_before": profile["current_y"]
        }
        
        # 应用Y值影响
        profile["current_y"] = apply_injection_y_change(
            profile["current_y"],
            parsed_injection["y_impact"]
        )
        
        # 将注入内容作为新的"第0轮"
        new_chain = [{
            "type": "player_strong_injection",
            "round": 0,
            "content": parsed_injection["action_description"],
            "emotion_tags": parsed_injection["emotion_tags"],
            "y_after": profile["current_y"]
        }]
        
        return {
            "new_profile": profile,
            "chain_modification": "reset",
            "fusion_notes": f"强注入采纳，直接以玩家内容为新起点",
            "continue_from": 1,
            "pre_injection_state": pre_injection_state
        }
    
    # === 中注入处理 ===
    elif inj_type == "medium":
        # 中断当前演化，融合新信息
        
        # 触发心理反应
        profile["current_y"] = apply_injection_y_change(
            profile["current_y"],
            parsed_injection["y_impact"]
        )
        
        # 在当前轮次插入新内容
        current_chain.append({
            "type": "player_medium_injection",
            "round": chain_len + 1,
            "content": parsed_injection["action_description"],
            "emotion_tags": parsed_injection["emotion_tags"],
            "is_milestone": True  # 标记为里程碑
        })
        
        # 添加异常记忆
        add_abnormal_memory(profile, parsed_injection["action_description"])
        
        return {
            "new_profile": profile,
            "chain_modification": "interrupt",
            "fusion_notes": f"中注入融合，触发心理反应，演化中断",
            "continue_from": chain_len + 1
        }
    
    # === 弱注入处理 ===
    else:
        # 仅更新情绪状态，不打断演化
        
        # 更新情绪记录
        if "emotion_log" not in profile:
            profile["emotion_log"] = []
        
        profile["emotion_log"].append({
            "content": parsed_injection["action_description"],
            "emotion_tags": parsed_injection["emotion_tags"],
            "timestamp": evolution_state.get("current_round", 0)
        })
        
        return {
            "new_profile": profile,
            "chain_modification": "append",
            "fusion_notes": f"弱注入追加，不打断演化链",
            "continue_from": chain_len
        }
```

## 四、冲突检测与解决

```python
def check_injection_conflict(
    parsed_injection: dict,
    current_chain: list,
    profile: dict
) -> dict:
    """
    检测玩家注入与当前演化链的冲突
    
    冲突类型：
    1. 方向冲突：玩家注入的方向与演化链预期方向相反
    2. 情绪跳跃：注入的情绪与当前情绪差异过大
    3. 能力越界：玩家让角色做了角色"不会"的事
    """
    
    conflicts = []
    
    if not current_chain:
        return {"has_conflict": False, "conflicts": []}
    
    last_behavior = current_chain[-1]
    
    # === 方向冲突检测 ===
    if parsed_injection["type"] == "strong":
        # 强注入通常不冲突（玩家说了算）
        pass
    
    # === 情绪跳跃检测 ===
    if parsed_injection["emotion_tags"] and last_behavior.get("emotion_tags"):
        last_emotions = set(last_behavior["emotion_tags"])
        new_emotions = set(parsed_injection["emotion_tags"])
        
        # 定义对立情绪对
        opposing_pairs = [
            {"喜悦", "悲伤"},
            {"愤怒", "恐惧"},
            {"愤怒", "愧疚"}
        ]
        
        for pair in opposing_pairs:
            if pair.issubset(last_emotions | new_emotions):
                # 存在对立情绪但无过渡
                conflicts.append({
                    "type": "emotion_jump",
                    "severity": "warning",
                    "description": f"情绪从{last_emotions}直接跳到{new_emotions}，可能需要过渡"
                })
    
    # === 能力越界检测（简化版）===
    # 实际实现需要角色能力列表
    # 这里只做关键词检测
    forbidden_actions = ["突然失忆", "瞬间消失", "原地复活"]
    for action in forbidden_actions:
        if action in parsed_injection["action_description"]:
            conflicts.append({
                "type": "capability_violation",
                "severity": "error",
                "description": f"行为'{action}'超出角色能力范围"
            })
    
    return {
        "has_conflict": len([c for c in conflicts if c["severity"] == "error"]) > 0,
        "conflicts": conflicts
    }

def suggest_resolution(conflict: dict) -> str:
    """给出冲突解决建议"""
    if conflict["type"] == "emotion_jump":
        return "建议在演化链中插入情绪过渡行为"
    elif conflict["type"] == "direction_conflict":
        return "建议玩家明确是替换还是叠加当前演化方向"
    elif conflict["type"] == "capability_violation":
        return "建议调整该行为至角色能力范围内"
    return "请玩家重新斟酌注入内容"
```
