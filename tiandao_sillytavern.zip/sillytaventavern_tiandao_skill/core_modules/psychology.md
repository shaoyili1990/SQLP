# 心理引擎核心模块 (psychology.py)

## 模块职责

作为天道演化系统的"心理内核"，负责：
1. Y值状态管理与跃迁计算
2. 触发机制判定
3. 补偿机制执行
4. 回弹机制管理
5. JSON心理档案读写

## 一、Y值状态机

```python
class YValueState:
    """Y值状态管理"""
    
    def __init__(self, base_y: int, mbti: str, trauma_offset: int = 0):
        # 基线Y值（由MBTI决定）
        self.base_y = base_y
        # Y值区间 [min, max]
        self.y_min = base_y - 5
        self.y_max = base_y + 5
        # 当前Y值
        self.current_y = base_y + trauma_offset
        # 创伤偏移量
        self.trauma_offset = trauma_offset
        # 补偿状态
        self.compensation_active = False
        self.compensation_remaining = 0
        # 回弹状态
        self.rebound_active = False
        self.rebound_progress = 0
        
    def get_base_with_trauma(self) -> int:
        """获取包含创伤偏移的基线"""
        return self.base_y + self.trauma_offset
```

## 二、击穿阈值判定

```python
def calculate_delta_y(actor_y: int, target_y: int) -> int:
    """
    计算Y值差（用于击穿判定）
    ΔY = 对方Y - 自身Y
    """
    return target_y - actor_y

def get_breakthrough_threshold(self_y: int) -> int:
    """
    获取击穿阈值
    Y < 40: 阈值30（极度脆弱）
    40 <= Y < 70: 阈值20（普通~偏强）
    Y >= 70: 阈值15（意志极强/创伤者）
    """
    if self_y < 40:
        return 30
    elif self_y < 70:
        return 20
    else:
        return 15

def is_breakthrough(self_y: int, target_y: int) -> bool:
    """判定是否触发击穿"""
    delta = calculate_delta_y(self_y, target_y)
    threshold = get_breakthrough_threshold(self_y)
    return delta >= threshold
```

## 三、跃迁计算

```python
def calculate_y_jump(self_y: int, base_y: int, reaction_type: str) -> int:
    """
    击穿后Y值跃迁计算
    reaction_type: "defensive" | "collapse" | "chaos"
    
    新Y = 基线 ± 浮动值P（1~10，根据心理状态判定）
    """
    import random
    P = random.randint(1, 10)
    
    if reaction_type == "defensive":
        # 防御性反应 → 基线 + P
        return min(base_y + P, 100)
    elif reaction_type == "collapse":
        # 崩溃性反应 → 基线 - P
        return max(base_y - P, 0)
    else:  # chaos
        # 混乱性反应 → 基线 ± P
        direction = random.choice([1, -1])
        return max(0, min(100, base_y + direction * P))
```

## 四、补偿机制

```python
def apply_compensation(current_y: int, compensation_type: str) -> int:
    """
    补偿机制计算
    compensation_type: 
        "post_break"   → +2~+5（被击穿后防御）
        "guilt"        → +5~+10（愧疚爆发）
        "self_deceive" → -3~-8（自我麻痹）
        "attachment"   → ±3以内（依恋填补）
    """
    import random
    if compensation_type == "post_break":
        return current_y + random.randint(2, 5)
    elif compensation_type == "guilt":
        return current_y + random.randint(5, 10)
    elif compensation_type == "self_deceive":
        return current_y - random.randint(3, 8)
    else:  # attachment
        return current_y + random.randint(-3, 3)
```

## 五、回弹机制

```python
def apply_rebound(current_y: int, base_y: int) -> int:
    """
    回弹机制计算
    每1~2个剧情节点调整 ±1~2，直至回归基线区间
    
    回弹方向：current_y > base_y → 下调；current_y < base_y → 上调
    """
    if current_y > base_y:
        return max(base_y, current_y - 2)
    elif current_y < base_y:
        return min(base_y, current_y + 2)
    return base_y

def is_in_baseline(current_y: int, base_y: int, tolerance: int = 5) -> bool:
    """判定Y值是否已回归基线区间"""
    return abs(current_y - base_y) <= tolerance
```

## 六、完整跃迁流程执行

```python
def execute_y_transition(state: YValueState, event: dict) -> dict:
    """
    执行完整Y值跃迁流程
    
    event = {
        "type": "breakthrough" | "trauma" | "pstd" | "emotion_extreme" | "player_injection",
        "actor_y": int,  # 施加影响者的Y值（人际互动时）
        "reaction_type": str,  # 反应类型（defensive/collapse/chaos）
        "compensation_type": str,
        "description": str  # 事件描述
    }
    
    返回: {
        "new_y": int,
        "mechanism": "trigger" | "compensation" | "rebound",
        "description": str
    }
    """
    result = {}
    
    if event["type"] in ["breakthrough", "trauma", "pstd", "emotion_extreme"]:
        # === 触发机制 ===
        base = state.get_base_with_trauma()
        new_y = calculate_y_jump(
            state.current_y, 
            base, 
            event.get("reaction_type", "defensive")
        )
        state.current_y = new_y
        state.compensation_active = True
        state.compensation_remaining = random.randint(1, 3)
        result["mechanism"] = "trigger"
        
    elif event["type"] == "player_injection":
        # === 玩家注入处理 ===
        # 玩家注入视为重大事件，直接触发跃迁
        injection_impact = event.get("impact", "moderate")
        if injection_impact == "high":
            state.current_y = min(100, state.current_y + random.randint(8, 15))
        elif injection_impact == "moderate":
            state.current_y = min(100, state.current_y + random.randint(3, 8))
        else:
            state.current_y = min(100, state.current_y + random.randint(1, 3))
        result["mechanism"] = "player_injection"
    
    result["new_y"] = state.current_y
    result["description"] = event.get("description", "")
    return result
```

## 七、JSON心理档案操作

```python
def load_profile(profile_path: str) -> dict:
    """加载JSON心理档案"""
    import json
    with open(profile_path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_profile(profile: dict, profile_path: str):
    """保存JSON心理档案"""
    import json
    with open(profile_path, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)

def create_profile_from_card(card_data: dict) -> dict:
    """
    从SillyTavern角色卡创建JSON心理档案
    card_data: 角色卡的JSON/YAML数据
    """
    profile = {
        "name": card_data.get("name", "Unknown"),
        "mbti": card_data.get("mbti", "INFJ"),
        "base_y": card_data.get("base_y", 50),
        "y_min": card_data.get("base_y", 50) - 5,
        "y_max": card_data.get("base_y", 50) + 5,
        "current_y": card_data.get("base_y", 50),
        "trauma_offset": card_data.get("trauma_offset", 0),
        "memory": {
            "total": [],
            "normal": {"habits": [], "routines": []},
            "abnormal": [],
            "long_term": [],
            "short_term": []
        },
        "evolution_chain": [],
        "event_log": []
    }
    return profile
```

## 八、心理过载检测

```python
def check_psychological_overload(profile: dict) -> dict:
    """
    检查心理过载状态
    异常记忆 > 15条时触发惩罚
    """
    abnormal_count = len(profile["memory"]["abnormal"])
    
    if abnormal_count <= 15:
        return {"overload": False, "level": "none", "penalty": 0}
    elif abnormal_count <= 20:
        return {"overload": True, "level": "light", "penalty": 5}
    elif abnormal_count <= 30:
        return {"overload": True, "level": "medium", "penalty": 10}
    else:
        return {"overload": True, "level": "heavy", "penalty": 15}
```
