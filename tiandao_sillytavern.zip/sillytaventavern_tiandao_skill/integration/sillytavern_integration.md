# SillyTavern集成层 (sillytavern_integration.py)

## 模块职责

作为天道系统与SillyTavern之间的适配层，处理：
1. SillyTavern API接口对接
2. 角色卡导入/导出
3. 消息格式转换
4. 插件化集成方案

## 一、SillyTavern API对接

```python
class SillyTavernConnector:
    """SillyTavern连接器"""
    
    def __init__(self, api_base: str = "http://localhost:8080"):
        self.api_base = api_base
        self.api_key = None
    
    def set_api_key(self, key: str):
        self.api_key = key
    
    # === 角色卡操作 ===
    
    def get_character(self, char_id: str) -> dict:
        """获取角色信息"""
        # GET /api/characters/{char_id}
        pass
    
    def list_characters(self) -> list:
        """列出所有角色"""
        # GET /api/characters
        pass
    
    def import_character(self, card_data: dict) -> str:
        """导入角色卡，返回角色ID"""
        # POST /api/characters
        pass
    
    # === 聊天操作 ===
    
    def get_chat_history(self, chat_id: str, limit: int = 50) -> list:
        """获取聊天历史"""
        # GET /api/chats/{chat_id}/messages?limit=N
        pass
    
    def send_message(self, chat_id: str, message: str, speaker: str = "user") -> dict:
        """发送消息"""
        # POST /api/chats/{chat_id}/messages
        pass
    
    # === 演化触发 ===
    
    def trigger_evolution(self, char_id: str, context: dict) -> dict:
        """触发天道演化系统"""
        # POST /api/evolution/trigger
        pass
    
    def get_evolution_result(self, session_id: str) -> dict:
        """获取演化结果"""
        # GET /api/evolution/{session_id}/result
        pass
```

## 二、角色卡导入适配

```python
def adapt_sillytavern_card(sillytavern_card: dict) -> dict:
    """
    将SillyTavern角色卡适配为天道系统心理档案格式
    
    SillyTavern字段映射：
    """
    
    adapted = {
        # 基础信息
        "name": sillytavern_card.get("name", ""),
        "description": sillytavern_card.get("description", ""),
        "personality": sillytavern_card.get("personality", ""),
        "first_message": sillytavern_card.get("first_message", ""),
        "avatar": sillytavern_card.get("avatar", ""),
        
        # 扩展字段（SillyTavern特有）
        "sillytavern_extensions": {
            "chat_examples": sillytavern_card.get("chat_examples", ""),
            "creator_notes": sillytavern_card.get("creator_notes", ""),
            "system_prompt": sillytavern_card.get("system_prompt", ""),
            "post_history_instructions": sillytavern_card.get("post_history_instructions", ""),
            "tags": sillytavern_card.get("tags", []),
            "creator": sillytavern_card.get("creator", ""),
            "character_version": sillytavern_card.get("character_version", ""),
            "alternate_greetings": sillytavern_card.get("alternate_greetings", [])
        },
        
        # 附加数据
        "data": sillytavern_card.get("data", {})
    }
    
    return adapted
```

## 三、消息格式转换

```python
def convert_to_sillytavern_message(
    behavior_chain: list,
    profile: dict,
    format_type: str = "mixed"
) -> list:
    """
    将演化行为链转换为SillyTavern消息格式
    
    返回: [{
        "role": "character" | "user" | "system",
        "content": str,
        "name": str
    }]
    """
    
    messages = []
    
    for item in behavior_chain:
        behavior = item.get("behavior", "")
        action_type = item.get("action_type", "mixed")
        
        if format_type == "internal":
            # 内心独白格式
            content = f"*{behavior}*"
        elif format_type == "dialogue":
            # 对话格式
            content = f"{profile['name']}: {behavior}"
        else:
            # 混合格式
            content = f"*{profile['name']}* {behavior}"
        
        messages.append({
            "role": "character",
            "content": content,
            "name": profile["name"]
        })
    
    return messages

def extract_player_input(raw_input: str) -> dict:
    """
    从SillyTavern输入中提取玩家内容
    
    支持格式：
    - 普通文本
    - /命令格式
    - [注入]标记格式
    """
    
    result = {
        "type": "normal",
        "content": raw_input,
        "command": None,
        "injection": None
    }
    
    # 检测命令
    if raw_input.startswith("/"):
        parts = raw_input.split(" ", 1)
        result["type"] = "command"
        result["command"] = parts[0]
        result["content"] = parts[1] if len(parts) > 1 else ""
    
    # 检测注入标记
    elif raw_input.startswith("[注入]"):
        result["type"] = "injection"
        result["injection"] = raw_input[4:].strip()
        result["content"] = raw_input[4:].strip()
    
    return result
```

## 四、插件化集成方案

### 4.1 SillyTavern插件接口

```javascript
// sillytaventavern_tiandao_plugin.js
// 注入到SillyTavern的插件系统

const TiandaoPlugin = {
  name: "天道系统 - Tiandao Evolution",
  version: "1.0.0",
  
  // 插件初始化
  init: function(app) {
    console.log("天道系统插件初始化");
    
    // 注册演化命令
    this.registerCommands();
    
    // 注册事件监听
    this.registerEventListeners();
    
    // 添加UI按钮
    this.addUI();
  },
  
  // 注册命令
  registerCommands: function() {
    const commands = [
      { cmd: "/evolve", desc: "启动角色演化" },
      { cmd: "/evolve inject", desc: "注入想法" },
      { cmd: "/evolve pause", desc: "暂停演化" },
      { cmd: "/evolve status", desc: "查看状态" }
    ];
    // 注册到SillyTavern命令系统
  },
  
  // 注册事件监听
  registerEventListeners: function() {
    // 监听消息发送事件
    eventBus.on("messageSent", this.onMessageSent.bind(this));
    
    // 监听角色切换
    eventBus.on("characterChanged", this.onCharacterChanged.bind(this));
  },
  
  // 消息发送回调
  onMessageSent: function(message) {
    // 当玩家发送消息时，触发天道演化系统
    tiandaoSystem.onPlayerInput(message);
  },
  
  // 核心演化触发
  triggerEvolution: function(context) {
    // 调用天道系统核心
    tiandaoSystem.evolve(context);
  }
};
```

### 4.2 集成配置

```json
{
  "sillytaventavern_tiandao": {
    "enabled": true,
    "api_endpoint": "http://localhost:8080",
    "evolution": {
      "default_rounds": 3,
      "max_rounds": 5,
      "auto_trigger": false,
      "output_mode": "mixed"
    },
    "psychology": {
      "y_value_enabled": true,
      "memory_enabled": true,
      "mbmbti_enabled": true
    },
    "integration": {
      "output_to_thought": false,
      "output_to_chat": true,
      "inject_command": "/inject"
    }
  }
}
```

## 五、快速开始指南

### Step 1: 加载角色卡
```
用户通过SillyTavern界面选择角色
→ 系统自动解析角色卡 → 生成JSON心理档案
```

### Step 2: 正常聊天
```
用户发送消息 → SillyTavern正常处理 → 角色回复
→ 天道系统记录当前心理状态
```

### Step 3: 触发演化
```
用户输入 /evolve
→ 天道系统启动 → 生成N轮自主行为
→ 行为输出到聊天界面或内心独白
```

### Step 4: 注入想法
```
用户输入 /inject [想法内容]
→ 天道系统暂停 → 融合新想法 → 继续演化
```
