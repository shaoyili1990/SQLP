# 快速开始指南

## 一、环境准备

### 1.1 依赖环境

- Python 3.9+
- LLM API（OpenAI / Claude / 本地模型）
- SillyTavern 1.0+

### 1.2 安装步骤

```bash
# 1. 克隆/下载天道系统
git clone https://github.com/shaoyili1990/SQLP.git

# 2. 解压天道skill系统.zip到~/.hermes/skills/

# 3. 安装Python依赖
pip install -r requirements.txt

# 4. 配置SillyTavern插件（可选）
# 将integration/sillytaventavern_tiandao_plugin.js复制到SillyTavern插件目录
```

## 二、基础使用

### 2.1 导入角色卡

```python
from core_modules.parser import parse_character_card, build_full_profile

# 读取角色卡文件
with open("my_character.json", "r") as f:
    card_data = f.read()

# 解析角色卡
profile = parse_character_card(card_data)

# 构建完整心理档案
full_profile = build_full_profile(profile)

# 保存档案
from core_modules.parser import save_profile
save_profile(full_profile)
```

### 2.2 启动演化

```python
from core_modules.evolution import run_evolution
from core_modules.scene import evolve_singleton, evolve_couple
from core_modules.formatter import EvolutionFormatter

# 单人场景演化
chain = evolve_singleton(full_profile, {
    "type": "singleton",
    "location": "房间",
    "time": "深夜"
})

# 双人场景演化
chain = evolve_couple(char_a_profile, char_b_profile, {
    "type": "couple",
    "location": "咖啡馆",
    "time": "下午"
})

# 格式化输出
formatter = EvolutionFormatter()
output = formatter.format_chain(chain, full_profile, mode="mixed")
print(output)
```

### 2.3 处理玩家注入

```python
from core_modules.injection import parse_injection, fuse_injection
from core_modules.psychology import execute_y_transition

# 玩家注入
player_input = "我突然想起那个雨夜，他离开时的背影..."

# 解析注入
parsed = parse_injection(player_input, full_profile["name"])

# 融合到演化链
fusion_result = fuse_injection(full_profile, parsed, current_chain, evolution_state)

# 继续演化
new_chain = run_evolution(full_profile, scene_context, max_rounds=3)
```

## 三、命令参考

| 命令 | 说明 | 示例 |
|------|------|------|
| `/evolve start [N]` | 启动演化，N=轮次数 | `/evolve start 3` |
| `/evolve inject [内容]` | 注入想法 | `/evolve inject 我在想他` |
| `/evolve pause` | 暂停演化 | |
| `/evolve resume` | 继续演化 | |
| `/evolve stop` | 停止并归档 | |
| `/evolve status` | 查看状态 | |
| `/evolve scene [类型]` | 切换场景 | `/evolve scene couple` |

## 四、输出模式

| 模式 | 说明 | 示例输出 |
|------|------|----------|
| `narrative` | 纯叙述 | "角色的视线落在远处..." |
| `dialogue` | 对话格式 | "角色：今天天气真好" |
| `mixed` | 混合模式 | "*角色* 转身，"走吧" |
| `internal` | 内心独白 | "(他在想，如果当初...)" |
| `minimal` | 极简 | "他站起身" |
