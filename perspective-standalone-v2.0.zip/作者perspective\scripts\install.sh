#!/bin/bash

# 作者perspective Skill 安装脚本
# 支持: macOS, Linux, Windows (Git Bash / WSL)

SKILL_NAME="作者perspective"
INSTALL_TARGET="${HOME}/.claude/skills/${SKILL_NAME}"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "========================================"
echo "作者perspective Skill 安装程序"
echo "========================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "[1/4] 检查目标目录..."
if [ -d "$INSTALL_TARGET" ]; then
    echo -e "${YELLOW}警告：$INSTALL_TARGET 已存在${NC}"
    read -p "是否覆盖？(y/n): " OVERWRITE
    if [ "$OVERWRITE" != "y" ] && [ "$OVERWRITE" != "Y" ]; then
        echo "安装已取消"
        exit 0
    fi
    rm -rf "$INSTALL_TARGET"
fi

echo "[2/4] 创建目录结构..."
mkdir -p "$INSTALL_TARGET"
mkdir -p "$INSTALL_TARGET/knowledge"
mkdir -p "$INSTALL_TARGET/memory"
mkdir -p "$INSTALL_TARGET/references/research"
mkdir -p "$INSTALL_TARGET/references/sources"
mkdir -p "$INSTALL_TARGET/scripts"

echo "[3/4] 复制文件..."
cp -r "$SOURCE_DIR/knowledge/"* "$INSTALL_TARGET/knowledge/" 2>/dev/null
cp -r "$SOURCE_DIR/memory/"* "$INSTALL_TARGET/memory/" 2>/dev/null
cp -r "$SOURCE_DIR/references/"* "$INSTALL_TARGET/references/" 2>/dev/null
cp -r "$SOURCE_DIR/scripts/"* "$INSTALL_TARGET/scripts/" 2>/dev/null
cp "$SOURCE_DIR/SKILL.md" "$INSTALL_TARGET/" 2>/dev/null

echo "[4/4] 验证安装..."
if [ -f "$INSTALL_TARGET/SKILL.md" ]; then
    echo -e "${GREEN}✓ 安装成功！${NC}"
    echo "  路径：$INSTALL_TARGET"
else
    echo -e "${RED}✗ 安装失败：SKILL.md 未找到${NC}"
    exit 1
fi

echo ""
echo "========================================"
echo "安装完成！"
echo "========================================"
echo ""
echo "知识库状态："
KNOWLEDGE_COUNT=$(ls "$INSTALL_TARGET/knowledge/"*.md 2>/dev/null | wc -l | tr -d ' ')
MEMORY_COUNT=$(ls "$INSTALL_TARGET/memory/"*.md 2>/dev/null | wc -l | tr -d ' ')
echo "  $KNOWLEDGE_COUNT 个知识文件"
echo "  $MEMORY_COUNT 个记忆文件"
echo ""
echo "下一步："
echo "  1. 重启 Claude Code"
echo "  2. 或使用 /skill reload 命令"
echo "  3. 输入"创作"或"头脑风暴"激活此Skill"
echo ""
