# 作者Skill 技能集成清单

> 记录哪些skills可以集成到作者skill中，以及集成方式

---

## 集成方式说明

| 标记 | 含义 |
|------|------|
| 依赖 | 核心功能，必须集成 |
| 调用 | 需要时调用，非必须 |
| 参考 | 借鉴其方法论，非直接集成 |
| 工具注入 | 作为工具提供给作者skill使用 |

---

## 第一梯队：核心依赖

### 1. deep-reading
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\deep-reading\`
- **集成方式**：依赖
- **理由**：作者skill需要深度理解素材库/文档支持中的大量文档，deep-reading的"冷读+热读"模式完美匹配
- **调用场景**：
  - 分析作者原始文档时
  - 挖掘素材中的隐藏模式时
  - 理解跨作品关联时

### 2. self-evolving-skill
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\self-evolving-skill\`
- **集成方式**：框架参考 + 依赖
- **理由**：作者的RAG系统需要自主进化能力，self-evolving-skill的"数据收集→特征提取→自我建模→反馈迭代"闭环可以直接迁移
- **调用场景**：
  - 初始化新领域知识时
  - 更新经验库时
  - 检错与迭代时

### 3. memory-tiering
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\memory-tiering\`
- **集成方式**：依赖
- **理由**：RAG知识库需要分层管理，memory-tiering的"冷却期→长期区→激活态"模型完美适配
- **调用场景**：
  - 管理经验库时
  - 知识碎片分类时
  - 调用频率统计时

---

## 第二梯队：功能增强

### 4. tavily-search
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\tavily-search\`
- **集成方式**：工具注入
- **理由**：弥补作者知识的实时性盲区
- **调用场景**：
  - 需要查证现实知识时
  - 补充外部信息时
  - 跨领域研究时

### 5. pdf-reader
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\pdf-reader\`
- **集成方式**：工具注入
- **理由**：素材库中可能包含PDF文档
- **调用场景**：
  - 读取PDF格式素材时

### 6. reading
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\reading\`
- **集成方式**：工具注入
- **理由**：通用文档读取，补充PDF-reader覆盖不到的格式
- **调用场景**：
  - 读取docx/epub等格式时
  - 通用文本处理时

### 7. writing-plans
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\writing-plans\`
- **集成方式**：能力参考
- **理由**：结构化写作规划方法可借鉴
- **调用场景**：
  - 长篇创作规划时
  - 章节结构设计时

### 8. article-style-analyzer
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\article-style-analyzer\`
- **集成方式**：能力参考
- **理由**：风格分析可辅助作者适配不同心声流变体
- **调用场景**：
  - 分析目标风格时
  - 风格迁移时

### 9. insight-writer
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\insight-writer\`
- **集成方式**：能力参考
- **理由**：洞见生成方法论可补充作者的知识碎片输出
- **调用场景**：
  - 生成创作洞见时
  - 整理知识碎片时

---

## 第三梯队：特定场景

### 10. project-deep-analyzer
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\project-deep-analyzer\`
- **集成方式**：场景调用
- **理由**：复杂项目分析能力
- **调用场景**：
  - 分析世界观架构时
  - 多线索推演时

### 11. brain-storm
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\brain-storm\`
- **集成方式**：场景调用
- **理由**：头脑风暴辅助
- **调用场景**：
  - 情节卡壳时
  - 需要发散思维时

### 12. question-refine
- **路径**：`C:\Users\shaoy\Desktop\作者整合\skills\question-refine\`
- **集成方式**：场景调用
- **理由**：问题深化能力
- **调用场景**：
  - 需求不清晰时
  - 需要追问时

---

## 未推荐技能

以下技能不适合作者skill：

| 技能 | 原因 |
|------|------|
| notion | 非通用创作工具 |
| email | 与创作无关 |
| workflow | 过于通用，非作者特化 |

---

## 集成优先级

1. **立即集成**：deep-reading, self-evolving-skill, memory-tiering, tavily-search, reading
2. **后续集成**：writing-plans, article-style-analyzer, insight-writer, pdf-reader
3. **按需调用**：project-deep-analyzer, brain-storm, question-refine

---

*最后更新：2026-04-25*
