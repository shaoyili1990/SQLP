@echo off
chcp 65001 >nul
echo ========================================
echo 作者perspective 自检程序
echo ========================================
echo.

set SKILL_DIR=%~dp0

echo [1/5] 检查核心文件...
set CORE_FILES=SKILL.md
for %%f in (%CORE_FILES%) do (
    if exist "%SKILL_DIR%%%f" (
        echo   ✓ %%f
    ) else (
        echo   ✗ %%f [缺失]
    )
)

echo.
echo [2/5] 检查知识库...
set KNOWLEDGE_FILES=索引.md 方法论-天道系统.md 方法论-叙事契约.md 方法论-三维坐标.md 方法论-静动寂.md 哲学-意志博弈.md 哲学-灰度思维.md 系统-权重转移.md 系统-NPC能动性.md 心理-马斯洛.md 心理-依恋理论.md 作品-龙藏.md
for %%f in (%KNOWLEDGE_FILES%) do (
    if exist "%SKILL_DIR%knowledge\%%f" (
        echo   ✓ %%f
    ) else (
        echo   ○ %%f [未找到]
    )
)

echo.
echo [3/5] 检查记忆库...
set MEMORY_FILES=经验库.md 知识碎片.md
for %%f in (%MEMORY_FILES%) do (
    if exist "%SKILL_DIR%memory\%%f" (
        echo   ✓ %%f
    ) else (
        echo   ○ %%f [未找到]
    )
)

echo.
echo [4/5] 检查参考资料...
if exist "%SKILL_DIR%references\skill-integrations.md" (
    echo   ✓ skill-integrations.md
) else (
    echo   ○ skill-integrations.md [未找到]
)

echo.
echo [5/5] 统计信息...
echo   知识库文件：
for /f %%i in ('dir /B "%SKILL_DIR%knowledge\*.md" 2^|find /C ".md"') do echo     %%i 个
echo   记忆文件：
for /f %%i in ('dir /B "%SKILL_DIR%memory\*.md" 2^|find /C ".md"') do echo     %%i 个

echo.
echo ========================================
echo 自检完成
echo ========================================
echo.
echo 状态说明：
echo   ✓ = 存在且完整
echo   ○ = 可选文件，当前未找到
echo   ✗ = 必需文件，缺失
echo.
echo 如有缺失，可以：
echo 1. 重新安装
echo 2. 手动添加知识文件到对应目录
echo 3. 询问作者获取完整包
echo.
pause
