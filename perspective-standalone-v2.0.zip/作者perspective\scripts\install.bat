@echo off
chcp 65001 >nul
echo ========================================
echo 作者perspective Skill 安装程序
echo ========================================
echo.

set SKILL_NAME=作者perspective
set INSTALL_TARGET=%USERPROFILE%\.claude\skills\%SKILL_NAME%
set SOURCE_DIR=%~dp0

echo [1/4] 检查目标目录...
if exist "%INSTALL_TARGET%" (
    echo 警告：%INSTALL_TARGET% 已存在
    set /p OVERWRITE="是否覆盖？(y/n): "
    if /i not "%OVERWRITE%"=="y" goto :end
)

echo [2/4] 创建目录结构...
mkdir "%INSTALL_TARGET%" 2>nul
mkdir "%INSTALL_TARGET%\knowledge" 2>nul
mkdir "%INSTALL_TARGET%\memory" 2>nul
mkdir "%INSTALL_TARGET%\references" 2>nul
mkdir "%INSTALL_TARGET%\references\research" 2>nul
mkdir "%INSTALL_TARGET%\references\sources" 2>nul
mkdir "%INSTALL_TARGET%\scripts" 2>nul

echo [3/4] 复制文件...
xcopy /E /Y "%SOURCE_DIR%knowledge\*" "%INSTALL_TARGET%\knowledge\" 2>nul
xcopy /E /Y "%SOURCE_DIR%memory\*" "%INSTALL_TARGET%\memory\" 2>nul
xcopy /E /Y "%SOURCE_DIR%references\*" "%INSTALL_TARGET%\references\" 2>nul
xcopy /E /Y "%SOURCE_DIR%scripts\*" "%INSTALL_TARGET%\scripts\" 2>nul
copy /Y "%SOURCE_DIR%SKILL.md" "%INSTALL_TARGET%\" 2>nul

echo [4/4] 验证安装...
if exist "%INSTALL_TARGET%\SKILL.md" (
    echo ✓ 安装成功！
    echo   路径：%INSTALL_TARGET%
) else (
    echo ✗ 安装失败：SKILL.md 未找到
    goto :end
)

echo.
echo ========================================
echo 安装完成！
echo ========================================
echo.
echo 知识库状态：
dir /B "%INSTALL_TARGET%\knowledge\" | find /C ".md"
echo 个知识文件
dir /B "%INSTALL_TARGET%\memory\" | find /C ".md"
echo 个记忆文件
echo.
echo 下一步：
echo 1. 重启 Claude Code
echo 2. 或使用 /skill reload 命令
echo 3. 输入"创作"或"头脑风暴"激活此Skill
echo.

:end
pause
