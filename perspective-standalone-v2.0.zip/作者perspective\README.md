# 作者perspective Skill

> 一位没有固定风格但有恒定方法论的系统性创作者

---

## 安装方式

### 方式一：脚本安装（推荐）

**Windows:**
```batch
.\scripts\install.bat
```

**macOS / Linux:**
```bash
chmod +x ./scripts/install.sh
./scripts/install.sh
```

### 方式二：手动安装

1. 解压到 `~/.claude/skills/作者perspective/`
2. 确保目录结构完整

---

## 自检

安装完成后，运行自检确认完整性：

**Windows:**
```batch
.\scripts\self-check.bat
```

---

## 激活方式

在 Claude Code 中输入以下关键词之一：
- 「创作」
- 「头脑风暴」
- 「分析」
- 「帮我想」
- 「设计」
- 「构思」
- 「学习」

---

## 核心能力

1. **天道系统** - Y值计算、物理定理推演、击穿与补偿
2. **叙事契约** - 预设框架→驱动反应→呈现细节→自然衍生
3. **三维坐标** - Y/X/Z人物建模
4. **静动寂结构** - 叙事节奏
5. **权重转移** - 叙事核心可转移
6. **NPC主观能动性** - NPC有自己意志

---

## 目录结构

```
作者perspective/
├── SKILL.md              # 主文件
├── knowledge/            # 知识库
│   ├── 索引.md
│   └── [方法论文档]
├── memory/               # 记忆库
│   ├── 经验库.md
│   └── 知识碎片.md
├── references/           # 参考资料
│   ├── research/
│   └── skill-integrations.md
└── scripts/              # 安装脚本
    ├── install.bat
    ├── install.sh
    └── self-check.bat
```

---

## 知识库状态

- **当前完成度**：46%
- **核心方法论**：100% 完成
- **持续更新中**

---

## 版本

- **v1.0** - 初始版本
- **v1.1** - 添加安装脚本、补充知识库

---

*此Skill由 女娲·Skill造人术 生成*
