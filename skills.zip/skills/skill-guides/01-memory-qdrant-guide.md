# Skill调用流程说明文档 - memory-qdrant

**Skill名称**: memory-qdrant  
**版本**: 1.0.10  
**用途**: 向量数据库记忆管理（天道系统核心组件）  
**安装时间**: 2026-04-17  

---

## 一、功能概述

memory-qdrant 是一个本地语义记忆插件，使用 Qdrant 向量数据库和 Transformers.js 嵌入模型。用于天道系统的五类记忆存储与检索：
- 总记忆
- 常态记忆
- 异常记忆
- 长记忆
- 短记忆

**核心优势**:
- 完全本地运行，无需API密钥
- 语义搜索，支持相似度匹配
- 可配置持久化存储或内存模式

---

## 二、配置方法

### 1. 启用插件

在 OpenClaw 配置文件中添加：

```json
{
  "plugins": {
    "memory-qdrant": {
      "enabled": true,
      "autoCapture": false,
      "autoRecall": true,
      "qdrantUrl": ""
    }
  }
}
```

### 2. 配置选项说明

| 选项 | 默认值 | 说明 |
|------|--------|------|
| `enabled` | true | 是否启用插件 |
| `autoCapture` | false | 是否自动记录对话（建议关闭，手动控制） |
| `autoRecall` | true | 是否自动注入相关记忆 |
| `qdrantUrl` | "" | 外部Qdrant服务器地址（空=内存模式） |

---

## 三、调用流程

### 流程1：存储角色记忆（天道系统）

**场景**: 角色经历事件后，需要更新记忆档案

```javascript
// 存储角色A的创伤记忆
memory_store({
  text: "角色A在童年时期目睹了家庭破碎，形成核心创伤：被抛弃恐惧",
  category: "trauma_memory",  // 异常记忆
  metadata: {
    character_id: "char_A",
    memory_type: "abnormal",  // 异常记忆
    y_value_impact: -15,
    timestamp: "2026-04-17T12:00:00Z"
  }
})

// 存储角色B的短期互动记忆
memory_store({
  text: "角色B今天与主角发生了争执，感到被冒犯",
  category: "short_term_memory",  // 短记忆
  metadata: {
    character_id: "char_B",
    memory_type: "short",
    weight_change: -2,
    timestamp: "2026-04-17T12:30:00Z"
  }
})
```

### 流程2：检索相关记忆（触发补偿机制时）

**场景**: 角色Y值变化，需要检索相关记忆进行补偿行为计算

```javascript
// 搜索与"被羞辱"相关的记忆
memory_search({
  query: "角色A被羞辱 被抛弃 被否定",
  limit: 5,
  filter: {
    character_id: "char_A",
    memory_type: ["abnormal", "long"]  // 只搜索异常记忆和长记忆
  }
})

// 搜索结果将返回最相关的记忆片段，用于：
// 1. 判断触发阈值
// 2. 确定补偿行为方向
// 3. 计算补偿强度
```

### 流程3：检索社会关系记忆（人道系统）

**场景**: 计算权重变化时，检索角色间的历史互动

```javascript
// 搜索角色A与角色B的互动历史
memory_search({
  query: "角色A 角色B 互动 关系 权重",
  limit: 10,
  filter: {
    characters: ["char_A", "char_B"],
    category: "social_interaction"
  }
})
```

### 流程4：清理过期记忆

**场景**: 记忆库过大，需要清理不重要的短记忆

```javascript
// 删除特定记忆
memory_forget({ memoryId: "uuid-of-memory" })

// 或删除符合条件的记忆
memory_forget({ 
  query: "短记忆 已过期",
  filter: {
    memory_type: "short",
    age_days: ">30"
  }
})
```

---

## 四、天道系统集成方案

### 记忆五类映射

| 天道记忆类型 | Qdrant Category | 存储策略 |
|-------------|-----------------|----------|
| 总记忆 | `total_memory` | 永久存储 |
| 常态记忆 | `normal_memory` | 定期归档 |
| 异常记忆 | `abnormal_memory` | 高优先级保留 |
| 长记忆 | `long_term_memory` | 永久存储 |
| 短记忆 | `short_term_memory` | 定期清理 |

### 集成代码示例

```javascript
// 天道系统记忆存储函数
function storeTianDaoMemory(characterId, memoryType, content, metadata) {
  const categoryMap = {
    'total': 'total_memory',
    'normal': 'normal_memory',
    'abnormal': 'abnormal_memory',
    'long': 'long_term_memory',
    'short': 'short_term_memory'
  };
  
  return memory_store({
    text: content,
    category: categoryMap[memoryType],
    metadata: {
      character_id: characterId,
      memory_type: memoryType,
      ...metadata
    }
  });
}

// 天道系统记忆检索函数
function recallTianDaoMemory(characterId, query, memoryTypes, limit = 5) {
  return memory_search({
    query: query,
    limit: limit,
    filter: {
      character_id: characterId,
      memory_type: memoryTypes
    }
  });
}
```

---

## 五、注意事项

1. **首次运行**: 会下载约25MB的嵌入模型，需要网络连接
2. **内存模式**: 默认使用内存模式，重启后数据清空，适合测试
3. **生产环境**: 建议配置外部Qdrant服务器进行持久化存储
4. **隐私保护**: autoCapture默认关闭，避免意外记录敏感信息

---

## 六、故障排查

| 问题 | 解决方案 |
|------|----------|
| 模型下载失败 | 检查网络连接，或手动下载模型到指定目录 |
| 内存不足 | 切换到外部Qdrant服务器模式 |
| 搜索结果不准确 | 调整查询文本，增加关键词 |

---

*文档生成时间: 2026-04-17*  
*对应Skill: memory-qdrant v1.0.10*
