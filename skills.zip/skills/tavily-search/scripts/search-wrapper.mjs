#!/usr/bin/env node
// Wrapper script that reads API key from OpenClaw config

import { readFileSync } from 'fs';
import { homedir } from 'os';
import { join } from 'path';

// Read OpenClaw config
const configPath = join(homedir(), '.stepclaw', 'openclaw.json');
let apiKey = '';

try {
  const config = JSON.parse(readFileSync(configPath, 'utf8'));
  apiKey = config?.skills?.entries?.['tavily-search']?.apiKey || '';
} catch (e) {
  console.error('Warning: Could not read OpenClaw config');
}

// Set environment variable for the actual script
process.env.TAVILY_API_KEY = apiKey;

// Import and run the actual search script
await import('./search.mjs');
