# 天道系统 Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** 实现天道系统核心引擎，包含Y值计算、MBTI人格骨架、三大机制（触发/补偿/回弹）、JSON心理档案、人道系统权重体系

**Architecture:** 
- 核心引擎：TypeScript/Python 规则计算引擎
- 数据层：JSON Schema 定义心理档案结构
- 接口层：与SillyTavern兼容的API
- 渲染层：对接云端AI进行自然语言生成

**Tech Stack:** TypeScript, JSON Schema, Jest测试框架

---

## 任务清单概览

1. 项目初始化与目录结构
2. 核心类型定义（TypeScript接口）
3. Y值计算引擎
4. MBTI人格模块
5. 三大机制实现（触发/补偿/回弹）
6. JSON心理档案系统
7. 人道系统权重体系
8. 记忆模块（5类记忆）
9. SillyTavern对接适配器
10. 测试套件与验证

---

### Task 1: 项目初始化与目录结构

**Files:**
- Create: `tiandao-system/package.json`
- Create: `tiandao-system/tsconfig.json`
- Create: `tiandao-system/README.md`
- Create: `tiandao-system/src/index.ts`
- Create: `tiandao-system/src/types/index.ts`

**Step 1: 初始化项目**

```bash
cd ~/.stepclaw/workspace
mkdir -p tiandao-system/src/{types,core,mechanisms,memory,humanway,adapter}
mkdir -p tiandao-system/tests
mkdir -p tiandao-system/docs
```

**Step 2: 创建 package.json**

```json
{
  "name": "tiandao-system",
  "version": "1.0.0",
  "description": "天道系统 - 角色心理模拟引擎",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "test": "jest",
    "test:watch": "jest --watch",
    "dev": "ts-node src/index.ts"
  },
  "devDependencies": {
    "@types/jest": "^29.5.0",
    "@types/node": "^20.0.0",
    "jest": "^29.5.0",
    "ts-jest": "^29.1.0",
    "ts-node": "^10.9.0",
    "typescript": "^5.0.0"
  },
  "keywords": ["tiandao", "character", "psychology", "simulation"],
  "license": "MIT"
}
```

**Step 3: 创建 tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "lib": ["ES2020"],
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "tests"]
}
```

**Step 4: 创建 jest.config.js**

```javascript
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  roots: ['<rootDir>/tests'],
  testMatch: ['**/*.test.ts'],
  collectCoverageFrom: ['src/**/*.ts', '!src/**/*.d.ts'],
};
```

**Step 5: 提交**

```bash
cd tiandao-system
git init
git add .
git commit -m "chore: initialize tiandao-system project"
```

---

### Task 2: 核心类型定义

**Files:**
- Create: `tiandao-system/src/types/core.ts`
- Create: `tiandao-system/src/types/mbti.ts`
- Create: `tiandao-system/src/types/memory.ts`
- Create: `tiandao-system/src/types/index.ts`

**Step 1: 创建核心类型定义**

```typescript
// src/types/core.ts

/**
 * Y值：人物主观意识凝练强度 (40-100)
 * - 执行力：Y越高，主观意识越坚定
 * - 影响力：Y越高，气场越强，越能碾压低Y值
 * - 被影响力：Y越低，意识越涣散，越容易被操控
 */
export type YValue = number;

/**
 * Y值等级定义
 */
export enum YLevel {
  COLLAPSED = 0,      // 意识崩溃/死亡
  FRAGMENTED = 20,    // 精神分裂/PTSD
  UNSTABLE = 40,      // 常人下限
  NORMAL = 60,        // 常人基准
  STABLE = 70,        // 常人上限
  DOMINANT = 80,      // 气场碾压
  OVERWHELMING = 90,  // 绝对支配
}

/**
 * 人物状态
 */
export interface CharacterState {
  id: string;
  name: string;
  yValue: YValue;
  yBase: YValue;           // Y值基线
  yMax: YValue;            // Y值上限
  yMin: YValue;            // Y值下限
  mbti: MBTIType;
  emotions: EmotionState;
  willpower: WillpowerState;
  traumaFlags: TraumaFlag[];
  isDead: boolean;
}

/**
 * 情绪状态（七情六欲）
 */
export interface EmotionState {
  // 七情
  joy: number;        // 喜
  anger: number;      // 怒
  sorrow: number;     // 哀
  fear: number;       // 惧
  love: number;       // 爱
  hate: number;       // 憎
  desire: number;     // 欲
  
  // 六欲（基于感官）
  visual: number;     // 见欲
  auditory: number;   // 听欲
  olfactory: number;  // 香欲
  gustatory: number;  // 味欲
  tactile: number;    // 触欲
  mental: number;     // 意欲
}

/**
 * 意志力状态
 */
export interface WillpowerState {
  current: number;     // 当前意志力 (0-100)
  max: number;         // 最大意志力
  regeneration: number; // 恢复速率
}

/**
 * 创伤标记
 */
export interface TraumaFlag {
  type: TraumaType;
  severity: number;    // 1-10
  permanent: boolean;  // 是否永久性改变Y值基线
  yBaseShift: number;  // 基线偏移量
}

export enum TraumaType {
  FAMILY_DEATH = 'family_death',
  BETRAYAL = 'betrayal',
  ABUSE = 'abuse',
  WAR = 'war',
  ISOLATION = 'isolation',
  LOSS = 'loss',
}
```

**Step 2: 创建MBTI类型定义**

```typescript
// src/types/mbti.ts

/**
 * MBTI 16型人格
 */
export type MBTIType = 
  | 'INTJ' | 'INTP' | 'ENTJ' | 'ENTP'
  | 'INFJ' | 'INFP' | 'ENFJ' | 'ENFP'
  | 'ISTJ' | 'ISFJ' | 'ESTJ' | 'ESFJ'
  | 'ISTP' | 'ISFP' | 'ESTP' | 'ESFP';

/**
 * MBTI 维度
 */
export interface MBTIDimensions {
  ei: number;  // Extraversion (正) vs Introversion (负)
  sn: number;  // Sensing (正) vs Intuition (负)
  tf: number;  // Thinking (正) vs Feeling (负)
  jp: number;  // Judging (正) vs Perceiving (负)
}

/**
 * MBTI 权重配置
 */
export interface MBTIWeights {
  type: MBTIType;
  dimensions: MBTIDimensions;
  
  // 各维度的Y值影响系数
  yModifiers: {
    dominance: number;    // 支配性
    resilience: number;   // 抗压性
    empathy: number;      // 共情能力
    logic: number;        // 逻辑强度
  };
  
  // 情绪响应模式
  emotionPatterns: {
    triggerThreshold: number;  // 触发阈值
    recoveryRate: number;      // 恢复速率
    intensityMultiplier: number; // 强度乘数
  };
}
```

**Step 3: 创建记忆类型定义**

```typescript
// src/types/memory.ts

/**
 * 五类记忆系统
 */
export interface MemorySystem {
  sensory: SensoryMemory;      // 感官记忆（瞬时）
  shortTerm: ShortTermMemory;  // 短期记忆
  longTerm: LongTermMemory;    // 长期记忆
  emotional: EmotionalMemory;  // 情绪记忆
  core: CoreMemory;            // 核心记忆（人格基石）
}

/**
 * 感官记忆（2-3秒）
 */
export interface SensoryMemory {
  visual: VisualSnapshot[];
  auditory: AuditorySnapshot[];
  capacity: number;  // 容量限制
}

export interface VisualSnapshot {
  timestamp: number;
  content: string;
  intensity: number;
}

export interface AuditorySnapshot {
  timestamp: number;
  content: string;
  tone: number;  // 语调强度
}

/**
 * 短期记忆（30秒-1分钟）
 */
export interface ShortTermMemory {
  items: MemoryItem[];
  capacity: number;  // 通常 7±2 个组块
  duration: number;  // 持续时间（毫秒）
}

export interface MemoryItem {
  id: string;
  content: string;
  timestamp: number;
  importance: number;
  associations: string[];
}

/**
 * 长期记忆
 */
export interface LongTermMemory {
  episodes: EpisodeMemory[];   // 情景记忆
  facts: FactMemory[];         // 语义记忆
  procedures: ProcedureMemory[]; // 程序记忆
}

export interface EpisodeMemory {
  id: string;
  timestamp: number;
  scene: string;
  participants: string[];
  emotionalValence: number;
  yImpact: number;  // 对Y值的影响
}

export interface FactMemory {
  id: string;
  content: string;
  confidence: number;
  source: string;
}

export interface ProcedureMemory {
  id: string;
  skill: string;
  proficiency: number;  // 熟练度
}

/**
 * 情绪记忆
 */
export interface EmotionalMemory {
  traumas: TraumaMemory[];
  joys: JoyMemory[];
  attachments: AttachmentMemory[];
}

export interface TraumaMemory {
  id: string;
  event: string;
  severity: number;
  yBaseShift: number;
  triggerWords: string[];
}

export interface JoyMemory {
  id: string;
  event: string;
  intensity: number;
  associatedPeople: string[];
}

export interface AttachmentMemory {
  targetId: string;
  strength: number;  // 依恋强度
  type: 'secure' | 'anxious' | 'avoidant' | 'disorganized';
}

/**
 * 核心记忆（人格基石）
 */
export interface CoreMemory {
  identity: string;           // 自我认知
  values: Value[];            // 核心价值观
  beliefs: Belief[];          // 核心信念
  purpose: string;            // 人生目标
}

export interface Value {
  name: string;
  priority: number;  // 1-10
  flexibility: number;  // 可妥协程度
}

export interface Belief {
  content: string;
  certainty: number;  // 确信程度
  evidence: string[];
}
```

**Step 4: 创建索引文件**

```typescript
// src/types/index.ts
export * from './core';
export * from './mbti';
export * from './memory';
```

**Step 5: 提交**

```bash
git add .
git commit -m "feat(types): add core, mbti, and memory type definitions"
```

---

### Task 3: Y值计算引擎

**Files:**
- Create: `tiandao-system/src/core/yvalue.ts`
- Create: `tiandao-system/tests/core/yvalue.test.ts`

**Step 1: 创建Y值计算引擎**

```typescript
// src/core/yvalue.ts
import { YValue, YLevel, CharacterState, TraumaFlag } from '../types';

/**
 * Y值计算引擎
 * 核心逻辑：计算人物在特定情境下的Y值变化
 */
export class YValueEngine {
  
  /**
   * 计算基础Y值（考虑MBTI和创伤）
   */
  static calculateBaseYValue(
    mbtiBase: number,
    traumaFlags: TraumaFlag[],
    willpower: number
  ): YValue {
    // MBTI基础影响 (-10 到 +10)
    let base = 60 + mbtiBase;
    
    // 创伤基线偏移
    for (const trauma of traumaFlags) {
      if (trauma.permanent) {
        base += trauma.yBaseShift;
      }
    }
    
    // 意志力加成（意志力高时Y值更稳定）
    const willpowerBonus = (willpower - 50) * 0.2;
    base += willpowerBonus;
    
    // 限制在有效范围内
    return Math.max(20, Math.min(100, base));
  }
  
  /**
   * 计算Y值等级
   */
  static getYLevel(yValue: YValue): YLevel {
    if (yValue <= 0) return YLevel.COLLAPSED;
    if (yValue < 30) return YLevel.FRAGMENTED;
    if (yValue < 50) return YLevel.UNSTABLE;
    if (yValue < 65) return YLevel.NORMAL;
    if (yValue < 75) return YLevel.STABLE;
    if (yValue < 90) return YLevel.DOMINANT;
    return YLevel.OVERWHELMING;
  }
  
  /**
   * 计算两个角色间的Y值差值影响
   * 差值越大，低Y值角色受到的影响越大
   */
  static calculateYDifferenceImpact(
    higherY: YValue,
    lowerY: YValue
  ): {
    pressureOnLower: number;  // 对低Y值角色的压力
    dominanceFactor: number;  // 支配系数
  } {
    const diff = higherY - lowerY;
    
    // 差值影响非线性增长
    const pressureOnLower = Math.pow(diff / 10, 1.5);
    
    // 支配系数：高Y值对低Y值的控制程度
    const dominanceFactor = diff > 20 
      ? Math.min(1, (diff - 20) / 40) 
      : 0;
    
    return { pressureOnLower, dominanceFactor };
  }
  
  /**
   * 应用Y值变化（带边界检查）
   */
  static applyYChange(
    currentY: YValue,
    change: number,
    yMin: YValue,
    yMax: YValue
  ): YValue {
    let newY = currentY + change;
    
    // 应用边界
    newY = Math.max(yMin, Math.min(yMax, newY));
    
    // 死亡检查
    if (newY <= 0) {
      return 0; // 意识崩溃/死亡
    }
    
    return newY;
  }
  
  /**
   * 计算Y值恢复（回弹机制）
   */
  static calculateRecovery(
    currentY: YValue,
    yBase: YValue,
    timeElapsed: number,  // 毫秒
    recoveryRate: number
  ): number {
    const distance = yBase - currentY;
    if (distance <= 0) return 0;
    
    // 恢复速率随时间递减
    const timeFactor = Math.exp(-timeElapsed / (3600000 * recoveryRate)); // 1小时基准
    const recovery = distance * (1 - timeFactor) * 0.1; // 每次最多恢复10%
    
    return Math.min(distance, recovery);
  }
}
```

**Step 2: 创建测试**

```typescript
// tests/core/yvalue.test.ts
import { YValueEngine, YLevel } from '../../src/core/yvalue';

describe('YValueEngine', () => {
  describe('calculateBaseYValue', () => {
    it('should calculate base Y value with MBTI modifier', () => {
      const result = YValueEngine.calculateBaseYValue(5, [], 50);
      expect(result).toBe(65); // 60 + 5
    });
    
    it('should apply trauma base shift', () => {
      const traumas = [{ type: 'test' as any, severity: 5, permanent: true, yBaseShift: 10 }];
      const result = YValueEngine.calculateBaseYValue(0, traumas, 50);
      expect(result).toBe(70); // 60 + 0 + 10
    });
    
    it('should apply willpower bonus', () => {
      const result = YValueEngine.calculateBaseYValue(0, [], 100);
      expect(result).toBe(70); // 60 + (50 * 0.2)
    });
    
    it('should clamp to valid range', () => {
      const result = YValueEngine.calculateBaseYValue(-50, [], 0);
      expect(result).toBe(20); // min clamp
    });
  });
  
  describe('getYLevel', () => {
    it('should return COLLAPSED for Y <= 0', () => {
      expect(YValueEngine.getYLevel(0)).toBe(YLevel.COLLAPSED);
    });
    
    it('should return DOMINANT for Y >= 80', () => {
      expect(YValueEngine.getYLevel(85)).toBe(YLevel.DOMINANT);
    });
    
    it('should return OVERWHELMING for Y >= 90', () => {
      expect(YValueEngine.getYLevel(95)).toBe(YLevel.OVERWHELMING);
    });
  });
  
  describe('calculateYDifferenceImpact', () => {
    it('should calculate pressure based on difference', () => {
      const result = YValueEngine.calculateYDifferenceImpact(80, 60);
      expect(result.pressureOnLower).toBeGreaterThan(0);
      expect(result.dominanceFactor).toBeGreaterThan(0);
    });
    
    it('should have zero dominance for small differences', () => {
      const result = YValueEngine.calculateYDifferenceImpact(70, 60);
      expect(result.dominanceFactor).toBe(0);
    });
  });
  
  describe('applyYChange', () => {
    it('should apply positive change', () => {
      const result = YValueEngine.applyYChange(60, 10, 20, 100);
      expect(result).toBe(70);
    });
    
    it('should respect upper bound', () => {
      const result = YValueEngine.applyYChange(90, 20, 20, 100);
      expect(result).toBe(100);
    });
    
    it('should return 0 for death', () => {
      const result = YValueEngine.applyYChange(10, -20, 20, 100);
      expect(result).toBe(0);
    });
  });
});
```

**Step 3: 运行测试**

```bash
npm test -- tests/core/yvalue.test.ts
```

**Step 4: 提交**

```bash
git add .
git commit -m "feat(core): implement Y-value calculation engine with tests"
```

---

### Task 4: MBTI人格模块

**Files:**
- Create: `tiandao-system/src/core/mbti.ts`
- Create: `tiandao-system/src/data/mbti-profiles.ts`
- Create: `tiandao-system/tests/core/mbti.test.ts`

**Step 1: 创建MBTI数据配置**

```typescript
// src/data/mbti-profiles.ts
import { MBTIWeights } from '../types';

export const MBTI_PROFILES: Record<string, MBTIWeights> = {
  INTJ: {
    type: 'INTJ',
    dimensions: { ei: -7, sn: -5, tf: 8, jp: 9 },
    yModifiers: {
      dominance: 0.8,
      resilience: 0.9,
      empathy: -0.3,
      logic: 1.0,
    },
    emotionPatterns: {
      triggerThreshold: 0.7,
      recoveryRate: 0.6,
      intensityMultiplier: 0.8,
    },
  },
  INTP: {
    type: 'INTP',
    dimensions: { ei: -8, sn: -6, tf: 5, jp: -7 },
    yModifiers: {
      dominance: 0.3,
      resilience: 0.6,
      empathy: -0.2,
      logic: 0.9,
    },
    emotionPatterns: {
      triggerThreshold: 0.8,
      recoveryRate: 0.7,
      intensityMultiplier: 0.6,
    },
  },
  ENTJ: {
    type: 'ENTJ',
    dimensions: { ei: 8, sn: -3, tf: 9, jp: 9 },
    yModifiers: {
      dominance: 1.0,
      resilience: 0.8,
      empathy: -0.4,
      logic: 0.9,
    },
    emotionPatterns: {
      triggerThreshold: 0.5,
      recoveryRate: 0.8,
      intensityMultiplier: 1.0,
    },
  },
  ENTP: {
    type: 'ENTP',
    dimensions: { ei: 7, sn: -5, tf: 5, jp: -6 },
    yModifiers: {
      dominance: 0.6,
      resilience: 0.7,
      empathy: -0.1,
      logic: 0.7,
    },
    emotionPatterns: {
      triggerThreshold: 0.6,
      recoveryRate: 0.9,
      intensityMultiplier: 0.9,
    },
  },
  INFJ: {
    type: 'INFJ',
    dimensions: { ei: -5, sn: -3, tf: -7, jp: 6 },
    yModifiers: {
      dominance: 0.2,
      resilience: 0.5,
      empathy: 1.0,
      logic: 0.4,
    },
    emotionPatterns: {
      triggerThreshold: 0.4,
      recoveryRate: 0.4,
      intensityMultiplier: 1.2,
    },
  },
  INFP: {
    type: 'INFP',
    dimensions: { ei: -7, sn: -4, tf: -8, jp: -8 },
    yModifiers: {
      dominance: -0.2,
      resilience: 0.3,
      empathy: 0.9,
      logic: 0.3,
    },
    emotionPatterns: {
      triggerThreshold: 0.3,
      recoveryRate: 0.3,
      intensityMultiplier: 1.3,
    },
  },
  // ... 其他类型继续添加
};
```

**Step 2: 创建MBTI引擎**

```typescript
// src/core/mbti.ts
import { MBTIType, MBTIWeights, CharacterState } from '../types';
import { MBTI_PROFILES } from '../data/mbti-profiles';

/**
 * MBTI人格引擎
 */
export class MBTIEngine {
  
  /**
   * 获取MBTI配置
   */
  static getProfile(type: MBTIType): MBTIWeights {
    const profile = MBTI_PROFILES[type];
    if (!profile) {
      throw new Error(`Unknown MBTI type: ${type}`);
    }
    return profile;
  }
  
  /**
   * 计算MBTI对Y值的基础影响
   */
  static calculateYBaseModifier(type: MBTIType): number {
    const profile = this.getProfile(type);
    const { dimensions, yModifiers } = profile;
    
    // 综合各维度计算Y值基础偏移
    let modifier = 0;
    
    // E/I 影响：外向更自信，内向更内敛
    modifier += dimensions.ei * 0.3;
    
    // T/F 影响：思考型更稳定，情感型更易波动
    modifier += dimensions.tf * 0.2;
    
    // J/P 影响：判断型更有主见，感知型更灵活
    modifier += dimensions.jp * 0.3;
    
    // 应用Y值修正器
    modifier += yModifiers.dominance * 5;
    modifier += yModifiers.resilience * 3;
    
    return modifier;
  }
  
  /**
   * 计算情绪响应
   */
  static calculateEmotionResponse(
    type: MBTIType,
    stimulusIntensity: number,
    isNegative: boolean
  ): {
    intensity: number;
    duration: number;
    recoveryRate: number;
  } {
    const profile = this.getProfile(type);
    const { emotionPatterns } = profile;
    
    // 是否触发情绪反应
    if (stimulusIntensity < emotionPatterns.triggerThreshold) {
      return { intensity: 0, duration: 0, recoveryRate: 0 };
    }
    
    // 计算情绪强度
    const intensity = stimulusIntensity * emotionPatterns.intensityMultiplier;
    
    // 计算持续时间（毫秒）
    const duration = intensity * 60000 * (isNegative ? 1.5 : 1);
    
    return {
      intensity: Math.min(10, intensity),
      duration,
      recoveryRate: emotionPatterns.recoveryRate,
    };
  }
  
  /**
   * 计算人格间的相性
   */
  static calculateCompatibility(type1: MBTIType, type2: MBTIType): number {
    const p1 = this.getProfile(type1);
    const p2 = this.getProfile(type2);
    
    // 计算维度相似度
    const eiDiff = Math.abs(p1.dimensions.ei - p2.dimensions.ei);
    const snDiff = Math.abs(p1.dimensions.sn - p2.dimensions.sn);
    const tfDiff = Math.abs(p1.dimensions.tf - p2.dimensions.tf);
    const jpDiff = Math.abs(p1.dimensions.jp - p2.dimensions.jp);
    
    // 总差异（越低越相似）
    const totalDiff = eiDiff + snDiff + tfDiff + jpDiff;
    
    // 转换为相性分数（0-1）
    const compatibility = Math.max(0, 1 - totalDiff / 40);
    
    return compatibility;
  }
}
```

**Step 3: 创建测试**

```typescript
// tests/core/mbti.test.ts
import { MBTIEngine } from '../../src/core/mbti';

describe('MBTIEngine', () => {
  describe('getProfile', () => {
    it('should return profile for valid type', () => {
      const profile = MBTIEngine.getProfile('INTJ');
      expect(profile.type).toBe('INTJ');
      expect(profile.dimensions).toBeDefined();
    });
    
    it('should throw for invalid type', () => {
      expect(() => MBTIEngine.getProfile('INVALID' as any)).toThrow();
    });
  });
  
  describe('calculateYBaseModifier', () => {
    it('should calculate modifier for INTJ', () => {
      const modifier = MBTIEngine.calculateYBaseModifier('INTJ');
      expect(typeof modifier).toBe('number');
    });
  });
  
  describe('calculateEmotionResponse', () => {
    it('should return zero for weak stimulus', () => {
      const response = MBTIEngine.calculateEmotionResponse('INTJ', 0.3, false);
      expect(response.intensity).toBe(0);
    });
    
    it('should calculate response for strong stimulus', () => {
      const response = MBTIEngine.calculateEmotionResponse('INTJ', 0.9, true);
      expect(response.intensity).toBeGreaterThan(0);
      expect(response.duration).toBeGreaterThan(0);
    });
  });
  
  describe('calculateCompatibility', () => {
    it('should return high compatibility for same type', () => {
      const compat = MBTIEngine.calculateCompatibility('INTJ', 'INTJ');
      expect(compat).toBe(1);
    });
    
    it('should return lower compatibility for different types', () => {
      const compat = MBTIEngine.calculateCompatibility('INTJ', 'ESFP');
      expect(compat).toBeLessThan(1);
    });
  });
});
```

**Step 4: 运行测试并提交**

```bash
npm test -- tests/core/mbti.test.ts
git add .
git commit -m "feat(core): implement MBTI personality engine with profiles"
```

---

### Task 5: 三大机制实现（触发/补偿/回弹）

**Files:**
- Create: `tiandao-system/src/mechanisms/trigger.ts`
- Create: `tiandao-system/src/mechanisms/compensation.ts`
- Create: `tiandao-system/src/mechanisms/rebound.ts`
- Create: `tiandao-system/tests/mechanisms/trigger.test.ts`

**Step 1: 触发机制**

```typescript
// src/mechanisms/trigger.ts
import { CharacterState, YValue } from '../types';
import { YValueEngine } from '../core/yvalue';

/**
 * 触发机制：外部刺激导致Y值变化
 */
export interface TriggerEvent {
  type: TriggerType;
  source: string;        // 触发源（人物ID或事件）
  intensity: number;     // 强度 (0-10)
  targetEmotion?: string; // 目标情绪
  description: string;   // 描述
}

export enum TriggerType {
  DOMINATION = 'domination',     // 被支配/碾压
  BREAKTHROUGH = 'breakthrough', // 被击穿
  INSPIRATION = 'inspiration',   // 启发/共鸣
  THREAT = 'threat',             // 威胁
  LOSS = 'loss',                 // 失去
  GAIN = 'gain',                 // 获得
}

/**
 * 触发机制引擎
 */
export class TriggerMechanism {
  
  /**
   * 处理触发事件
   */
  static processTrigger(
    character: CharacterState,
    event: TriggerEvent,
    sourceY: YValue  // 触发源的Y值
  ): {
    yChange: number;
    newY: YValue;
    emotionalImpact: Record<string, number>;
    isBroken: boolean;  // 是否被击穿
  } {
    let yChange = 0;
    const emotionalImpact: Record<string, number> = {};
    
    // 计算Y值差值影响
    const { pressureOnLower } = YValueEngine.calculateYDifferenceImpact(
      sourceY,
      character.yValue
    );
    
    switch (event.type) {
      case TriggerType.DOMINATION:
        // 被高Y值支配：Y值下降
        yChange = -event.intensity * (1 + pressureOnLower * 0.5);
        emotionalImpact.fear = event.intensity * 0.8;
        break;
        
      case TriggerType.BREAKTHROUGH:
        // 被击穿：Y值大幅下降
        yChange = -event.intensity * 2;
        emotionalImpact.sorrow = event.intensity;
        emotionalImpact.fear = event.intensity * 0.5;
        break;
        
      case TriggerType.INSPIRATION:
        // 被启发：Y值可能上升或下降（取决于共鸣）
        const resonance = this.calculateResonance(character, event.source);
        yChange = event.intensity * resonance * 0.5;
        emotionalImpact.joy = Math.abs(yChange) * 0.5;
        break;
        
      case TriggerType.THREAT:
        // 威胁：Y值下降，但高Y值角色下降较少
        const threatResistance = character.yValue / 100;
        yChange = -event.intensity * (1 - threatResistance * 0.5);
        emotionalImpact.fear = event.intensity * (1 - threatResistance);
        emotionalImpact.anger = event.intensity * threatResistance;
        break;
        
      case TriggerType.LOSS:
        // 失去：Y值下降，与失去的重要性相关
        yChange = -event.intensity * 1.5;
        emotionalImpact.sorrow = event.intensity;
        break;
        
      case TriggerType.GAIN:
        // 获得：Y值上升
        yChange = event.intensity * 0.8;
        emotionalImpact.joy = event.intensity;
        break;
    }
    
    // 应用Y值变化
    const newY = YValueEngine.applyYChange(
      character.yValue,
      yChange,
      character.yMin,
      character.yMax
    );
    
    // 检查是否被击穿（Y值降至基线以下超过20%）
    const isBroken = newY < character.yBase * 0.8;
    
    return {
      yChange,
      newY,
      emotionalImpact,
      isBroken,
    };
  }
  
  /**
   * 计算共鸣度（-1到1）
   */
  private static calculateResonance(
    character: CharacterState,
    source: string
  ): number {
    // 简化实现：基于MBTI相性
    // 实际应查询source的MBTI类型
    return Math.random() * 2 - 1; // 临时随机值
  }
}
```

**Step 2: 补偿机制**

```typescript
// src/mechanisms/compensation.ts
import { CharacterState, YValue } from '../types';

/**
 * 补偿机制：Y值下降后的自我保护反应
 */
export interface CompensationResult {
  type: CompensationType;
  yRecovery: number;           // Y值恢复量
  willpowerCost: number;       // 意志力消耗
  sideEffects: SideEffect[];   // 副作用
}

export enum CompensationType {
  AGGRESSION = 'aggression',     // 攻击性补偿（反击）
  WITHDRAWAL = 'withdrawal',     // 退缩性补偿（逃避）
  RATIONALIZATION = 'rationalization', // 合理化（自我欺骗）
  SUBLIMATION = 'sublimation',   // 升华（转化为创作/工作动力）
  NONE = 'none',                 // 无补偿（崩溃边缘）
}

export interface SideEffect {
  type: string;
  severity: number;
  duration: number;
}

/**
 * 补偿机制引擎
 */
export class CompensationMechanism {
  
  /**
   * 计算补偿反应
   */
  static calculateCompensation(
    character: CharacterState,
    yDrop: number,  // Y值下降幅度
    triggerSource: string
  ): CompensationResult {
    const willpower = character.willpower.current;
    const mbti = character.mbti;
    
    // 根据MBTI和意志力决定补偿类型
    let type = this.determineCompensationType(mbti, willpower, yDrop);
    
    let yRecovery = 0;
    let willpowerCost = 0;
    const sideEffects: SideEffect[] = [];
    
    switch (type) {
      case CompensationType.AGGRESSION:
        // 攻击性补偿：消耗大量意志力，小幅恢复Y值
        yRecovery = yDrop * 0.3;
        willpowerCost = 30;
        sideEffects.push({
          type: 'relationship_damage',
          severity: yDrop * 0.5,
          duration: 86400000, // 1天
        });
        break;
        
      case CompensationType.WITHDRAWAL:
        // 退缩性补偿：消耗中等意志力，中幅恢复Y值
        yRecovery = yDrop * 0.5;
        willpowerCost = 20;
        sideEffects.push({
          type: 'social_isolation',
          severity: yDrop * 0.3,
          duration: 172800000, // 2天
        });
        break;
        
      case CompensationType.RATIONALIZATION:
        // 合理化：消耗少量意志力，小幅恢复Y值，但产生认知偏差
        yRecovery = yDrop * 0.2;
        willpowerCost = 10;
        sideEffects.push({
          type: 'cognitive_bias',
          severity: yDrop * 0.4,
          duration: 604800000, // 7天
        });
        break;
        
      case CompensationType.SUBLIMATION:
        // 升华：消耗中等意志力，中幅恢复Y值，正面副作用
        yRecovery = yDrop * 0.4;
        willpowerCost = 25;
        sideEffects.push({
          type: 'productivity_boost',
          severity: yDrop * 0.3,
          duration: 259200000, // 3天
        });
        break;
        
      case CompensationType.NONE:
        // 无补偿：意志力耗尽，无法恢复
        yRecovery = 0;
        willpowerCost = 0;
        sideEffects.push({
          type: 'vulnerability',
          severity: 10,
          duration: -1, // 持续到意志力恢复
        });
        break;
    }
    
    return {
      type,
      yRecovery,
      willpowerCost,
      sideEffects,
    };
  }
  
  /**
   * 确定补偿类型
   */
  private static determineCompensationType(
    mbti: string,
    willpower: number,
    yDrop: number
  ): CompensationType {
    // 意志力耗尽时无法补偿
    if (willpower < 10) {
      return CompensationType.NONE;
    }
    
    // 根据MBTI倾向选择
    const typeMap: Record<string, CompensationType> = {
      'INTJ': CompensationType.RATIONALIZATION,
      'INTP': CompensationType.RATIONALIZATION,
      'ENTJ': CompensationType.AGGRESSION,
      'ENTP': CompensationType.AGGRESSION,
      'INFJ': CompensationType.SUBLIMATION,
      'INFP': CompensationType.WITHDRAWAL,
      'ENFJ': CompensationType.SUBLIMATION,
      'ENFP': CompensationType.SUBLIMATION,
      'ISTJ': CompensationType.WITHDRAWAL,
      'ISFJ': CompensationType.WITHDRAWAL,
      'ESTJ': CompensationType.AGGRESSION,
      'ESFJ': CompensationType.SUBLIMATION,
      'ISTP': CompensationType.WITHDRAWAL,
      'ISFP': CompensationType.WITHDRAWAL,
      'ESTP': CompensationType.AGGRESSION,
      'ESFP': CompensationType.AGGRESSION,
    };
    
    return typeMap[mbti] || CompensationType.RATIONALIZATION;
  }
}
```

**Step 3: 回弹机制**

```typescript
// src/mechanisms/rebound.ts
import { CharacterState, YValue } from '../types';
import { YValueEngine } from '../core/yvalue';

/**
 * 回弹机制：Y值向基线恢复的倾向
 */
export interface ReboundState {
  isRebounding: boolean;
  targetY: YValue;
  recoveryRate: number;
  estimatedTime: number;  // 预计恢复时间（毫秒）
}

/**
 * 回弹机制引擎
 */
export class ReboundMechanism {
  
  /**
   * 计算回弹状态
   */
  static calculateRebound(
    character: CharacterState,
    timeSinceEvent: number  // 距离上次事件的时间（毫秒）
  ): ReboundState {
    const currentY = character.yValue;
    const baseY = character.yBase;
    
    // 如果Y值高于基线，不回弹（保持高位）
    if (currentY >= baseY) {
      return {
        isRebounding: false,
        targetY: currentY,
        recoveryRate: 0,
        estimatedTime: 0,
      };
    }
    
    // 计算与基线的距离
    const distance = baseY - currentY;
    
    // 根据MBTI确定恢复速率
    const baseRecoveryRate = this.getRecoveryRateByMBTI(character.mbti);
    
    // 时间衰减因子（越久恢复越慢）
    const timeFactor = Math.exp(-timeSinceEvent / 3600000); // 1小时基准
    const recoveryRate = baseRecoveryRate * (0.3 + 0.7 * timeFactor);
    
    // 计算预计恢复时间
    const estimatedTime = distance / recoveryRate;
    
    return {
      isRebounding: true,
      targetY: baseY,
      recoveryRate,
      estimatedTime,
    };
  }
  
  /**
   * 应用回弹效果
   */
  static applyRebound(
    character: CharacterState,
    elapsedTime: number
  ): {
    newY: YValue;
    recoveredAmount: number;
  } {
    const rebound = this.calculateRebound(character, elapsedTime);
    
    if (!rebound.isRebounding) {
      return { newY: character.yValue, recoveredAmount: 0 };
    }
    
    // 计算恢复量
    const recoveredAmount = rebound.recoveryRate * elapsedTime / 1000;
    const clampedRecovery = Math.min(
      recoveredAmount,
      rebound.targetY - character.yValue
    );
    
    const newY = YValueEngine.applyYChange(
      character.yValue,
      clampedRecovery,
      character.yMin,
      character.yMax
    );
    
    return { newY, recoveredAmount: clampedRecovery };
  }
  
  /**
   * 获取MBTI对应的恢复速率
   */
  private static getRecoveryRateByMBTI(mbti: string): number {
    // 恢复速率：单位Y值/秒
    const rates: Record<string, number> = {
      'INTJ': 0.02,
      'INTP': 0.015,
      'ENTJ': 0.03,
      'ENTP': 0.025,
      'INFJ': 0.01,
      'INFP': 0.008,
      'ENFJ': 0.02,
      'ENFP': 0.015,
      'ISTJ': 0.025,
      'ISFJ': 0.02,
      'ESTJ': 0.03,
      'ESFJ': 0.025,
      'ISTP': 0.02,
      'ISFP': 0.015,
      'ESTP': 0.03,
      'ESFP': 0.025,
    };
    
    return rates[mbti] || 0.02;
  }
}
```

**Step 4: 创建测试**

```typescript
// tests/mechanisms/trigger.test.ts
import { TriggerMechanism, TriggerType, TriggerEvent } from '../../src/mechanisms/trigger';
import { CharacterState } from '../../src/types';

describe('TriggerMechanism', () => {
  const mockCharacter: CharacterState = {
    id: 'test',
    name: 'Test',
    yValue: 60,
    yBase: 60,
    yMax: 80,
    yMin: 40,
    mbti: 'INTJ',
    emotions: {} as any,
    willpower: { current: 80, max: 100, regeneration: 1 },
    traumaFlags: [],
    isDead: false,
  };
  
  describe('processTrigger', () => {
    it('should decrease Y value for DOMINATION trigger', () => {
      const event: TriggerEvent = {
        type: TriggerType.DOMINATION,
        source: 'dominator',
        intensity: 5,
        description: 'test',
      };
      
      const result = TriggerMechanism.processTrigger(mockCharacter, event, 80);
      expect(result.yChange).toBeLessThan(0);
      expect(result.newY).toBeLessThan(mockCharacter.yValue);
    });
    
    it('should increase Y value for GAIN trigger', () => {
      const event: TriggerEvent = {
        type: TriggerType.GAIN,
        source: 'reward',
        intensity: 5,
        description: 'test',
      };
      
      const result = TriggerMechanism.processTrigger(mockCharacter, event, 60);
      expect(result.yChange).toBeGreaterThan(0);
      expect(result.newY).toBeGreaterThan(mockCharacter.yValue);
    });
    
    it('should detect breakthrough when Y drops significantly', () => {
      const event: TriggerEvent = {
        type: TriggerType.BREAKTHROUGH,
        source: 'attacker',
        intensity: 8,
        description: 'test',
      };
      
      const result = TriggerMechanism.processTrigger(mockCharacter, event, 90);
      expect(result.isBroken).toBe(true);
    });
  });
});
```

**Step 5: 运行测试并提交**

```bash
npm test -- tests/mechanisms/
git add .
git commit -m "feat(mechanisms): implement trigger, compensation, and rebound mechanisms"
```

---

### Task 6: JSON心理档案系统

**Files:**
- Create: `tiandao-system/src/core/psych-profile.ts`
- Create: `tiandao-system/src/schemas/psych-profile.json`
- Create: `tiandao-system/tests/core/psych-profile.test.ts`

**Step 1: 创建JSON Schema**

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Psychological Profile",
  "type": "object",
  "required": ["id", "name", "mbti", "yValue"],
  "properties": {
    "id": {
      "type": "string",
      "description": "角色唯一标识"
    },
    "name": {
      "type": "string",
      "description": "角色名称"
    },
    "mbti": {
      "type": "string",
      "enum": ["INTJ", "INTP", "ENTJ", "ENTP", "INFJ", "INFP", "ENFJ", "ENFP", "ISTJ", "ISFJ", "ESTJ", "ESFJ", "ISTP", "ISFP", "ESTP", "ESFP"],
      "description": "MBTI人格类型"
    },
    "yValue": {
      "type": "object",
      "required": ["current", "base", "min", "max"],
      "properties": {
        "current": { "type": "number", "minimum": 0, "maximum": 100 },
        "base": { "type": "number", "minimum": 20, "maximum": 100 },
        "min": { "type": "number", "minimum": 0, "maximum": 100 },
        "max": { "type": "number", "minimum": 20, "maximum": 100 }
      }
    },
    "emotions": {
      "type": "object",
      "properties": {
        "joy": { "type": "number", "minimum": 0, "maximum": 10 },
        "anger": { "type": "number", "minimum": 0, "maximum": 10 },
        "sorrow": { "type": "number", "minimum": 0, "maximum": 10 },
        "fear": { "type": "number", "minimum": 0, "maximum": 10 },
        "love": { "type": "number", "minimum": 0, "maximum": 10 },
        "hate": { "type": "number", "minimum": 0, "maximum": 10 },
        "desire": { "type": "number", "minimum": 0, "maximum": 10 }
      }
    },
    "willpower": {
      "type": "object",
      "properties": {
        "current": { "type": "number", "minimum": 0, "maximum": 100 },
        "max": { "type": "number", "minimum": 0, "maximum": 100 },
        "regeneration": { "type": "number", "minimum": 0 }
      }
    },
    "traumaFlags": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "type": { "type": "string" },
          "severity": { "type": "number", "minimum": 1, "maximum": 10 },
          "permanent": { "type": "boolean" },
          "yBaseShift": { "type": "number" }
        }
      }
    },
    "coreMemory": {
      "type": "object",
      "properties": {
        "identity": { "type": "string" },
        "values": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "name": { "type": "string" },
              "priority": { "type": "number", "minimum": 1, "maximum": 10 },
              "flexibility": { "type": "number", "minimum": 0, "maximum": 1 }
            }
          }
        },
        "beliefs": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "content": { "type": "string" },
              "certainty": { "type": "number", "minimum": 0, "maximum": 1 }
            }
          }
        },
        "purpose": { "type": "string" }
      }
    },
    "metadata": {
      "type": "object",
      "properties": {
        "version": { "type": "string" },
        "createdAt": { "type": "string", "format": "date-time" },
        "updatedAt": { "type": "string", "format": "date-time" },
        "author": { "type": "string" }
      }
    }
  }
}
```

**Step 2: 创建心理档案管理器**

```typescript
// src/core/psych-profile.ts
import { CharacterState, MBTIType } from '../types';
import * as fs from 'fs';
import * as path from 'path';

/**
 * 心理档案管理器
 */
export class PsychProfileManager {
  private profilesDir: string;
  
  constructor(profilesDir: string = './profiles') {
    this.profilesDir = profilesDir;
    if (!fs.existsSync(profilesDir)) {
      fs.mkdirSync(profilesDir, { recursive: true });
    }
  }
  
  /**
   * 创建新角色档案
   */
  createProfile(
    id: string,
    name: string,
    mbti: MBTIType,
    options: Partial<CharacterState> = {}
  ): CharacterState {
    const profile: CharacterState = {
      id,
      name,
      mbti,
      yValue: options.yValue ?? 60,
      yBase: options.yBase ?? 60,
      yMin: options.yMin ?? 20,
      yMax: options.yMax ?? 100,
      emotions: options.emotions ?? {
        joy: 5, anger: 0, sorrow: 0, fear: 0,
        love: 0, hate: 0, desire: 5,
      },
      willpower: options.willpower ?? {
        current: 80, max: 100, regeneration: 1,
      },
      traumaFlags: options.traumaFlags ?? [],
      isDead: false,
      ...options,
    };
    
    this.saveProfile(profile);
    return profile;
  }
  
  /**
   * 保存档案到文件
   */
  saveProfile(profile: CharacterState): void {
    const filePath = path.join(this.profilesDir, `${profile.id}.json`);
    const data = {
      ...profile,
      metadata: {
        version: '1.0.0',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    };
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  }
  
  /**
   * 加载档案
   */
  loadProfile(id: string): CharacterState | null {
    const filePath = path.join(this.profilesDir, `${id}.json`);
    if (!fs.existsSync(filePath)) {
      return null;
    }
    
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    return data as CharacterState;
  }
  
  /**
   * 列出所有档案
   */
  listProfiles(): string[] {
    const files = fs.readdirSync(this.profilesDir);
    return files
      .filter(f => f.endsWith('.json'))
      .map(f => f.replace('.json', ''));
  }
  
  /**
   * 删除档案
   */
  deleteProfile(id: string): boolean {
    const filePath = path.join(this.profilesDir, `${id}.json`);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  }
  
  /**
   * 更新档案
   */
  updateProfile(
    id: string,
    updates: Partial<CharacterState>
  ): CharacterState | null {
    const profile = this.loadProfile(id);
    if (!profile) return null;
    
    const updated = { ...profile, ...updates };
    this.saveProfile(updated);
    return updated;
  }
  
  /**
   * 导出为SillyTavern格式
   */
  exportToSillyTavern(profile: CharacterState): object {
    return {
      name: profile.name,
      description: this.generateDescription(profile),
      personality: this.generatePersonality(profile),
      scenario: '',
      first_mes: '',
      mes_example: '',
      creatorcomment: `MBTI: ${profile.mbti}, Y-Value: ${profile.yValue}`,
      tags: [profile.mbti, 'tiandao-system'],
    };
  }
  
  /**
   * 生成角色描述
   */
  private generateDescription(profile: CharacterState): string {
    return `[${profile.mbti}型人格 | Y值:${profile.yValue}]
${profile.name}是一个主观意识凝练强度为${profile.yValue}的角色。
基线Y值:${profile.yBase}，当前意志力:${profile.willpower.current}。
${profile.traumaFlags.length > 0 ? `携带${profile.traumaFlags.length}个创伤标记。` : ''}`;
  }
  
  /**
   * 生成性格描述
   */
  private generatePersonality(profile: CharacterState): string {
    return `MBTI: ${profile.mbti}
Y值系统: ${profile.yValue}/${profile.yMax}
意志力: ${profile.willpower.current}/${profile.willpower.max}
核心情绪: 喜${profile.emotions.joy} 怒${profile.emotions.anger} 哀${profile.emotions.sorrow} 惧${profile.emotions.fear}`;
  }
}
```

**Step 3: 创建测试**

```typescript
// tests/core/psych-profile.test.ts
import { PsychProfileManager } from '../../src/core/psych-profile';
import * as fs from 'fs';
import * as path from 'path';

describe('PsychProfileManager', () => {
  const testDir = './test-profiles';
  let manager: PsychProfileManager;
  
  beforeEach(() => {
    if (fs.existsSync(testDir)) {
      fs.rmSync(testDir, { recursive: true });
    }
    manager = new PsychProfileManager(testDir);
  });
  
  afterEach(() => {
    if (fs.existsSync(testDir)) {
      fs.rmSync(testDir, { recursive: true });
    }
  });
  
  describe('createProfile', () => {
    it('should create a new profile', () => {
      const profile = manager.createProfile('test-1', 'Test Character', 'INTJ');
      expect(profile.id).toBe('test-1');
      expect(profile.name).toBe('Test Character');
      expect(profile.mbti).toBe('INTJ');
      expect(profile.yValue).toBe(60);
    });
    
    it('should save profile to file', () => {
      manager.createProfile('test-2', 'Test', 'ENTP');
      const filePath = path.join(testDir, 'test-2.json');
      expect(fs.existsSync(filePath)).toBe(true);
    });
  });
  
  describe('loadProfile', () => {
    it('should load existing profile', () => {
      manager.createProfile('test-3', 'Test', 'INFJ');
      const loaded = manager.loadProfile('test-3');
      expect(loaded).not.toBeNull();
      expect(loaded?.name).toBe('Test');
    });
    
    it('should return null for non-existent profile', () => {
      const loaded = manager.loadProfile('non-existent');
      expect(loaded).toBeNull();
    });
  });
  
  describe('exportToSillyTavern', () => {
    it('should export in SillyTavern format', () => {
      const profile = manager.createProfile('test-4', 'Test', 'INTJ');
      const exported = manager.exportToSillyTavern(profile);
      expect(exported.name).toBe('Test');
      expect(exported.tags).toContain('INTJ');
    });
  });
});
```

**Step 4: 运行测试并提交**

```bash
npm test -- tests/core/psych-profile.test.ts
git add .
git commit -m "feat(core): implement JSON psychological profile system with SillyTavern export"
```

---

### Task 7: 人道系统权重体系

**Files:**
- Create: `tiandao-system/src/humanway/weights.ts`
- Create: `tiandao-system/src/humanway/interaction.ts`
- Create: `tiandao-system/tests/humanway/weights.test.ts`

**Step 1: 创建权重体系**

```typescript
// src/humanway/weights.ts

/**
 * 人道系统权重体系
 * 模拟社会资源分配的马太效应
 */

/**
 * 资源类型
 */
export enum ResourceType {
  SOCIAL_CAPITAL = 'social_capital',     // 社会资本
  ECONOMIC_CAPITAL = 'economic_capital', // 经济资本
  CULTURAL_CAPITAL = 'cultural_capital', // 文化资本
  POLITICAL_CAPITAL = 'political_capital', // 政治资本
}

/**
 * 权重配置
 */
export interface WeightConfig {
  resourceType: ResourceType;
  baseValue: number;           // 基础值
  growthRate: number;          // 增长率
  decayRate: number;           // 衰减率
  transferRate: number;        // 转移率（从他人获取）
  lossRate: number;            // 损失率（被他人获取）
}

/**
 * 角色权重状态
 */
export interface CharacterWeights {
  characterId: string;
  resources: Record<ResourceType, number>;
  influence: number;           // 影响力指数
  vulnerability: number;       // 脆弱性指数
  lastUpdated: number;         // 时间戳
}

/**
 * 人道权重引擎
 */
export class HumanWayWeightsEngine {
  
  /**
   * 初始化角色权重
   */
  static initializeWeights(
    characterId: string,
    initialResources: Partial<Record<ResourceType, number>> = {}
  ): CharacterWeights {
    const defaultResources: Record<ResourceType, number> = {
      [ResourceType.SOCIAL_CAPITAL]: 50,
      [ResourceType.ECONOMIC_CAPITAL]: 50,
      [ResourceType.CULTURAL_CAPITAL]: 50,
      [ResourceType.POLITICAL_CAPITAL]: 30,
    };
    
    const resources = { ...defaultResources, ...initialResources };
    
    return {
      characterId,
      resources,
      influence: this.calculateInfluence(resources),
      vulnerability: this.calculateVulnerability(resources),
      lastUpdated: Date.now(),
    };
  }
  
  /**
   * 计算影响力指数
   */
  static calculateInfluence(
    resources: Record<ResourceType, number>
  ): number {
    // 加权计算影响力
    const weights = {
      [ResourceType.SOCIAL_CAPITAL]: 0.3,
      [ResourceType.ECONOMIC_CAPITAL]: 0.25,
      [ResourceType.CULTURAL_CAPITAL]: 0.25,
      [ResourceType.POLITICAL_CAPITAL]: 0.2,
    };
    
    let influence = 0;
    for (const [type, value] of Object.entries(resources)) {
      influence += value * weights[type as ResourceType];
    }
    
    // 马太效应：高资源者获得额外加成
    const totalResources = Object.values(resources).reduce((a, b) => a + b, 0);
    const bonus = Math.pow(totalResources / 200, 1.5);
    
    return Math.min(100, influence * (1 + bonus * 0.1));
  }
  
  /**
   * 计算脆弱性指数
   */
  static calculateVulnerability(
    resources: Record<ResourceType, number>
  ): number {
    const total = Object.values(resources).reduce((a, b) => a + b, 0);
    const average = total / Object.keys(resources).length;
    
    // 资源越不均衡，脆弱性越高
    let variance = 0;
    for (const value of Object.values(resources)) {
      variance += Math.pow(value - average, 2);
    }
    const imbalance = Math.sqrt(variance / Object.keys(resources).length);
    
    // 资源越少，脆弱性越高
    const scarcity = Math.max(0, 100 - total / 2);
    
    return Math.min(100, (imbalance * 0.5 + scarcity * 0.5));
  }
  
  /**
   * 资源转移（损不足以奉有余）
   */
  static transferResources(
    from: CharacterWeights,
    to: CharacterWeights,
    resourceType: ResourceType,
    amount: number
  ): { from: CharacterWeights; to: CharacterWeights } {
    // 实际转移量受双方影响力影响
    const transferEfficiency = to.influence / (from.influence + to.influence);
    const actualTransfer = amount * (0.5 + transferEfficiency * 0.5);
    
    const newFrom = { ...from };
    const newTo = { ...to };
    
    newFrom.resources[resourceType] = Math.max(
      0,
      from.resources[resourceType] - actualTransfer
    );
    newTo.resources[resourceType] = Math.min(
      100,
      to.resources[resourceType] + actualTransfer
    );
    
    // 重新计算指数
    newFrom.influence = this.calculateInfluence(newFrom.resources);
    newFrom.vulnerability = this.calculateVulnerability(newFrom.resources);
    newFrom.lastUpdated = Date.now();
    
    newTo.influence = this.calculateInfluence(newTo.resources);
    newTo.vulnerability = this.calculateVulnerability(newTo.resources);
    newTo.lastUpdated = Date.now();
    
    return { from: newFrom, to: newTo };
  }
  
  /**
   * 时间演化（资源自然增长/衰减）
   */
  static evolveWeights(
    weights: CharacterWeights,
    elapsedTime: number,  // 毫秒
    config: Record<ResourceType, WeightConfig>
  ): CharacterWeights {
    const hours = elapsedTime / 3600000;
    const newWeights = { ...weights };
    
    for (const [type, value] of Object.entries(weights.resources)) {
      const resourceType = type as ResourceType;
      const cfg = config[resourceType];
      
      if (cfg) {
        // 增长或衰减
        const change = value > cfg.baseValue 
          ? -cfg.decayRate * hours  // 高于基础值则衰减
          : cfg.growthRate * hours; // 低于基础值则增长
        
        newWeights.resources[resourceType] = Math.max(
          0,
          Math.min(100, value + change)
        );
      }
    }
    
    // 重新计算指数
    newWeights.influence = this.calculateInfluence(newWeights.resources);
    newWeights.vulnerability = this.calculateVulnerability(newWeights.resources);
    newWeights.lastUpdated = Date.now();
    
    return newWeights;
  }
}
```

**Step 2: 创建交互引擎**

```typescript
// src/humanway/interaction.ts
import { CharacterState, YValue } from '../types';
import { CharacterWeights, HumanWayWeightsEngine, ResourceType } from './weights';

/**
 * 人道交互结果
 */
export interface HumanWayInteraction {
  type: InteractionType;
  resourceChanges: Record<string, Record<ResourceType, number>>;
  yValueChanges: Record<string, number>;
  powerShift: PowerShift;
  socialDynamics: SocialDynamics;
}

export enum InteractionType {
  COOPERATION = 'cooperation',     // 合作
  COMPETITION = 'competition',     // 竞争
  DOMINATION = 'domination',       // 支配
  SUBMISSION = 'submission',       // 臣服
  EXCHANGE = 'exchange',           // 交换
  CONFLICT = 'conflict',           // 冲突
}

export interface PowerShift {
  dominant: string;      // 占据主导的角色ID
  submissive: string;    // 处于从属的角色ID
  dominanceDegree: number; // 支配程度 (0-1)
}

export interface SocialDynamics {
  allianceFormed: boolean;
  rivalryFormed: boolean;
  trustChange: Record<string, number>;
}

/**
 * 人道交互引擎
 */
export class HumanWayInteractionEngine {
  
  /**
   * 处理角色间交互
   */
  static processInteraction(
    character1: { state: CharacterState; weights: CharacterWeights },
    character2: { state: CharacterState; weights: CharacterWeights },
    interactionType: InteractionType,
    intensity: number  // 交互强度 (0-10)
  ): HumanWayInteraction {
    const c1 = character1.state;
    const c2 = character2.state;
    const w1 = character1.weights;
    const w2 = character2.weights;
    
    // 计算Y值差值
    const yDiff = c1.yValue - c2.yValue;
    const influenceDiff = w1.influence - w2.influence;
    
    let resourceChanges: Record<string, Record<ResourceType, number>> = {
      [c1.id]: {},
      [c2.id]: {},
    };
    let yValueChanges: Record<string, number> = {
      [c1.id]: 0,
      [c2.id]: 0,
    };
    
    switch (interactionType) {
      case InteractionType.COOPERATION:
        // 合作：双方资源可能增长，取决于互补性
        const synergy = this.calculateSynergy(c1.mbti, c2.mbti);
        resourceChanges[c1.id][ResourceType.SOCIAL_CAPITAL] = intensity * synergy * 0.5;
        resourceChanges[c2.id][ResourceType.SOCIAL_CAPITAL] = intensity * synergy * 0.5;
        yValueChanges[c1.id] = intensity * 0.1;
        yValueChanges[c2.id] = intensity * 0.1;
        break;
        
      case InteractionType.COMPETITION:
        // 竞争：高Y值/高影响力者获益
        const winner = yDiff + influenceDiff > 0 ? c1.id : c2.id;
        const loser = winner === c1.id ? c2.id : c1.id;
        resourceChanges[winner][ResourceType.SOCIAL_CAPITAL] = intensity * 0.8;
        resourceChanges[loser][ResourceType.SOCIAL_CAPITAL] = -intensity * 0.5;
        yValueChanges[winner] = intensity * 0.2;
        yValueChanges[loser] = -intensity * 0.1;
        break;
        
      case InteractionType.DOMINATION:
        // 支配：支配者获得资源，被支配者损失资源和Y值
        const dominator = yDiff > 0 ? c1.id : c2.id;
        const submissive = dominator === c1.id ? c2.id : c1.id;
        resourceChanges[dominator][ResourceType.POLITICAL_CAPITAL] = intensity * 0.6;
        resourceChanges[submissive][ResourceType.POLITICAL_CAPITAL] = -intensity * 0.4;
        yValueChanges[dominator] = intensity * 0.3;
        yValueChanges[submissive] = -intensity * 0.5;
        break;
        
      case InteractionType.EXCHANGE:
        // 交换：资源互换，效率取决于信任度
        const efficiency = 0.7; // 简化：固定效率
        resourceChanges[c1.id][ResourceType.ECONOMIC_CAPITAL] = intensity * efficiency;
        resourceChanges[c2.id][ResourceType.ECONOMIC_CAPITAL] = intensity * efficiency;
        break;
        
      case InteractionType.CONFLICT:
        // 冲突：双方都可能损失，高Y值者损失较少
        const c1Loss = intensity * (1 - c1.yValue / 100) * 0.5;
        const c2Loss = intensity * (1 - c2.yValue / 100) * 0.5;
        resourceChanges[c1.id][ResourceType.SOCIAL_CAPITAL] = -c1Loss;
        resourceChanges[c2.id][ResourceType.SOCIAL_CAPITAL] = -c2Loss;
        yValueChanges[c1.id] = -intensity * 0.2;
        yValueChanges[c2.id] = -intensity * 0.2;
        break;
    }
    
    return {
      type: interactionType,
      resourceChanges,
      yValueChanges,
      powerShift: {
        dominant: yDiff > 0 ? c1.id : c2.id,
        submissive: yDiff > 0 ? c2.id : c1.id,
        dominanceDegree: Math.abs(yDiff) / 100,
      },
      socialDynamics: {
        allianceFormed: interactionType === InteractionType.COOPERATION && intensity > 7,
        rivalryFormed: interactionType === InteractionType.COMPETITION && intensity > 7,
        trustChange: this.calculateTrustChange(interactionType, intensity),
      },
    };
  }
  
  /**
   * 计算MBTI互补性
   */
  private static calculateSynergy(mbti1: string, mbti2: string): number {
    // 简化实现：某些组合更有协同效应
    const complementaryPairs = [
      ['INTJ', 'ENFP'], ['INTP', 'ENTJ'], ['INFJ', 'ENFP'],
      ['INFP', 'ENFJ'], ['ISTJ', 'ESFP'], ['ISFJ', 'ESTP'],
    ];
    
    for (const [a, b] of complementaryPairs) {
      if ((mbti1 === a && mbti2 === b) || (mbti1 === b && mbti2 === a)) {
        return 1.5;
      }
    }
    
    return 1.0;
  }
  
  /**
   * 计算信任度变化
   */
  private static calculateTrustChange(
    interactionType: InteractionType,
    intensity: number
  ): Record<string, number> {
    const changes: Record<string, number> = {};
    
    switch (interactionType) {
      case InteractionType.COOPERATION:
        changes.trust = intensity * 0.1;
        break;
      case InteractionType.CONFLICT:
        changes.trust = -intensity * 0.15;
        break;
      case InteractionType.DOMINATION:
        changes.trust = -intensity * 0.2;
        break;
      default:
        changes.trust = 0;
    }
    
    return changes;
  }
}
```

**Step 3: 创建测试**

```typescript
// tests/humanway/weights.test.ts
import { HumanWayWeightsEngine, ResourceType } from '../../src/humanway/weights';

describe('HumanWayWeightsEngine', () => {
  describe('initializeWeights', () => {
    it('should initialize with default resources', () => {
      const weights = HumanWayWeightsEngine.initializeWeights('test-1');
      expect(weights.characterId).toBe('test-1');
      expect(weights.resources[ResourceType.SOCIAL_CAPITAL]).toBe(50);
      expect(weights.influence).toBeGreaterThan(0);
      expect(weights.vulnerability).toBeGreaterThan(0);
    });
    
    it('should use custom initial resources', () => {
      const weights = HumanWayWeightsEngine.initializeWeights('test-2', {
        [ResourceType.ECONOMIC_CAPITAL]: 80,
      });
      expect(weights.resources[ResourceType.ECONOMIC_CAPITAL]).toBe(80);
    });
  });
  
  describe('calculateInfluence', () => {
    it('should increase with more resources', () => {
      const lowResources = {
        [ResourceType.SOCIAL_CAPITAL]: 30,
        [ResourceType.ECONOMIC_CAPITAL]: 30,
        [ResourceType.CULTURAL_CAPITAL]: 30,
        [ResourceType.POLITICAL_CAPITAL]: 30,
      };
      const highResources = {
        [ResourceType.SOCIAL_CAPITAL]: 80,
        [ResourceType.ECONOMIC_CAPITAL]: 80,
        [ResourceType.CULTURAL_CAPITAL]: 80,
        [ResourceType.POLITICAL_CAPITAL]: 80,
      };
      
      const lowInfluence = HumanWayWeightsEngine.calculateInfluence(lowResources);
      const highInfluence = HumanWayWeightsEngine.calculateInfluence(highResources);
      
      expect(highInfluence).toBeGreaterThan(lowInfluence);
    });
  });
  
  describe('transferResources', () => {
    it('should transfer resources between characters', () => {
      const from = HumanWayWeightsEngine.initializeWeights('from');
      const to = HumanWayWeightsEngine.initializeWeights('to');
      
      const initialFrom = from.resources[ResourceType.SOCIAL_CAPITAL];
      const result = HumanWayWeightsEngine.transferResources(
        from, to, ResourceType.SOCIAL_CAPITAL, 10
      );
      
      expect(result.from.resources[ResourceType.SOCIAL_CAPITAL]).toBeLessThan(initialFrom);
      expect(result.to.resources[ResourceType.SOCIAL_CAPITAL]).toBeGreaterThan(50);
    });
  });
});
```

**Step 4: 运行测试并提交**

```bash
npm test -- tests/humanway/
git add .
git commit -m "feat(humanway): implement human way weights system and interaction engine"
```

---

### Task 8: 记忆模块实现

**Files:**
- Create: `tiandao-system/src/memory/system.ts`
- Create: `tiandao-system/src/memory/operations.ts`
- Create: `tiandao-system/tests/memory/system.test.ts`

**Step 1: 创建记忆系统**

```typescript
// src/memory/system.ts
import { MemorySystem, SensoryMemory, ShortTermMemory, LongTermMemory, EmotionalMemory, CoreMemory, MemoryItem, EpisodeMemory } from '../types';

/**
 * 记忆系统管理器
 */
export class MemorySystemManager {
  private system: MemorySystem;
  private characterId: string;
  
  constructor(characterId: string) {
    this.characterId = characterId;
    this.system = this.initializeSystem();
  }
  
  /**
   * 初始化记忆系统
   */
  private initializeSystem(): MemorySystem {
    return {
      sensory: {
        visual: [],
        auditory: [],
        capacity: 10,
      },
      shortTerm: {
        items: [],
        capacity: 7,
        duration: 60000, // 1分钟
      },
      longTerm: {
        episodes: [],
        facts: [],
        procedures: [],
      },
      emotional: {
        traumas: [],
        joys: [],
        attachments: [],
      },
      core: {
        identity: '',
        values: [],
        beliefs: [],
        purpose: '',
      },
    };
  }
  
  /**
   * 添加感官记忆
   */
  addSensoryMemory(type: 'visual' | 'auditory', content: string, intensity: number): void {
    const snapshot = {
      timestamp: Date.now(),
      content,
      intensity,
    };
    
    if (type === 'visual') {
      this.system.sensory.visual.unshift(snapshot);
      if (this.system.sensory.visual.length > this.system.sensory.capacity) {
        this.system.sensory.visual.pop();
      }
    } else {
      this.system.sensory.auditory.unshift({ ...snapshot, tone: intensity });
      if (this.system.sensory.auditory.length > this.system.sensory.capacity) {
        this.system.sensory.auditory.pop();
      }
    }
  }
  
  /**
   * 编码到短期记忆
   */
  encodeToShortTerm(content: string, importance: number = 5): void {
    const item: MemoryItem = {
      id: `stm-${Date.now()}`,
      content,
      timestamp: Date.now(),
      importance,
      associations: [],
    };
    
    this.system.shortTerm.items.unshift(item);
    
    // 容量限制：7±2
    if (this.system.shortTerm.items.length > this.system.shortTerm.capacity) {
      const forgotten = this.system.shortTerm.items.pop();
      // 重要记忆可能进入长期记忆
      if (forgotten && forgotten.importance > 7) {
        this.consolidateToLongTerm(forgotten);
      }
    }
  }
  
  /**
   * 巩固到长期记忆（情景记忆）
   */
  consolidateToLongTerm(item: MemoryItem, scene?: string, participants?: string[]): void {
    const episode: EpisodeMemory = {
      id: `ep-${Date.now()}`,
      timestamp: item.timestamp,
      scene: scene || 'unknown',
      participants: participants || [],
      emotionalValence: item.importance - 5, // -5 to +5
      yImpact: 0,
    };
    
    this.system.longTerm.episodes.unshift(episode);
    
    // 限制长期记忆容量（模拟遗忘）
    if (this.system.longTerm.episodes.length > 100) {
      this.system.longTerm.episodes.pop();
    }
  }
  
  /**
   * 添加情绪记忆
   */
  addEmotionalMemory(
    type: 'trauma' | 'joy' | 'attachment',
    data: any
  ): void {
    switch (type) {
      case 'trauma':
        this.system.emotional.traumas.unshift({
          id: `tr-${Date.now()}`,
          ...data,
        });
        break;
      case 'joy':
        this.system.emotional.joys.unshift({
          id: `jy-${Date.now()}`,
          ...data,
        });
        break;
      case 'attachment':
        this.system.emotional.attachments.push(data);
        break;
    }
  }
  
  /**
   * 检索记忆
   */
  retrieveMemories(query: string, limit: number = 5): MemoryItem[] {
    const results: MemoryItem[] = [];
    
    // 搜索短期记忆
    for (const item of this.system.shortTerm.items) {
      if (item.content.includes(query)) {
        results.push(item);
      }
    }
    
    // 搜索长期情景记忆
    for (const episode of this.system.longTerm.episodes) {
      if (episode.scene.includes(query)) {
        results.push({
          id: episode.id,
          content: episode.scene,
          timestamp: episode.timestamp,
          importance: Math.abs(episode.emotionalValence) + 5,
          associations: episode.participants,
        });
      }
    }
    
    return results.slice(0, limit);
  }
  
  /**
   * 获取记忆系统状态
   */
  getSystem(): MemorySystem {
    return this.system;
  }
  
  /**
   * 导出记忆摘要（用于AI提示词）
   */
  exportMemorySummary(): string {
    const recentEpisodes = this.system.longTerm.episodes.slice(0, 5);
    const traumas = this.system.emotional.traumas;
    const attachments = this.system.emotional.attachments;
    
    let summary = `[记忆摘要]\n`;
    summary += `最近经历: ${recentEpisodes.map(e => e.scene).join(', ')}\n`;
    
    if (traumas.length > 0) {
      summary += `创伤记忆: ${traumas.map(t => t.event).join(', ')}\n`;
    }
    
    if (attachments.length > 0) {
      summary += `依恋对象: ${attachments.map(a => a.targetId).join(', ')}\n`;
    }
    
    return summary;
  }
}
```

**Step 2: 创建记忆操作工具**

```typescript
// src/memory/operations.ts
import { MemorySystemManager } from './system';
import { CharacterState } from '../types';

/**
 * 记忆操作
 */
export class MemoryOperations {
  
  /**
   * 处理事件并更新记忆
   */
  static processEvent(
    manager: MemorySystemManager,
    event: {
      type: string;
      description: string;
      intensity: number;
      participants: string[];
      yImpact: number;
    }
  ): void {
    // 添加到感官记忆
    manager.addSensoryMemory('visual', event.description, event.intensity);
    
    // 编码到短期记忆
    manager.encodeToShortTerm(event.description, event.intensity);
    
    // 高影响事件直接进入长期记忆
    if (event.intensity > 6 || event.yImpact > 10) {
      manager.consolidateToLongTerm(
        {
          id: `evt-${Date.now()}`,
          content: event.description,
          timestamp: Date.now(),
          importance: event.intensity,
          associations: event.participants,
        },
        event.type,
        event.participants
      );
    }
    
    // 负面高影响事件成为创伤记忆
    if (event.intensity > 7 && event.yImpact < -10) {
      manager.addEmotionalMemory('trauma', {
        event: event.description,
        severity: event.intensity,
        yBaseShift: event.yImpact * 0.1,
        triggerWords: event.description.split(' ').slice(0, 3),
      });
    }
  }
  
  /**
   * 形成依恋
   */
  static formAttachment(
    manager: MemorySystemManager,
    targetId: string,
    strength: number,
    type: 'secure' | 'anxious' | 'avoidant' | 'disorganized'
  ): void {
    manager.addEmotionalMemory('attachment', {
      targetId,
      strength,
      type,
    });
  }
  
  /**
   * 检索相关记忆（用于生成上下文）
   */
  static retrieveContext(
    manager: MemorySystemManager,
    situation: string,
    participants: string[]
  ): string {
    const memories = manager.retrieveMemories(situation, 3);
    
    if (memories.length === 0) {
      return '';
    }
    
    return memories
      .map(m => `[记忆] ${m.content} (重要性:${m.importance})`)
      .join('\n');
  }
}
```

**Step 3: 创建测试**

```typescript
// tests/memory/system.test.ts
import { MemorySystemManager } from '../../src/memory/system';
import { MemoryOperations } from '../../src/memory/operations';

describe('MemorySystemManager', () => {
  let manager: MemorySystemManager;
  
  beforeEach(() => {
    manager = new MemorySystemManager('test-char');
  });
  
  describe('addSensoryMemory', () => {
    it('should add visual memory', () => {
      manager.addSensoryMemory('visual', 'saw a red car', 5);
      const system = manager.getSystem();
      expect(system.sensory.visual.length).toBe(1);
      expect(system.sensory.visual[0].content).toBe('saw a red car');
    });
    
    it('should respect capacity limit', () => {
      for (let i = 0; i < 15; i++) {
        manager.addSensoryMemory('visual', `memory ${i}`, 5);
      }
      const system = manager.getSystem();
      expect(system.sensory.visual.length).toBe(10);
    });
  });
  
  describe('encodeToShortTerm', () => {
    it('should add item to short term memory', () => {
      manager.encodeToShortTerm('important information', 8);
      const system = manager.getSystem();
      expect(system.shortTerm.items.length).toBe(1);
      expect(system.shortTerm.items[0].content).toBe('important information');
    });
  });
  
  describe('retrieveMemories', () => {
    it('should retrieve matching memories', () => {
      manager.encodeToShortTerm('meeting with Alice', 7);
      manager.encodeToShortTerm('lunch with Bob', 5);
      
      const results = manager.retrieveMemories('Alice');
      expect(results.length).toBe(1);
      expect(results[0].content).toBe('meeting with Alice');
    });
  });
  
  describe('exportMemorySummary', () => {
    it('should export summary string', () => {
      const summary = manager.exportMemorySummary();
      expect(summary).toContain('[记忆摘要]');
    });
  });
});

describe('MemoryOperations', () => {
  let manager: MemorySystemManager;
  
  beforeEach(() => {
    manager = new MemorySystemManager('test-char');
  });
  
  describe('processEvent', () => {
    it('should process high intensity event to long term', () => {
      MemoryOperations.processEvent(manager, {
        type: 'confrontation',
        description: 'intense argument',
        intensity: 8,
        participants: ['Alice'],
        yImpact: -15,
      });
      
      const system = manager.getSystem();
      expect(system.longTerm.episodes.length).toBeGreaterThan(0);
      expect(system.emotional.traumas.length).toBeGreaterThan(0);
    });
  });
});
```

**Step 4: 运行测试并提交**

```bash
npm test -- tests/memory/
git add .
git commit -m "feat(memory): implement five-tier memory system with operations"
```

---

### Task 9: SillyTavern对接适配器

**Files:**
- Create: `tiandao-system/src/adapter/sillytavern.ts`
- Create: `tiandao-system/src/adapter/prompt-builder.ts`
- Create: `tiandao-system/tests/adapter/sillytavern.test.ts`

**Step 1: 创建SillyTavern适配器**

```typescript
// src/adapter/sillytavern.ts
import { CharacterState } from '../types';
import { PsychProfileManager } from '../core/psych-profile';
import { MemorySystemManager } from '../memory/system';
import { YValueEngine } from '../core/yvalue';

/**
 * SillyTavern角色卡格式
 */
export interface SillyTavernCard {
  name: string;
  description: string;
  personality: string;
  scenario: string;
  first_mes: string;
  mes_example: string;
  creatorcomment: string;
  tags: string[];
  // 扩展字段（天道系统专用）
  extensions?: {
    tiandao?: {
      version: string;
      yValue: number;
      yBase: number;
      mbti: string;
      willpower: number;
      traumaFlags: any[];
    };
  };
}

/**
 * SillyTavern适配器
 */
export class SillyTavernAdapter {
  private profileManager: PsychProfileManager;
  
  constructor(profileDir: string = './profiles') {
    this.profileManager = new PsychProfileManager(profileDir);
  }
  
  /**
   * 导出角色卡
   */
  exportCard(characterId: string): SillyTavernCard | null {
    const profile = this.profileManager.loadProfile(characterId);
    if (!profile) return null;
    
    const yLevel = YValueEngine.getYLevel(profile.yValue);
    
    return {
      name: profile.name,
      description: this.buildDescription(profile),
      personality: this.buildPersonality(profile),
      scenario: '',
      first_mes: '',
      mes_example: this.buildExamples(profile),
      creatorcomment: `天道系统 v1.0 | ${profile.mbti} | Y:${profile.yValue}/${profile.yBase}`,
      tags: [profile.mbti, 'tiandao-system', `Y${profile.yValue}`],
      extensions: {
        tiandao: {
          version: '1.0.0',
          yValue: profile.yValue,
          yBase: profile.yBase,
          mbti: profile.mbti,
          willpower: profile.willpower.current,
          traumaFlags: profile.traumaFlags,
        },
      },
    };
  }
  
  /**
   * 导入角色卡
   */
  importCard(card: SillyTavernCard): CharacterState {
    const tiandaoData = card.extensions?.tiandao;
    
    const profile: CharacterState = {
      id: this.sanitizeId(card.name),
      name: card.name,
      mbti: (tiandaoData?.mbti || 'INTJ') as any,
      yValue: tiandaoData?.yValue ?? 60,
      yBase: tiandaoData?.yBase ?? 60,
      yMin: 20,
      yMax: 100,
      emotions: {
        joy: 5, anger: 0, sorrow: 0, fear: 0,
        love: 0, hate: 0, desire: 5,
      },
      willpower: {
        current: tiandaoData?.willpower ?? 80,
        max: 100,
        regeneration: 1,
      },
      traumaFlags: tiandaoData?.traumaFlags || [],
      isDead: false,
    };
    
    this.profileManager.saveProfile(profile);
    return profile;
  }
  
  /**
   * 构建角色描述
   */
  private buildDescription(profile: CharacterState): string {
    const yLevel = YValueEngine.getYLevel(profile.yValue);
    const traumaInfo = profile.traumaFlags.length > 0 
      ? `\n[创伤] ${profile.traumaFlags.map(t => t.type).join(', ')}`
      : '';
    
    return `[${profile.mbti} | Y值:${profile.yValue} | 意志力:${profile.willpower.current}]${traumaInfo}\n\n{{char}}是一个主观意识凝练强度为${profile.yValue}的角色。当前处于${this.getYLevelDescription(yLevel)}状态。`;
  }
  
  /**
   * 构建性格描述
   */
  private buildPersonality(profile: CharacterState): string {
    return `MBTI: ${profile.mbti}
Y值系统: ${profile.yValue}/${profile.yBase} (上限:${profile.yMax})
意志力: ${profile.willpower.current}/${profile.willpower.max}
情绪状态: 喜${profile.emotions.joy} 怒${profile.emotions.anger} 哀${profile.emotions.sorrow} 惧${profile.emotions.fear}
核心欲望: ${profile.emotions.desire}`;
  }
  
  /**
   * 构建示例对话
   */
  private buildExamples(profile: CharacterState): string {
    const yDesc = profile.yValue > 70 ? '强势主导' : profile.yValue < 50 ? '被动顺从' : '平等交流';
    
    return `<START>
{{user}}: 你好
{{char}}: [Y值:${profile.yValue}，${yDesc}模式] ...

<START>
{{user}}: 你看起来不太对劲
{{char}}: [检测到Y值波动] ...`;
  }
  
  /**
   * 获取Y值等级描述
   */
  private getYLevelDescription(level: number): string {
    const descriptions: Record<number, string> = {
      0: '意识崩溃',
      20: '精神分裂',
      40: '不稳定',
      60: '正常',
      70: '稳定自信',
      80: '气场碾压',
      90: '绝对支配',
    };
    return descriptions[level] || '未知';
  }
  
  /**
   * 清理ID
   */
  private sanitizeId(name: string): string {
    return name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  }
  
  /**
   * 保存角色卡到文件
   */
  saveCardToFile(characterId: string, outputDir: string = './cards'): string | null {
    const card = this.exportCard(characterId);
    if (!card) return null;
    
    const fs = require('fs');
    const path = require('path');
    
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const filePath = path.join(outputDir, `${characterId}.json`);
    fs.writeFileSync(filePath, JSON.stringify(card, null, 2), 'utf-8');
    
    return filePath;
  }
}
```

**Step 2: 创建提示词构建器**

```typescript
// src/adapter/prompt-builder.ts
import { CharacterState } from '../types';
import { MemorySystemManager } from '../memory/system';
import { YValueEngine } from '../core/yvalue';
import { MemoryOperations } from '../memory/operations';

/**
 * AI提示词构建器
 */
export class PromptBuilder {
  
  /**
   * 构建系统提示词
   */
  static buildSystemPrompt(
    character: CharacterState,
    memoryManager?: MemorySystemManager
  ): string {
    const parts: string[] = [];
    
    // 角色定义
    parts.push(this.buildCharacterDefinition(character));
    
    // Y值状态
    parts.push(this.buildYValueContext(character));
    
    // 记忆上下文
    if (memoryManager) {
      parts.push(memoryManager.exportMemorySummary());
    }
    
    // 行为指令
    parts.push(this.buildBehaviorInstructions(character));
    
    return parts.join('\n\n---\n\n');
  }
  
  /**
   * 构建角色定义
   */
  private static buildCharacterDefinition(character: CharacterState): string {
    return `[角色定义]
名称: ${character.name}
MBTI: ${character.mbti}
Y值: ${character.yValue} (基线: ${character.yBase}, 范围: ${character.yMin}-${character.yMax})
意志力: ${character.willpower.current}/${character.willpower.max}`;
  }
  
  /**
   * 构建Y值上下文
   */
  private static buildYValueContext(character: CharacterState): string {
    const yLevel = YValueEngine.getYLevel(character.yValue);
    const levelDesc = this.getYLevelBehaviorDescription(yLevel);
    
    return `[Y值状态]
当前: ${character.yValue}
等级: ${yLevel}
行为特征: ${levelDesc}

Y值影响:
- 执行力: ${character.yValue > 60 ? '强' : character.yValue < 40 ? '弱' : '一般'}
- 影响力: ${character.yValue > 70 ? '气场碾压' : character.yValue < 50 ? '易被影响' : '平等互动'}
- 稳定性: ${character.yValue > character.yBase ? '超频状态' : character.yValue < character.yBase ? '受损状态' : '基线状态'}`;
  }
  
  /**
   * 构建行为指令
   */
  private static buildBehaviorInstructions(character: CharacterState): string {
    return `[行为指令]
1. 所有回应必须体现当前Y值(${character.yValue})对应的心理状态
2. 当Y值高于对方时，展现支配性语言和行为
3. 当Y值低于对方时，展现顺从、犹豫或防御性
4. 意志力低(${character.willpower.current < 30})时，容易情绪失控
5. 参考记忆摘要中的创伤和依恋对象，影响互动方式
6. 情绪响应符合${character.mbti}型人格特征`;
  }
  
  /**
   * 获取Y值等级行为描述
   */
  private static getYLevelBehaviorDescription(level: number): string {
    const descriptions: Record<number, string> = {
      0: '意识崩溃，无法自主行动',
      20: '精神分裂，行为不可预测',
      40: '不稳定，易受外界影响',
      60: '正常状态，适度自信',
      70: '稳定自信，有主见',
      80: '气场强大，自然支配他人',
      90: '绝对支配，一言九鼎',
    };
    return descriptions[level] || '未知状态';
  }
  
  /**
   * 构建对话上下文
   */
  static buildDialogueContext(
    character: CharacterState,
    dialogue: Array<{ speaker: string; content: string }>,
    memoryManager?: MemorySystemManager
  ): string {
    const parts: string[] = [];
    
    // 检索相关记忆
    if (memoryManager && dialogue.length > 0) {
      const lastMessage = dialogue[dialogue.length - 1].content;
      const relevantMemories = MemoryOperations.retrieveContext(
        memoryManager,
        lastMessage,
        []
      );
      if (relevantMemories) {
        parts.push(`[相关记忆]\n${relevantMemories}`);
      }
    }
    
    // 对话历史
    parts.push('[对话历史]');
    for (const turn of dialogue.slice(-10)) { // 最近10轮
      parts.push(`${turn.speaker}: ${turn.content}`);
    }
    
    return parts.join('\n');
  }
  
  /**
   * 构建完整提示词
   */
  static buildFullPrompt(
    character: CharacterState,
    dialogue: Array<{ speaker: string; content: string }>,
    memoryManager?: MemorySystemManager
  ): string {
    const systemPrompt = this.buildSystemPrompt(character, memoryManager);
    const dialogueContext = this.buildDialogueContext(character, dialogue, memoryManager);
    
    return `${systemPrompt}\n\n${dialogueContext}\n\n${character.name}:`;
  }
}
```

**Step 3: 创建测试**

```typescript
// tests/adapter/sillytavern.test.ts
import { SillyTavernAdapter } from '../../src/adapter/sillytavern';
import { PsychProfileManager } from '../../src/core/psych-profile';
import { PromptBuilder } from '../../src/adapter/prompt-builder';

describe('SillyTavernAdapter', () => {
  const testDir = './test-profiles-adapter';
  let adapter: SillyTavernAdapter;
  let profileManager: PsychProfileManager;
  
  beforeEach(() => {
    adapter = new SillyTavernAdapter(testDir);
    profileManager = new PsychProfileManager(testDir);
  });
  
  describe('exportCard', () => {
    it('should export existing profile as card', () => {
      profileManager.createProfile('test-export', 'Test Character', 'INTJ', {
        yValue: 75,
        yBase: 60,
      });
      
      const card = adapter.exportCard('test-export');
      expect(card).not.toBeNull();
      expect(card?.name).toBe('Test Character');
      expect(card?.extensions?.tiandao?.yValue).toBe(75);
    });
    
    it('should return null for non-existent profile', () => {
      const card = adapter.exportCard('non-existent');
      expect(card).toBeNull();
    });
  });
  
  describe('importCard', () => {
    it('should import card as profile', () => {
      const card = {
        name: 'Imported Character',
        description: 'test',
        personality: 'test',
        scenario: '',
        first_mes: '',
        mes_example: '',
        creatorcomment: '',
        tags: [],
        extensions: {
          tiandao: {
            version: '1.0.0',
            yValue: 80,
            yBase: 70,
            mbti: 'ENTJ',
            willpower: 90,
            traumaFlags: [],
          },
        },
      };
      
      const profile = adapter.importCard(card);
      expect(profile.name).toBe('Imported Character');
      expect(profile.mbti).toBe('ENTJ');
      expect(profile.yValue).toBe(80);
    });
  });
});

describe('PromptBuilder', () => {
  describe('buildSystemPrompt', () => {
    it('should include character definition', () => {
      const character = {
        id: 'test',
        name: 'Test',
        mbti: 'INTJ',
        yValue: 70,
        yBase: 60,
        yMin: 40,
        yMax: 90,
        emotions: { joy: 5, anger: 0, sorrow: 0, fear: 0, love: 0, hate: 0, desire: 5 },
        willpower: { current: 80, max: 100, regeneration: 1 },
        traumaFlags: [],
        isDead: false,
      } as any;
      
      const prompt = PromptBuilder.buildSystemPrompt(character);
      expect(prompt).toContain('Test');
      expect(prompt).toContain('INTJ');
      expect(prompt).toContain('Y值');
    });
  });
});
```

**Step 4: 运行测试并提交**

```bash
npm test -- tests/adapter/
git add .
git commit -m "feat(adapter): implement SillyTavern card adapter and prompt builder"
```

---

### Task 10: 测试套件与验证

**Files:**
- Create: `tiandao-system/tests/integration/full-flow.test.ts`
- Modify: `tiandao-system/package.json` (添加测试脚本)
- Create: `tiandao-system/README.md`

**Step 1: 创建集成测试**

```typescript
// tests/integration/full-flow.test.ts
import { PsychProfileManager } from '../../src/core/psych-profile';
import { YValueEngine } from '../../src/core/yvalue';
import { MBTIEngine } from '../../src/core/mbti';
import { TriggerMechanism, TriggerType } from '../../src/mechanisms/trigger';
import { CompensationMechanism } from '../../src/mechanisms/compensation';
import { ReboundMechanism } from '../../src/mechanisms/rebound';
import { MemorySystemManager } from '../../src/memory/system';
import { MemoryOperations } from '../../src/memory/operations';
import { HumanWayWeightsEngine, HumanWayInteractionEngine, InteractionType, ResourceType } from '../../src/humanway';
import { SillyTavernAdapter } from '../../src/adapter/sillytavern';
import { PromptBuilder } from '../../src/adapter/prompt-builder';

describe('天道系统 完整流程测试', () => {
  const testDir = './test-integration';
  
  describe('角色创建到对话生成', () => {
    it('应该能创建角色并导出SillyTavern卡片', () => {
      // 1. 创建角色档案
      const profileManager = new PsychProfileManager(testDir);
      const character = profileManager.createProfile('yuejianfeng', '月见枫', 'INTJ', {
        yValue: 70,
        yBase: 70,
        traumaFlags: [{ type: 'family_death', severity: 10, permanent: true, yBaseShift: 10 }],
      });
      
      expect(character.name).toBe('月见枫');
      expect(character.mbti).toBe('INTJ');
      expect(character.yBase).toBe(70);
      
      // 2. 导出SillyTavern卡片
      const adapter = new SillyTavernAdapter(testDir);
      const card = adapter.exportCard('yuejianfeng');
      
      expect(card).not.toBeNull();
      expect(card?.name).toBe('月见枫');
      expect(card?.extensions?.tiandao?.mbti).toBe('INTJ');
    });
    
    it('应该能模拟Y值变化和三大机制', () => {
      const character = {
        id: 'test',
        name: 'Test',
        yValue: 60,
        yBase: 60,
        yMin: 40,
        yMax: 80,
        mbti: 'INTJ',
        emotions: {} as any,
        willpower: { current: 80, max: 100, regeneration: 1 },
        traumaFlags: [],
        isDead: false,
      };
      
      // 触发机制：被高Y值角色支配
      const triggerResult = TriggerMechanism.processTrigger(
        character,
        { type: TriggerType.DOMINATION, source: 'dominator', intensity: 6, description: '被压制' },
        85
      );
      
      expect(triggerResult.yChange).toBeLessThan(0);
      expect(triggerResult.newY).toBeLessThan(character.yValue);
      
      // 补偿机制
      const compensation = CompensationMechanism.calculateCompensation(
        { ...character, yValue: triggerResult.newY },
        Math.abs(triggerResult.yChange),
        'dominator'
      );
      
      expect(compensation.type).toBeDefined();
      expect(compensation.yRecovery).toBeGreaterThan(0);
      
      // 回弹机制
      const rebound = ReboundMechanism.calculateRebound(
        { ...character, yValue: triggerResult.newY },
        3600000 // 1小时
      );
      
      expect(rebound.isRebounding).toBe(true);
      expect(rebound.targetY).toBe(character.yBase);
    });
    
    it('应该能处理记忆系统', () => {
      const memoryManager = new MemorySystemManager('test-char');
      
      // 添加事件到记忆
      MemoryOperations.processEvent(memoryManager, {
        type: 'confrontation',
        description: '与宿敌的激烈对决',
        intensity: 9,
        participants: ['宿敌'],
        yImpact: -20,
      });
      
      const system = memoryManager.getSystem();
      expect(system.longTerm.episodes.length).toBeGreaterThan(0);
      expect(system.emotional.traumas.length).toBeGreaterThan(0);
      
      // 检索记忆
      const memories = memoryManager.retrieveMemories('对决', 3);
      expect(memories.length).toBeGreaterThan(0);
    });
    
    it('应该能处理人道系统交互', () => {
      // 初始化两个角色的权重
      const weights1 = HumanWayWeightsEngine.initializeWeights('char1', {
        [ResourceType.SOCIAL_CAPITAL]: 70,
        [ResourceType.POLITICAL_CAPITAL]: 60,
      });
      const weights2 = HumanWayWeightsEngine.initializeWeights('char2', {
        [ResourceType.SOCIAL_CAPITAL]: 40,
        [ResourceType.POLITICAL_CAPITAL]: 30,
      });
      
      // 高权重角色支配低权重角色
      const character1 = {
        state: { id: 'char1', yValue: 75, mbti: 'ENTJ' } as any,
        weights: weights1,
      };
      const character2 = {
        state: { id: 'char2', yValue: 55, mbti: 'INFP' } as any,
        weights: weights2,
      };
      
      const interaction = HumanWayInteractionEngine.processInteraction(
        character1,
        character2,
        InteractionType.DOMINATION,
        7
      );
      
      expect(interaction.powerShift.dominant).toBe('char1');
      expect(interaction.yValueChanges.char1).toBeGreaterThan(0);
      expect(interaction.yValueChanges.char2).toBeLessThan(0);
    });
    
    it('应该能生成AI提示词', () => {
      const character = {
        id: 'test',
        name: '月见枫',
        mbti: 'INTJ',
        yValue: 70,
        yBase: 70,
        yMin: 40,
        yMax: 90,
        emotions: { joy: 5, anger: 2, sorrow: 3, fear: 1, love: 0, hate: 4, desire: 6 },
        willpower: { current: 75, max: 100, regeneration: 1 },
        traumaFlags: [{ type: 'family_death', severity: 10, permanent: true, yBaseShift: 10 }],
        isDead: false,
      } as any;
      
      const memoryManager = new MemorySystemManager('test');
      MemoryOperations.processEvent(memoryManager, {
        type: 'loss',
        description: '家族被灭门',
        intensity: 10,
        participants: [],
        yImpact: -30,
      });
      
      const prompt = PromptBuilder.buildSystemPrompt(character, memoryManager);
      
      expect(prompt).toContain('月见枫');
      expect(prompt).toContain('INTJ');
      expect(prompt).toContain('Y值');
      expect(prompt).toContain('创伤');
    });
  });
  
  describe('完整场景：月见枫与有希子的对决', () => {
    it('应该能模拟完整的天道系统场景', () => {
      // 创建两个角色
      const profileManager = new PsychProfileManager(testDir);
      
      const yuejianfeng = profileManager.createProfile('feng', '月见枫', 'INTJ', {
        yValue: 70,
        yBase: 70,
        traumaFlags: [{ type: 'family_death', severity: 10, permanent: true, yBaseShift: 10 }],
      });
      
      const youxizi = profileManager.createProfile('you', '有希子', 'ENFJ', {
        yValue: 65,
        yBase: 65,
      });
      
      // 初始化记忆系统
      const fengMemory = new MemorySystemManager('feng');
      const youMemory = new MemorySystemManager('you');
      
      // 场景：有希子试图支配月见枫
      const triggerResult = TriggerMechanism.processTrigger(
        yuejianfeng,
        { type: TriggerType.DOMINATION, source: '有希子', intensity: 7, description: '精神压制' },
        youxizi.yValue
      );
      
      // 月见枫因创伤基线高，抵抗成功
      expect(yuejianfeng.yBase).toBe(70); // 基线因创伤抬高
      
      // 记录到记忆
      MemoryOperations.processEvent(fengMemory, {
        type: 'confrontation',
        description: '有希子试图精神压制但失败',
        intensity: 7,
        participants: ['有希子'],
        yImpact: triggerResult.yChange,
      });
      
      // 生成提示词
      const updatedFeng = { ...yuejianfeng, yValue: triggerResult.newY };
      const prompt = PromptBuilder.buildSystemPrompt(updatedFeng, fengMemory);
      
      expect(prompt).toContain('月见枫');
      expect(prompt).toContain('有希子');
    });
  });
});
```

**Step 2: 运行完整测试套件**

```bash
npm test
```

**Step 3: 创建项目README**

```markdown
# 天道系统 (Tiandao System)

一个基于Y值、MBTI人格和三大机制（触发/补偿/回弹）的角色心理模拟引擎，兼容SillyTavern生态。

## 核心概念

### Y值 (主观意识凝练强度)
- **定义**: 人物精神内核的稳定指数 (0-100)
- **影响**: 执行力、影响力、被影响力
- **范围**: 
  - 0: 意识崩溃/死亡
  - 20-40: 不稳定/精神分裂
  - 40-70: 常人范围
  - 70-90: 气场碾压
  - 90-100: 绝对支配

### MBTI人格骨架
- 16型人格完整支持
- 每型配有Y值修正、情绪响应模式
- 人格间相性计算

### 三大机制
1. **触发机制**: 外部刺激导致Y值变化
