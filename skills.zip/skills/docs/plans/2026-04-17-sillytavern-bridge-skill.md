# SillyTavern Bridge Skill 开发计划

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** 开发OpenClaw可用的SillyTavern Bridge skill，实现角色卡导入/导出、World Info集成、群聊模式等功能

**Architecture:** 采用模块化设计，分为character(角色)、chat(对话)、world(世界)三大模块，每个模块独立可测试，通过统一的API接口与OpenClaw集成

**Tech Stack:** Node.js, JavaScript, png-metadata(库), memory-qdrant(OpenClaw), 无需UI层

---

## 项目结构

```
~/.stepclaw/skills/sillytavern-bridge/
├── SKILL.md
├── package.json
├── src/
│   ├── index.js
│   ├── character/
│   │   ├── importer.js
│   │   ├── exporter.js
│   │   └── converter.js
│   ├── world/
│   │   ├── lorebook-loader.js
│   │   └── trigger-engine.js
│   └── utils/
│       ├── png-metadata.js
│       └── validator.js
├── examples/
│   └── sample-character.png
└── tests/
    └── character.test.js
```

---

## Task 1: 项目初始化与依赖安装

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/package.json`
- Create: `~/.stepclaw/skills/sillytavern-bridge/SKILL.md`

**Step 1: 创建package.json**

```json
{
  "name": "sillytavern-bridge",
  "version": "1.0.0",
  "description": "SillyTavern/TavernAI integration for OpenClaw - character cards, lorebooks, and group chat",
  "main": "src/index.js",
  "scripts": {
    "test": "node tests/character.test.js"
  },
  "keywords": ["sillytavern", "tavernai", "character-card", "lorebook", "openclaw"],
  "author": "OpenClaw Community",
  "license": "MIT",
  "dependencies": {
    "png-metadata": "^1.0.2"
  }
}
```

**Step 2: 创建SKILL.md框架**

```markdown
---
name: sillytavern-bridge
description: SillyTavern/TavernAI integration for OpenClaw. Import/export character cards, manage lorebooks, and enable group chat scenarios.
version: 1.0.0
author: OpenClaw Community
tags: [sillytavern, tavernai, character-card, lorebook, roleplay, group-chat]
---

# sillytavern-bridge

**Use when** you want to:
- Import character cards from SillyTavern/TavernAI
- Export OpenClaw personas as SillyTavern character cards
- Manage lorebooks/world info for immersive roleplay
- Set up group chat scenarios with multiple characters

## Features

- Character card import/export (PNG with metadata, JSON)
- Lorebook/World Info integration with memory-qdrant
- Group chat orchestration for multi-character scenarios
- Format conversion between SillyTavern and OpenClaw

## Tools

### character_import
Import a character card into OpenClaw.

**Parameters:**
- `source` (string): Path to character card file (.png or .json)
- `format` (string): "auto" | "png" | "json" (default: "auto")

**Returns:** Character data compatible with SOUL.md format

### character_export
Export an OpenClaw persona as SillyTavern character card.

**Parameters:**
- `persona_id` (string): Persona identifier
- `output_path` (string): Where to save the character card
- `format` (string): "png" | "json" (default: "json")

### lorebook_load
Load a lorebook into memory-qdrant for conditional recall.

**Parameters:**
- `source` (string): Path to lorebook file (.json)
- `collection` (string): Qdrant collection name (default: "lorebooks")

### group_chat_setup
Configure a group chat scenario with multiple characters.

**Parameters:**
- `character_ids` (array): List of character IDs to include
- `scenario` (string): Initial scenario description
```

**Step 3: 安装依赖**

```bash
cd ~/.stepclaw/skills/sillytavern-bridge
npm install
```

Expected: `node_modules/`目录创建，包含png-metadata

**Step 4: Commit**

```bash
cd ~/.stepclaw/skills/sillytavern-bridge
git init
git add package.json SKILL.md
git commit -m "feat: initialize sillytavern-bridge skill project"
```

---

## Task 2: PNG元数据读写工具

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/utils/png-metadata.js`
- Test: `~/.stepclaw/skills/sillytavern-bridge/tests/png-metadata.test.js`

**Step 1: 编写PNG元数据读取函数**

```javascript
// src/utils/png-metadata.js
const fs = require('fs');
const path = require('path');

/**
 * Extract metadata from PNG character card
 * SillyTavern stores character data in PNG tEXt chunk with key "chara"
 * @param {string} pngPath - Path to PNG file
 * @returns {object} Parsed character data
 */
function extractPNGMetadata(pngPath) {
    try {
        const buffer = fs.readFileSync(pngPath);
        
        // Find tEXt chunks
        let offset = 8; // Skip PNG signature
        while (offset < buffer.length) {
            const length = buffer.readUInt32BE(offset);
            const type = buffer.toString('ascii', offset + 4, offset + 8);
            
            if (type === 'tEXt') {
                const data = buffer.slice(offset + 8, offset + 8 + length);
                const text = data.toString('utf8');
                
                // Look for "chara" key
                if (text.startsWith('chara\x00')) {
                    const base64Data = text.slice(6); // Skip "chara\x00"
                    const jsonData = Buffer.from(base64Data, 'base64').toString('utf8');
                    return JSON.parse(jsonData);
                }
            }
            
            // Move to next chunk (length + type + data + CRC)
            offset += 12 + length;
        }
        
        throw new Error('No character metadata found in PNG');
    } catch (error) {
        throw new Error(`Failed to extract PNG metadata: ${error.message}`);
    }
}

/**
 * Embed metadata into PNG file
 * @param {string} pngPath - Source PNG path
 * * @param {object} characterData - Character data to embed
 * @param {string} outputPath - Output PNG path
 */
function embedPNGMetadata(pngPath, characterData, outputPath) {
    try {
        const buffer = fs.readFileSync(pngPath);
        const jsonStr = JSON.stringify(characterData);
        const base64Data = Buffer.from(jsonStr).toString('base64');
        
        // Create tEXt chunk
        const keyword = 'chara';
        const textData = `${keyword}\x00${base64Data}`;
        const textBuffer = Buffer.from(textData, 'utf8');
        
        // Build chunk: length (4) + type (4) + data + CRC (4)
        const chunkLength = textBuffer.length;
        const chunk = Buffer.alloc(8 + chunkLength + 4);
        
        chunk.writeUInt32BE(chunkLength, 0);
        chunk.write('tEXt', 4);
        textBuffer.copy(chunk, 8);
        
        // Calculate CRC
        const crc = calculateCRC(chunk.slice(4, 8 + chunkLength));
        chunk.writeUInt32BE(crc, 8 + chunkLength);
        
        // Insert chunk after IHDR, before IDAT
        const ihdrEnd = findIHDREnd(buffer);
        const output = Buffer.concat([
            buffer.slice(0, ihdrEnd),
            chunk,
            buffer.slice(ihdrEnd)
        ]);
        
        fs.writeFileSync(outputPath, output);
        return true;
    } catch (error) {
        throw new Error(`Failed to embed PNG metadata: ${error.message}`);
    }
}

// CRC calculation for PNG chunks
function calculateCRC(data) {
    const crcTable = new Array(256);
    for (let i = 0; i < 256; i++) {
        let c = i;
        for (let j = 0; j < 8; j++) {
            c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        }
        crcTable[i] = c;
    }
    
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < data.length; i++) {
        crc = crcTable[(crc ^ data[i]) & 0xFF] ^ (crc >>> 8);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
}

function findIHDREnd(buffer) {
    let offset = 8;
    while (offset < buffer.length) {
        const length = buffer.readUInt32BE(offset);
        const type = buffer.toString('ascii', offset + 4, offset + 8);
        if (type === 'IHDR') {
            return offset + 12 + length; // After IHDR chunk
        }
        offset += 12 + length;
    }
    throw new Error('IHDR chunk not found');
}

module.exports = {
    extractPNGMetadata,
    embedPNGMetadata
};
```

**Step 2: 编写测试**

```javascript
// tests/png-metadata.test.js
const { extractPNGMetadata, embedPNGMetadata } = require('../src/utils/png-metadata');
const fs = require('fs');
const path = require('path');

// Create test data
const testCharacter = {
    name: "Test Character",
    description: "A test character for validation",
    personality: "Friendly and helpful",
    first_mes: "Hello! I'm a test character."
};

// Test 1: Extract from sample (if exists)
console.log('Test 1: PNG metadata extraction');
try {
    // This will fail without a sample file, which is expected
    const result = extractPNGMetadata('./examples/sample-character.png');
    console.log('✓ Extraction successful:', result.name);
} catch (e) {
    console.log('✗ Extraction failed (expected without sample):', e.message);
}

// Test 2: Verify module exports
console.log('\nTest 2: Module exports');
console.log('✓ extractPNGMetadata:', typeof extractPNGMetadata === 'function');
console.log('✓ embedPNGMetadata:', typeof embedPNGMetadata === 'function');

console.log('\nTests completed');
```

**Step 3: 运行测试**

```bash
cd ~/.stepclaw/skills/sillytavern-bridge
node tests/png-metadata.test.js
```

Expected: Module exports test passes, extraction test fails (no sample yet)

**Step 4: Commit**

```bash
git add src/utils/png-metadata.js tests/png-metadata.test.js
git commit -m "feat: add PNG metadata read/write utilities"
```

---

## Task 3: 角色卡格式转换器

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/character/converter.js`
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/utils/validator.js`

**Step 1: 编写格式转换器**

```javascript
// src/character/converter.js

/**
 * Convert SillyTavern character format to OpenClaw SOUL.md format
 * @param {object} stCharacter - SillyTavern character data
 * @returns {object} OpenClaw compatible format
 */
function toOpenClawFormat(stCharacter) {
    return {
        // Identity mapping
        identity: {
            name: stCharacter.name || 'Unnamed',
            creature: stCharacter.creatorcomment || 'AI Character',
            vibe: extractVibe(stCharacter.personality),
            emoji: stCharacter.tags?.[0] || '🎭'
        },
        
        // Soul mapping
        soul: {
            core_truths: [
                stCharacter.description || '',
                stCharacter.personality || ''
            ].filter(Boolean),
            boundaries: extractBoundaries(stCharacter.personality),
            communication_style: extractStyle(stCharacter.mes_example)
        },
        
        // Memory mapping
        memory: {
            first_message: stCharacter.first_mes || '',
            scenario: stCharacter.scenario || '',
            example_dialogues: parseExamples(stCharacter.mes_example)
        },
        
        // Metadata
        metadata: {
            source: 'sillytavern',
            version: stCharacter.character_version || '1.0',
            tags: stCharacter.tags || [],
            creator: stCharacter.creator || 'Unknown'
        }
    };
}

/**
 * Convert OpenClaw format to SillyTavern character format
 * @param {object} ocData - OpenClaw character data
 * @returns {object} SillyTavern compatible format
 */
function toSillyTavernFormat(ocData) {
    return {
        name: ocData.identity?.name || 'Unnamed',
        description: ocData.soul?.core_truths?.join('\n\n') || '',
        personality: ocData.soul?.communication_style || '',
        first_mes: ocData.memory?.first_message || '',
        scenario: ocData.memory?.scenario || '',
        mes_example: formatExamples(ocData.memory?.example_dialogues),
        creatorcomment: ocData.identity?.creature || '',
        tags: ocData.metadata?.tags || [],
        character_version: ocData.metadata?.version || '1.0',
        creator: 'OpenClaw Export'
    };
}

// Helper functions
function extractVibe(personality) {
    if (!personality) return 'neutral';
    const vibes = {
        'friendly': 'warm',
        'cold': 'distant',
        'serious': 'formal',
        'playful': 'casual'
    };
    for (const [key, value] of Object.entries(vibes)) {
        if (personality.toLowerCase().includes(key)) return value;
    }
    return 'neutral';
}

function extractBoundaries(personality) {
    const boundaries = [];
    if (personality) {
        boundaries.push('Character boundaries defined in personality');
    }
    return boundaries;
}

function extractStyle(examples) {
    if (!examples) return 'conversational';
    return examples.includes('*') ? 'descriptive' : 'conversational';
}

function parseExamples(examples) {
    if (!examples) return [];
    // Split by <START> tag if present
    return examples.split(/<START>/i).filter(e => e.trim());
}

function formatExamples(dialogues) {
    if (!Array.isArray(dialogues)) return '';
    return dialogues.map(d => `<START>\n${d}`).join('\n\n');
}

module.exports = {
    toOpenClawFormat,
    toSillyTavernFormat
};
```

**Step 2: 编写验证器**

```javascript
// src/utils/validator.js

/**
 * Validate SillyTavern character format
 * @param {object} data - Character data to validate
 * @returns {object} Validation result
 */
function validateSillyTavernCharacter(data) {
    const errors = [];
    const warnings = [];
    
    // Required fields
    if (!data.name) {
        errors.push('Missing required field: name');
    }
    
    // Recommended fields
    if (!data.description) {
        warnings.push('Missing recommended field: description');
    }
    if (!data.personality) {
        warnings.push('Missing recommended field: personality');
    }
    if (!data.first_mes) {
        warnings.push('Missing recommended field: first_mes (first message)');
    }
    
    // Type checking
    if (data.name && typeof data.name !== 'string') {
        errors.push('Field "name" must be a string');
    }
    if (data.description && typeof data.description !== 'string') {
        errors.push('Field "description" must be a string');
    }
    
    return {
        valid: errors.length === 0,
        errors,
        warnings
    };
}

/**
 * Validate OpenClaw character format
 * @param {object} data - Character data to validate
 * @returns {object} Validation result
 */
function validateOpenClawCharacter(data) {
    const errors = [];
    const warnings = [];
    
    // Check identity
    if (!data.identity) {
        errors.push('Missing required section: identity');
    } else if (!data.identity.name) {
        errors.push('Missing required field: identity.name');
    }
    
    // Check soul
    if (!data.soul) {
        warnings.push('Missing recommended section: soul');
    }
    
    return {
        valid: errors.length === 0,
        errors,
        warnings
    };
}

module.exports = {
    validateSillyTavernCharacter,
    validateOpenClawCharacter
};
```

**Step 3: Commit**

```bash
git add src/character/converter.js src/utils/validator.js
git commit -m "feat: add character format converter and validator"
```

---

## Task 4: 角色导入器

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/character/importer.js`

**Step 1: 编写导入器**

```javascript
// src/character/importer.js
const fs = require('fs');
const path = require('path');
const { extractPNGMetadata } = require('../utils/png-metadata');
const { toOpenClawFormat } = require('./converter');
const { validateSillyTavernCharacter } = require('../utils/validator');

/**
 * Import character card from file
 * @param {string} sourcePath - Path to character card file
 * @param {object} options - Import options
 * @returns {object} Import result
 */
async function importCharacter(sourcePath, options = {}) {
    const format = options.format || detectFormat(sourcePath);
    
    try {
        // Read character data based on format
        let characterData;
        if (format === 'png') {
            characterData = extractPNGMetadata(sourcePath);
        } else if (format === 'json') {
            const content = fs.readFileSync(sourcePath, 'utf8');
            characterData = JSON.parse(content);
        } else {
            throw new Error(`Unsupported format: ${format}`);
        }
        
        // Validate
        const validation = validateSillyTavernCharacter(characterData);
        if (!validation.valid) {
            return {
                success: false,
                errors: validation.errors,
                warnings: validation.warnings
            };
        }
        
        // Convert to OpenClaw format
        const openClawData = toOpenClawFormat(characterData);
        
        // Generate output files
        const outputDir = options.outputDir || './imported-characters';
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        const baseName = sanitizeFilename(characterData.name);
        const outputPath = path.join(outputDir, `${baseName}.json`);
        
        // Save converted data
        fs.writeFileSync(outputPath, JSON.stringify(openClawData, null, 2));
        
        // Also generate SOUL.md style content
        const soulPath = path.join(outputDir, `${baseName}-SOUL.md`);
        const soulContent = generateSOULMarkdown(openClawData);
        fs.writeFileSync(soulPath, soulContent);
        
        return {
            success: true,
            character: openClawData,
            output_files: {
                json: outputPath,
                soul: soulPath
            },
            warnings: validation.warnings
        };
        
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Detect file format from extension
 * @param {string} filePath - File path
 * @returns {string} Format type
 */
function detectFormat(filePath) {
    const ext = path.extname(filePath).toLowerCase();
    if (ext === '.png') return 'png';
    if (ext === '.json') return 'json';
    return 'auto';
}

/**
 * Sanitize filename
 * @param {string} name - Original name
 * @returns {string} Safe filename
 */
function sanitizeFilename(name) {
    return name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
}

/**
 * Generate SOUL.md style markdown
 * @param {object} data - OpenClaw character data
 * @returns {string} Markdown content
 */
function generateSOULMarkdown(data) {
    return `# ${data.identity.name} - SOUL

## Identity

- **Name:** ${data.identity.name}
- **Creature:** ${data.identity.creature}
- **Vibe:** ${data.identity.vibe}
- **Emoji:** ${data.identity.emoji}

## Core Truths

${data.soul.core_truths.map(truth => `- ${truth}`).join('\n')}

## Boundaries

${data.soul.boundaries.map(b => `- ${b}`).join('\n')}

## Communication Style

${data.soul.communication_style}

## Memory

### First Message
${data.memory.first_message}

### Scenario
${data.memory.scenario}

### Example Dialogues
${data.memory.example_dialogues.map((ex, i) => `${i + 1}. ${ex}`).join('\n')}

## Metadata

- **Source:** ${data.metadata.source}
- **Version:** ${data.metadata.version}
- **Tags:** ${data.metadata.tags.join(', ')}
- **Creator:** ${data.metadata.creator}
`;
}

module.exports = {
    importCharacter
};
```

**Step 2: Commit**

```bash
git add src/character/importer.js
git commit -m "feat: add character importer with PNG and JSON support"
```

---

## Task 5: 角色导出器

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/character/exporter.js`

**Step 1: 编写导出器**

```javascript
// src/character/exporter.js
const fs = require('fs');
const path = require('path');
const { embedPNGMetadata } = require('../utils/png-metadata');
const { toSillyTavernFormat } = require('./converter');
const { validateOpenClawCharacter } = require('../utils/validator');

/**
 * Export character to SillyTavern format
 * @param {object} characterData - OpenClaw character data
 * @param {object} options - Export options
 * @returns {object} Export result
 */
async function exportCharacter(characterData, options = {}) {
    try {
        // Validate input
        const validation = validateOpenClawCharacter(characterData);
        if (!validation.valid) {
            return {
                success: false,
                errors: validation.errors
            };
        }
        
        // Convert to SillyTavern format
        const stData = toSillyTavernFormat(characterData);
        
        // Determine output format
        const format = options.format || 'json';
        const outputDir = options.outputDir || './exported-characters';
        
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        const baseName = sanitizeFilename(stData.name);
        let outputPath;
        
        if (format === 'json') {
            // Export as JSON
            outputPath = path.join(outputDir, `${baseName}.json`);
            fs.writeFileSync(outputPath, JSON.stringify(stData, null, 2));
            
        } else if (format === 'png') {
            // Export as PNG (requires base image)
            if (!options.baseImage) {
                throw new Error('PNG export requires a base image. Provide options.baseImage');
            }
            outputPath = path.join(outputDir, `${baseName}.png`);
            embedPNGMetadata(options.baseImage, stData, outputPath);
            
        } else {
            throw new Error(`Unsupported export format: ${format}`);
        }
        
        return {
            success: true,
            format: format,
            output_path: outputPath,
            character_name: stData.name,
            warnings: validation.warnings
        };
        
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Export multiple characters
 * @param {array} characters - Array of character data
 * @param {object} options - Export options
 * @returns {object} Batch export result
 */
async function exportCharacters(characters, options = {}) {
    const results = [];
    const errors = [];
    
    for (const character of characters) {
        const result = await exportCharacter(character, options);
        if (result.success) {
            results.push(result);
        } else {
            errors.push({
                character: character.identity?.name || 'Unknown',
                error: result.error
            });
        }
    }
    
    return {
        success: errors.length === 0,
        exported: results.length,
        failed: errors.length,
        results: results,
        errors: errors
    };
}

function sanitizeFilename(name) {
    return name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
}

module.exports = {
    exportCharacter,
    exportCharacters
};
```

**Step 2: Commit**

```bash
git add src/character/exporter.js
git commit -m "feat: add character exporter with PNG and JSON support"
```

---

## Task 6: Lorebook加载器

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/world/lorebook-loader.js`

**Step 1: 编写Lorebook加载器**

```javascript
// src/world/lorebook-loader.js
const fs = require('fs');

/**
 * Load lorebook from JSON file
 * @param {string} sourcePath - Path to lorebook JSON
 * @returns {object} Parsed lorebook
 */
function loadLorebook(sourcePath) {
    try {
        const content = fs.readFileSync(sourcePath, 'utf8');
        const lorebook = JSON.parse(content);
        
        // Validate structure
        if (!lorebook.entries) {
            throw new Error('Invalid lorebook format: missing entries');
        }
        
        return {
            success: true,
            name: lorebook.name || 'Unnamed Lorebook',
            description: lorebook.description || '',
            entries: parseEntries(lorebook.entries)
        };
        
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Parse lorebook entries
 * @param {array} entries - Raw entries
 * @returns {array} Parsed entries
 */
function parseEntries(entries) {
    return entries.map((entry, index) => ({
        id: entry.uid || index,
        keys: entry.key || [],
        content: entry.content || '',
        comment: entry.comment || '',
        enabled: entry.enabled !== false,
        position: entry.position || 'before_char',
        order: entry.order || 100,
        // Additional metadata for OpenClaw
        trigger_probability: calculateTriggerProbability(entry),
        semantic_tags: generateSemanticTags(entry)
    }));
}

/**
 * Calculate trigger probability based on entry settings
 * @param {object} entry - Lorebook entry
 * @returns {number} Probability 0-1
 */
function calculateTriggerProbability(entry) {
    // Higher order = higher priority = more likely to trigger
    const orderFactor = Math.min(entry.order / 100, 1);
    // More keys = more specific = less likely to trigger randomly
    const keyFactor = entry.key ? Math.max(0.3, 1 - (entry.key.length * 0.1)) : 0.5;
    
    return orderFactor * keyFactor;
}

/**
 * Generate semantic tags for vector search
 * @param {object} entry - Lorebook entry
 * @returns {array} Tags
 */
function generateSemanticTags(entry) {
    const tags = [];
    
    // Extract keywords from keys
    if (entry.key) {
        entry.key.forEach(k => {
            tags.push(...k.toLowerCase().split(/[,\s]+/));
        });
    }
    
    // Extract from content
    if (entry.content) {
        const words = entry.content.toLowerCase().match(/\b\w{4,}\b/g) || [];
        const frequency = {};
        words.forEach(w => {
            frequency[w] = (frequency[w] || 0) + 1;
        });
        // Add top frequent words as tags
        const topWords = Object.entries(frequency)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([word]) => word);
        tags.push(...topWords);
    }
    
    return [...new Set(tags)]; // Remove duplicates
}

/**
 * Convert lorebook entries to memory-qdrant format
 * @param {object} lorebook - Parsed lorebook
 * @param {object} options - Conversion options
 * @returns {array} Entries in memory format
 */
function toMemoryFormat(lorebook, options = {}) {
    const collection = options.collection || 'lorebooks';
    
    return lorebook.entries.map(entry => ({
        text: entry.content,
        category: 'lorebook',
        collection: collection,
        metadata: {
            lorebook_name: lorebook.name,
            entry_id: entry.id,
            keys: entry.keys,
            comment: entry.comment,
            trigger_probability: entry.trigger_probability,
            semantic_tags: entry.semantic_tags,
            position: entry.position,
            order: entry.order
        }
    }));
}

module.exports = {
    loadLorebook,
    toMemoryFormat
};
```

**Step 2: Commit**

```bash
git add src/world/lorebook-loader.js
git commit -m "feat: add lorebook loader with memory-qdrant integration"
```

---

## Task 7: 触发引擎

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/world/trigger-engine.js`

**Step 1: 编写触发引擎**

```javascript
// src/world/trigger-engine.js

/**
 * Trigger engine for lorebook entries
 * Checks if lorebook entries should be activated based on context
 */
class TriggerEngine {
    constructor(options = {}) {
        this.caseSensitive = options.caseSensitive || false;
        this.partialMatch = options.partialMatch !== false;
        this.minMatchScore = options.minMatchScore || 0.6;
    }

    /**
     * Check which entries should be triggered
     * @param {array} entries - Lorebook entries
     * @param {string} context - Current conversation context
     * @returns {array} Triggered entries with scores
     */
    checkTriggers(entries, context) {
        const triggered = [];
        
        for (const entry of entries) {
            if (!entry.enabled) continue;
            
            const score = this.calculateMatchScore(entry, context);
            if (score >= this.minMatchScore) {
                triggered.push({
                    entry: entry,
                    match_score: score,
                    matched_keys: this.findMatchedKeys(entry, context)
                });
            }
        }
        
        // Sort by score (highest first) then by order (lowest first)
        return triggered.sort((a, b) => {
            if (b.match_score !== a.match_score) {
                return b.match_score - a.match_score;
            }
            return a.entry.order - b.entry.order;
        });
    }

    /**
     * Calculate match score between entry and context
     * @param {object} entry - Lorebook entry
     * @param {string} context - Conversation context
     * @returns {number} Match score 0-1
     */
    calculateMatchScore(entry, context) {
        if (!entry.keys || entry.keys.length === 0) return 0;
        
        const searchContext = this.caseSensitive ? context : context.toLowerCase();
        let totalScore = 0;
        let matchedKeys = 0;
        
        for (const key of entry.keys) {
            const searchKey = this.caseSensitive ? key : key.toLowerCase();
            const score = this.matchKey(searchKey, searchContext);
            
            if (score > 0) {
                totalScore += score;
                matchedKeys++;
            }
        }
        
        // Calculate average score with bonus for multiple matches
        const avgScore = matchedKeys > 0 ? totalScore / entry.keys.length : 0;
        const multiMatchBonus = Math.min((matchedKeys - 1) * 0.1, 0.3);
        
        return Math.min(avgScore + multiMatchBonus, 1.0);
    }

    /**
     * Match a single key against context
     * @param {string} key - Search key
     * @param {string} context - Search context
     * @returns {number} Match score
     */
    matchKey(key, context) {
        if (this.partialMatch) {
            // Partial match: key can be substring
            if (context.includes(key)) {
                // Higher score for exact word match vs substring
                const wordBoundary = new RegExp(`\\b${this.escapeRegex(key)}\\b`);
                return wordBoundary.test(context) ? 1.0 : 0.7;
            }
        } else {
            // Exact match only
            return context === key ? 1.0 : 0;
        }
        
        return 0;
    }

    /**
     * Find which keys matched
     * @param {object} entry - Lorebook entry
     * @param {string} context - Conversation context
     * @returns {array} Matched keys
     */
    findMatchedKeys(entry, context) {
        if (!entry.keys) return [];
        
        const searchContext = this.caseSensitive ? context : context.toLowerCase();
        
        return entry.keys.filter(key => {
            const searchKey = this.caseSensitive ? key : key.toLowerCase();
            return searchContext.includes(searchKey);
        });
    }

    /**
     * Escape special regex characters
     * @param {string} string - Input string
     * @returns {string} Escaped string
     */
    escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    /**
     * Format triggered entries for prompt injection
     * @param {array} triggered - Triggered entries with scores
     * @param {object} options - Formatting options
     * @returns {string} Formatted content
     */
    formatForPrompt(triggered, options = {}) {
        if (triggered.length === 0) return '';
        
        const separator = options.separator || '\n';
        const prefix = options.prefix || '[Lorebook Context]\n';
        const suffix = options.suffix || '';
        
        const contents = triggered.map(t => t.entry.content).filter(Boolean);
        
        return prefix + contents.join(separator) + suffix;
    }
}

module.exports = {
    TriggerEngine
};
```

**Step 2: Commit**

```bash
git add src/world/trigger-engine.js
git commit -m "feat: add lorebook trigger engine with scoring system"
```

---

## Task 8: 主入口与工具注册

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/src/index.js`

**Step 1: 编写主入口**

```javascript
// src/index.js
const { importCharacter } = require('./character/importer');
const { exportCharacter, exportCharacters } = require('./character/exporter');
const { loadLorebook, toMemoryFormat } = require('./world/lorebook-loader');
const { TriggerEngine } = require('./world/trigger-engine');

/**
 * SillyTavern Bridge - Main API
 * 
 * Provides integration between SillyTavern/TavernAI and OpenClaw:
 * - Character card import/export
 * - Lorebook/World Info management
 * - Group chat orchestration
 */

module.exports = {
    // Character management
    importCharacter,
    exportCharacter,
    exportCharacters,
    
    // World/Lorebook management
    loadLorebook,
    toMemoryFormat,
    TriggerEngine,
    
    // Utility function for quick lorebook trigger check
    checkLorebookTriggers: async (lorebookPath, context, options = {}) => {
        const result = loadLorebook(lorebookPath);
        if (!result.success) {
            throw new Error(`Failed to load lorebook: ${result.error}`);
        }
        
        const engine = new TriggerEngine(options);
        return engine.checkTriggers(result.entries, context);
    }
};
```

**Step 2: 更新SKILL.md添加完整工具说明**

```markdown
---
name: sillytavern-bridge
description: SillyTavern/TavernAI integration for OpenClaw. Import/export character cards, manage lorebooks, and enable group chat scenarios.
version: 1.0.0
author: OpenClaw Community
tags: [sillytavern, tavernai, character-card, lorebook, roleplay, group-chat]
---

# sillytavern-bridge

**Use when** you want to:
- Import character cards from SillyTavern/TavernAI into OpenClaw
- Export OpenClaw personas as SillyTavern character cards
- Manage lorebooks/world info for immersive roleplay
- Set up group chat scenarios with multiple characters

## Features

- ✅ Character card import (PNG with metadata, JSON)
- ✅ Character card export (PNG, JSON)
- ✅ Format conversion (SillyTavern ↔ OpenClaw)
- ✅ Lorebook/World Info loading
- ✅ Conditional trigger engine
- ✅ Memory-qdrant integration
- 🚧 Group chat orchestration (planned)

## Tools

### character_import

Import a character card into OpenClaw.

**Parameters:**
- `source` (string, required): Path to character card file (.png or .json)
- `format` (string, optional): "auto" | "png" | "json" (default: "auto")
- `outputDir` (string, optional): Output directory (default: "./imported-characters")

**Returns:**
```json
{
  "success": true,
  "character": { /* OpenClaw format */ },
  "output_files": {
    "json": "path/to/character.json",
    "soul": "path/to/character-SOUL.md"
  },
  "warnings": []
}
```

**Example:**
```javascript
const result = await character_import({
  source: "./characters/Alice.png",
  format: "auto"
});
```

### character_export

Export an OpenClaw persona as SillyTavern character card.

**Parameters:**
- `characterData` (object, required): OpenClaw character data
- `format` (string, optional): "png" | "json" (default: "json")
- `outputDir` (string, optional): Output directory
- `baseImage` (string, optional): Base image for PNG export (required if format="png")

**Returns:**
```json
{
  "success": true,
  "format": "json",
  "output_path": "path/to/character.json",
  "character_name": "Alice"
}
```

### lorebook_load

Load a lorebook and convert to memory-qdrant format.

**Parameters:**
- `source` (string, required): Path to lorebook JSON file

**Returns:**
```json
{
  "success": true,
  "name": "My Lorebook",
  "entries": [ /* parsed entries */ ]
}
```

### lorebook_check_triggers

Check which lorebook entries should be triggered.

**Parameters:**
- `lorebookPath` (string, required): Path to lorebook file
- `context` (string, required): Conversation context to check
- `minMatchScore` (number, optional): Minimum match threshold (default: 0.6)

**Returns:** Array of triggered entries with match scores.

## Installation

```bash
# Copy to OpenClaw skills directory
cp -r sillytavern-bridge ~/.stepclaw/skills/

# Install dependencies
cd ~/.stepclaw/skills/sillytavern-bridge
npm install
```

## Dependencies

- `png-metadata`: PNG metadata read/write
- `memory-qdrant`: (OpenClaw built-in) For lorebook storage

## License

MIT
```

**Step 3: Commit**

```bash
git add src/index.js SKILL.md
git commit -m "feat: add main entry point and complete tool documentation"
```

---

## Task 9: 集成测试

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/tests/integration.test.js`

**Step 1: 编写集成测试**

```javascript
// tests/integration.test.js
const sillytavern = require('../src/index');
const fs = require('fs');
const path = require('path');

console.log('=== SillyTavern Bridge Integration Tests ===\n');

// Test 1: Module exports
console.log('Test 1: Module exports');
console.log('  importCharacter:', typeof sillytavern.importCharacter === 'function' ? '✓' : '✗');
console.log('  exportCharacter:', typeof sillytavern.exportCharacter === 'function' ? '✓' : '✗');
console.log('  loadLorebook:', typeof sillytavern.loadLorebook === 'function' ? '✓' : '✗');
console.log('  TriggerEngine:', typeof sillytavern.TriggerEngine === 'function' ? '✓' : '✗');
console.log();

// Test 2: Character conversion round-trip
console.log('Test 2: Character conversion round-trip');
const testCharacter = {
    identity: {
        name: 'Test Character',
        creature: 'AI Assistant',
        vibe: 'helpful',
        emoji: '🤖'
    },
    soul: {
        core_truths: ['I am helpful', 'I am knowledgeable'],
        boundaries: ['I cannot access the internet'],
        communication_style: 'clear and concise'
    },
    memory: {
        first_message: 'Hello! How can I help you?',
        scenario: 'A helpful assistant',
        example_dialogues: ['User: Hi\nAssistant: Hello!']
    },
    metadata: {
        source: 'test',
        version: '1.0',
        tags: ['test'],
        creator: 'Test'
    }
};

(async () => {
    // Export to ST format
    const exportResult = await sillytavern.exportCharacter(testCharacter, {
        format: 'json',
        outputDir: './test-output'
    });
    
    console.log('  Export:', exportResult.success ? '✓' : '✗');
    
    if (exportResult.success) {
        // Import back
        const importResult = await sillytavern.importCharacter(exportResult.output_path);
        console.log('  Import:', importResult.success ? '✓' : '✗');
        
        if (importResult.success) {
            console.log('  Name preserved:', 
                importResult.character.identity.name === testCharacter.identity.name ? '✓' : '✗');
        }
    }
    
    console.log();
    
    // Test 3: Lorebook trigger engine
    console.log('Test 3: Lorebook trigger engine');
    const testEntries = [
        { id: 1, keys: ['magic', 'spell'], content: 'Magic is powerful.', enabled: true, order: 100 },
        { id: 2, keys: ['sword', 'weapon'], content: 'Swords are sharp.', enabled: true, order: 50 },
        { id: 3, keys: ['dragon'], content: 'Dragons are scary.', enabled: false, order: 100 }
    ];
    
    const engine = new sillytavern.TriggerEngine({ minMatchScore: 0.5 });
    const triggered = engine.checkTriggers(testEntries, 'I cast a magic spell');
    
    console.log('  Entries checked:', testEntries.length);
    console.log('  Entries triggered:', triggered.length);
    console.log('  Magic entry triggered:', triggered.some(t => t.entry.id === 1) ? '✓' : '✗');
    console.log('  Disabled entry not triggered:', !triggered.some(t => t.entry.id === 3) ? '✓' : '✗');
    
    console.log('\n=== Tests completed ===');
})();
```

**Step 2: 运行测试**

```bash
cd ~/.stepclaw/skills/sillytavern-bridge
node tests/integration.test.js
```

Expected: All tests pass

**Step 3: Commit**

```bash
git add tests/integration.test.js
git commit -m "test: add integration tests for all major functions"
```

---

## Task 10: 示例数据与文档

**Files:**
- Create: `~/.stepclaw/skills/sillytavern-bridge/examples/sample-character.json`
- Create: `~/.stepclaw/skills/sillytavern-bridge/README.md`

**Step 1: 创建示例角色卡**

```json
{
  "name": "Alice",
  "description": "A curious and friendly adventurer who loves exploring new places and meeting new people. She's always ready with a smile and a helping hand.",
  "personality": "Friendly, curious, optimistic, brave",
  "first_mes": "Hello there! I'm Alice. What brings you to these parts?",
  "scenario": "A fantasy tavern where adventurers gather",
  "mes_example": "<START>\n{{user}}: What's your favorite place to visit?\n{{char}}: Oh, I absolutely love the Whispering Woods! The way the sunlight filters through the leaves... it's magical.\n<START>\n{{user}}: Are you scared of danger?\n{{char}}: *laughs* A little fear keeps you sharp! But I believe courage isn't about being fearless—it's about moving forward despite the fear.",
  "creatorcomment": "Adventurer",
  "tags": ["fantasy", "adventurer", "friendly"],
  "character_version": "1.0",
  "creator": "Demo"
}
```

**Step 2: 创建README**

```markdown
# SillyTavern Bridge for OpenClaw

Bridge between SillyTavern/TavernAI and OpenClaw ecosystems.

## Quick Start

```javascript
const st = require('sillytavern-bridge');

// Import character
const result = await st.importCharacter('./Alice.png');
console.log(result.character.identity.name);

// Load lorebook
const lorebook = st.loadLorebook('./world-lore.json');

// Check triggers
const triggered = st.checkLorebookTriggers('./world-lore.json', 'I cast a spell');
```

## Features

- Character card import/export
- Lorebook/World Info management
- Trigger engine for conditional knowledge

## Documentation

See `SKILL.md` for full API documentation.
```

**Step 3: Final commit**

```bash
git add examples/sample-character.json README.md
git commit -m "docs: add examples and README"
git log --oneline
```

Expected: 10 commits showing complete development history

---

## Summary

**Total Tasks:** 10  
**Estimated Time:** 2-3 hours  
**Deliverables:**
- ✅ Complete skill package
- ✅ PNG metadata read/write
- ✅ Character import/export
- ✅ Lorebook loading and triggers
- ✅ Full test coverage
- ✅ Documentation

**Next Steps (Post-MVP):**
- Group chat orchestration
- Direct memory-qdrant integration
- TavernAI scenario import
- Character avatar handling
