# 天道系统 Skill 开发计划

> **For Claude:** REQUIRED SUB-SKILL: Use executing-plans to implement this plan task-by-task.

**Goal:** 开发一个OpenClaw可用的天道系统Skill，实现Y值心理动力学模拟、人道系统群体动力学、与SillyTavern生态对接

**Architecture:** 
- 分层架构：规则引擎层（白箱）+ 指令生成层 + 渲染适配层
- 模块化设计：core（核心规则）、sillytavern（对接层）、memory（记忆管理）、skills-bridge（技能桥接）
- 可插拔AI后端：支持多模型切换，本地优先

**Tech Stack:** Node.js, JavaScript/TypeScript, JSON Schema, Qdrant向量库

---

## 前置依赖检查

### Task 1: 检查SillyTavern相关Skill可用性
**Action:** 搜索并评估SillyTavern生态skill
**Files to check:** 
- `davidgibbons/sillytavern-skills@sillytavern-extension-builder`
- `davidgibbons/sillytavern-skills@character-card-v3-generator`
- `linkerlin/puax@sillytavern-overseer`
**How to test:** `npx skills find sillytavern`
**Success criteria:** 确认至少1个可用skill作为基础

### Task 2: 验证核心依赖Skill状态
**Action:** 检查以下skill是否已正确安装配置
- memory-qdrant（向量记忆）
- tavily-search（搜索爬取）
- summarize-pro（内容理解）
- article-style-analyzer（风格分析）
- self-improving（自我迭代）
**How to test:** 读取各skill的SKILL.md确认功能
**Success criteria:** 所有核心skill可用

---

## Phase 1: 项目初始化与架构搭建

### Task 3: 创建项目目录结构
**Action:** 创建天道系统skill目录
**Command:**
```bash
mkdir -p ~/.stepclaw/skills/tiandao-system/{src/{core,sillytavern,memory,skills-bridge,utils},tests,examples,docs}
```
**Files to create:**
- `~/.stepclaw/skills/tiandao-system/package.json`
- `~/.stepclaw/skills/tiandao-system/SKILL.md`
- `~/.stepclaw/skills/tiandao-system/README.md`

### Task 4: 初始化package.json
**Action:** 创建Node.js项目配置
**File:** `~/.stepclaw/skills/tiandao-system/package.json`
**Content:**
```json
{
  "name": "tiandao-system",
  "version": "1.0.0",
  "description": "天道系统 - 虚拟世界心理动力学与群体动力学模拟器",
  "main": "src/index.js",
  "scripts": {
    "test": "jest",
    "lint": "eslint src/",
    "start": "node src/index.js"
  },
  "dependencies": {
    "@qdrant/js-client-rest": "^1.0.0"
  },
  "devDependencies": {
    "jest": "^29.0.0",
    "eslint": "^8.0.0"
  },
  "keywords": ["tiandao", "sillytavern", "ai-narrative", "agent-simulation"],
  "author": "OpenClaw Agent",
  "license": "MIT"
}
```

### Task 5: 创建核心SKILL.md
**Action:** 创建skill入口文档
**File:** `~/.stepclaw/skills/tiandao-system/SKILL.md`
**Content outline:**
- 系统概述（天道+人道双系统）
- 触发条件（用户提及Y值、心理模拟、SillyTavern对接等）
- 核心功能列表
- 依赖skill清单
- 使用方法

---

## Phase 2: 核心规则引擎实现

### Task 6: 实现Y值计算引擎
**Action:** 创建Y值核心计算模块
**File:** `~/.stepclaw/skills/tiandao-system/src/core/y-value-engine.js`
**Functions to implement:**
- `calculateDeltaY(selfY, otherY)` - 计算差值
- `checkBreakthroughThreshold(selfY, deltaY)` - 检查击穿阈值
- `calculateYJump(currentY, baseline, triggerType)` - 计算Y值跃迁
- `calculateCompensation(currentY, triggerType)` - 计算补偿
- `calculateRebound(currentY, baseline, steps)` - 计算回弹
**Test:** `tests/core/y-value-engine.test.js`

### Task 7: 实现MBTI映射模块
**Action:** 创建MBTI与性格标签映射
**File:** `~/.stepclaw/skills/tiandao-system/src/core/mbti-mapper.js`
**Functions to implement:**
- `mapTagsToMBTI(tags)` - 标签映射到MBTI
- `getBaselineRange(mbti, traumaHistory)` - 获取基线区间
- `getReactionPattern(mbti, eventType)` - 获取反应模式
**Data:** 内置MBTI基线区间表

### Task 8: 实现触发机制引擎
**Action:** 创建四大触发机制
**File:** `~/.stepclaw/skills/tiandao-system/src/core/trigger-engine.js`
**Functions to implement:**
- `checkBreakthroughTrigger(character, event)` - 击穿触发
- `checkMajorEventTrigger(character, event)` - 重大事件触发
- `checkPTSDTrigger(character, event)` - PTSD扳机触发
- `checkEmotionLimitTrigger(character, emotion)` - 情绪极限触发
**Test:** 覆盖所有触发场景

### Task 9: 实现JSON心理档案管理
**Action:** 创建角色档案数据结构与管理
**File:** `~/.stepclaw/skills/tiandao-system/src/core/character-profile.js`
**Schema:**
```javascript
const characterProfileSchema = {
  name: String,
  mbti: String,
  baseY: Number,
  currentY: Number,
  baselineRange: [Number, Number],
  traumaHistory: Array,
  valuePriority: Array,
  absoluteBottom: String,
  psychologicalPattern: String,
  ptsdTriggers: Array,
  maslowNeeds: Object,
  tuckmanStage: Object,
  recentEvents: Array
};
```

---

## Phase 3: SillyTavern对接层

### Task 10: 实现角色卡导入
**Action:** 从SillyTavern PNG角色卡提取数据
**File:** `~/.stepclaw/skills/tiandao-system/src/sillytavern/character-import.js`
**Functions:**
- `extractCharacterFromPNG(pngPath)` - 提取PNG元数据
- `convertToTiandaoProfile(characterData)` - 转换为天道档案
- `importFromSillyTavern(cardPath)` - 主导入函数
**Integration:** 使用已安装的sillytavern相关skill

### Task 11: 实现Lorebook对接
**Action:** 世界设定与记忆管理对接
**File:** `~/.stepclaw/skills/tiandao-system/src/sillytavern/lorebook-bridge.js`
**Functions:**
- `loadLorebook(lorebookPath)` - 加载Lorebook
- `convertToWorldMemory(lorebookData)` - 转换为世界记忆
- `syncWithMemoryQdrant(worldData)` - 同步到向量记忆

### Task 12: 实现指令生成器
**Action:** 将天道状态转化为AI可执行指令
**File:** `~/.stepclaw/skills/tiandao-system/src/sillytavern/prompt-generator.js`
**Functions:**
- `generateCharacterPrompt(character)` - 生成角色提示
- `generateScenePrompt(scene, characters)` - 生成场景提示
- `generateYValueContext(character)` - 生成Y值上下文
**Strategy:** 碎片化输出，去语境化行为原子

---

## Phase 4: 记忆系统集成

### Task 13: 集成memory-qdrant
**Action:** 实现语义记忆存储与检索
**File:** `~/.stepclaw/skills/tiandao-system/src/memory/vector-memory.js`
**Functions:**
- `storeMemory(characterId, memory, embedding)` - 存储记忆
- `searchRelevantMemories(characterId, query, limit)` - 语义搜索
- `getCharacterMemories(characterId, memoryType)` - 按类型获取
**Integration:** 调用memory-qdrant skill

### Task 14: 实现五级记忆管理
**Action:** 总记忆/常态/异常/长/短记忆分层
**File:** `~/.stepclaw/skills/tiandao-system/src/memory/tiered-memory.js`
**Functions:**
- `classifyMemoryType(memory, character)` - 分类记忆类型
- `consolidateMemories(characterId)` - 记忆凝练
- `decayMemories(characterId, rate)` - 记忆衰减
- `loadMemoriesForContext(characterId, weight)` - 按权重加载

### Task 15: 实现事件记录系统
**Action:** 记录Y值跃迁与触发事件
**File:** `~/.stepclaw/skills/tiandao-system/src/memory/event-logger.js`
**Schema:**
```javascript
const eventRecord = {
  timestamp: Date,
  characterId: String,
  event: String,
  triggerType: String,
  deltaY: Number,
  yJump: String, // "从 X→X"
  compensatedY: Number,
  reboundStatus: String
};
```

---

## Phase 5: Skill桥接层

### Task 16: 实现Skill调用路由器
**Action:** 动态调用其他skill完成复杂任务
**File:** `~/.stepclaw/skills/tiandao-system/src/skills-bridge/skill-router.js`
**Functions:**
- `callSkill(skillName, params)` - 通用skill调用
- `summarizeContent(text, options)` - 调用summarize-pro
- `searchWeb(query)` - 调用tavily-search
- `analyzeStyle(text)` - 调用article-style-analyzer
- `humanizeText(text)` - 调用ai-humanizer

### Task 17: 实现自我迭代接口
**Action:** 集成self-improving与xiucheng-self-improving-agent
**File:** `~/.stepclaw/skills/tiandao-system/src/skills-bridge/self-improvement.js`
**Functions:**
- `reflectOnOutput(output, feedback)` - 自我反思
- `optimizeContext(context)` - 调用context-optimizer
- `learnFromInteraction(interaction)` - 学习优化

### Task 18: 实现工作流自动化
**Action:** 集成auto-workflow-builder与n8n
**File:** `~/.stepclaw/skills/tiandao-system/src/skills-bridge/workflow-automation.js`
**Functions:**
- `createNarrativeWorkflow(config)` - 创建叙事工作流
- `scheduleWorldUpdate(cronExpression)` - 定时世界更新
- `triggerEventChain(event)` - 触发事件链

---

## Phase 6: 人道系统（群体动力学）

### Task 19: 实现权重计算引擎
**Action:** 创建社会资本/影响力计算
**File:** `~/.stepclaw/skills/tiandao-system/src/core/weight-engine.js`
**Functions:**
- `calculateCharacterWeight(character, world)` - 计算角色权重
- `evaluateActionValue(action, character)` - 评估行为价值
- `updateWeights(worldState, events)` - 更新全局权重

### Task 20: 实现"老天爷"评判系统
**Action:** 基于规则的价值评判
**File:** `~/.stepclaw/skills/tiandao-system/src/core/heaven-judge.js`
**Functions:**
- `judgeAction(action, context)` - 评判行为
- `calculateButterflyEffect(event, world)` - 计算蝴蝶效应
- `determineCharacterFate(character, world)` - 决定角色命运

### Task 21: 实现回合制循环
**Action:** 单线程世界演化循环
**File:** `~/.stepclaw/skills/tiandao-system/src/core/turn-engine.js`
**Functions:**
- `processTurn(worldState)` - 处理回合
- `checkCharacterActions(character, world)` - 检查角色行动
- `resolveGlobalState(world)` - 全局结算
- `advanceTime(world, units)` - 推进时间

---

## Phase 7: CLI与API接口

### Task 22: 实现CLI工具
**Action:** 命令行交互接口
**File:** `~/.stepclaw/skills/tiandao-system/src/cli.js`
**Commands:**
- `tiandao init` - 初始化世界
- `tiandao import <character>` - 导入角色
- `tiandao run` - 运行世界
- `tiandao status` - 查看状态
- `tiandao config` - 配置管理

### Task 23: 实现JavaScript API
**Action:** 程序化接口
**File:** `~/.stepclaw/skills/tiandao-system/src/index.js`
**Exports:**
- `TiandaoSystem` - 主类
- `YValueEngine` - Y值引擎
- `CharacterProfile` - 角色档案
- `WorldSimulator` - 世界模拟器

---

## Phase 8: 测试与验证

### Task 24: 编写单元测试
**Action:** 核心模块测试
**Files:** `tests/**/*.test.js`
**Coverage:**
- Y值计算（所有跃迁场景）
- 触发机制（四大触发类型）
- 补偿/回弹计算
- 权重计算
- 记忆管理

### Task 25: 编写集成测试
**Action:** 端到端场景测试
**File:** `tests/integration/full-cycle.test.js`
**Scenarios:**
- 月见枫被击穿场景
- 有希子愧疚爆发场景
- 多人互动场景
- 世界演化场景

### Task 26: 创建示例项目
**Action:** 可运行的示例
**Files:**
- `examples/basic-world/` - 基础世界示例
- `examples/sillytavern-bridge/` - SillyTavern对接示例
- `examples/multi-character/` - 多角色互动示例

---

## Phase 9: 文档与发布

### Task 27: 完善SKILL.md
**Action:** 完整的skill使用文档
**Sections:**
- 快速开始
- 核心概念解释
- API参考
- 配置指南
- 故障排查

### Task 28: 创建架构文档
**Action:** 技术架构说明
**File:** `docs/architecture.md`
**Content:**
- 系统架构图
- 数据流图
- 模块依赖图
- 扩展点说明

### Task 29: 创建哲学背景文档
**Action:** 设计理念说明
**File:** `docs/philosophy.md`
**Content:**
- 道德经与系统设计
- 黑箱哲学
- 合理性vs精确性
- 半可控原则

---

## Phase 10: 安装与验证

### Task 30: 本地安装测试
**Action:** 验证skill可正常安装使用
**Command:**
```bash
cd ~/.stepclaw/skills/tiandao-system
npm install
npm test
```

### Task 31: 集成验证
**Action:** 测试与其他skill的集成
**Tests:**
- 调用memory-qdrant存储记忆
- 调用summarize-pro总结内容
- 调用tavily-search搜索信息
- 调用self-improving自我优化

### Task 32: 发布准备
**Action:** 准备发布到ClawHub
**Files:**
- 更新版本号
- 创建发布说明
- 打包skill

---

## 附录：依赖Skill清单

### 必需依赖
- `memory-qdrant` - 向量语义记忆
- `summarize-pro` - 内容理解与总结

### 可选依赖（自动调用）
- `tavily-search` - 网络搜索
- `article-style-analyzer` - 风格分析
- `ai-humanizer` - 文本润色
- `self-improving` / `xiucheng-self-improving-agent` - 自我迭代
- `auto-workflow-builder` / `n8n-workflow-automation` - 工作流
- `skill-vetter` - 安全检查
- `find-skills` / `find-skills-clawhub` - 技能发现
- `code` - 代码生成

### 外部生态
- `sillytavern-extension-builder` - SillyTavern扩展基础
- `character-card-v3-generator` - 角色卡生成

---

*计划创建时间: 2026-04-17*
*预计开发周期: 2-3周*
*任务总数: 32个*
