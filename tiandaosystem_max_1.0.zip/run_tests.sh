#!/bin/bash
cd /tmp/projects/tiandaosystem_max_1.0
python -m pytest tests/ -v --tb=short 2>&1 | head -100