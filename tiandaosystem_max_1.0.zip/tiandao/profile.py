"""
Character Profile Module
角色画像模块

Aggregates PsychologyProfile, MBTIProfile, MemorySystem, and MotivationChain
into a unified character profile.
"""

import json
import os
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any

# Import or define the component classes
# In a full implementation, these would be in separate modules

class PsychologyProfile:
    """Psychology profile with Y-value system."""

    def __init__(self, name: str, base_y: float = 0.5):
        self.name = name
        self.base_y = base_y
        self.current_y = base_y
        self.history: List[Dict] = []

    def update_y(self, value: float) -> float:
        """Update current Y-value."""
        self.current_y = max(0.0, min(1.0, value))
        self.history.append({"value": self.current_y, "event": "update"})
        return self.current_y

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "base_y": self.base_y,
            "current_y": self.current_y,
            "history": self.history,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "PsychologyProfile":
        profile = cls(data["name"], data["base_y"])
        profile.current_y = data["current_y"]
        profile.history = data.get("history", [])
        return profile


class MBTIProfile:
    """MBTI personality type profile."""

    def __init__(self, mbti_type: str = "INTJ"):
        self.mbti_type = mbti_type.upper() if mbti_type else "INTJ"
        if len(self.mbti_type) != 4:
            self.mbti_type = "INTJ"

    def get_dimension(self, index: int) -> str:
        return self.mbti_type[index] if index < len(self.mbti_type) else ""

    def get_description(self) -> str:
        descriptions = {
            "I": "Introverted (内向)",
            "E": "Extroverted (外向)",
            "N": "Intuition (直觉)",
            "S": "Sensing (感觉)",
            "T": "Thinking (思考)",
            "F": "Feeling (情感)",
            "J": "Judging (判断)",
            "P": "Perceiving (知觉)",
        }
        return " | ".join(
            descriptions.get(self.mbti_type[i], "")
            for i in range(min(4, len(self.mbti_type)))
        )

    def to_dict(self) -> Dict:
        return {"mbti_type": self.mbti_type}

    @classmethod
    def from_dict(cls, data: Dict) -> "MBTIProfile":
        return cls(data["mbti_type"])


class MemorySystem:
    """Character memory and experience storage."""

    def __init__(self, personality_type: str = "INTJ"):
        self.personality_type = personality_type
        self.memories: List[Dict] = []
        self.event_counter = 0

    def add_memory(self, content: str, tags: Optional[List[str]] = None) -> Dict:
        """Add a new memory."""
        self.event_counter += 1
        memory = {
            "id": self.event_counter,
            "content": content,
            "tags": tags or [],
            "personality": self.personality_type,
        }
        self.memories.append(memory)
        return memory

    def list_memories(self) -> List[Dict]:
        return self.memories

    def search_memories(self, keyword: str) -> List[Dict]:
        return [m for m in self.memories if keyword.lower() in m["content"].lower()]

    def to_dict(self) -> Dict:
        return {
            "personality_type": self.personality_type,
            "memories": self.memories,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "MemorySystem":
        system = cls(data["personality_type"])
        system.memories = data.get("memories", [])
        system.event_counter = len(system.memories)
        return system


class MotivationChain:
    """Motivation chain for analyzing character drive hierarchy."""

    def __init__(self):
        self.chains: List[Dict] = []
        self.primary_motivation: Optional[str] = None

    def add_link(self, motivation: str, intensity: float = 0.5) -> Dict:
        """Add a motivation link to the chain."""
        link = {
            "motivation": motivation,
            "intensity": max(0.0, min(1.0, intensity)),
            "index": len(self.chains),
        }
        self.chains.append(link)
        if len(self.chains) == 1:
            self.primary_motivation = motivation
        return link

    def get_chain(self) -> List[Dict]:
        return self.chains

    def to_dict(self) -> Dict:
        return {
            "chains": self.chains,
            "primary_motivation": self.primary_motivation,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "MotivationChain":
        chain = cls()
        chain.chains = data.get("chains", [])
        chain.primary_motivation = data.get("primary_motivation")
        return chain


# ============================================================================
# Character Profile Aggregator
# ============================================================================

@dataclass
class CharacterProfile:
    """
    Unified character profile combining all subsystems.

    Attributes:
        name: Character name
        psychology: PsychologyProfile instance
        mbti: MBTIProfile instance
        memory: MemorySystem instance
        motivation: MotivationChain instance
        metadata: Additional custom metadata
    """

    name: str
    psychology: PsychologyProfile = field(default_factory=lambda: PsychologyProfile(""))
    mbti: MBTIProfile = field(default_factory=lambda: MBTIProfile())
    memory: MemorySystem = field(default_factory=lambda: MemorySystem())
    motivation: MotivationChain = field(default_factory=MotivationChain)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert profile to dictionary."""
        return {
            "name": self.name,
            "psychology": self.psychology.to_dict(),
            "mbti": self.mbti.to_dict(),
            "memory": self.memory.to_dict(),
            "motivation": self.motivation.to_dict(),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "CharacterProfile":
        """Create profile from dictionary."""
        return cls(
            name=data["name"],
            psychology=PsychologyProfile.from_dict(data["psychology"]),
            mbti=MBTIProfile.from_dict(data["mbti"]),
            memory=MemorySystem.from_dict(data["memory"]),
            motivation=MotivationChain.from_dict(data["motivation"]),
            metadata=data.get("metadata", {}),
        )

    def update_profile(self, **kwargs) -> None:
        """Update profile fields."""
        if "name" in kwargs:
            self.name = kwargs["name"]
        if "mbti_type" in kwargs:
            self.mbti = MBTIProfile(kwargs["mbti_type"])
            self.memory = MemorySystem(kwargs["mbti_type"])
        if "base_y" in kwargs:
            self.psychology = PsychologyProfile(self.name, kwargs["base_y"])
        if "metadata" in kwargs:
            self.metadata.update(kwargs["metadata"])

    def get_summary(self) -> str:
        """Get a summary string of the profile."""
        lines = [
            f"Character: {self.name}",
            f"MBTI: {self.mbti.mbti_type} - {self.mbti.get_description()}",
            f"Y-Value: {self.psychology.current_y:.2f}",
            f"Primary Motivation: {self.motivation.primary_motivation or 'None'}",
            f"Memories: {len(self.memory.memories)}",
        ]
        return "\n".join(lines)


# ============================================================================
# Factory Functions
# ============================================================================

def create_profile(name: str, mbti_type: str = "INTJ", base_y: float = 0.5) -> CharacterProfile:
    """
    Create a new character profile.

    Args:
        name: Character name
        mbti_type: MBTI personality type
        base_y: Base Y-value for psychology profile

    Returns:
        New CharacterProfile instance
    """
    return CharacterProfile(
        name=name,
        psychology=PsychologyProfile(name, base_y),
        mbti=MBTIProfile(mbti_type),
        memory=MemorySystem(mbti_type),
        motivation=MotivationChain(),
    )


def update_profile(profile: CharacterProfile, **kwargs) -> CharacterProfile:
    """
    Update an existing profile.

    Args:
        profile: Existing CharacterProfile
        **kwargs: Fields to update

    Returns:
        Updated CharacterProfile
    """
    profile.update_profile(**kwargs)
    return profile


def save_profile(profile: CharacterProfile, filepath: str) -> str:
    """
    Save profile to JSON file.

    Args:
        profile: CharacterProfile to save
        filepath: Path to save file

    Returns:
        Path where file was saved
    """
    os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(profile.to_dict(), f, indent=2, ensure_ascii=False)
    return filepath


def load_profile(filepath: str) -> CharacterProfile:
    """
    Load profile from JSON file.

    Args:
        filepath: Path to profile file

    Returns:
        Loaded CharacterProfile
    """
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    return CharacterProfile.from_dict(data)
