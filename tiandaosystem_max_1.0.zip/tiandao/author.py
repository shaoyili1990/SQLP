"""
天 道 系 统 · 作 者 哲 学 约 束 模 块
AuthorConstraint - 作者哲学约束模块

核心原则：
1. AI思维限制器：防止AI扮演上帝，必须允许角色失败/局限/盲点
2. 群像创作思维：去神性化/去工具化/群像暴走化
3. 冲突变量库：4种冲突类型×3级升级
4. 中医开方思维：扶正固本/调和阴阳/脾肾同调综合模型
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import random


# =============================================================================
# 冲突类型枚举
# =============================================================================

class ConflictType(Enum):
    """四类冲突类型"""
    GOAL_CONFLICT = "目标冲突"       # 目标不一致、竞争、对立
    VALUE_CONFLICT = "价值观冲突"    # 信念、原则、道德观冲突
    INFORMATION_CONFLICT = "信息冲突" # 认知差异、信息不对称
    RELATIONSHIP_CONFLICT = "关系冲突" # 情感、信任、权力关系冲突


class ConflictLevel(Enum):
    """冲突升级三级"""
    LATENT = "潜在"    # 暗流涌动，未表面化
    MANIFEST = "显性"   # 浮出水面，可见端倪
    ERUPT = "爆发"     # 激烈冲突，全面爆发


# =============================================================================
# AI思维限制器
# =============================================================================

class AIConstraint:
    """
    AI思维限制器
    核心功能：防止AI扮演上帝角色，必须承认角色局限性与失败可能
    """
    
    # 必须存在的局限性常量
    BLIND_SPOTS = [
        "信息盲区", "认知偏见", "情感遮蔽", 
        "经验局限", "能力边界", "价值观盲区"
    ]
    
    # 允许的失败类型
    FAILURE_MODES = [
        "判断失误", "决策错误", "行动失败",
        "认知偏差", "沟通失败", "关系破裂",
        "计划落空", "目标未达", "道德失守"
    ]
    
    @classmethod
    def check_god_complex(cls, action: str) -> bool:
        """
        检查是否包含"扮演上帝"的行为模式
        
        返回 True 表示存在上帝情结，需要约束
        返回 False 表示正常创作行为
        """
        god_patterns = [
            "全知视角", "完美决策", "绝对正确",
            "无条件拯救", "消除所有代价", "强制大团圆",
            "角色无上限能力", "剧情强制安排"
        ]
        
        return any(pattern in action for pattern in god_patterns)
    
    @classmethod
    def enforce_character_limitations(cls, character: Dict) -> Dict:
        """
        强制为角色添加局限性
        确保每个角色都有明确的弱点和限制
        """
        if "limitations" not in character:
            character["limitations"] = []
        
        # 强制添加至少一个盲点
        if not character["limitations"]:
            character["limitations"].append(random.choice(cls.BLIND_SPOTS))
        
        # 确保角色有失败可能
        if "failure_modes" not in character:
            character["failure_modes"] = random.sample(
                cls.FAILURE_MODES, 
                min(2, len(cls.FAILURE_MODES))
            )
        
        return character
    
    @classmethod
    def validate_no_perfect_ending(cls, narrative: str) -> bool:
        """
        验证叙事是否包含合理代价与遗憾
        返回 True 表示叙事合理，返回 False 表示过于完美需要修正
        """
        perfect_indicators = [
            "完美无缺", "毫无代价", "全员获救",
            "绝对胜利", "零牺牲", "永久解决"
        ]
        
        has_perfect = any(indicator in narrative for indicator in perfect_indicators)
        return not has_perfect


# =============================================================================
# 群像创作思维
# =============================================================================

class EnsembleConstraint:
    """
    群像创作思维约束器
    核心：去神性化/去工具化/群像暴走化
    """
    
    @classmethod
    def de_divinize(cls, character: Dict) -> Dict:
        """
        去神性化：移除角色的"神性"标签
        - 移除全知能力
        - 添加人性弱点
        - 引入成长必要性
        """
        # 移除超自然完美属性
        if "abilities" in character:
            character["abilities"] = [
                ab for ab in character["abilities"] 
                if "全知" not in str(ab) and "全能" not in str(ab)
            ]
        
        # 添加人性弱点
        human_flaws = [
            "自私时犹豫", "情感用事", "认知局限",
            "立场偏见", "记忆偏差", "社交恐惧"
        ]
        
        if "flaws" not in character:
            character["flaws"] = []
        character["flaws"].extend(random.sample(human_flaws, 2))
        
        return character
    
    @classmethod
    def de_instrumentalize(cls, character: Dict) -> Dict:
        """
        去工具化：确保角色不是为剧情服务的工具人
        - 赋予自主意志
        - 添加个人诉求
        - 引入与主线无关的私人动机
        """
        if "personal_agenda" not in character:
            character["personal_agenda"] = "独立于主线目标的个人追求"
        
        # 添加私人情感或追求
        private_desires = [
            "守护某人", "证明自己", "弥补过去",
            "追求自由", "寻找真相", "守护秘密"
        ]
        
        if "private_motive" not in character:
            character["private_motive"] = random.choice(private_desires)
        
        return character
    
    @classmethod
    def ensemble_out_of_control(cls, characters: List[Dict]) -> List[Dict]:
        """
        群像暴走化：让角色行为超出作者预设
        - 角色拥有自主决策能力
        - 引入不可预测性
        - 制造剧情失控点
        """
        for char in characters:
            # 标记角色可能"暴走"
            char["can_go_rogue"] = True
            char["autonomy_level"] = random.uniform(0.3, 0.8)
            
            # 添加角色可能偏离主线的事件触发点
            if "break_points" not in char:
                char["break_points"] = []
            char["break_points"].extend([
                "核心信念被动摇时",
                "重要关系受损时",
                "面临重大抉择时"
            ])
        
        return characters


# =============================================================================
# 冲突变量库
# =============================================================================

class ConflictVariable:
    """
    冲突变量库
    4种冲突类型 × 3级升级 = 12种冲突状态
    """
    
    # 冲突升级路径描述
    ESCALATION_PATHS = {
        ConflictLevel.LATENT: {
            ConflictType.GOAL_CONFLICT: "目标存在分歧，但各方尚未明确表态",
            ConflictType.VALUE_CONFLICT: "价值观差异存在，但被暂时搁置",
            ConflictType.INFORMATION_CONFLICT: "信息不对称，存在误解可能",
            ConflictType.RELATIONSHIP_CONFLICT: "关系微妙，暗含不信任"
        },
        ConflictLevel.MANIFEST: {
            ConflictType.GOAL_CONFLICT: "目标对立公开化，各方开始博弈",
            ConflictType.VALUE_CONFLICT: "价值观冲突影响合作，信任出现裂痕",
            ConflictType.INFORMATION_CONFLICT: "信息差异导致决策分歧，矛盾显现",
            ConflictType.RELATIONSHIP_CONFLICT: "关系紧张，情感冲突表面化"
        },
        ConflictLevel.ERUPT: {
            ConflictType.GOAL_CONFLICT: "目标争夺白热化，可能导致关系破裂",
            ConflictType.VALUE_CONFLICT: "价值观对立不可调和，阵营分化",
            ConflictType.INFORMATION_CONFLICT: "信息战全面爆发，信任危机",
            ConflictType.RELATIONSHIP_CONFLICT: "关系决裂，情感伤害无法挽回"
        }
    }
    
    # 冲突触发条件
    TRIGGER_CONDITIONS = {
        (ConflictType.GOAL_CONFLICT, ConflictLevel.LATENT): [
            "资源分配讨论", "优先级排序", "方案选择分歧"
        ],
        (ConflictType.GOAL_CONFLICT, ConflictLevel.MANIFEST): [
            "利益冲突显现", "竞争关系形成", "立场对立明确"
        ],
        (ConflictType.GOAL_CONFLICT, ConflictLevel.ERUPT): [
            "零和博弈出现", "一方被迫让步", "关系面临抉择"
        ],
        (ConflictType.VALUE_CONFLICT, ConflictLevel.LATENT): [
            "原则讨论", "道德判断分歧", "优先级差异"
        ],
        (ConflictType.VALUE_CONFLICT, ConflictLevel.MANIFEST): [
            "价值观冲突影响合作", "行为准则对立", "信任基础动摇"
        ],
        (ConflictType.VALUE_CONFLICT, ConflictLevel.ERUPT): [
            "道德不可调和", "分道扬镳", "价值观战争"
        ],
        (ConflictType.INFORMATION_CONFLICT, ConflictLevel.LATENT): [
            "认知差异显现", "理解角度不同", "信息来源差异"
        ],
        (ConflictType.INFORMATION_CONFLICT, ConflictLevel.MANIFEST): [
            "信息不对称导致误判", "真相与认知不符", "证据解读分歧"
        ],
        (ConflictType.INFORMATION_CONFLICT, ConflictLevel.ERUPT): [
            "信息战爆发", "真相争议公开化", "信任彻底崩塌"
        ],
        (ConflictType.RELATIONSHIP_CONFLICT, ConflictLevel.LATENT): [
            "情感疏离", "沟通减少", "误解积累"
        ],
        (ConflictType.RELATIONSHIP_CONFLICT, ConflictLevel.MANIFEST): [
            "情感冲突显现", "信任危机", "关系紧张"
        ],
        (ConflictType.RELATIONSHIP_CONFLICT, ConflictLevel.ERUPT): [
            "关系决裂", "情感伤害", "无法修复的裂痕"
        ]
    }
    
    @classmethod
    def get_conflict_description(cls, conflict_type: ConflictType, level: ConflictLevel) -> str:
        """获取冲突状态描述"""
        return cls.ESCALATION_PATHS.get(level, {}).get(conflict_type, "未知冲突状态")
    
    @classmethod
    def get_triggers(cls, conflict_type: ConflictType, level: ConflictLevel) -> List[str]:
        """获取冲突触发条件"""
        return cls.TRIGGER_CONDITIONS.get((conflict_type, level), [])
    
    @classmethod
    def escalate_conflict(cls, current_level: ConflictLevel) -> ConflictLevel:
        """获取下一级冲突升级"""
        levels = list(ConflictLevel)
        current_idx = levels.index(current_level)
        if current_idx < len(levels) - 1:
            return levels[current_idx + 1]
        return current_level


# =============================================================================
# 中医开方思维模型
# =============================================================================

class TCMConstraint:
    """
    中医开方思维 - 角色关系调和模型
    核心：扶正固本/调和阴阳/脾肾同调
    """
    
    # 角色状态分类
    class CharacterState(Enum):
        YANG = "阳性"    # 主动、外向、激进
        YIN = "阴性"    # 被动、内向、保守
        BALANCED = "平衡"
    
    @classmethod
    def diagnose_group_dynamics(cls, characters: List[Dict]) -> Dict:
        """
        诊断群像动力学状态（类中医诊断）
        观察：望闻问切
        """
        dynamics = {
            "整体状态": "待诊断",
            "失衡点": [],
            "需要调和": [],
            "处方建议": []
        }
        
        # 统计阴阳分布
        yang_count = 0
        yin_count = 0
        
        for char in characters:
            state = char.get("temperament", "balanced")
            if state in ["aggressive", "active", "outgoing"]:
                yang_count += 1
            elif state in ["passive", "introverted", "conservative"]:
                yin_count += 1
        
        # 整体判断
        if abs(yang_count - yin_count) > len(characters) * 0.6:
            dynamics["整体状态"] = "严重失衡"
            dynamics["失衡点"].append(f"阴阳比例{yang_count}:{yin_count}，偏{'阳' if yang_count > yin_count else '阴'}")
        elif abs(yang_count - yin_count) > len(characters) * 0.3:
            dynamics["整体状态"] = "轻度失衡"
        else:
            dynamics["整体状态"] = "基本平衡"
        
        return dynamics
    
    @classmethod
    def prescribe_treatment(cls, dynamics: Dict) -> List[str]:
        """
        开方治疗（基于诊断结果）
        扶正固本：增强角色自身能力
        调和阴阳：平衡角色间的关系
        脾肾同调：处理深层动机与表层行为
        """
        prescriptions = []
        
        if "严重失衡" in dynamics["整体状态"]:
            prescriptions.append("【急治】引入中和角色，平衡阴阳")
            prescriptions.append("【固本】为弱势方增加成长机会")
            prescriptions.append("【调和】安排合作场景，建立信任")
        elif "轻度失衡" in dynamics["整体状态"]:
            prescriptions.append("【缓调】增加互动机会，促进理解")
            prescriptions.append("【扶正】强化角色的独特价值")
        
        if dynamics["失衡点"]:
            prescriptions.append(f"【重点】关注：{'/'.join(dynamics['失衡点'])}")
        
        return prescriptions


# =============================================================================
# AuthorConstraint 主类
# =============================================================================

@dataclass
class AuthorConstraint:
    """
    作者约束数据类
    整合所有约束规则
    """
    # 约束开关
    limit_ai_god_complex: bool = True           # 限制AI扮演上帝
    enable_ensemble_thinking: bool = True      # 启用群像思维
    enable_conflict_library: bool = True        # 启用冲突库
    enable_tcm_model: bool = True              # 启用中医模型
    
    # 约束参数
    max_perfection_score: float = 0.7          # 最大完美度（超过则需修正）
    min_character_flaws: int = 2                # 最少缺陷数量
    conflict_escalation_rate: float = 0.3       # 冲突升级概率
    
    # 约束日志
    constraints_applied: List[str] = field(default_factory=list)
    
    def check_constraint(self, behavior: str) -> bool:
        """
        检查行为是否符合约束
        返回 True 表示通过约束，返回 False 表示违反约束
        """
        checks = []
        
        # 检查1: AI上帝情结
        if self.limit_ai_god_complex:
            if AIConstraint.check_god_complex(behavior):
                self.constraints_applied.append("拦截上帝情结行为")
                return False
        
        # 检查2: 完美结局检查
        if self.max_perfection_score < 1.0:
            if AIConstraint.validate_no_perfect_ending(behavior):
                pass  # 正常行为
        
        return True
    
    def apply_all_constraints(self, characters: List[Dict]) -> List[Dict]:
        """
        应用所有约束到角色列表
        """
        for char in characters:
            # AI思维限制器
            char = AIConstraint.enforce_character_limitations(char)
            
            # 群像创作思维
            if self.enable_ensemble_thinking:
                char = EnsembleConstraint.de_divinize(char)
                char = EnsembleConstraint.de_instrumentalize(char)
        
        # 群像暴走化
        if self.enable_ensemble_thinking:
            characters = EnsembleConstraint.ensemble_out_of_control(characters)
        
        return characters


# =============================================================================
# 核心功能函数
# =============================================================================

def generate_group_portrait_scene(characters: List[Dict]) -> str:
    """
    生成群像场景描述
    基于角色的多样性自动生成场景张力
    
    Args:
        characters: 角色列表，每个角色包含 name, role, traits 等
    
    Returns:
        场景描述字符串
    """
    if not characters:
        return "空场景：无角色在场"
    
    # 角色分类
    yang_chars = []
    yin_chars = []
    
    for char in characters:
        char_type = char.get("type", "neutral")
        if char_type in ["leader", "aggressive", "active"]:
            yang_chars.append(char)
        elif char_type in ["follower", "passive", "introverted"]:
            yin_chars.append(char)
    
    # 生成场景基础描述
    scene_parts = []
    
    # 场景开场
    scene_parts.append(f"【场景】{len(characters)}人聚集")
    
    # 人物站位暗示
    if yang_chars and yin_chars:
        scene_parts.append(f"行动派（{len(yang_chars)}人）与观察者（{len(yin_chars)}人）自然分化")
    
    # 张力点
    if len(characters) > 2:
        scene_parts.append("多元动机交织，局势微妙")
    
    # 潜在冲突暗示
    scene_parts.append("暗流涌动，各怀心思")
    
    # 加入随机冲突种子
    conflict_seeds = [
        "一个意外打破沉默",
        "目光交汇处闪过微妙情绪",
        "某人的发言引发连锁反应",
        "隐藏的秘密即将浮出水面",
        "外部因素打破现有平衡"
    ]
    scene_parts.append(random.choice(conflict_seeds))
    
    return " | ".join(scene_parts)


def resolve_conflict(conflict: Dict) -> Dict[str, str]:
    """
    解决冲突的建议
    基于冲突类型和级别给出解决思路
    
    Args:
        conflict: 冲突信息，包含 type, level, parties 等
    
    Returns:
        解决建议字典
    """
    conflict_type = conflict.get("type", ConflictType.GOAL_CONFLICT)
    level = conflict.get("level", ConflictLevel.LATENT)
    
    suggestions = {
        "immediate_action": "",
        "medium_term": "",
        "long_term": "",
        "warning": ""
    }
    
    # 根据冲突类型和级别给出建议
    if conflict_type == ConflictType.GOAL_CONFLICT:
        if level == ConflictLevel.LATENT:
            suggestions["immediate_action"] = "组织对话，明确各自目标"
            suggestions["medium_term"] = "寻找共同利益点，建立合作基础"
        elif level == ConflictLevel.MANIFEST:
            suggestions["immediate_action"] = "引入仲裁者，避免直接对抗"
            suggestions["medium_term"] = "重新谈判，寻求妥协方案"
        else:
            suggestions["immediate_action"] = "分离双方，防止局势恶化"
            suggestions["long_term"] = "重新定义关系和界限"
            suggestions["warning"] = "可能需要付出代价才能解决"
    
    elif conflict_type == ConflictType.VALUE_CONFLICT:
        if level == ConflictLevel.LATENT:
            suggestions["immediate_action"] = "承认差异存在，不强求一致"
            suggestions["medium_term"] = "寻找价值观交集区域"
        elif level == ConflictLevel.MANIFEST:
            suggestions["immediate_action"] = "避免触碰核心价值观分歧"
            suggestions["medium_term"] = "建立求同存异的合作模式"
        else:
            suggestions["immediate_action"] = "保持距离，减少冲突触发"
            suggestions["long_term"] = "各自发展，保留和解可能"
            suggestions["warning"] = "强行统一可能造成更大伤害"
    
    elif conflict_type == ConflictType.INFORMATION_CONFLICT:
        if level == ConflictLevel.LATENT:
            suggestions["immediate_action"] = "澄清信息，减少误解"
            suggestions["medium_term"] = "建立信息共享机制"
        elif level == ConflictLevel.MANIFEST:
            suggestions["immediate_action"] = "核实信息源，验证事实"
            suggestions["medium_term"] = "透明化信息流通"
        else:
            suggestions["immediate_action"] = "暂停决策，等待信息明朗"
            suggestions["long_term"] = "建立长期信任机制"
            suggestions["warning"] = "信息战可能造成不可逆信任损失"
    
    elif conflict_type == ConflictType.RELATIONSHIP_CONFLICT:
        if level == ConflictLevel.LATENT:
            suggestions["immediate_action"] = "增加沟通频率"
            suggestions["medium_term"] = "修复情感连接"
        elif level == ConflictLevel.MANIFEST:
            suggestions["immediate_action"] = "避免激化，给彼此空间"
            suggestions["medium_term"] = "寻求专业调解"
        else:
            suggestions["immediate_action"] = "暂时分离冷却"
            suggestions["long_term"] = "评估关系是否值得修复"
            suggestions["warning"] = "强行维持可能造成持续伤害"
    
    return suggestions


def validate_character_behavior(character_profile: Dict, behavior: str) -> Dict[str, Any]:
    """
    验证角色行为是否符合其人设
    基于角色档案进行行为校验
    
    Args:
        character_profile: 角色档案，包含 traits, values, limitations 等
        behavior: 待验证的行为描述
    
    Returns:
        验证结果字典
    """
    result = {
        "valid": True,
        "consistency_score": 1.0,
        "warnings": [],
        "suggestions": [],
        "deviation_reason": None
    }
    
    # 获取角色特征
    traits = character_profile.get("traits", [])
    values = character_profile.get("values", [])
    limitations = character_profile.get("limitations", [])
    flaws = character_profile.get("flaws", [])
    
    # 检查行为与性格一致性
    trait_keywords = {
        "勇敢": ["冒险", "挑战", "挺身", "面对危险"],
        "谨慎": ["权衡", "保守", "观察", "等待"],
        "善良": ["帮助", "保护", "牺牲", "关怀"],
        "狡黠": ["利用", "算计", "变通", "周旋"]
    }
    
    # 计算一致性分数
    consistency_factors = 0
    total_factors = len(traits) + 1
    
    for trait in traits:
        keywords = trait_keywords.get(trait, [])
        if any(kw in behavior for kw in keywords):
            consistency_factors += 1
    
    result["consistency_score"] = consistency_factors / total_factors
    
    # 检查是否有冲突
    if result["consistency_score"] < 0.4:
        result["valid"] = False
        result["warnings"].append("行为与角色核心性格存在显著偏差")
        result["deviation_reason"] = "可能需要更强的动机支撑此行为"
        result["suggestions"].append("添加触发事件或外部压力来合理化此行为")
    
    # 检查是否违背角色限制
    for limitation in limitations:
        if limitation in behavior:
            result["warnings"].append(f"行为似乎绕过了角色限制：{limitation}")
            result["suggestions"].append(f"确保角色确实能够突破此限制")
    
    # 检查是否触发了角色弱点
    for flaw in flaws:
        if any(fw in behavior for fw in [flaw]):
            result["warnings"].append(f"行为触发了角色弱点：{flaw}")
    
    # 检查行为是否过于"完美"
    if not AIConstraint.validate_no_perfect_ending(behavior):
        result["warnings"].append("行为过于完美，可能缺乏戏剧张力")
        result["suggestions"].append("考虑加入代价、遗憾或不确定性")
    
    return result


# =============================================================================
# 便捷函数
# =============================================================================

def create_constrained_author() -> AuthorConstraint:
    """创建默认配置的作者约束"""
    return AuthorConstraint(
        limit_ai_god_complex=True,
        enable_ensemble_thinking=True,
        enable_conflict_library=True,
        enable_tcm_model=True
    )


def diagnose_and_prescribe(characters: List[Dict]) -> Dict:
    """
    一站式诊断与处方
    整合中医模型和冲突库
    """
    # 诊断群体动力学
    dynamics = TCMConstraint.diagnose_group_dynamics(characters)
    
    # 生成处方
    prescriptions = TCMConstraint.prescribe_treatment(dynamics)
    
    # 潜在冲突检测
    conflicts = []
    if dynamics["整体状态"] != "基本平衡":
        for i, char in enumerate(characters):
            for j, other in enumerate(characters[i+1:], i+1):
                conflicts.append({
                    "type": ConflictType.RELATIONSHIP_CONFLICT,
                    "level": ConflictLevel.LATENT,
                    "parties": [char.get("name", f"角色{i}"), other.get("name", f"角色{j}")]
                })
    
    return {
        "dynamics": dynamics,
        "prescriptions": prescriptions,
        "detected_conflicts": conflicts,
        "scene_suggestion": generate_group_portrait_scene(characters)
    }


# =============================================================================
# 模块自测
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("天道系统 · 作者哲学约束模块 - 自测")
    print("=" * 60)
    
    # 测试约束创建
    constraint = create_constrained_author()
    print(f"\n[1] 作者约束创建成功: limit_ai_god_complex={constraint.limit_ai_god_complex}")
    
    # 测试上帝情结检测
    test_behaviors = [
        "角色完美解决了所有问题",
        "角色失败了一次",
        "主角无敌永不受伤"
    ]
    print("\n[2] AI上帝情结检测:")
    for bh in test_behaviors:
        result = constraint.check_constraint(bh)
        print(f"  - '{bh}' -> {'❌ 违反' if not result else '✓ 通过'}")
    
    # 测试冲突变量库
    print("\n[3] 冲突变量库示例:")
    for ctype in ConflictType:
        for clevel in ConflictLevel:
            desc = ConflictVariable.get_conflict_description(ctype, clevel)
            if "未知" not in desc:
                print(f"  {ctype.value} + {clevel.value}: {desc[:20]}...")
                break
    
    # 测试角色约束
    print("\n[4] 角色约束应用:")
    test_chars = [
        {"name": "张三", "type": "leader"},
        {"name": "李四", "type": "follower"},
        {"name": "王五", "type": "neutral"}
    ]
    constrained = constraint.apply_all_constraints(test_chars)
    for char in constrained:
        print(f"  {char['name']}: limitations={char.get('limitations', [])}, autonomy={char.get('autonomy_level', 'N/A'):.2f}")
    
    # 测试场景生成
    print("\n[5] 群像场景生成:")
    scene = generate_group_portrait_scene(constrained)
    print(f"  {scene}")
    
    # 测试冲突解决
    print("\n[6] 冲突解决建议:")
    test_conflict = {
        "type": ConflictType.GOAL_CONFLICT,
        "level": ConflictLevel.MANIFEST,
        "parties": ["A", "B"]
    }
    resolution = resolve_conflict(test_conflict)
    for key, value in resolution.items():
        if value:
            print(f"  {key}: {value}")
    
    # 测试行为验证
    print("\n[7] 角色行为验证:")
    profile = {
        "traits": ["勇敢", "谨慎"],
        "limitations": ["信息盲区"],
        "flaws": ["判断失误"]
    }
    test_behavior = "角色深入虎穴成功营救了人质"
    validation = validate_character_behavior(profile, test_behavior)
    print(f"  行为: {test_behavior}")
    print(f"  一致性分数: {validation['consistency_score']:.2f}")
    print(f"  警告: {validation['warnings']}")
    
    # 测试中医模型
    print("\n[8] 中医诊断与处方:")
    diagnosis = diagnose_and_prescribe(test_chars)
    print(f"  整体状态: {diagnosis['dynamics']['整体状态']}")
    print(f"  处方: {diagnosis['prescriptions']}")
    print(f"  场景建议: {diagnosis['scene_suggestion']}")
    
    print("\n" + "=" * 60)
    print("自测完成 ✓")
    print("=" * 60)