"""
逻辑动机链模块 - Motivation Chain Module

核心概念:
1. 七种本能驱动: 求存/求知/表现/舒适/情欲/表达/母性本能
2. 四层动机链: 表层动机→深层动机→核心动机→灵魂动机
3. 七种决策框架: 利益/情感/逻辑/社交/安全/成长/使命优先

本模块提供角色动机分析、动机链生成和决策框架选择功能。
"""

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional
import random


# ==================== 本能驱动枚举 ====================

class Instinct(IntEnum):
    """七种本能驱动"""
    SURVIVAL = 1      # 求存本能 - 生存、安全、资源获取
    KNOWLEDGE = 2     # 求知本能 - 探索、学习、好奇心
    EXPRESSION = 3    # 表现本能 - 展示自我、获得认可
    COMFORT = 4       # 舒适本能 - 追求舒适、避免痛苦
    DESIRE = 5        # 情欲本能 - 情感、亲密、繁殖
    CREATIVE = 6      # 表达本能 - 创造、艺术、表达
    MATERNAL = 7      # 母性本能 - 保护、养育、归属


INSTINCT_NAMES = {
    Instinct.SURVIVAL: "求存本能",
    Instinct.KNOWLEDGE: "求知本能",
    Instinct.EXPRESSION: "表现本能",
    Instinct.COMFORT: "舒适本能",
    Instinct.DESIRE: "情欲本能",
    Instinct.CREATIVE: "表达本能",
    Instinct.MATERNAL: "母性本能",
}

INSTINCT_NAMES_EN = {
    Instinct.SURVIVAL: "SURVIVAL",
    Instinct.KNOWLEDGE: "KNOWLEDGE",
    Instinct.EXPRESSION: "EXPRESSION",
    Instinct.COMFORT: "COMFORT",
    Instinct.DESIRE: "DESIRE",
    Instinct.CREATIVE: "CREATIVE",
    Instinct.MATERNAL: "MATERNAL",
}

# 本能驱动描述
INSTINCT_DESCRIPTIONS = {
    Instinct.SURVIVAL: "追求生存、安全和资源获取，避免危险和死亡",
    Instinct.KNOWLEDGE: "渴望探索、学习和理解，满足好奇心和求知欲",
    Instinct.EXPRESSION: "希望展示自我、获得认可和尊重，体现个人价值",
    Instinct.COMFORT: "追求身体和心理的舒适感，避免痛苦和不适",
    Instinct.DESIRE: "情感需求、亲密关系、生理欲望和繁殖本能",
    Instinct.CREATIVE: "创造欲望、艺术表达、美感追求和审美体验",
    Instinct.MATERNAL: "保护、养育、关怀后代，寻求归属和被需要感",
}


# ==================== 决策框架枚举 ====================

class DecisionFramework(IntEnum):
    """七种决策框架"""
    PROFIT = 1     # 利益优先 - 权衡利弊、追求最大化收益
    EMOTION = 2    # 情感优先 - 跟随内心、重视情感体验
    LOGIC = 3      # 逻辑优先 - 理性分析、注重因果关系
    SOCIAL = 4     # 社交优先 - 考虑人际、重视社会评价
    SAFETY = 5     # 安全优先 - 规避风险、追求稳定
    GROWTH = 6     # 成长优先 - 追求发展、重视潜力挖掘
    MISSION = 7    # 使命优先 - 追求意义、关注长远价值


FRAMEWORK_NAMES = {
    DecisionFramework.PROFIT: "利益优先",
    DecisionFramework.EMOTION: "情感优先",
    DecisionFramework.LOGIC: "逻辑优先",
    DecisionFramework.SOCIAL: "社交优先",
    DecisionFramework.SAFETY: "安全优先",
    DecisionFramework.GROWTH: "成长优先",
    DecisionFramework.MISSION: "使命优先",
}

FRAMEWORK_NAMES_EN = {
    DecisionFramework.PROFIT: "PROFIT",
    DecisionFramework.EMOTION: "EMOTION",
    DecisionFramework.LOGIC: "LOGIC",
    DecisionFramework.SOCIAL: "SOCIAL",
    DecisionFramework.SAFETY: "SAFETY",
    DecisionFramework.GROWTH: "GROWTH",
    DecisionFramework.MISSION: "MISSION",
}

# 决策框架描述
FRAMEWORK_DESCRIPTIONS = {
    DecisionFramework.PROFIT: "权衡利弊得失，追求利益最大化，实用主义导向",
    DecisionFramework.EMOTION: "跟随内心感受，重视情感体验，人文关怀导向",
    DecisionFramework.LOGIC: "理性分析推理，注重因果逻辑，科学方法导向",
    DecisionFramework.SOCIAL: "考虑人际影响，重视社会评价，关系维护导向",
    DecisionFramework.SAFETY: "规避风险损失，追求稳定可控，保守谨慎导向",
    DecisionFramework.GROWTH: "追求自我发展，重视潜力挖掘，成长进步导向",
    DecisionFramework.MISSION: "追求意义价值，关注长远影响，使命愿景导向",
}


# ==================== 动机链数据类 ====================

@dataclass
class MotivationChain:
    """
    动机链数据类
    
    表示从本能驱动到灵魂动机的四层动机链结构:
    - 本能: 最底层的生理/心理本能
    - 表层动机: 直接的行动目标
    - 深层动机: 内心真实诉求
    - 核心动机: 核心价值观体现
    - 灵魂动机: 终极人生意义
    
    Attributes:
        instinct: 本能驱动类型
        surface: 表层动机 - 即时行动目标
        deep: 深层动机 - 内心真实诉求
        core: 核心动机 - 核心价值观体现
        soul: 灵魂动机 - 终极人生意义
        intensity: 动机强度 (0-100)
        confidence: 动机确定性 (0-1)
    """
    instinct: Instinct
    surface: str
    deep: str
    core: str
    soul: str
    intensity: float = 75.0
    confidence: float = 0.8
    
    def __post_init__(self):
        """数据验证"""
        self.intensity = max(0.0, min(100.0, self.intensity))
        self.confidence = max(0.0, min(1.0, self.confidence))


@dataclass
class DecisionFrameworkProfile:
    """
    决策框架数据类
    
    表示角色在决策时的优先级和权重配置
    
    Attributes:
        primary: 主要决策框架
        secondary: 次要决策框架
        weights: 各框架权重 (0-1)
        flexibility: 框架灵活度 (0-1)
    """
    primary: DecisionFramework
    secondary: DecisionFramework
    weights: dict = field(default_factory=dict)
    flexibility: float = 0.5
    
    def __post_init__(self):
        """初始化默认权重"""
        if not self.weights:
            self.weights = {
                DecisionFramework.PROFIT: 0.3,
                DecisionFramework.EMOTION: 0.3,
                DecisionFramework.LOGIC: 0.3,
                DecisionFramework.SOCIAL: 0.3,
                DecisionFramework.SAFETY: 0.3,
                DecisionFramework.GROWTH: 0.3,
                DecisionFramework.MISSION: 0.3,
            }


# ==================== 动机链生成器 ====================

# 本能-表层动机映射
INSTINCT_SURFACE_MAP = {
    Instinct.SURVIVAL: ["获取食物", "躲避危险", "寻找庇护", "积累资源", "保护领地"],
    Instinct.KNOWLEDGE: ["收集信息", "学习技能", "分析问题", "研究原理", "探索未知"],
    Instinct.EXPRESSION: ["展示成果", "发表观点", "获得赞美", "建立形象", "证明能力"],
    Instinct.COMFORT: ["休息放松", "改善环境", "寻求安稳", "避免冲突", "享受美食"],
    Instinct.DESIRE: ["建立亲密", "表达情感", "追求浪漫", "寻求陪伴", "满足情感"],
    Instinct.CREATIVE: ["创作作品", "艺术表达", "设计创新", "美化事物", "分享美感"],
    Instinct.MATERNAL: ["保护他人", "照顾弱者", "建立归属", "提供支持", "传承经验"],
}

# 本能-深层动机映射
INSTINCT_DEEP_MAP = {
    Instinct.SURVIVAL: ["确保生存安全", "获得掌控感", "消除不确定性", "建立保障", "避免威胁"],
    Instinct.KNOWLEDGE: ["满足好奇心", "提升能力感", "理解世界规律", "获得成长", "成为专家"],
    Instinct.EXPRESSION: ["获得认同感", "体现自我价值", "建立自信", "赢得尊重", "被看见"],
    Instinct.COMFORT: ["获得愉悦感", "减少焦虑", "保持平衡", "享受生活", "内心平静"],
    Instinct.DESIRE: ["获得归属感", "体验亲密", "表达爱意", "被爱的需求", "情感连接"],
    Instinct.CREATIVE: ["表达内在世界", "留下印记", "创造意义", "超越自我", "永恒价值"],
    Instinct.MATERNAL: ["延续血脉/理念", "被需要感", "付出爱", "建立传承", "群体认同"],
}

# 本能-核心动机映射
INSTINCT_CORE_MAP = {
    Instinct.SURVIVAL: ["存在即价值", "适者生存", "安全第一", "资源为王", "实力证明一切"],
    Instinct.KNOWLEDGE: ["知行合一", "求真务实", "理性至上", "智慧即力量", "认知即自由"],
    Instinct.EXPRESSION: ["自我实现", "人格独立", "价值证明", "声誉积累", "影响力"],
    Instinct.COMFORT: ["身心和谐", "中庸之道", "知足常乐", "活在当下", "生活质量"],
    Instinct.DESIRE: ["爱即永恒", "情感至上", "连接为本", "真诚相待", "情感自由"],
    Instinct.CREATIVE: ["创造即存在", "艺术即真理", "美即本质", "创新驱动", "独特价值"],
    Instinct.MATERNAL: ["爱出者爱返", "薪火相传", "归属即家", "共同体意识", "大爱无疆"],
}

# 本能-灵魂动机映射
INSTINCT_SOUL_MAP = {
    Instinct.SURVIVAL: ["生命的延续", "永恒的存在", "超越死亡", "宇宙中的一粒尘埃", "存在的意义"],
    Instinct.KNOWLEDGE: ["终极真理", "智慧传承", "认识你自己", "宇宙的全知", "觉醒与觉悟"],
    Instinct.EXPRESSION: ["灵魂的表达", "成为自己", "活出真我", "独特的生命故事", "存在的印记"],
    Instinct.COMFORT: ["内心的安宁", "与自我和解", "灵魂的平静", "圆满具足", "安然自在"],
    Instinct.DESIRE: ["爱的真谛", "灵魂的伴侣", "永恒的爱", "超越时空的连接", "大爱无界"],
    Instinct.CREATIVE: ["创造即救赎", "永恒的艺术", "灵魂的造物", "超越时空的价值", "神性显现"],
    Instinct.MATERNAL: ["永恒的守护", "灵魂的归属", "大爱无疆", "生命的延续", "宇宙的延续"],
}


def _get_motivation_variant(instinct: Instinct, scene: str, role: str) -> tuple:
    """
    根据场景和角色获取动机变体
    
    Args:
        instinct: 本能类型
        scene: 场景描述
        role: 角色描述
        
    Returns:
        tuple: (surface, deep, core, soul) 四个层次的动机
    """
    random.seed(hash(scene + role) % 1000000)
    
    surface_list = INSTINCT_SURFACE_MAP.get(instinct, ["采取行动"])
    deep_list = INSTINCT_DEEP_MAP.get(instinct, ["满足需求"])
    core_list = INSTINCT_CORE_MAP.get(instinct, ["自我实现"])
    soul_list = INSTINCT_SOUL_MAP.get(instinct, ["人生意义"])
    
    surface = random.choice(surface_list)
    deep = random.choice(deep_list)
    core = random.choice(core_list)
    soul = random.choice(soul_list)
    
    return surface, deep, core, soul


def _calculate_intensity(instinct: Instinct, scene: str, role: str) -> float:
    """
    计算动机强度
    
    基于本能类型、场景紧迫性和角色特性计算动机强度
    
    Args:
        instinct: 本能类型
        scene: 场景描述
        role: 角色描述
        
    Returns:
        float: 动机强度 (0-100)
    """
    # 基础强度
    base_intensity = 60.0
    
    # 根据本能类型调整
    instinct_weights = {
        Instinct.SURVIVAL: 15,    # 求存本能强度最高
        Instinct.DESIRE: 12,      # 情欲本能次之
        Instinct.COMFORT: 10,     # 舒适本能
        Instinct.EXPRESSION: 8,   # 表现本能
        Instinct.KNOWLEDGE: 6,    # 求知本能
        Instinct.MATERNAL: 5,     # 母性本能
        Instinct.CREATIVE: 4,     # 表达本能
    }
    
    # 场景关键词对强度的影响
    scene_intensity_keywords = {
        "紧急": 15, "危险": 15, "关键": 12, "重要": 10,
        "日常": 0, "普通": 0, "可选": -10,
        "犹豫": -5, "困惑": -5
    }
    
    intensity = base_intensity + instinct_weights.get(instinct, 5)
    
    for keyword, delta in scene_intensity_keywords.items():
        if keyword in scene:
            intensity += delta
    
    # 角色关键词对强度的影响
    role_intensity_keywords = {
        "坚定": 10, "强烈": 10, "执着": 8,
        "犹豫": -8, "迷茫": -5, "淡漠": -10
    }
    
    for keyword, delta in role_intensity_keywords.items():
        if keyword in role:
            intensity += delta
    
    return max(20.0, min(100.0, intensity))


def _calculate_confidence(instinct: Instinct, scene: str, role: str) -> float:
    """
    计算动机确定性
    
    Args:
        instinct: 本能类型
        scene: 场景描述
        role: 角色描述
        
    Returns:
        float: 确定性 (0-1)
    """
    base_confidence = 0.7
    
    # 复杂场景降低确定性
    if any(k in scene for k in ["选择", "矛盾", "复杂", "两难"]):
        base_confidence -= 0.2
    
    # 坚定角色提高确定性
    if any(k in role for k in ["坚定", "果断", "明确", "清晰"]):
        base_confidence += 0.15
    
    return max(0.3, min(0.95, base_confidence))


def generate_motivation_chain(
    instinct: Instinct,
    scene: str,
    role: str
) -> MotivationChain:
    """
    生成动机链
    
    根据本能类型、场景和角色生成完整的四层动机链
    
    Args:
        instinct: 本能驱动类型
        scene: 场景描述
        role: 角色描述
        
    Returns:
        MotivationChain: 动机链对象
        
    Example:
        >>> chain = generate_motivation_chain(
        ...     Instinct.SURVIVAL,
        ...     "面对敌人威胁",
        ...     "勇敢的战士"
        ... )
        >>> print(chain.surface)
        躲避危险
    """
    surface, deep, core, soul = _get_motivation_variant(instinct, scene, role)
    intensity = _calculate_intensity(instinct, scene, role)
    confidence = _calculate_confidence(instinct, scene, role)
    
    return MotivationChain(
        instinct=instinct,
        surface=surface,
        deep=deep,
        core=core,
        soul=soul,
        intensity=intensity,
        confidence=confidence
    )


# ==================== 决策框架生成器 ====================

# 角色类型到决策框架的默认映射
ROLE_FRAMEWORK_MAP = {
    # 利益导向角色
    "商人": DecisionFramework.PROFIT,
    "投资者": DecisionFramework.PROFIT,
    "企业家": DecisionFramework.PROFIT,
    
    # 情感导向角色
    "恋人": DecisionFramework.EMOTION,
    "艺术家": DecisionFramework.EMOTION,
    "诗人": DecisionFramework.EMOTION,
    
    # 逻辑导向角色
    "科学家": DecisionFramework.LOGIC,
    "工程师": DecisionFramework.LOGIC,
    "侦探": DecisionFramework.LOGIC,
    
    # 社交导向角色
    "外交官": DecisionFramework.SOCIAL,
    "销售": DecisionFramework.SOCIAL,
    "公关": DecisionFramework.SOCIAL,
    
    # 安全导向角色
    "保守者": DecisionFramework.SAFETY,
    "公务员": DecisionFramework.SAFETY,
    "守卫": DecisionFramework.SAFETY,
    
    # 成长导向角色
    "学生": DecisionFramework.GROWTH,
    "创业者": DecisionFramework.GROWTH,
    "运动员": DecisionFramework.GROWTH,
    
    # 使命导向角色
    "领导者": DecisionFramework.MISSION,
    "政治家": DecisionFramework.MISSION,
    "改革者": DecisionFramework.MISSION,
}

# 角色类型到次要框架的映射
ROLE_SECONDARY_MAP = {
    "企业家": DecisionFramework.GROWTH,
    "艺术家": DecisionFramework.EMOTION,
    "科学家": DecisionFramework.LOGIC,
    "外交官": DecisionFramework.LOGIC,
    "创业者": DecisionFramework.PROFIT,
    "领导者": DecisionFramework.SOCIAL,
    "诗人": DecisionFramework.EMOTION,
    "守卫": DecisionFramework.SAFETY,
}


def get_decision_framework(role: str) -> DecisionFrameworkProfile:
    """
    获取角色的决策框架配置
    
    根据角色类型返回对应的决策框架配置，包含主次框架和权重
    
    Args:
        role: 角色描述
        
    Returns:
        DecisionFrameworkProfile: 决策框架配置
        
    Example:
        >>> profile = get_decision_framework("企业家")
        >>> print(profile.primary)
        1  # PROFIT
    """
    role_lower = role.lower()
    
    # 查找主要框架
    primary = DecisionFramework.PROFIT  # 默认
    for keyword, framework in ROLE_FRAMEWORK_MAP.items():
        if keyword in role_lower:
            primary = framework
            break
    
    # 查找次要框架
    secondary = DecisionFramework.LOGIC  # 默认
    for keyword, framework in ROLE_SECONDARY_MAP.items():
        if keyword in role_lower:
            secondary = framework
            break
    
    # 生成权重配置
    weights = {}
    for framework in DecisionFramework:
        if framework == primary:
            weights[framework] = 0.9
        elif framework == secondary:
            weights[framework] = 0.6
        elif framework in [DecisionFramework.PROFIT, DecisionFramework.LOGIC]:
            weights[framework] = 0.4
        else:
            weights[framework] = 0.2
    
    # 灵活度：社交型角色更灵活，使命型角色更坚定
    flexibility = 0.5
    if any(k in role_lower for k in ["外交", "销售", "公关", "灵活"]):
        flexibility = 0.7
    elif any(k in role_lower for k in ["坚定", "固执", "保守", "原则"]):
        flexibility = 0.3
    
    return DecisionFrameworkProfile(
        primary=primary,
        secondary=secondary,
        weights=weights,
        flexibility=flexibility
    )


def calculate_decision_score(
    profile: DecisionFrameworkProfile,
    option_profit: float,
    option_emotion: float,
    option_logic: float,
    option_social: float,
    option_safety: float,
    option_growth: float,
    option_mission: float
) -> float:
    """
    计算决策加权得分
    
    根据决策框架权重计算各选项的加权得分
    
    Args:
        profile: 决策框架配置
        option_profit: 选项的利益得分
        option_emotion: 选项的情感得分
        option_logic: 选项的逻辑得分
        option_social: 选项的社交得分
        option_safety: 选项的安全得分
        option_growth: 选项的成长得分
        option_mission: 选项的使命得分
        
    Returns:
        float: 加权决策得分
    """
    option_scores = {
        DecisionFramework.PROFIT: option_profit,
        DecisionFramework.EMOTION: option_emotion,
        DecisionFramework.LOGIC: option_logic,
        DecisionFramework.SOCIAL: option_social,
        DecisionFramework.SAFETY: option_safety,
        DecisionFramework.GROWTH: option_growth,
        DecisionFramework.MISSION: option_mission,
    }
    
    total_score = 0.0
    total_weight = 0.0
    
    for framework, score in option_scores.items():
        weight = profile.weights.get(framework, 0.3)
        total_score += score * weight
        total_weight += weight
    
    if total_weight == 0:
        return 50.0
    
    return (total_score / total_weight) * 100 / max(option_scores.values()) if max(option_scores.values()) > 0 else 50.0


# ==================== 动机强度计算 ====================

def calculate_motivation_strength(
    instinct: Instinct,
    urgency: float = 0.5,
    importance: float = 0.5,
    personal_relevance: float = 0.5
) -> float:
    """
    计算动机强度
    
    综合紧迫性、重要性和个人关联度计算动机强度
    
    Args:
        instinct: 本能类型
        urgency: 紧迫程度 (0-1)
        importance: 重要程度 (0-1)
        personal_relevance: 个人关联度 (0-1)
        
    Returns:
        float: 动机强度 (0-100)
    """
    # 本能基础权重
    base_weights = {
        Instinct.SURVIVAL: 90,
        Instinct.DESIRE: 80,
        Instinct.COMFORT: 70,
        Instinct.EXPRESSION: 60,
        Instinct.KNOWLEDGE: 55,
        Instinct.MATERNAL: 75,
        Instinct.CREATIVE: 50,
    }
    
    base = base_weights.get(instinct, 50)
    
    # 综合计算
    strength = base * 0.4 + (urgency * 100) * 0.2 + (importance * 100) * 0.2 + (personal_relevance * 100) * 0.2
    
    return max(10.0, min(100.0, strength))


def compare_motivations(chain1: MotivationChain, chain2: MotivationChain) -> int:
    """
    比较两个动机链的优先级
    
    Args:
        chain1: 动机链1
        chain2: 动机链2
        
    Returns:
        int: 1 if chain1更强, -1 if chain2更强, 0 if 相等
    """
    score1 = chain1.intensity * chain1.confidence
    score2 = chain2.intensity * chain2.confidence
    
    if score1 > score2:
        return 1
    elif score1 < score2:
        return -1
    return 0


# ==================== 格式化输出 ====================

def format_motivation_chain(chain: MotivationChain, verbose: bool = False) -> str:
    """
    格式化动机链输出
    
    Args:
        chain: 动机链对象
        verbose: 详细模式
        
    Returns:
        str: 格式化字符串
    """
    instinct_name = INSTINCT_NAMES.get(chain.instinct, "未知")
    instinct_en = INSTINCT_NAMES_EN.get(chain.instinct, "UNKNOWN")
    
    lines = [
        f"=== 动机链分析 ===",
        f"本能驱动: {instinct_name} ({instinct_en})",
        f"表层动机: {chain.surface}",
        f"深层动机: {chain.deep}",
        f"核心动机: {chain.core}",
        f"灵魂动机: {chain.soul}",
    ]
    
    if verbose:
        lines.extend([
            f"动机强度: {chain.intensity:.1f}/100",
            f"确定性: {chain.confidence:.0%}",
            f"驱动指数: {chain.intensity * chain.confidence:.1f}",
        ])
        lines.append(f"本能描述: {INSTINCT_DESCRIPTIONS.get(chain.instinct, '')}")
    
    return "\n".join(lines)


def format_motivation_chain_detailed(chain: MotivationChain) -> str:
    """
    格式化动机链详细输出
    
    Args:
        chain: 动机链对象
        
    Returns:
        str: 详细格式字符串
    """
    instinct_name = INSTINCT_NAMES.get(chain.instinct, "未知")
    instinct_en = INSTINCT_NAMES_EN.get(chain.instinct, "UNKNOWN")
    
    # 动机链可视化
    arrow = " → "
    chain_visual = f"{chain.surface}{arrow}{chain.deep}{arrow}{chain.core}{arrow}{chain.soul}"
    
    # 强度条
    bar_width = 30
    filled = int((chain.intensity / 100) * bar_width)
    bar = "█" * filled + "░" * (bar_width - filled)
    
    return f"""
╔══════════════════════════════════════════════════════════════╗
║                    动机链详细分析                               ║
╠══════════════════════════════════════════════════════════════╣
║ 本能类型: {instinct_name:<6} ({instinct_en:<10})                            ║
║ 本能描述: {INSTINCT_DESCRIPTIONS.get(chain.instinct, ''):<46}║
╠══════════════════════════════════════════════════════════════╣
║ 动机链可视化:                                                  ║
║ {chain_visual:<56}║
╠══════════════════════════════════════════════════════════════╣
║ 动机强度: [{bar}] {chain.intensity:.1f}%                    ║
║ 确定性:   {chain.confidence:.0%}                                                    ║
║ 驱动指数: {chain.intensity * chain.confidence:.1f}                                                    ║
╚══════════════════════════════════════════════════════════════╝
"""


def format_decision_framework(profile: DecisionFrameworkProfile) -> str:
    """
    格式化决策框架输出
    
    Args:
        profile: 决策框架配置
        
    Returns:
        str: 格式化字符串
    """
    primary_name = FRAMEWORK_NAMES.get(profile.primary, "未知")
    secondary_name = FRAMEWORK_NAMES.get(profile.secondary, "未知")
    
    # 权重排序
    sorted_weights = sorted(profile.weights.items(), key=lambda x: x[1], reverse=True)
    weight_lines = []
    for framework, weight in sorted_weights:
        name = FRAMEWORK_NAMES.get(framework, "未知")
        weight_lines.append(f"  {name}: {weight:.0%}")
    
    return f"""
=== 决策框架配置 ===
主框架: {primary_name}
次框架: {secondary_name}
灵活度: {profile.flexibility:.0%}

权重分布:
{chr(10).join(weight_lines)}
"""


def format_full_report(chain: MotivationChain, profile: Optional[DecisionFrameworkProfile] = None) -> str:
    """
    格式化完整动机分析报告
    
    Args:
        chain: 动机链对象
        profile: 决策框架配置（可选）
        
    Returns:
        str: 完整报告字符串
    """
    instinct_name = INSTINCT_NAMES.get(chain.instinct, "未知")
    
    report_lines = [
        "=" * 60,
        "              动机分析完整报告",
        "=" * 60,
        "",
        format_motivation_chain(chain, verbose=True),
        "",
        "动机链结构:",
        f"  [本能层] {instinct_name}",
        f"    ↓",
        f"  [表层] {chain.surface}",
        f"    ↓",
        f"  [深层] {chain.deep}",
        f"    ↓",
        f"  [核心] {chain.core}",
        f"    ↓",
        f"  [灵魂] {chain.soul}",
    ]
    
    if profile:
        report_lines.extend([
            "",
            format_decision_framework(profile),
        ])
    
    report_lines.append("=" * 60)
    
    return "\n".join(report_lines)


# ==================== 辅助函数 ====================

def get_all_instincts() -> list[Instinct]:
    """获取所有本能类型列表"""
    return list(Instinct)


def get_all_frameworks() -> list[DecisionFramework]:
    """获取所有决策框架列表"""
    return list(DecisionFramework)


def instinct_to_string(instinct: Instinct) -> str:
    """本能类型转中文字符串"""
    return INSTINCT_NAMES.get(instinct, "未知本能")


def framework_to_string(framework: DecisionFramework) -> str:
    """决策框架转中文字符串"""
    return FRAMEWORK_NAMES.get(framework, "未知框架")


def parse_instinct_from_string(text: str) -> Instinct:
    """从字符串解析本能类型"""
    text_lower = text.lower()
    
    instinct_map = {
        "求存": Instinct.SURVIVAL,
        "生存": Instinct.SURVIVAL,
        "安全": Instinct.SURVIVAL,
        "survival": Instinct.SURVIVAL,
        "求知": Instinct.KNOWLEDGE,
        "知识": Instinct.KNOWLEDGE,
        "好奇": Instinct.KNOWLEDGE,
        "knowledge": Instinct.KNOWLEDGE,
        "表现": Instinct.EXPRESSION,
        "展示": Instinct.EXPRESSION,
        "expression": Instinct.EXPRESSION,
        "舒适": Instinct.COMFORT,
        "享受": Instinct.COMFORT,
        "comfort": Instinct.COMFORT,
        "情欲": Instinct.DESIRE,
        "情感": Instinct.DESIRE,
        "亲密": Instinct.DESIRE,
        "desire": Instinct.DESIRE,
        "表达": Instinct.CREATIVE,
        "创造": Instinct.CREATIVE,
        "creative": Instinct.CREATIVE,
        "母性": Instinct.MATERNAL,
        "养育": Instinct.MATERNAL,
        "保护": Instinct.MATERNAL,
        "maternal": Instinct.MATERNAL,
    }
    
    for key, instinct in instinct_map.items():
        if key in text_lower:
            return instinct
    
    return Instinct.SURVIVAL  # 默认


# ==================== 演示代码 ====================

if __name__ == "__main__":
    print("=" * 60)
    print("逻辑动机链模块演示")
    print("=" * 60)
    
    # 演示七种本能
    print("\n[1] 七种本能驱动演示:")
    print("-" * 40)
    for instinct in Instinct:
        print(f"  {INSTINCT_NAMES[instinct]}: {INSTINCT_DESCRIPTIONS[instinct]}")
    
    # 生成动机链示例
    print("\n[2] 动机链生成示例:")
    print("-" * 40)
    
    examples = [
        (Instinct.SURVIVAL, "面对敌人追杀", "勇敢的战士"),
        (Instinct.KNOWLEDGE, "发现神秘遗迹", "好奇的探险家"),
        (Instinct.EXPRESSION, "作品展出", "追求认可的艺术家"),
        (Instinct.COMFORT, "旅途疲惫", "需要休息的旅人"),
        (Instinct.DESIRE, "遇见心上人", "陷入爱河的恋人"),
        (Instinct.CREATIVE, "灵感涌现", "创作中的画家"),
        (Instinct.MATERNAL, "孩子生病", "焦急的母亲"),
    ]
    
    for instinct, scene, role in examples:
        chain = generate_motivation_chain(instinct, scene, role)
        print(f"\n场景: {scene}")
        print(f"角色: {role}")
        print(format_motivation_chain(chain, verbose=True))
    
    # 决策框架示例
    print("\n[3] 决策框架配置示例:")
    print("-" * 40)
    
    role_examples = ["企业家", "诗人", "科学家", "外交官", "创业者"]
    for role in role_examples:
        profile = get_decision_framework(role)
        print(f"\n角色: {role}")
        print(format_decision_framework(profile))
    
    # 动机强度计算
    print("\n[4] 动机强度计算示例:")
    print("-" * 40)
    
    test_cases = [
        (Instinct.SURVIVAL, 0.9, 0.8, 0.7),
        (Instinct.KNOWLEDGE, 0.5, 0.6, 0.8),
        (Instinct.DESIRE, 0.7, 0.9, 0.95),
    ]
    
    for instinct, urgency, importance, relevance in test_cases:
        strength = calculate_motivation_strength(instinct, urgency, importance, relevance)
        print(f"{INSTINCT_NAMES[instinct]}: 紧迫性={urgency}, 重要性={importance}, 关联度={relevance}")
        print(f"  → 动机强度: {strength:.1f}")
    
    print("\n" + "=" * 60)
    print("演示完成")
    print("=" * 60)
