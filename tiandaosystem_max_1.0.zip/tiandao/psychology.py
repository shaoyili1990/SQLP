"""
Y值心理引擎核心模块 - Psychology Engine Core Module

Y值系统：角色心理状态量化指标，范围0-100
- 崩溃区 (0-15):  极度负面，情绪失控
- 低压区 (16-30): 消极低沉，缺乏动力
- 稳定区 (31-70): 心理平衡，行为可控
- 冲高区 (71-85): 积极亢奋，可能冲动
- 爆发区 (86-100): 极度亢奋，可能失控
"""

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional
import random


class YState(IntEnum):
    """Y值状态枚举"""
    COLLAPSE = 0      # 崩溃 0-15
    LOW_PRESSURE = 1  # 低压 16-30
    STABLE = 2        # 稳定 31-70
    HIGH_DRIVE = 3    # 冲高 71-85
    ERUPTION = 4      # 爆发 86-100


# 状态常量
STATE_THRESHOLDS = {
    YState.COLLAPSE: (0, 15),
    YState.LOW_PRESSURE: (16, 30),
    YState.STABLE: (31, 70),
    YState.HIGH_DRIVE: (71, 85),
    YState.ERUPTION: (86, 100),
}

STATE_NAMES_CN = {
    YState.COLLAPSE: "崩溃",
    YState.LOW_PRESSURE: "低压",
    YState.STABLE: "稳定",
    YState.HIGH_DRIVE: "冲高",
    YState.ERUPTION: "爆发",
}

STATE_NAMES_EN = {
    YState.COLLAPSE: "COLLAPSE",
    YState.LOW_PRESSURE: "LOW_PRESSURE",
    YState.STABLE: "STABLE",
    YState.HIGH_DRIVE: "HIGH_DRIVE",
    YState.ERUPTION: "ERUPTION",
}

# 行为倾向映射表
BEHAVIOR_TENDENCIES = {
    YState.COLLAPSE: [
        "退缩回避", "自我封闭", "消极抵抗", "情绪崩溃", "放弃挣扎"
    ],
    YState.LOW_PRESSURE: [
        "被动应对", "敷衍了事", "缺乏热情", "消极配合", "沉默寡言"
    ],
    YState.STABLE: [
        "理性应对", "积极配合", "主动沟通", "适度表现", "稳中求进"
    ],
    YState.HIGH_DRIVE: [
        "积极表现", "主动出击", "过度投入", "冒险倾向", "争强好胜"
    ],
    YState.ERUPTION: [
        "冲动行为", "失控爆发", "极端手段", "不惜代价", "孤注一掷"
    ],
}


@dataclass
class PsychologyProfile:
    """
    心理画像数据类
    
    Attributes:
        base_y: 基础Y值，默认50
        current_y: 当前Y值
        compensation_value: 当前补偿值
        compensation_remaining: 补偿持续场景数
        delta_y: Y值变化量(ΔY)
        last_y: 上一个Y值
        breakdown_triggered: 是否触发击穿
        event_history: 事件历史记录
    """
    base_y: float = 50.0
    current_y: float = 50.0
    compensation_value: float = 0.0
    compensation_remaining: int = 0
    delta_y: float = 0.0
    last_y: float = 50.0
    breakdown_triggered: bool = False
    event_history: list = field(default_factory=list)
    
    def __post_init__(self):
        self.last_y = self.current_y


class YPsychologyEngine:
    """
    Y值心理引擎
    
    核心机制:
    1. 触发机制: 阈值公式 max(5, floor((100-y)/10))
       - Y值越低，触发阈值越高（更容易触发心理波动）
       - Y值越高，触发阈值越低（更容易保持稳定）
    
    2. 补偿机制: 事件补偿 +2~10，持续1-3场景后衰减
       - 用于模拟外部事件对心理的正向/负向影响
       - 补偿效果会随场景逐渐衰减
    
    3. 回弹机制: y = base_y + (y - base_y) * 0.85
       - 心理状态会逐渐向基础值回归
       - 系数0.85表示回归程度（越小回归越快）
    """
    
    def __init__(self, base_y: float = 50.0):
        """
        初始化心理引擎
        
        Args:
            base_y: 基础Y值，范围0-100，默认50
        """
        self.base_y = max(0.0, min(100.0, base_y))
        self.profile = PsychologyProfile(base_y=self.base_y, current_y=self.base_y)
        self._state_history: list[tuple[int, YState]] = []  # (scene_num, state)
    
    # ==================== 核心计算方法 ====================
    
    def calculate_trigger_threshold(self, y: Optional[float] = None) -> int:
        """
        计算触发阈值
        
        公式: max(5, floor((100-y)/10))
        
        Args:
            y: Y值，默认为当前值
            
        Returns:
            int: 触发阈值(5-10)
        """
        if y is None:
            y = self.profile.current_y
        return max(5, int((100 - y) // 10))
    
    def apply_compensation(self, value: float, duration: Optional[int] = None) -> float:
        """
        应用补偿效果
        
        Args:
            value: 补偿值，范围-10到+10
            duration: 持续场景数，1-3，默认随机
            
        Returns:
            float: 实际应用的补偿值
        """
        # 限制补偿值范围
        value = max(-10.0, min(10.0, value))
        
        # 随机持续时间
        if duration is None:
            duration = random.randint(1, 3)
        
        self.profile.compensation_value = value
        self.profile.compensation_remaining = duration
        
        return value
    
    def apply_rebound(self, y: Optional[float] = None) -> float:
        """
        应用回弹机制
        
        公式: y = base_y + (y - base_y) * 0.85
        
        Args:
            y: 当前Y值，默认为当前值
            
        Returns:
            float: 回弹后的Y值
        """
        if y is None:
            y = self.profile.current_y
        
        # 回弹计算
        new_y = self.base_y + (y - self.base_y) * 0.85
        return max(0.0, min(100.0, new_y))
    
    def decay_compensation(self) -> None:
        """补偿衰减处理（每场景调用）"""
        if self.profile.compensation_remaining > 0:
            self.profile.compensation_remaining -= 1
            if self.profile.compensation_remaining == 0:
                self.profile.compensation_value = 0.0
    
    # ==================== Y值更新 ====================
    
    def update(self, event_delta: float = 0.0, scene_num: int = 0) -> float:
        """
        更新Y值（主方法）
        
        执行顺序:
        1. 计算ΔY差值
        2. 更新当前Y值
        3. 应用补偿
        4. 应用回弹
        5. 判定击穿
        6. 更新状态历史
        
        Args:
            event_delta: 事件导致的Y值变化
            scene_num: 当前场景编号
            
        Returns:
            float: 更新后的Y值
        """
        # 记录上一个Y值
        self.profile.last_y = self.profile.current_y
        
        # 计算事件影响后的Y值
        temp_y = self.profile.current_y + event_delta
        temp_y = max(0.0, min(100.0, temp_y))
        
        # 应用补偿
        if self.profile.compensation_remaining > 0:
            temp_y += self.profile.compensation_value
            self.decay_compensation()
        
        temp_y = max(0.0, min(100.0, temp_y))
        
        # 应用回弹
        temp_y = self.apply_rebound(temp_y)
        
        # 更新当前Y值
        self.profile.current_y = temp_y
        
        # 计算ΔY
        self.profile.delta_y = self.profile.current_y - self.profile.last_y
        
        # 判定击穿
        self.profile.breakdown_triggered = self._check_breakdown()
        
        # 记录状态历史
        current_state = self.get_state()
        self._state_history.append((scene_num, current_state))
        
        return self.profile.current_y
    
    def _check_breakdown(self) -> bool:
        """
        击穿判定
        
        击穿条件: ΔY绝对值 > 触发阈值 * 2
        
        Returns:
            bool: 是否触发击穿
        """
        threshold = self.calculate_trigger_threshold()
        return abs(self.profile.delta_y) > threshold * 2
    
    # ==================== 状态查询 ====================
    
    def get_state(self, y: Optional[float] = None) -> YState:
        """
        获取Y值对应的状态
        
        Args:
            y: Y值，默认为当前值
            
        Returns:
            YState: 心理状态
        """
        if y is None:
            y = self.profile.current_y
        
        for state, (low, high) in STATE_THRESHOLDS.items():
            if low <= y <= high:
                return state
        
        # 边界处理
        if y < 0:
            return YState.COLLAPSE
        return YState.ERUPTION
    
    def get_behavior_tendency(self) -> list[str]:
        """
        获取当前行为倾向列表
        
        Returns:
            list[str]: 行为倾向列表
        """
        state = self.get_state()
        return BEHAVIOR_TENDENCIES.get(state, [])
    
    def get_random_behavior(self) -> str:
        """
        获取随机行为倾向
        
        Returns:
            str: 随机选中的行为倾向
        """
        tendencies = self.get_behavior_tendency()
        return random.choice(tendencies) if tendencies else "未知行为"
    
    # ==================== 格式化输出 ====================
    
    def format_status(self, scene_num: int = 0, verbose: bool = False) -> str:
        """
        格式化输出当前心理状态
        
        Args:
            scene_num: 场景编号
            verbose: 详细模式
            
        Returns:
            str: 格式化状态字符串
        """
        state = self.get_state()
        state_cn = STATE_NAMES_CN.get(state, "未知")
        state_en = STATE_NAMES_EN.get(state, "UNKNOWN")
        threshold = self.calculate_trigger_threshold()
        
        lines = [
            f"=== Y值心理状态 [场景{scene_num}] ===",
            f"Y值: {self.profile.current_y:.2f} ({state_cn}/{state_en})",
            f"基础值: {self.base_y:.2f} | ΔY: {self.profile.delta_y:+.2f}",
            f"触发阈值: {threshold}",
        ]
        
        if verbose:
            lines.extend([
                f"补偿值: {self.profile.compensation_value:+.2f} (剩余{self.profile.compensation_remaining}场景)",
                f"击穿状态: {'触发' if self.profile.breakdown_triggered else '未触发'}",
                f"行为倾向: {', '.join(self.get_behavior_tendency())}",
            ])
        else:
            lines.append(f"当前行为: {self.get_random_behavior()}")
        
        return "\n".join(lines)
    
    def format_state_bar(self, width: int = 50) -> str:
        """
        格式化状态条形图
        
        Args:
            width: 条形图宽度
            
        Returns:
            str: 条形图字符串
        """
        y = self.profile.current_y
        bar_length = int((y / 100) * width)
        
        # 状态颜色标记
        state = self.get_state()
        markers = {
            YState.COLLAPSE: "[崩溃]",
            YState.LOW_PRESSURE: "[低压]",
            YState.STABLE: "[稳定]",
            YState.HIGH_DRIVE: "[冲高]",
            YState.ERUPTION: "[爆发]",
        }
        marker = markers.get(state, "")
        
        bar = "█" * bar_length + "░" * (width - bar_length)
        return f"{marker} [{bar}] {y:.1f}"
    
    def format_full_report(self, scene_num: int = 0) -> str:
        """
        格式化完整心理报告
        
        Args:
            scene_num: 场景编号
            
        Returns:
            str: 完整报告字符串
        """
        state = self.get_state()
        state_cn = STATE_NAMES_CN.get(state, "未知")
        
        return f"""
╔══════════════════════════════════════════════════════════════╗
║                    Y值心理引擎完整报告                        ║
╠══════════════════════════════════════════════════════════════╣
║ 场景编号: {scene_num:<50}║
║ 基础Y值: {self.base_y:<10.2f}                                       ║
║ 当前Y值: {self.profile.current_y:<10.2f} ({state_cn})                      ║
║ 上次Y值: {self.profile.last_y:<10.2f}                                       ║
║ ΔY差值: {self.profile.delta_y:<+10.2f}                                       ║
╠══════════════════════════════════════════════════════════════╣
║ 触发阈值: {self.calculate_trigger_threshold():<6}  (公式: max(5, floor((100-y)/10)))     ║
║ 补偿值:   {self.profile.compensation_value:<+10.2f} (剩余{self.profile.compensation_remaining}场景)                      ║
║ 击穿判定: {'触发 ⚠️' if self.profile.breakdown_triggered else '未触发'}                                              ║
╠══════════════════════════════════════════════════════════════╣
║ 状态条: {self.format_state_bar():<44}║
╠══════════════════════════════════════════════════════════════╣
║ 行为倾向:                                                       ║
║ {', '.join(self.get_behavior_tendency()):<58}║
╚══════════════════════════════════════════════════════════════╝
"""


# ==================== 辅助函数 ====================

def get_state_info(state: YState) -> dict:
    """
    获取状态详细信息
    
    Args:
        state: Y状态
        
    Returns:
        dict: 状态信息字典
    """
    low, high = STATE_THRESHOLDS.get(state, (0, 100))
    return {
        "state": state,
        "name_cn": STATE_NAMES_CN.get(state, "未知"),
        "name_en": STATE_NAMES_EN.get(state, "UNKNOWN"),
        "range": (low, high),
        "behaviors": BEHAVIOR_TENDENCIES.get(state, []),
    }


def y_to_state(y: float) -> YState:
    """
    Y值转状态（便捷函数）
    
    Args:
        y: Y值
        
    Returns:
        YState: 对应状态
    """
    for state, (low, high) in STATE_THRESHOLDS.items():
        if low <= y <= high:
            return state
    return YState.COLLAPSE if y < 0 else YState.ERUPTION


def calculate_trigger(y: float) -> int:
    """
    计算触发阈值（便捷函数）
    
    Args:
        y: Y值
        
    Returns:
        int: 触发阈值
    """
    return max(5, int((100 - y) // 10))


def calculate_rebound(y: float, base_y: float = 50.0) -> float:
    """
    计算回弹后的Y值（便捷函数）
    
    Args:
        y: 当前Y值
        base_y: 基础Y值
        
    Returns:
        float: 回弹后的Y值
    """
    return max(0.0, min(100.0, base_y + (y - base_y) * 0.85))


# ==================== 演示代码 ====================

if __name__ == "__main__":
    print("=" * 60)
    print("Y值心理引擎演示")
    print("=" * 60)
    
    # 创建引擎实例
    engine = YPsychologyEngine(base_y=50.0)
    
    print("\n[1] 初始状态:")
    print(engine.format_full_report(scene_num=0))
    
    # 模拟场景变化
    print("\n[2] 场景1: 负面事件影响 (ΔY = -25)")
    engine.update(event_delta=-25, scene_num=1)
    print(engine.format_status(scene_num=1, verbose=True))
    print(engine.format_state_bar())
    
    print("\n[3] 场景2: 持续低压状态")
    engine.update(event_delta=0, scene_num=2)
    print(engine.format_status(scene_num=2))
    print(engine.format_state_bar())
    
    print("\n[4] 场景3: 正向补偿 (+8, 持续2场景)")
    engine.apply_compensation(8, 2)
    engine.update(event_delta=0, scene_num=3)
    print(engine.format_status(scene_num=3, verbose=True))
    print(engine.format_state_bar())
    
    print("\n[5] 场景4: 补偿持续中")
    engine.update(event_delta=0, scene_num=4)
    print(engine.format_status(scene_num=4))
    print(engine.format_state_bar())
    
    print("\n[6] 场景5: 补偿结束，回弹中")
    engine.update(event_delta=0, scene_num=5)
    print(engine.format_status(scene_num=5))
    print(engine.format_state_bar())
    
    print("\n[7] 快速变化测试: 爆发场景 (ΔY = +60)")
    engine2 = YPsychologyEngine(base_y=50.0)
    engine2.update(event_delta=60, scene_num=1)
    print(engine2.format_full_report(scene_num=1))
    
    print("\n[8] 击穿判定演示")
    print(f"场景: Y={engine.profile.current_y:.2f}, ΔY={engine.profile.delta_y:.2f}")
    print(f"触发阈值: {engine.calculate_trigger_threshold()}")
    print(f"击穿条件: |ΔY| > {engine.calculate_trigger_threshold() * 2}")
    print(f"击穿结果: {'是 ⚠️' if engine.profile.breakdown_triggered else '否'}")
    
    print("\n" + "=" * 60)
    print("演示结束")
    print("=" * 60)
