#!/usr/bin/env python3
"""
Tiandao CLI - Command Line Interface
天道系统命令行工具

Usage examples:
    python -m tiandao mbti show INFP
    python -m tiandao y-value calculate 0.75
    python -m tiandao memory add "Key event" --personality ENFP
    python -m tiandao author validate "author_name"
"""

import argparse
import json
import sys
from typing import Optional

# ============================================================================
# Psychology Profile Module
# ============================================================================

class PsychologyProfile:
    """Psychology profile with Y-value system for emotional regulation analysis."""

    def __init__(self, name: str, base_y: float = 0.5):
        self.name = name
        self.base_y = base_y
        self.current_y = base_y
        self.history = []

    def update_y(self, value: float) -> float:
        """Update current Y-value."""
        self.current_y = max(0.0, min(1.0, value))
        self.history.append({"value": self.current_y, "event": "update"})
        return self.current_y

    def to_dict(self) -> dict:
        return {"name": self.name, "base_y": self.base_y, "current_y": self.current_y}

    @classmethod
    def from_dict(cls, data: dict) -> "PsychologyProfile":
        profile = cls(data["name"], data["base_y"])
        profile.current_y = data["current_y"]
        return profile


# ============================================================================
# MBTI Profile Module  
# ============================================================================

class MBTIProfile:
    """MBTI personality type profile."""

    TYPES = ["IE", "NS", "TF", "JP"]

    def __init__(self, mbti_type: str = "INTJ"):
        self.mbti_type = mbti_type.upper() if mbti_type else "INTJ"
        if len(self.mbti_type) != 4:
            self.mbti_type = "INTJ"

    def get_dimension(self, index: int) -> str:
        return self.mbti_type[index] if index < len(self.mbti_type) else ""

    def get_description(self) -> str:
        descriptions = {
            "I": "Introverted (内向)",
            "E": "Extroverted (外向)",
            "N": "Intuition (直觉)",
            "S": "Sensing (感觉)",
            "T": "Thinking (思考)",
            "F": "Feeling (情感)",
            "J": "Judging (判断)",
            "P": "Perceiving (知觉)",
        }
        dims = []
        for i, c in enumerate(self.mbti_type):
            if i < 4 and c in descriptions:
                dims.append(descriptions[c])
        return " | ".join(dims)

    def to_dict(self) -> dict:
        return {"mbti_type": self.mbti_type}

    @classmethod
    def from_dict(cls, data: dict) -> "MBTIProfile":
        return cls(data["mbti_type"])


# ============================================================================
# Memory System Module
# ============================================================================

class MemorySystem:
    """Character memory and experience storage."""

    def __init__(self, personality_type: str = "INTJ"):
        self.personality_type = personality_type
        self.memories = []
        self.event_counter = 0

    def add_memory(self, content: str, tags: Optional[list] = None) -> dict:
        """Add a new memory."""
        self.event_counter += 1
        memory = {
            "id": self.event_counter,
            "content": content,
            "tags": tags or [],
            "personality": self.personality_type,
        }
        self.memories.append(memory)
        return memory

    def list_memories(self) -> list:
        """List all memories."""
        return self.memories

    def search_memories(self, keyword: str) -> list:
        """Search memories by keyword."""
        return [
            m for m in self.memories
            if keyword.lower() in m["content"].lower()
        ]

    def to_dict(self) -> dict:
        return {
            "personality_type": self.personality_type,
            "memories": self.memories,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MemorySystem":
        system = cls(data["personality_type"])
        system.memories = data.get("memories", [])
        system.event_counter = len(system.memories)
        return system


# ============================================================================
# Motivation Chain Module
# ============================================================================

class MotivationChain:
    """Motivation chain for analyzing character drive hierarchy."""

    def __init__(self):
        self.chains = []
        self.primary_motivation = None

    def add_link(self, motivation: str, intensity: float = 0.5) -> dict:
        """Add a motivation link to the chain."""
        link = {
            "motivation": motivation,
            "intensity": max(0.0, min(1.0, intensity)),
            "index": len(self.chains),
        }
        self.chains.append(link)
        if len(self.chains) == 1:
            self.primary_motivation = motivation
        return link

    def get_chain(self) -> list:
        return self.chains

    def to_dict(self) -> dict:
        return {
            "chains": self.chains,
            "primary_motivation": self.primary_motivation,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MotivationChain":
        chain = cls()
        chain.chains = data.get("chains", [])
        chain.primary_motivation = data.get("primary_motivation")
        return chain


# ============================================================================
# Y-Value Calculator
# ============================================================================

def calculate_y_value(base: float, modifier: float = 0.0) -> float:
    """Calculate Y-value with optional modifier."""
    return max(0.0, min(1.0, base + modifier))


def calculate_rebound(start: float, target: float, factor: float = 0.618) -> float:
    """Calculate Y-value rebound using golden ratio factor."""
    diff = target - start
    return start + diff * factor


def calculate_compensate(current: float, deviation: float) -> float:
    """Calculate compensation for Y-value deviation."""
    return max(0.0, min(1.0, current + deviation))


# ============================================================================
# Author Validator
# ============================================================================

def validate_author(author_name: str) -> dict:
    """Validate author name format."""
    valid = len(author_name) >= 2 and author_name.replace("_", "").replace("-", "").isalnum()
    return {
        "author": author_name,
        "valid": valid,
        "message": "Valid author name" if valid else "Invalid: use 2+ alphanumeric chars, - or _ allowed",
    }


# ============================================================================
# MBTI Operations
# ============================================================================

def show_mbti(mbti_type: str) -> dict:
    """Display MBTI type information."""
    profile = MBTIProfile(mbti_type)
    return {
        "type": profile.mbti_type,
        "description": profile.get_description(),
    }


def compare_mbti(type1: str, type2: str) -> dict:
    """Compare two MBTI types."""
    p1 = MBTIProfile(type1)
    p2 = MBTIProfile(type2)
    matches = sum(1 for i in range(4) if p1.get_dimension(i) == p2.get_dimension(i))
    return {
        "type1": p1.mbti_type,
        "type2": p2.mbti_type,
        "match_count": matches,
        "compatibility": f"{matches * 25}%",
    }


# ============================================================================
# Run Demo
# ============================================================================

def run_demo():
    """Run demonstration of all features."""
    print("=" * 60)
    print("Tiandao System Demo / 天道系统演示")
    print("=" * 60)

    # Psychology Profile Demo
    print("\n[1] Psychology Profile / 心理画像")
    profile = PsychologyProfile("Demo Character", 0.7)
    print(f"    Name: {profile.name}")
    print(f"    Base Y: {profile.base_y}")
    print(f"    Updated Y: {profile.update_y(0.85)}")

    # MBTI Demo
    print("\n[2] MBTI Profile / MBTI性格")
    mbti = MBTIProfile("ENFP")
    print(f"    Type: {mbti.mbti_type}")
    print(f"    Description: {mbti.get_description()}")

    # Memory Demo
    print("\n[3] Memory System / 记忆系统")
    memory = MemorySystem("ENFP")
    memory.add_memory("First adventure", tags=["action"])
    memory.add_memory("Meeting the mentor", tags=["character"])
    print(f"    Total memories: {len(memory.list_memories())}")

    # Motivation Chain Demo
    print("\n[4] Motivation Chain / 动机链")
    chain = MotivationChain()
    chain.add_link("Self-actualization", 0.9)
    chain.add_link("Achievement", 0.8)
    chain.add_link("Connection", 0.7)
    print(f"    Primary: {chain.primary_motivation}")
    print(f"    Chain length: {len(chain.get_chain())}")

    # Y-Value Calculations
    print("\n[5] Y-Value Calculations / Y值计算")
    print(f"    Calculate: {calculate_y_value(0.75, 0.1)}")
    print(f"    Rebound: {calculate_rebound(0.3, 0.8)}")
    print(f"    Compensate: {calculate_compensate(0.5, 0.2)}")

    # Author Validation
    print("\n[6] Author Validation / 作者验证")
    result = validate_author("test_author")
    print(f"    {result['author']}: {result['valid']}")

    print("\n" + "=" * 60)
    print("Demo Complete / 演示完成")
    print("=" * 60)


# ============================================================================
# CLI Entry Point
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        prog="tiandao",
        description="Tiandao System CLI - Character Psychology & Motivation Analysis",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Y-value subcommand
    y_parser = subparsers.add_parser("y-value", help="Y-value operations")
    y_subparsers = y_parser.add_subparsers(dest="action")
    
    calc_parser = y_subparsers.add_parser("calculate", help="Calculate Y-value")
    calc_parser.add_argument("value", type=float, help="Base Y-value")
    calc_parser.add_argument("--modifier", type=float, default=0.0, help="Modifier")
    
    rebound_parser = y_subparsers.add_parser("rebound", help="Calculate rebound")
    rebound_parser.add_argument("start", type=float, help="Start value")
    rebound_parser.add_argument("target", type=float, help="Target value")
    rebound_parser.add_argument("--factor", type=float, default=0.618, help="Rebound factor")
    
    compensate_parser = y_subparsers.add_parser("compensate", help="Calculate compensation")
    compensate_parser.add_argument("current", type=float, help="Current value")
    compensate_parser.add_argument("deviation", type=float, help="Deviation")

    # MBTI subcommand
    mbti_parser = subparsers.add_parser("mbti", help="MBTI operations")
    mbti_subparsers = mbti_parser.add_subparsers(dest="action")
    
    show_parser = mbti_subparsers.add_parser("show", help="Show MBTI type info")
    show_parser.add_argument("type", help="MBTI type (e.g., INFP)")
    
    compare_parser = mbti_subparsers.add_parser("compare", help="Compare two MBTI types")
    compare_parser.add_argument("type1", help="First MBTI type")
    compare_parser.add_argument("type2", help="Second MBTI type")

    # Memory subcommand
    mem_parser = subparsers.add_parser("memory", help="Memory system operations")
    mem_subparsers = mem_parser.add_subparsers(dest="action")
    
    add_parser = mem_subparsers.add_parser("add", help="Add memory")
    add_parser.add_argument("content", help="Memory content")
    add_parser.add_argument("--personality", default="INTJ", help="Personality type")
    add_parser.add_argument("--tags", nargs="*", help="Memory tags")
    
    list_parser = mem_subparsers.add_parser("list", help="List memories")
    list_parser.add_argument("--personality", default="INTJ", help="Personality type")
    
    search_parser = mem_subparsers.add_parser("search", help="Search memories")
    search_parser.add_argument("keyword", help="Search keyword")
    search_parser.add_argument("--personality", default="INTJ", help="Personality type")

    # Motivation subcommand
    motiv_parser = subparsers.add_parser("motivation", help="Motivation chain operations")
    motiv_parser.add_argument("--add", nargs=2, metavar=("MOTIVATION", "INTENSITY"), help="Add motivation link")
    motiv_parser.add_argument("--show", action="store_true", help="Show motivation chain")

    # Author subcommand
    auth_parser = subparsers.add_parser("author", help="Author operations")
    auth_subparsers = auth_parser.add_subparsers(dest="action")
    
    validate_parser = auth_subparsers.add_parser("validate", help="Validate author name")
    validate_parser.add_argument("name", help="Author name")

    # Demo subcommand
    subparsers.add_parser("run-demo", help="Run system demonstration")

    return parser


def main():
    """Main CLI entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # In-memory storage for memory system
    if not hasattr(main, "_memory_storage"):
        main._memory_storage = {}
    if not hasattr(main, "_motivation_storage"):
        main._motivation_storage = MotivationChain()

    try:
        if args.command == "y-value":
            if args.action == "calculate":
                result = calculate_y_value(args.value, args.modifier)
                print(json.dumps({"result": result}))
            elif args.action == "rebound":
                result = calculate_rebound(args.start, args.target, args.factor)
                print(json.dumps({"result": result}))
            elif args.action == "compensate":
                result = calculate_compensate(args.current, args.deviation)
                print(json.dumps({"result": result}))

        elif args.command == "mbti":
            if args.action == "show":
                result = show_mbti(args.type)
                print(json.dumps(result, indent=2))
            elif args.action == "compare":
                result = compare_mbti(args.type1, args.type2)
                print(json.dumps(result, indent=2))

        elif args.command == "memory":
            if args.action == "add":
                key = args.personality
                if key not in main._memory_storage:
                    main._memory_storage[key] = MemorySystem(key)
                memory = main._memory_storage[key].add_memory(args.content, args.tags)
                print(json.dumps({"added": memory}))
            elif args.action == "list":
                key = args.personality
                if key not in main._memory_storage:
                    main._memory_storage[key] = MemorySystem(key)
                memories = main._memory_storage[key].list_memories()
                print(json.dumps({"memories": memories}, indent=2))
            elif args.action == "search":
                key = args.personality
                if key not in main._memory_storage:
                    main._memory_storage[key] = MemorySystem(key)
                results = main._memory_storage[key].search_memories(args.keyword)
                print(json.dumps({"results": results}, indent=2))

        elif args.command == "motivation":
            if args.add:
                motivation, intensity = args.add
                link = main._motivation_storage.add_link(motivation, float(intensity))
                print(json.dumps({"added": link}))
            if args.show or not args.add:
                chain = main._motivation_storage.get_chain()
                print(json.dumps({"chain": chain}, indent=2))

        elif args.command == "author":
            if args.action == "validate":
                result = validate_author(args.name)
                print(json.dumps(result, indent=2))

        elif args.command == "run-demo":
            run_demo()

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
