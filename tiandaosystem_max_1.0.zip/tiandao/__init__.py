"""
Tiandao System - Character Psychology & Motivation Analysis Framework
天道系统 - 角色心理与动机分析框架

A comprehensive framework for character profiling, motivation analysis,
and psychological behavior modeling.
"""

__version__ = "1.0.0"
__author__ = "Tiandao System"

# Re-export all public modules
from .profile import CharacterProfile, create_profile, load_profile
from .cli import main as cli_main

__all__ = [
    "CharacterProfile",
    "create_profile",
    "load_profile",
    "cli_main",
]
