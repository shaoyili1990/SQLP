"""
天道系统 - 记忆管理系统模块
Memory Management System for Tiandao System

5种记忆类型:
- 总记忆 (total_memories): 无限存储所有记忆
- 常态记忆 (normal_memories): 常态模式下的记忆
- 异常记忆 (abnormal_memories): 创伤事件, max 15, 超限惩罚
- 长期记忆 (long_term_memories): max 20
- 短期记忆 (short_term_memories): max 10, 自动轮转
"""

import json
import time
import random
from dataclasses import dataclass, asdict, field
from datetime import datetime
from typing import Optional
from enum import Enum


class MemoryType(Enum):
    """记忆类型枚举"""
    NORMAL = "normal"
    ABNORMAL = "abnormal"
    LONG_TERM = "long_term"
    SHORT_TERM = "short_term"


@dataclass
class MemoryEntry:
    """
    记忆条目数据结构
    
    属性:
        name: 记忆名称/标题
        tag: 标签,用于分类和检索
        content: 记忆内容
        weight: 权重(0.0-1.0),影响记忆强度
        emotion: 情感值,正面(+)或负面(-)
        created_at: 创建时间戳
    """
    name: str
    tag: str
    content: str
    weight: float = 0.5
    emotion: float = 0.0
    created_at: float = field(default_factory=time.time)
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'MemoryEntry':
        """从字典创建实例"""
        return cls(**data)


class MemorySystem:
    """
    记忆管理系统
    
    负责管理5种类型的记忆,支持记忆的添加/删除/检索/强化/遗忘等操作
    """
    
    # 记忆容量限制
    ABNORMAL_MAX = 15
    LONG_TERM_MAX = 20
    SHORT_TERM_MAX = 10
    
    # 异常记忆过载惩罚参数
    PTSD_BASE_INCREASE = 5
    PTSD_MAX_INCREASE = 15
    
    def __init__(self, y_base: float = 50.0, ptsd_trigger_rate: float = 0.0):
        """
        初始化记忆系统
        
        Args:
            y_base: 基础Y值(心理稳定性指标)
            ptsd_trigger_rate: PTSD触发率基础值
        """
        # 5种记忆存储
        self.total_memories: list[MemoryEntry] = []  # 总记忆(无限)
        self.normal_memories: list[MemoryEntry] = []  # 常态记忆
        self.abnormal_memories: list[MemoryEntry] = []  # 异常记忆(创伤)
        self.long_term_memories: list[MemoryEntry] = []  # 长期记忆
        self.short_term_memories: list[MemoryEntry] = []  # 短期记忆
        
        # 心理状态指标
        self.y_base = y_base
        self.base_y_offset = 0  # 异常记忆导致的永久Y值偏移
        self.ptsd_trigger_rate = ptsd_trigger_rate
        
        # 统计信息
        self.stats = {
            'total_added': 0,
            'total_deleted': 0,
            'reinforcement_count': 0,
            'forget_count': 0,
            'rotation_count': 0,
            'ptsd_penalties_applied': 0
        }
    
    def add(self, entry: MemoryEntry, memory_type: MemoryType = MemoryType.NORMAL) -> bool:
        """
        添加记忆
        
        Args:
            entry: 记忆条目
            memory_type: 记忆类型
            
        Returns:
            bool: 添加是否成功
        """
        # 添加到总记忆
        self.total_memories.append(entry)
        
        # 根据类型添加到对应列表
        if memory_type == MemoryType.NORMAL:
            self.normal_memories.append(entry)
        elif memory_type == MemoryType.ABNORMAL:
            success = self._add_abnormal_memory(entry)
            if not success:
                return False
        elif memory_type == MemoryType.LONG_TERM:
            success = self._add_with_limit(entry, self.long_term_memories, self.LONG_TERM_MAX)
            if not success:
                return False
        elif memory_type == MemoryType.SHORT_TERM:
            success = self._add_with_rotation(entry, self.short_term_memories, self.SHORT_TERM_MAX)
            if not success:
                return False
        
        self.stats['total_added'] += 1
        return True
    
    def _add_abnormal_memory(self, entry: MemoryEntry) -> bool:
        """添加异常记忆,处理超限惩罚"""
        self.abnormal_memories.append(entry)
        
        # 检查是否超限
        if len(self.abnormal_memories) > self.ABNORMAL_MAX:
            self._apply_ptsd_penalty()
            return True  # 仍然添加,但应用惩罚
        
        return True
    
    def _apply_ptsd_penalty(self):
        """应用PTSD惩罚"""
        overflow = len(self.abnormal_memories) - self.ABNORMAL_MAX
        
        # 计算惩罚值: +5~+15 永久Y值提升
        penalty = min(self.PTSD_MAX_INCREASE, self.PTSD_BASE_INCREASE + overflow * 2)
        penalty = random.uniform(self.PTSD_BASE_INCREASE, penalty)
        
        self.base_y_offset += penalty
        self.y_base = 50.0 + self.base_y_offset  # 基础Y值永久提升
        
        # PTSD触发率增加
        self.ptsd_trigger_rate = min(1.0, self.ptsd_trigger_rate + 0.05 * overflow)
        
        self.stats['ptsd_penalties_applied'] += 1
    
    def _add_with_limit(self, entry: MemoryEntry, memory_list: list, max_limit: int) -> bool:
        """添加记忆到有容量限制的列表"""
        if len(memory_list) >= max_limit:
            return False
        memory_list.append(entry)
        return True
    
    def _add_with_rotation(self, entry: MemoryEntry, memory_list: list, max_limit: int) -> bool:
        """添加记忆到短期记忆(自动轮转)"""
        if len(memory_list) >= max_limit:
            # 移除最旧的记忆
            memory_list.pop(0)
            self.stats['rotation_count'] += 1
        memory_list.append(entry)
        return True
    
    def delete(self, name: str = None, tag: str = None, memory_type: MemoryType = None) -> int:
        """
        删除记忆
        
        Args:
            name: 按名称删除
            tag: 按标签删除
            memory_type: 指定记忆类型(不指定则从所有类型删除)
            
        Returns:
            int: 删除的记忆数量
        """
        deleted_count = 0
        
        def should_delete(entry: MemoryEntry) -> bool:
            if name and entry.name == name:
                return True
            if tag and entry.tag == tag:
                return True
            return False
        
        # 从总记忆删除
        original_len = len(self.total_memories)
        self.total_memories = [e for e in self.total_memories if not should_delete(e)]
        deleted_count += original_len - len(self.total_memories)
        
        # 从指定类型删除
        if memory_type is None:
            target_lists = [
                (self.normal_memories, 'normal'),
                (self.abnormal_memories, 'abnormal'),
                (self.long_term_memories, 'long_term'),
                (self.short_term_memories, 'short_term')
            ]
        else:
            type_map = {
                MemoryType.NORMAL: (self.normal_memories, 'normal'),
                MemoryType.ABNORMAL: (self.abnormal_memories, 'abnormal'),
                MemoryType.LONG_TERM: (self.long_term_memories, 'long_term'),
                MemoryType.SHORT_TERM: (self.short_term_memories, 'short_term')
            }
            target_lists = [type_map[memory_type]]
        
        for mem_list, _ in target_lists:
            original_len = len(mem_list)
            mem_list[:] = [e for e in mem_list if not should_delete(e)]
            deleted_count += original_len - len(mem_list)
        
        self.stats['total_deleted'] += deleted_count
        return deleted_count
    
    def search(self, keyword: str = None, tag: str = None, 
               memory_type: MemoryType = None) -> list[MemoryEntry]:
        """
        搜索记忆
        
        Args:
            keyword: 关键词(搜索名称和内容)
            tag: 标签
            memory_type: 指定记忆类型
            
        Returns:
            list[MemoryEntry]: 匹配的记忆列表
        """
        results = []
        
        if memory_type is None:
            search_lists = [self.total_memories]
        else:
            type_map = {
                MemoryType.NORMAL: self.normal_memories,
                MemoryType.ABNORMAL: self.abnormal_memories,
                MemoryType.LONG_TERM: self.long_term_memories,
                MemoryType.SHORT_TERM: self.short_term_memories
            }
            search_lists = [type_map.get(memory_type, [])]
        
        for mem_list in search_lists:
            for entry in mem_list:
                if tag and entry.tag != tag:
                    continue
                if keyword:
                    if keyword.lower() not in entry.name.lower() and \
                       keyword.lower() not in entry.content.lower():
                        continue
                results.append(entry)
        
        return results
    
    def rotate(self, memory_type: MemoryType = MemoryType.SHORT_TERM) -> MemoryEntry:
        """
        执行记忆轮转(移除最旧的短期记忆)
        
        Args:
            memory_type: 要轮转的记忆类型
            
        Returns:
            MemoryEntry: 被移除的记忆,如果没有则返回None
        """
        if memory_type == MemoryType.SHORT_TERM:
            if self.short_term_memories:
                rotated = self.short_term_memories.pop(0)
                self.stats['rotation_count'] += 1
                return rotated
        
        return None
    
    def reinforce(self, name: str = None, tag: str = None, 
                   weight_boost: float = 0.1) -> int:
        """
        强化记忆(提升权重)
        
        Args:
            name: 记忆名称
            tag: 标签
            weight_boost: 权重增量
            
        Returns:
            int: 强化的记忆数量
        """
        reinforced = 0
        
        for entry in self.total_memories:
            if name and entry.name != name:
                continue
            if tag and entry.tag != tag:
                continue
            
            # 提升权重,上限1.0
            entry.weight = min(1.0, entry.weight + weight_boost)
            reinforced += 1
        
        self.stats['reinforcement_count'] += reinforced
        return reinforced
    
    def forget(self, decay_rate: float = 0.05, min_weight: float = 0.1) -> int:
        """
        遗忘机制(按衰减率降低权重,移除低于阈值的记忆)
        
        Args:
            decay_rate: 权重衰减率
            min_weight: 最小权重阈值,低于此值将被遗忘
            
        Returns:
            int: 被遗忘的记忆数量
        """
        forgotten = 0
        
        # 衰减所有记忆权重
        for entry in self.total_memories:
            entry.weight = max(0.0, entry.weight - decay_rate)
        
        # 移除低于阈值的记忆
        to_forget = [e for e in self.total_memories if e.weight < min_weight]
        
        for entry in to_forget:
            self.delete(name=entry.name)
            forgotten += 1
        
        self.stats['forget_count'] += forgotten
        return forgotten
    
    def get_memories_by_tag(self, tag: str) -> list[MemoryEntry]:
        """
        按标签检索记忆
        
        Args:
            tag: 标签名
            
        Returns:
            list[MemoryEntry]: 匹配的记忆列表
        """
        return [e for e in self.total_memories if e.tag == tag]
    
    def get_recent_memories(self, limit: int = 10, 
                            memory_type: MemoryType = None) -> list[MemoryEntry]:
        """
        获取最近的记忆
        
        Args:
            limit: 返回数量限制
            memory_type: 指定记忆类型
            
        Returns:
            list[MemoryEntry]: 按时间排序的记忆列表
        """
        if memory_type is None:
            source = self.total_memories
        else:
            type_map = {
                MemoryType.NORMAL: self.normal_memories,
                MemoryType.ABNORMAL: self.abnormal_memories,
                MemoryType.LONG_TERM: self.long_term_memories,
                MemoryType.SHORT_TERM: self.short_term_memories
            }
            source = type_map.get(memory_type, self.total_memories)
        
        # 按创建时间降序排序
        sorted_memories = sorted(source, key=lambda e: e.created_at, reverse=True)
        return sorted_memories[:limit]
    
    def get_memory_stats(self) -> dict:
        """获取记忆系统统计信息"""
        return {
            'total_memories_count': len(self.total_memories),
            'normal_memories_count': len(self.normal_memories),
            'abnormal_memories_count': len(self.abnormal_memories),
            'abnormal_overflow': max(0, len(self.abnormal_memories) - self.ABNORMAL_MAX),
            'long_term_memories_count': len(self.long_term_memories),
            'short_term_memories_count': len(self.short_term_memories),
            'y_base': self.y_base,
            'base_y_offset': self.base_y_offset,
            'ptsd_trigger_rate': self.ptsd_trigger_rate,
            'stats': self.stats.copy()
        }
    
    def serialize(self) -> str:
        """
        序列化记忆系统到JSON字符串
        
        Returns:
            str: JSON格式的序列化数据
        """
        data = {
            'total_memories': [e.to_dict() for e in self.total_memories],
            'normal_memories': [e.to_dict() for e in self.normal_memories],
            'abnormal_memories': [e.to_dict() for e in self.abnormal_memories],
            'long_term_memories': [e.to_dict() for e in self.long_term_memories],
            'short_term_memories': [e.to_dict() for e in self.short_term_memories],
            'y_base': self.y_base,
            'base_y_offset': self.base_y_offset,
            'ptsd_trigger_rate': self.ptsd_trigger_rate,
            'stats': self.stats,
            'serialized_at': time.time()
        }
        return json.dumps(data, ensure_ascii=False, indent=2)
    
    def deserialize(self, json_str: str) -> bool:
        """
        从JSON字符串反序列化
        
        Args:
            json_str: JSON格式的序列化数据
            
        Returns:
            bool: 反序列化是否成功
        """
        try:
            data = json.loads(json_str)
            
            # 恢复记忆数据
            self.total_memories = [MemoryEntry.from_dict(e) for e in data.get('total_memories', [])]
            self.normal_memories = [MemoryEntry.from_dict(e) for e in data.get('normal_memories', [])]
            self.abnormal_memories = [MemoryEntry.from_dict(e) for e in data.get('abnormal_memories', [])]
            self.long_term_memories = [MemoryEntry.from_dict(e) for e in data.get('long_term_memories', [])]
            self.short_term_memories = [MemoryEntry.from_dict(e) for e in data.get('short_term_memories', [])]
            
            # 恢复心理状态
            self.y_base = data.get('y_base', 50.0)
            self.base_y_offset = data.get('base_y_offset', 0)
            self.ptsd_trigger_rate = data.get('ptsd_trigger_rate', 0.0)
            
            # 恢复统计
            self.stats = data.get('stats', self.stats)
            
            return True
        except (json.JSONDecodeError, KeyError, TypeError) as e:
            print(f"反序列化失败: {e}")
            return False
    
    def save_to_file(self, filepath: str) -> bool:
        """
        保存记忆系统到文件
        
        Args:
            filepath: 文件路径
            
        Returns:
            bool: 保存是否成功
        """
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(self.serialize())
            return True
        except IOError as e:
            print(f"保存失败: {e}")
            return False
    
    def load_from_file(self, filepath: str) -> bool:
        """
        从文件加载记忆系统
        
        Args:
            filepath: 文件路径
            
        Returns:
            bool: 加载是否成功
        """
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                json_str = f.read()
            return self.deserialize(json_str)
        except IOError as e:
            print(f"加载失败: {e}")
            return False


# 模块自检
if __name__ == "__main__":
    print("=== 记忆管理系统自检 ===\n")
    
    # 创建记忆系统
    ms = MemorySystem()
    
    # 测试添加记忆
    print("1. 测试添加记忆:")
    
    # 添加常态记忆
    ms.add(MemoryEntry("日常工作", "work", "完成日常任务", 0.7, 0.2), MemoryType.NORMAL)
    ms.add(MemoryEntry("朋友聚会", "social", "和朋友一起吃饭", 0.8, 0.5), MemoryType.NORMAL)
    
    # 添加长期记忆
    ms.add(MemoryEntry("重要决定", "life", "做出人生重要选择", 0.9, 0.3), MemoryType.LONG_TERM)
    
    # 添加短期记忆
    ms.add(MemoryEntry("临时任务", "task", "需要完成的任务", 0.3, 0.0), MemoryType.SHORT_TERM)
    
    # 添加异常记忆
    ms.add(MemoryEntry("事故经历", "trauma", "发生了一次事故", 0.9, -0.8), MemoryType.ABNORMAL)
    
    print(f"   - 添加了 5 条记忆")
    
    # 测试检索
    print("\n2. 测试记忆检索:")
    
    tag_results = ms.get_memories_by_tag("work")
    print(f"   - 按标签 'work' 检索: {len(tag_results)} 条")
    
    recent = ms.get_recent_memories(3)
    print(f"   - 最近 3 条记忆: {[e.name for e in recent]}")
    
    # 测试搜索
    search_results = ms.search(keyword="任务")
    print(f"   - 搜索 '任务': {len(search_results)} 条")
    
    # 测试强化
    print("\n3. 测试记忆强化:")
    reinforced = ms.reinforce(tag="work", weight_boost=0.1)
    print(f"   - 强化了 {reinforced} 条记忆")
    
    # 测试遗忘
    print("\n4. 测试遗忘机制:")
    forgotten = ms.forget(decay_rate=0.2, min_weight=0.6)
    print(f"   - 遗忘了 {forgotten} 条记忆")
    
    # 测试异常记忆超限
    print("\n5. 测试异常记忆超限惩罚:")
    for i in range(20):
        ms.add(MemoryEntry(f"创伤事件{i}", "trauma", f"创伤内容{i}", 0.9, -0.7), MemoryType.ABNORMAL)
    
    stats = ms.get_memory_stats()
    print(f"   - 异常记忆数量: {stats['abnormal_memories_count']}")
    print(f"   - 基础Y值: {stats['y_base']:.2f}")
    print(f"   - Y值偏移: {stats['base_y_offset']:.2f}")
    print(f"   - PTSD触发率: {stats['ptsd_trigger_rate']:.2%}")
    print(f"   - 惩罚应用次数: {stats['stats']['ptsd_penalties_applied']}")
    
    # 测试序列化
    print("\n6. 测试序列化/反序列化:")
    serialized = ms.serialize()
    print(f"   - 序列化成功,长度: {len(serialized)} 字符")
    
    # 创建新系统并反序列化
    ms2 = MemorySystem()
    success = ms2.deserialize(serialized)
    print(f"   - 反序列化: {'成功' if success else '失败'}")
    print(f"   - 恢复记忆数: {len(ms2.total_memories)}")
    
    # 统计信息
    print("\n7. 完整统计:")
    final_stats = ms.get_memory_stats()
    for key, value in final_stats.items():
        print(f"   - {key}: {value}")
    
    print("\n=== 自检完成 ===")
