"""
MBTI Weight System Module
16种MBTI类型的欲望权重和情绪权重系统
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

# ============================================================================
# MBTI字母定义
# ============================================================================

# 短字母映射
SHORT_LETTERS = {
    'E': 'Extroversion',   # 外向
    'I': 'Introversion',   # 内向
    'S': 'Sensing',        # 感觉
    'N': 'Intuition',      # 直觉
    'T': 'Thinking',       # 思考
    'F': 'Feeling',        # 情感
    'J': 'Judging',        # 判断
    'P': 'Perceiving',     # 知觉
}

# 长字母映射
LONG_LETTERS = {
    'E': '外向型',   # Extroversion
    'I': '内向型',   # Introversion
    'S': '感觉型',   # Sensing
    'N': '直觉型',   # Intuition
    'T': '思考型',   # Thinking
    'F': '情感型',   # Feeling
    'J': '判断型',   # Judging
    'P': '知觉型',   # Perceiving
}

# ============================================================================
# 16种MBTI类型名称
# ============================================================================

MBTI_NAMES = {
    'ISTJ': '检查者',
    'ISFJ': '保护者',
    'INFJ': '倡导者',
    'INTJ': '策划者',
    'ISTP': '工匠',
    'ISFP': '艺术家',
    'INFP': '理想主义者',
    'INTP': '逻辑学家',
    'ESTP': '企业家',
    'ESFP': '表演者',
    'ENFP': '激励者',
    'ENTP': '辩论家',
    'ESTJ': '监督者',
    'ESFJ': '供给者',
    'ENFJ': '教导者',
    'ENTJ': '指挥官',
}

# ============================================================================
# 6维欲望权重 (生存欲/求知欲/表达欲/表现欲/舒适欲/情欲)
# ============================================================================

DESIRE_WEIGHTS_16 = {
    # INFJ - 倡导者: 内向直觉情感判断
    'INFJ': {'survival': 0.7, 'knowledge': 0.9, 'expression': 0.6, 'performance': 0.5, 'comfort': 0.7, 'sexual': 0.5},
    
    # INFP - 理想主义者: 内向直觉情感知觉
    'INFP': {'survival': 0.6, 'knowledge': 0.9, 'expression': 0.7, 'performance': 0.4, 'comfort': 0.8, 'sexual': 0.5},
    
    # INTJ - 策划者: 内向直觉思考判断
    'INTJ': {'survival': 0.7, 'knowledge': 0.95, 'expression': 0.4, 'performance': 0.6, 'comfort': 0.6, 'sexual': 0.4},
    
    # INTP - 逻辑学家: 内向直觉思考知觉
    'INTP': {'survival': 0.6, 'knowledge': 0.98, 'expression': 0.4, 'performance': 0.5, 'comfort': 0.7, 'sexual': 0.4},
    
    # ISTJ - 检查者: 内向感觉思考判断
    'ISTJ': {'survival': 0.85, 'knowledge': 0.6, 'expression': 0.3, 'performance': 0.7, 'comfort': 0.75, 'sexual': 0.4},
    
    # ISFJ - 保护者: 内向感觉情感判断
    'ISFJ': {'survival': 0.85, 'knowledge': 0.5, 'expression': 0.5, 'performance': 0.6, 'comfort': 0.85, 'sexual': 0.45},
    
    # ISTP - 工匠: 内向感觉思考知觉
    'ISTP': {'survival': 0.8, 'knowledge': 0.7, 'expression': 0.35, 'performance': 0.6, 'comfort': 0.75, 'sexual': 0.5},
    
    # ISFP - 艺术家: 内向感觉情感知觉
    'ISFP': {'survival': 0.65, 'knowledge': 0.6, 'expression': 0.75, 'performance': 0.5, 'comfort': 0.9, 'sexual': 0.6},
    
    # ENFJ - 教导者: 外向直觉情感判断
    'ENFJ': {'survival': 0.65, 'knowledge': 0.8, 'expression': 0.9, 'performance': 0.7, 'comfort': 0.6, 'sexual': 0.55},
    
    # ENFP - 激励者: 外向直觉情感知觉
    'ENFP': {'survival': 0.6, 'knowledge': 0.8, 'expression': 0.95, 'performance': 0.65, 'comfort': 0.65, 'sexual': 0.6},
    
    # ENTJ - 指挥官: 外向直觉思考判断
    'ENTJ': {'survival': 0.75, 'knowledge': 0.85, 'expression': 0.75, 'performance': 0.85, 'comfort': 0.5, 'sexual': 0.55},
    
    # ENTP - 辩论家: 外向直觉思考知觉
    'ENTP': {'survival': 0.65, 'knowledge': 0.9, 'expression': 0.85, 'performance': 0.7, 'comfort': 0.6, 'sexual': 0.6},
    
    # ESTJ - 监督者: 外向感觉思考判断
    'ESTJ': {'survival': 0.9, 'knowledge': 0.6, 'expression': 0.7, 'performance': 0.8, 'comfort': 0.7, 'sexual': 0.5},
    
    # ESFJ - 供给者: 外向感觉情感判断
    'ESFJ': {'survival': 0.8, 'knowledge': 0.55, 'expression': 0.85, 'performance': 0.75, 'comfort': 0.8, 'sexual': 0.55},
    
    # ESTP - 企业家: 外向感觉思考知觉
    'ESTP': {'survival': 0.9, 'knowledge': 0.65, 'expression': 0.8, 'performance': 0.85, 'comfort': 0.7, 'sexual': 0.7},
    
    # ESFP - 表演者: 外向感觉情感知觉
    'ESFP': {'survival': 0.75, 'knowledge': 0.55, 'expression': 0.95, 'performance': 0.85, 'comfort': 0.85, 'sexual': 0.7},
}

# ============================================================================
# 7维情绪权重 (喜/怒/忧/思/悲/恐/惊)
# ============================================================================

EMOTION_WEIGHTS_16 = {
    # INFJ - 倡导者
    'INFJ': {'joy': 0.5, 'anger': 0.4, 'worry': 0.7, 'thinking': 0.85, 'sadness': 0.6, 'fear': 0.55, 'surprise': 0.4},
    
    # INFP - 理想主义者
    'INFP': {'joy': 0.55, 'anger': 0.35, 'worry': 0.65, 'thinking': 0.8, 'sadness': 0.7, 'fear': 0.5, 'surprise': 0.45},
    
    # INTJ - 策划者
    'INTJ': {'joy': 0.5, 'anger': 0.5, 'worry': 0.6, 'thinking': 0.9, 'sadness': 0.5, 'fear': 0.45, 'surprise': 0.5},
    
    # INTP - 逻辑学家
    'INTP': {'joy': 0.5, 'anger': 0.4, 'worry': 0.55, 'thinking': 0.95, 'sadness': 0.45, 'fear': 0.4, 'surprise': 0.55},
    
    # ISTJ - 检查者
    'ISTJ': {'joy': 0.5, 'anger': 0.55, 'worry': 0.6, 'thinking': 0.6, 'sadness': 0.5, 'fear': 0.5, 'surprise': 0.4},
    
    # ISFJ - 保护者
    'ISFJ': {'joy': 0.6, 'anger': 0.4, 'worry': 0.7, 'thinking': 0.5, 'sadness': 0.6, 'fear': 0.55, 'surprise': 0.4},
    
    # ISTP - 工匠
    'ISTP': {'joy': 0.6, 'anger': 0.5, 'worry': 0.45, 'thinking': 0.65, 'sadness': 0.4, 'fear': 0.45, 'surprise': 0.6},
    
    # ISFP - 艺术家
    'ISFP': {'joy': 0.7, 'anger': 0.35, 'worry': 0.55, 'thinking': 0.5, 'sadness': 0.6, 'fear': 0.45, 'surprise': 0.55},
    
    # ENFJ - 教导者
    'ENFJ': {'joy': 0.75, 'anger': 0.4, 'worry': 0.6, 'thinking': 0.6, 'sadness': 0.5, 'fear': 0.45, 'surprise': 0.5},
    
    # ENFP - 激励者
    'ENFP': {'joy': 0.85, 'anger': 0.35, 'worry': 0.5, 'thinking': 0.55, 'sadness': 0.5, 'fear': 0.4, 'surprise': 0.7},
    
    # ENTJ - 指挥官
    'ENTJ': {'joy': 0.65, 'anger': 0.65, 'worry': 0.5, 'thinking': 0.75, 'sadness': 0.4, 'fear': 0.4, 'surprise': 0.55},
    
    # ENTP - 辩论家
    'ENTP': {'joy': 0.7, 'anger': 0.55, 'worry': 0.45, 'thinking': 0.8, 'sadness': 0.4, 'fear': 0.35, 'surprise': 0.7},
    
    # ESTJ - 监督者
    'ESTJ': {'joy': 0.6, 'anger': 0.65, 'worry': 0.55, 'thinking': 0.55, 'sadness': 0.45, 'fear': 0.5, 'surprise': 0.45},
    
    # ESFJ - 供给者
    'ESFJ': {'joy': 0.8, 'anger': 0.45, 'worry': 0.6, 'thinking': 0.45, 'sadness': 0.55, 'fear': 0.45, 'surprise': 0.5},
    
    # ESTP - 企业家
    'ESTP': {'joy': 0.85, 'anger': 0.6, 'worry': 0.4, 'thinking': 0.5, 'sadness': 0.4, 'fear': 0.4, 'surprise': 0.75},
    
    # ESFP - 表演者
    'ESFP': {'joy': 0.9, 'anger': 0.45, 'worry': 0.45, 'thinking': 0.4, 'sadness': 0.5, 'fear': 0.4, 'surprise': 0.8},
}

# ============================================================================
# MBTIProfile dataclass
# ============================================================================

@dataclass
class MBTIProfile:
    """MBTI性格档案"""
    mbti_type: str                          # MBTI类型 (如: 'INTJ')
    name: str = ''                          # 类型名称
    letter_short: str = ''                  # 短字母解析
    letter_long: str = ''                   # 长字母解析
    
    # 6维欲望权重
    desire_weights: Dict[str, float] = field(default_factory=dict)
    
    # 7维情绪权重
    emotion_weights: Dict[str, float] = field(default_factory=dict)
    
    # 行为倾向描述
    behavior_tendency: List[str] = field(default_factory=list)
    
    # 性格特点
    traits: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """初始化后处理"""
        if not self.name:
            self.name = MBTI_NAMES.get(self.mbti_type, '未知')
        
        if not self.letter_short:
            self.letter_short = parse_mbti_short(self.mbti_type)
        
        if not self.letter_long:
            self.letter_long = parse_mbti_long(self.mbti_type)
        
        if not self.desire_weights:
            self.desire_weights = DESIRE_WEIGHTS_16.get(self.mbti_type, {}).copy()
        
        if not self.emotion_weights:
            self.emotion_weights = EMOTION_WEIGHTS_16.get(self.mbti_type, {}).copy()
        
        if not self.behavior_tendency:
            self.behavior_tendency = get_behavior_tendency(self.mbti_type)
        
        if not self.traits:
            self.traits = get_mbti_traits(self.mbti_type)


# ============================================================================
# 辅助函数
# ============================================================================

def parse_mbti_short(mbti: str) -> str:
    """解析MBTI短字母
    
    Args:
        mbti: MBTI类型 (如: 'INTJ')
    
    Returns:
        短字母解析 (如: 'I-N-T-J')
    """
    if len(mbti) != 4:
        return ''
    
    parts = []
    for i, letter in enumerate(mbti):
        if letter in SHORT_LETTERS:
            parts.append(f"{letter}={SHORT_LETTERS[letter]}")
    
    return ', '.join(parts)


def parse_mbti_long(mbti: str) -> str:
    """解析MBTI长字母(中文)
    
    Args:
        mbti: MBTI类型 (如: 'INTJ')
    
    Returns:
        长字母解析 (如: '内向-直觉-思考-判断')
    """
    if len(mbti) != 4:
        return ''
    
    parts = []
    for letter in mbti:
        if letter in LONG_LETTERS:
            parts.append(LONG_LETTERS[letter])
    
    return '-'.join(parts)


def get_mbti_weights(mbti: str) -> Dict:
    """获取MBTI类型的权重字典
    
    Args:
        mbti: MBTI类型 (如: 'INTJ')
    
    Returns:
        包含desire_weights和emotion_weights的字典
    """
    mbti = mbti.upper()
    
    desire = DESIRE_WEIGHTS_16.get(mbti, {})
    emotion = EMOTION_WEIGHTS_16.get(mbti, {})
    
    return {
        'mbti': mbti,
        'name': MBTI_NAMES.get(mbti, '未知'),
        'desire_weights': desire,
        'emotion_weights': emotion,
    }


def get_behavior_tendency(mbti: str) -> List[str]:
    """获取MBTI类型的行为倾向描述
    
    Args:
        mbti: MBTI类型
    
    Returns:
        行为倾向描述列表
    """
    tendencies = {
        'ISTJ': [
            '注重细节和事实',
            '按计划行事，责任心强',
            '诚实守信，遵守规则',
            '偏好稳定和有秩序的环境',
            '决策基于逻辑和实际经验',
        ],
        'ISFJ': [
            '安静内敛，关注他人需求',
            '做事细致周到，有耐心',
            '忠诚可靠，守护承诺',
            '不喜欢冲突和变化',
            '重视传统和家庭价值',
        ],
        'INFJ': [
            '洞察力强，关注深层意义',
            '有理想主义倾向，追求改变',
            '善于倾听，共情能力高',
            '独立自主，有明确价值观',
            '偏好深度交流而非表面社交',
        ],
        'INTJ': [
            '战略思维，系统性规划',
            '追求知识和能力提升',
            '独立自主，不依赖他人',
            '高标准，批判性思维',
            '偏好逻辑和效率',
        ],
        'ISTP': [
            '务实理性，善于分析',
            '灵活适应，随机应变',
            '动手能力强，喜欢探索',
            '享受独处和自由',
            '对原理和机制感兴趣',
        ],
        'ISFP': [
            '温和友善，敏感细腻',
            '注重当下，享受生活',
            '有艺术审美，创意丰富',
            '避免冲突，追求和谐',
            '价值观驱动行动',
        ],
        'INFP': [
            '理想主义，内心价值观强',
            '善于文字表达，有创意',
            '共情力高，理解他人',
            '追求意义和自我实现',
            '需要独处时间来充电',
        ],
        'INTP': [
            '逻辑分析，喜欢理论',
            '独立思考，不受约束',
            '好奇心强，探索未知',
            '追求精确和准确',
            '社交相对较少',
        ],
        'ESTP': [
            '行动导向，快速响应',
            '社交活跃，人脉广泛',
            '享受刺激和挑战',
            '灵活变通，适应力强',
            '活在当下，不纠结过去未来',
        ],
        'ESFP': [
            '热情开朗，社交达人',
            '富有表现力，吸引注意',
            '享受生活，乐观积极',
            '善于调解氛围',
            '不喜欢孤独和无聊',
        ],
        'ENFP': [
            '热情洋溢，想象力丰富',
            '善于激励他人',
            '讨厌规则束缚，追求自由',
            '多才多艺，兴趣广泛',
            '社交能力强，人缘好',
        ],
        'ENTP': [
            '思维敏捷，善于创新',
            '喜欢辩论和智力挑战',
            '善于发现可能性',
            '社交活跃，能言善辩',
            '讨厌重复和例行公事',
        ],
        'ESTJ': [
            '务实高效，注重结果',
            '善于组织和管理',
            '遵守规则，尊重传统',
            '决策果断，执行力强',
            '偏好清晰的结构和秩序',
        ],
        'ESFJ': [
            '热情友好，人际导向',
            '善于照顾他人需求',
            '有责任感，乐于助人',
            '重视和谐，避免冲突',
            '喜欢被认可和感谢',
        ],
        'ENFJ': [
            '有魅力，影响力强',
            '善于理解和支持他人',
            '有理想，推动改变',
            '善于沟通和协调',
            '关注他人成长和发展',
        ],
        'ENTJ': [
            '领导力强，果断决策',
            '战略眼光，系统思维',
            '追求效率和成就',
            '自信独立，意志坚定',
            '喜欢挑战和竞争',
        ],
    }
    
    return tendencies.get(mbti.upper(), ['未知类型的行为倾向'])


def get_mbti_traits(mbti: str) -> List[str]:
    """获取MBTI类型的性格特点
    
    Args:
        mbti: MBTI类型
    
    Returns:
        性格特点列表
    """
    traits = {
        'ISTJ': ['务实', '可靠', '有条理', '负责', '传统'],
        'ISFJ': ['忠诚', '体贴', '谦逊', '务实', '耐心'],
        'INFJ': ['洞察', '理想', '坚定', '善良', '独立'],
        'INTJ': ['独立', '分析', '战略', '高标准', '理性'],
        'ISTP': ['灵活', '适应', '理性', '好奇', '动手'],
        'ISFP': ['温和', '艺术', '敏感', '自发', '随和'],
        'INFP': ['理想', '创意', '共情', '价值驱动', '内省'],
        'INTP': ['逻辑', '分析', '好奇', '抽象', '独立'],
        'ESTP': ['活跃', '适应', '务实', '社交', '冒险'],
        'ESFP': ['热情', '表达', '社交', '乐观', '随性'],
        'ENFP': ['热情', '想象', '创意', '激励', '自由'],
        'ENTP': ['机智', '创新', '辩论', '好奇', '灵活'],
        'ESTJ': ['组织', '执行', '务实', '果断', '负责'],
        'ESFJ': ['友善', '合作', '体贴', '负责', '传统'],
        'ENFJ': ['魅力', '共情', '领导', '理想', '沟通'],
        'ENTJ': ['领导', '果断', '战略', '自信', '高效'],
    }
    
    return traits.get(mbti.upper(), ['未知'])


# ============================================================================
# 主函数/测试
# ============================================================================

def get_profile(mbti: str) -> MBTIProfile:
    """获取完整的MBTI档案
    
    Args:
        mbti: MBTI类型
    
    Returns:
        MBTIProfile对象
    """
    return MBTIProfile(mbti_type=mbti.upper())


if __name__ == '__main__':
    # 测试代码
    print("=" * 60)
    print("MBTI Weight System Test")
    print("=" * 60)
    
    # 测试所有16种类型
    test_types = ['INTJ', 'INFP', 'ENFP', 'ENTJ', 'ISTJ', 'ESFJ']
    
    for mbti in test_types:
        print(f"\n--- {mbti} ---")
        
        # 获取权重
        weights = get_mbti_weights(mbti)
        print(f"Name: {weights['name']}")
        print(f"Short Letters: {parse_mbti_short(mbti)}")
        print(f"Long Letters: {parse_mbti_long(mbti)}")
        
        print(f"Desire Weights: {weights['desire_weights']}")
        print(f"Emotion Weights: {weights['emotion_weights']}")
        
        print(f"Behavior Tendency: {get_behavior_tendency(mbti)[:2]}...")
    
    # 测试Profile
    print("\n" + "=" * 60)
    print("MBTIProfile Test")
    print("=" * 60)
    
    profile = get_profile('ENFP')
    print(f"MBTI: {profile.mbti_type}")
    print(f"Name: {profile.name}")
    print(f"Letter Short: {profile.letter_short}")
    print(f"Letter Long: {profile.letter_long}")
    print(f"Desire Weights: {profile.desire_weights}")
    print(f"Emotion Weights: {profile.emotion_weights}")
    print(f"Traits: {profile.traits}")
