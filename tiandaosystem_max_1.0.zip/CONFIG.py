"""
CONFIG.py - 天道系统全局配置常量
Configuration Constants for Tiandao System

提供系统级配置参数,集中管理各模块的默认值和限制。
"""

# ============================================================================
# Y值系统配置 (Y-Psychology Engine)
# ============================================================================

# Y值基础配置
DEFAULT_BASE_Y: float = 50.0  # 默认基础Y值(心理稳定性指标)
Y_VALUE_MIN: float = 0.0       # Y值最小值(崩溃)
Y_VALUE_MAX: float = 100.0    # Y值最大值(爆发)

# Y值状态阈值
Y_STATE_THRESHOLDS = {
    "collapse": (0, 15),        # 崩溃区
    "low_pressure": (16, 30),   # 低压区
    "stable": (31, 70),         # 稳定区
    "high_drive": (71, 85),     # 冲高区
    "eruption": (86, 100),      # 爆发区
}

# 触发机制参数
TRIGGER_FORMULA: str = "max(5, floor((100-y)/10))"  # 触发阈值计算公式
TRIGGER_MIN: int = 5    # 触发阈值最小值
TRIGGER_MAX: int = 10   # 触发阈值最大值

# 补偿机制参数
COMPENSATION_MIN: float = -10.0  # 补偿值最小值
COMPENSATION_MAX: float = 10.0   # 补偿值最大值
COMPENSATION_DURATION_MIN: int = 1   # 补偿持续时间最小
COMPENSATION_DURATION_MAX: int = 3   # 补偿持续时间最大

# 回弹机制参数
REBOUND_RATE: float = 0.85  # 回弹系数(越大回归越慢)
REBOUND_FORMULA: str = "y = base_y + (y - base_y) * 0.85"

# 击穿判定参数
BREAKDOWN_MULTIPLIER: int = 2  # 击穿判定乘数(ΔY > threshold * 2)


# ============================================================================
# 记忆系统配置 (Memory System)
# ============================================================================

# 记忆容量限制
MEMORY_LIMITS = {
    "abnormal_max": 15,       # 异常记忆最大数量
    "long_term_max": 20,      # 长期记忆最大数量
    "short_term_max": 10,     # 短期记忆最大数量
}

# PTSD惩罚参数
PTSD_BASE_INCREASE: float = 5.0   # PTSD基础惩罚值
PTSD_MAX_INCREASE: float = 15.0   # PTSD最大惩罚值
PTSD_TRIGGER_RATE_BASE: float = 0.0  # PTSD触发率基础值
PTSD_OVERFLOW_PENALTY: float = 2.0 # 溢出每条额外惩罚

# 记忆权重参数
WEIGHT_MIN: float = 0.0   # 权重最小值
WEIGHT_MAX: float = 1.0   # 权重最大值
WEIGHT_DECAY_RATE: float = 0.05  # 遗忘衰减率
WEIGHT_REINFORCE_BOOST: float = 0.1  # 强化增量
WEIGHT_MIN_THRESHOLD: float = 0.1   # 遗忘阈值

# 情感值参数
EMOTION_RANGE: tuple = (-1.0, 1.0)  # 情感值范围(负面到正面)


# ============================================================================
# MBTI权重系统配置 (MBTI Weight System)
# ============================================================================

# 欲望维度权重范围
DESIRE_DIMENSIONS = [
    "survival",       # 生存欲
    "knowledge",      # 求知欲
    "expression",     # 表达欲
    "performance",    # 表现欲
    "comfort",        # 舒适欲
    "sexual",         # 情欲
]

# 情绪维度权重范围
EMOTION_DIMENSIONS = [
    "joy",            # 喜
    "anger",          # 怒
    "worry",          # 忧
    "thinking",       # 思
    "sadness",        # 悲
    "fear",           # 恐
    "surprise",       # 惊
]

# MBTI类型列表
MBTI_TYPES = [
    "ISTJ", "ISFJ", "INFJ", "INTJ",
    "ISTP", "ISFP", "INFP", "INTP",
    "ESTP", "ESFP", "ENFP", "ENTP",
    "ESTJ", "ESFJ", "ENFJ", "ENTJ",
]


# ============================================================================
# 动机链系统配置 (Motivation Chain System)
# ============================================================================

# 本能驱动类型
INSTINCT_TYPES = [
    "SURVIVAL",    # 求存本能
    "KNOWLEDGE",   # 求知本能
    "EXPRESSION",  # 表现本能
    "COMFORT",     # 舒适本能
    "DESIRE",      # 情欲本能
    "CREATIVE",    # 表达本能
    "MATERNAL",    # 母性本能
]

# 决策框架类型
DECISION_FRAMEWORKS = [
    "PROFIT",    # 利益优先
    "EMOTION",   # 情感优先
    "LOGIC",     # 逻辑优先
    "SOCIAL",    # 社交优先
    "SAFETY",    # 安全优先
    "GROWTH",    # 成长优先
    "MISSION",   # 使命优先
]

# 动机强度参数
MOTIVATION_INTENSITY_MIN: float = 20.0   # 动机强度最小
MOTIVATION_INTENSITY_MAX: float = 100.0   # 动机强度最大
MOTIVATION_INTENSITY_BASE: float = 60.0   # 动机强度基础值

# 动机确定性参数
MOTIVATION_CONFIDENCE_MIN: float = 0.3    # 确定性最小
MOTIVATION_CONFIDENCE_MAX: float = 0.95   # 确定性最大
MOTIVATION_CONFIDENCE_BASE: float = 0.7   # 确定性基础值

# 框架权重参数
FRAMEWORK_WEIGHT_PRIMARY: float = 0.9   # 主要框架权重
FRAMEWORK_WEIGHT_SECONDARY: float = 0.6  # 次要框架权重
FRAMEWORK_WEIGHT_DEFAULT: float = 0.3   # 默认框架权重
FRAMEWORK_FLEXIBILITY_MIN: float = 0.3  # 灵活度最小
FRAMEWORK_FLEXIBILITY_MAX: float = 0.7  # 灵活度最大


# ============================================================================
# 群像创作配置 (Ensemble Writing Config)
# ============================================================================

# 冲突升级配置
CONFLICT_LEVELS = ["LATENT", "MANIFEST", "ERUPT"]  # 潜在/显性/爆发
CONFLICT_TYPES = [
    "GOAL_CONFLICT",           # 目标冲突
    "VALUE_CONFLICT",          # 价值观冲突
    "INFORMATION_CONFLICT",    # 信息冲突
    "RELATIONSHIP_CONFLICT",   # 关系冲突
]

# 角色约束配置
CHARACTER_MIN_FLAWS: int = 2           # 最少缺陷数量
CHARACTER_AUTONOMY_MIN: float = 0.3  # 自主度最小
CHARACTER_AUTONOMY_MAX: float = 0.8  # 自主度最大

# 完美度控制
MAX_PERFECTION_SCORE: float = 0.7    # 最大完美度
CONFLICT_ESCALATION_RATE: float = 0.3  # 冲突升级概率


# ============================================================================
# 系统全局配置
# ============================================================================

# 版本信息
VERSION: str = "1.0.0"
SYSTEM_NAME: str = "天道系统 (Tiandao System)"

# 系统开关
ENABLE_PSYCHOLOGY: bool = True    # 启用心理引擎
ENABLE_MEMORY: bool = True        # 启用记忆系统
ENABLE_MBTI: bool = True          # 启用MBTI系统
ENABLE_MOTIVATION: bool = True    # 启用动机系统
ENABLE_AUTHOR_CONSTRAINT: bool = True  # 启用作者约束

# 日志配置
LOG_LEVEL: str = "INFO"  # DEBUG/INFO/WARNING/ERROR
LOG_OUTPUT: str = "console"  # console/file/both


# ============================================================================
# 便捷访问函数
# ============================================================================

def get_y_state_threshold(state_name: str) -> tuple:
    """获取Y值状态阈值"""
    return Y_STATE_THRESHOLDS.get(state_name, (0, 100))


def get_memory_limit(memory_type: str) -> int:
    """获取记忆类型限制"""
    return MEMORY_LIMITS.get(memory_type, 999999)


def get_instinct_name(instinct_value: int) -> str:
    """获取本能名称"""
    names = {
        1: "求存本能",
        2: "求知本能",
        3: "表现本能",
        4: "舒适本能",
        5: "情欲本能",
        6: "表达本能",
        7: "母性本能",
    }
    return names.get(instinct_value, "未知本能")
