#!/usr/bin/env python3
"""
demo_group_scene.py - 群像场景演示
Demo: create 4 characters, generate group portrait scene, simulate conflicts and resolutions

Demonstrates:
- Creating 4 diverse characters
- Group portrait scene generation
- Conflict detection and escalation
- Conflict resolution strategies
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tiandao.author import (
    AuthorConstraint, ConflictType, ConflictLevel,
    ConflictVariable, generate_group_portrait_scene,
    EnsembleConstraint, TCMConstraint
)


def print_separator(title=""):
    """打印分隔线"""
    width = 70
    if title:
        print(f"\n{'='*width}")
        print(f" {title}")
        print(f"{'='*width}")
    else:
        print("-" * width)


def create_characters():
    """创建4个角色"""
    characters = [
        {
            "name": "林战略",
            "type": "leader",
            "role": "项目经理",
            "mbti": "ENTJ",
            "traits": ["果断", "战略眼光", "目标导向"],
            "temperament": "aggressive",
            "goal": "带领团队完成年度目标",
            "limiations": [],
        },
        {
            "name": "陈创意",
            "type": "creative",
            "role": "设计师",
            "mbti": "INFP",
            "traits": ["创意丰富", "理想主义", "敏感细腻"],
            "temperament": "passive",
            "goal": "追求完美的设计作品",
            "limitations": [],
        },
        {
            "name": "王执行",
            "type": "follower",
            "role": "工程师",
            "mbti": "ISTJ",
            "traits": ["务实", "可靠", "注重细节"],
            "temperament": "balanced",
            "goal": "按时交付高质量代码",
            "limitations": [],
        },
        {
            "name": "刘外交",
            "type": "social",
            "role": "客户经理",
            "mbti": "ENFJ",
            "traits": ["善于沟通", "共情力强", "人际导向"],
            "temperament": "active",
            "goal": "维护客户关系",
            "limitations": [],
        },
    ]
    
    return characters


def print_character(char, index):
    """打印角色信息"""
    print(f"\n  角色{index}: {char['name']}")
    print(f"    职位: {char['role']}")
    print(f"    MBTI: {char['mbti']}")
    print(f"    特质: {', '.join(char['traits'])}")
    print(f"    目标: {char['goal']}")
    print(f"    气质: {char['temperament']}")


def demo_constraint_system():
    """演示约束系统"""
    print_separator("作者约束系统")
    
    constraint = AuthorConstraint()
    
    print("\n  【AI思维限制器】")
    print("    目的: 防止AI扮演上帝,允许角色失败和局限")
    print("    功能:")
    print("      - 检查上帝情结行为")
    print("      - 强制添加角色局限性")
    print("      - 验证叙事包含合理代价")
    
    print("\n  【群像创作思维】")
    print("    去神性化: 移除完美属性,添加人性弱点")
    print("    去工具化: 赋予角色自主意志和个人诉求")
    print("    群像暴走化: 角色可超出预设,引入不可预测性")
    
    print("\n  【冲突变量库】")
    print("    4种冲突类型: 目标冲突/价值观冲突/信息冲突/关系冲突")
    print("    3级升级: 潜在 → 显性 → 爆发")
    
    print("\n  【中医开方思维】")
    print("    扶正固本: 增强角色自身能力")
    print("    调和阴阳: 平衡角色间关系")
    print("    脾肾同调: 处理深层动机与表层行为")


def simulate_conflict_evolution(characters):
    """模拟冲突演变"""
    print_separator("冲突演变模拟")
    
    print("\n  【初始场景】")
    scene_desc = generate_group_portrait_scene(characters)
    print(f"  {scene_desc}")
    
    # 定义冲突
    conflicts = [
        {
            "name": "目标冲突",
            "type": ConflictType.GOAL_CONFLICT,
            "level": ConflictLevel.LATENT,
            "description": "项目进度vs设计质量",
            "parties": ["林战略", "陈创意"],
        },
        {
            "name": "价值观冲突",
            "type": ConflictType.VALUE_CONFLICT,
            "level": ConflictLevel.LATENT,
            "description": "效率优先vs完美主义",
            "parties": ["王执行", "陈创意"],
        },
        {
            "name": "信息冲突",
            "type": ConflictType.INFORMATION_CONFLICT,
            "level": ConflictLevel.LATENT,
            "description": "客户真实需求不明确",
            "parties": ["刘外交", "王执行"],
        },
        {
            "name": "关系冲突",
            "type": ConflictType.RELATIONSHIP_CONFLICT,
            "level": ConflictLevel.LATENT,
            "description": "团队信任出现裂痕",
            "parties": ["林战略", "陈创意"],
        },
    ]
    
    # 冲突演变
    levels = [
        ConflictLevel.LATENT,
        ConflictLevel.MANIFEST,
        ConflictLevel.ERUPT,
    ]
    
    level_names = ["潜在阶段", "显性阶段", "爆发阶段"]
    
    for i, level in enumerate(levels):
        print(f"\n  【{level_names[i]}】")
        
        for conflict in conflicts:
            # 升级该冲突
            current_level_idx = levels.index(level)
            if current_level_idx > 0:
                conflict["level"] = level
            
            desc = ConflictVariable.get_conflict_description(
                conflict["type"], 
                conflict["level"]
            )
            triggers = ConflictVariable.get_triggers(
                conflict["type"],
                conflict["level"]
            )
            
            print(f"\n    {conflict['name']} ({', '.join(conflict['parties'])})")
            print(f"      状态: {desc}")
            if triggers:
                print(f"      触发条件: {triggers[0] if triggers else '无'}")
            
            if level == ConflictLevel.ERUPT:
                print(f"      ⚠️ 警告: 冲突已升级到最高级别!")


def demo_conflict_resolution():
    """演示冲突解决"""
    print_separator("冲突解决策略")
    
    print("\n  【解决思路】")
    
    resolutions = {
        ConflictType.GOAL_CONFLICT: [
            "【妥协】双方各退一步,找到平衡点",
            "【协调】重新评估目标优先级",
            "【资源调配】增加资源满足双方需求",
            "【外部仲裁】请上级或第三方裁决",
        ],
        ConflictType.VALUE_CONFLICT: [
            "【理解】尝试理解对方价值观来源",
            "【对话】开放沟通,坦诚表达",
            "【共识】寻找更高层次的共同价值观",
            "【空间】给彼此独立决策的空间",
        ],
        ConflictType.INFORMATION_CONFLICT: [
            "【澄清】主动核实信息准确性",
            "【共享】建立信息共享机制",
            "【确认】重要决策前再次确认",
            "【信任】基于信任而非完全信息决策",
        ],
        ConflictType.RELATIONSHIP_CONFLICT: [
            "【修复】主动道歉或表达善意",
            "【沟通】私下交流,澄清误会",
            "【行动】用行动证明诚意",
            "【时间】给关系修复留出时间",
        ],
    }
    
    for conflict_type, strategies in resolutions.items():
        print(f"\n  {conflict_type.value}:")
        for strategy in strategies:
            print(f"    {strategy}")


def demo_group_dynamics_analysis():
    """演示群像动力学分析"""
    print_separator("群像动力学分析")
    
    characters = create_characters()
    
    print("\n  【角色阴阳分布】")
    yang = sum(1 for c in characters if c["temperament"] in ["aggressive", "active"])
    yin = sum(1 for c in characters if c["temperament"] in ["passive", "introverted"])
    balanced = sum(1 for c in characters if c["temperament"] == "balanced")
    
    print(f"    阳性(主动/激进): {yang}人")
    for c in characters:
        if c["temperament"] in ["aggressive", "active"]:
            print(f"      - {c['name']}")
    
    print(f"    阴性(被动/保守): {yin}人")
    for c in characters:
        if c["temperament"] in ["passive", "introverted"]:
            print(f"      - {c['name']}")
    
    print(f"    平衡型: {balanced}人")
    for c in characters:
        if c["temperament"] == "balanced":
            print(f"      - {c['name']}")
    
    # 诊断
    print("\n  【TCM诊断】")
    dynamics = TCMConstraint.diagnose_group_dynamics(characters)
    print(f"    整体状态: {dynamics['整体状态']}")
    if dynamics['失衡点']:
        print(f"    失衡点: {', '.join(dynamics['失衡点'])}")
    
    # 开方
    print("\n  【中医开方】")
    prescriptions = TCMConstraint.prescribe_treatment(dynamics)
    for p in prescriptions:
        print(f"    {p}")


def apply_author_constraints():
    """应用作者约束"""
    print_separator("应用作者约束")
    
    characters = create_characters()
    constraint = AuthorConstraint()
    
    print("\n  【约束前角色状态】")
    for i, char in enumerate(characters, 1):
        has_limitations = len(char.get('limitations', [])) > 0
        print(f"    {char['name']}: 局限性={has_limitations}")
    
    # 应用约束
    constrained = constraint.apply_all_constraints(characters)
    
    print("\n  【约束后角色状态】")
    for char in constrained:
        limitations = char.get('limitations', [])
        failures = char.get('failure_modes', [])
        can_rogue = char.get('can_go_rogue', False)
        autonomy = char.get('autonomy_level', 0)
        
        print(f"\n    {char['name']}:")
        print(f"      局限性: {limitations if limitations else '无'}")
        print(f"      失败模式: {failures[:2] if failures else '无'}")
        print(f"      可暴走: {can_rogue}, 自主度: {autonomy:.1%}")


def main():
    """主函数"""
    print("=" * 70)
    print("       群像场景系统演示 - 冲突与解决")
    print("=" * 70)
    
    # 1. 创建角色
    print_separator("Step 1: 创建4个角色")
    characters = create_characters()
    
    print("\n  角色阵容:")
    for i, char in enumerate(characters, 1):
        print_character(char, i)
    
    # 2. 约束系统介绍
    demo_constraint_system()
    
    # 3. 群像场景生成
    print_separator("Step 2: 群像场景生成")
    scene = generate_group_portrait_scene(characters)
    print(f"\n  生成场景:")
    print(f"  {scene}")
    
    # 4. 冲突演变
    simulate_conflict_evolution(characters)
    
    # 5. 冲突解决
    demo_conflict_resolution()
    
    # 6. 群像动力学
    demo_group_dynamics_analysis()
    
    # 7. 应用约束
    apply_author_constraints()
    
    print_separator("演示完成")
    print("\n  系统核心原则:")
    print("  ✓ 去神性化: 角色必须有局限和弱点")
    print("  ✓ 去工具化: 角色有自己的意志和诉求")
    print("  ✓ 群像暴走: 角色行为可超出预设")
    print("  ✓ 冲突合理: 冲突有起因、升级、消解过程")
    print("  ✓ 代价必要: 叙事必须包含合理代价与遗憾")


if __name__ == "__main__":
    main()
