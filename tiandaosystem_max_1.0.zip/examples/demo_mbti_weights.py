#!/usr/bin/env python3
"""
demo_mbti_weights.py - MBTI权重系统演示
Demo: load all 16 MBTI types, show their desire and emotion weight radar chart (text-based), compare two types

Demonstrates:
- All 16 MBTI types loading
- 6-dimension desire weights radar chart
- 7-dimension emotion weights radar chart
- Two-type comparison view
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tiandao.mbti import (
    MBTI_NAMES, MBTIProfile, get_mbti_weights,
    DESIRE_WEIGHTS_16, EMOTION_WEIGHTS_16
)


def print_separator(title=""):
    """打印分隔线"""
    width = 70
    if title:
        print(f"\n{'='*width}")
        print(f" {title}")
        print(f"{'='*width}")
    else:
        print("-" * width)


def draw_text_radar(values, labels, width=40, height=10):
    """
    绘制文本雷达图
    
    Args:
        values: 数值列表 (0-1)
        labels: 标签列表
        width: 雷达图宽度
        height: 雷达图高度(层数)
    """
    n = len(values)
    if n == 0:
        return
    
    # 角度计算
    angles = [i * 360 / n for i in range(n)]
    
    # 打印标签
    print("  雷达图:")
    
    # 从外到内打印每一层
    for level in range(height, 0, -1):
        threshold = level / height
        line = "  " + " " * (width // 2)
        
        row = []
        for i, (val, angle) in enumerate(zip(values, angles)):
            # 计算该点的位置
            x = int((width // 2) + (width // 2 - 2) * threshold * val)
            y = int(height - level)
            
            # 用简单方式近似显示点
            # 对于雷达图，我们用一个列表模拟
            pass
        
        # 简化的垂直条形图代替复杂雷达图
        bar_chars = int(threshold * width)
        level_str = "█" * bar_chars
        print(f"  [{level}/{height}] {level_str:<{width}} {threshold:.1f}")
    
    # 打印标签
    label_line = "  "
    for i, label in enumerate(labels):
        pos = int((i + 0.5) * width / n)
        short_label = label[:3]
        label_line += f"{short_label:^{6}}"
    print(label_line)
    
    # 打印数值
    value_line = "  "
    for val in values:
        value_line += f"{val:.2f}  "
    print(f"  数值: {value_line}")


def draw_comparison_bar(type1, type2, weights1, weights2, labels, title):
    """绘制两个类型的对比条形图"""
    print(f"\n  {title}对比")
    print(f"  {'维度':<10} | {'类型1':^8} | {'类型2':^8} | 差异")
    print(f"  {'─'*10}─┼{'─'*10}─┼{'─'*10}─┼{'─'*10}")
    
    for i, label in enumerate(labels):
        v1 = weights1[i] if i < len(weights1) else 0
        v2 = weights2[i] if i < len(weights2) else 0
        diff = v1 - v2
        
        bar1 = "█" * int(v1 * 10)
        bar2 = "█" * int(v2 * 10)
        
        diff_str = f"{diff:+.2f}"
        diff_indicator = "▲" if diff > 0 else "▼" if diff < 0 else "="
        
        print(f"  {label:<10} | {v1:.2f} {bar1:<4} | {v2:.2f} {bar2:<4} | {diff_indicator} {abs(diff):.2f}")


def demo_all_types_overview():
    """演示所有16种MBTI类型概览"""
    print_separator("16种MBTI类型概览")
    
    print("\n类型列表:")
    print(f"  {'类型':<6} {'名称':<10} {'核心特征'}")
    print(f"  {'─'*6} {'─'*10} {'─'*30}")
    
    traits_preview = {
        'ISTJ': '务实可靠', 'ISFJ': '忠诚体贴', 'INFJ': '理想洞察', 'INTJ': '战略理性',
        'ISTP': '灵活分析', 'ISFP': '艺术温和', 'INFP': '理想创意', 'INTP': '逻辑好奇',
        'ESTP': '活力行动', 'ESFP': '热情表达', 'ENFP': '激励创新', 'ENTP': '机智辩论',
        'ESTJ': '务实执行', 'ESFJ': '友善合作', 'ENFJ': '魅力领导', 'ENTJ': '果断指挥',
    }
    
    for mbti_type in sorted(MBTI_NAMES.keys()):
        name = MBTI_NAMES[mbti_type]
        trait = traits_preview.get(mbti_type, '')
        print(f"  {mbti_type:<6} {name:<10} {trait}")


def demo_desire_weights_radar():
    """演示6维欲望权重"""
    print_separator("6维欲望权重雷达图")
    
    desire_labels = ['生存欲', '求知欲', '表达欲', '表现欲', '舒适欲', '情欲']
    desire_keys = ['survival', 'knowledge', 'expression', 'performance', 'comfort', 'sexual']
    
    # 选择四种典型类型进行对比
    types_to_show = ['INTJ', 'ENFP', 'ESTJ', 'ISFP']
    
    for mbti_type in types_to_show:
        profile = MBTIProfile(mbti_type=mbti_type)
        weights = [profile.desire_weights.get(k, 0) for k in desire_keys]
        
        print(f"\n【{mbti_type} - {profile.name}】")
        
        # 绘制简化的雷达图
        print("  欲望权重分布 (垂直条形表示):")
        max_width = 30
        for i, (label, val) in enumerate(zip(desire_labels, weights)):
            bar_len = int(val * max_width)
            bar = "█" * bar_len + "░" * (max_width - bar_len)
            print(f"    {label:<6}: [{bar}] {val:.2f}")
        
        # 找出最高和最低
        max_idx = weights.index(max(weights))
        min_idx = weights.index(min(weights))
        print(f"    最高: {desire_labels[max_idx]} ({weights[max_idx]:.2f})")
        print(f"    最低: {desire_labels[min_idx]} ({weights[min_idx]:.2f})")


def demo_emotion_weights_radar():
    """演示7维情绪权重"""
    print_separator("7维情绪权重雷达图")
    
    emotion_labels = ['喜', '怒', '忧', '思', '悲', '恐', '惊']
    emotion_keys = ['joy', 'anger', 'worry', 'thinking', 'sadness', 'fear', 'surprise']
    
    types_to_show = ['INTJ', 'ENFP', 'ESFJ', 'ISTP']
    
    for mbti_type in types_to_show:
        profile = MBTIProfile(mbti_type=mbti_type)
        weights = [profile.emotion_weights.get(k, 0) for k in emotion_keys]
        
        print(f"\n【{mbti_type} - {profile.name}】")
        
        # 绘制简化的雷达图
        print("  情绪权重分布:")
        max_width = 25
        for i, (label, val) in enumerate(zip(emotion_labels, weights)):
            bar_len = int(val * max_width)
            bar = "█" * bar_len + "░" * (max_width - bar_len)
            print(f"    {label:<3}: [{bar}] {val:.2f}")
        
        # 情绪特征分析
        max_idx = weights.index(max(weights))
        min_idx = weights.index(min(weights))
        print(f"    最强: {emotion_labels[max_idx]} ({weights[max_idx]:.2f})")
        print(f"    最弱: {emotion_labels[min_idx]} ({weights[min_idx]:.2f})")


def demo_type_comparison():
    """演示两个类型的详细对比"""
    print_separator("INTJ vs ENFP 详细对比")
    
    type1, type2 = 'INTJ', 'ENFP'
    profile1 = MBTIProfile(mbti_type=type1)
    profile2 = MBTIProfile(mbti_type=type2)
    
    print(f"\n{type1} ({profile1.name}) vs {type2} ({profile2.name})")
    print(f"\n性格特征:")
    print(f"  {type1}: {', '.join(profile1.traits)}")
    print(f"  {type2}: {', '.join(profile2.traits)}")
    
    # 欲望权重对比
    desire_labels = ['生存欲', '求知欲', '表达欲', '表现欲', '舒适欲', '情欲']
    desire_keys = ['survival', 'knowledge', 'expression', 'performance', 'comfort', 'sexual']
    
    weights1 = [profile1.desire_weights.get(k, 0) for k in desire_keys]
    weights2 = [profile2.desire_weights.get(k, 0) for k in desire_keys]
    
    draw_comparison_bar(type1, type2, weights1, weights2, desire_labels, "欲望权重")
    
    # 情绪权重对比
    emotion_labels = ['喜', '怒', '忧', '思', '悲', '恐', '惊']
    emotion_keys = ['joy', 'anger', 'worry', 'thinking', 'sadness', 'fear', 'surprise']
    
    weights1 = [profile1.emotion_weights.get(k, 0) for k in emotion_keys]
    weights2 = [profile2.emotion_weights.get(k, 0) for k in emotion_keys]
    
    draw_comparison_bar(type1, type2, weights1, weights2, emotion_labels, "情绪权重")
    
    # 行为倾向对比
    print(f"\n  行为倾向对比:")
    print(f"  {type1}:")
    for i, bt in enumerate(profile1.behavior_tendency[:3], 1):
        print(f"    {i}. {bt}")
    print(f"  {type2}:")
    for i, bt in enumerate(profile2.behavior_tendency[:3], 1):
        print(f"    {i}. {bt}")


def demo_full_profile():
    """演示完整档案"""
    print_separator("完整MBTI档案示例: INFP")
    
    profile = MBTIProfile(mbti_type='INFP')
    
    print(f"\n【{profile.mbti_type} - {profile.name}】")
    print(f"\n短字母解析: {profile.letter_short}")
    print(f"长字母解析: {profile.letter_long}")
    
    print(f"\n性格特点: {', '.join(profile.traits)}")
    
    print(f"\n行为倾向:")
    for i, bt in enumerate(profile.behavior_tendency, 1):
        print(f"  {i}. {bt}")
    
    print(f"\n欲望权重:")
    for key, val in profile.desire_weights.items():
        bar_len = int(val * 20)
        bar = "█" * bar_len + "░" * (20 - bar_len)
        print(f"  {key:<12}: [{bar}] {val:.2f}")
    
    print(f"\n情绪权重:")
    for key, val in profile.emotion_weights.items():
        bar_len = int(val * 20)
        bar = "█" * bar_len + "░" * (20 - bar_len)
        print(f"  {key:<10}: [{bar}] {val:.2f}")


def main():
    """主函数"""
    print("=" * 70)
    print("       MBTI 权重系统演示 - 16种性格类型完整分析")
    print("=" * 70)
    
    # 1. 所有类型概览
    demo_all_types_overview()
    
    # 2. 欲望权重演示
    demo_desire_weights_radar()
    
    # 3. 情绪权重演示
    demo_emotion_weights_radar()
    
    # 4. 类型对比演示
    demo_type_comparison()
    
    # 5. 完整档案示例
    demo_full_profile()
    
    print_separator("演示完成")
    print("\n系统说明:")
    print("  - 6维欲望: 生存欲/求知欲/表达欲/表现欲/舒适欲/情欲")
    print("  - 7维情绪: 喜/怒/忧/思/悲/恐/惊")
    print("  - 权重范围: 0.0-1.0")
    print("  - 数值越高表示该类型越容易受该因素影响")


if __name__ == "__main__":
    main()
