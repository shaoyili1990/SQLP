#!/usr/bin/env python3
"""
demo_motivation_chain.py - 逻辑动机链演示
Demo: generate motivation chains for 7 instinct types, show 4-layer depth

Demonstrates:
- All 7 instinct drives
- 4-layer motivation chain (surface/deep/core/soul)
- Decision framework profiles
- Scene-based motivation generation
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tiandao.motivation import (
    Instinct, INSTINCT_NAMES, INSTINCT_DESCRIPTIONS,
    INSTINCT_NAMES_EN,
    DecisionFramework, FRAMEWORK_NAMES,
    generate_motivation_chain, get_decision_framework
)


def print_separator(title=""):
    """打印分隔线"""
    width = 70
    if title:
        print(f"\n{'='*width}")
        print(f" {title}")
        print(f"{'='*width}")
    else:
        print("-" * width)


INSTINCT_SHORT_NAMES = {
    Instinct.SURVIVAL: "求存",
    Instinct.KNOWLEDGE: "求知",
    Instinct.EXPRESSION: "表现",
    Instinct.COMFORT: "舒适",
    Instinct.DESIRE: "情欲",
    Instinct.CREATIVE: "创造",
    Instinct.MATERNAL: "母性",
}


def draw_motivation_chain(chain, depth=4):
    """绘制动机链可视化"""
    instinct_name = INSTINCT_SHORT_NAMES.get(chain.instinct, str(chain.instinct))
    
    print(f"\n  本能类型: {instinct_name}")
    print(f"  动机强度: {chain.intensity:.1f}%")
    print(f"  确定程度: {chain.confidence:.0%}")
    
    print(f"\n  +---------------------------------------------+")
    print(f"  |              4层动机链结构                    |")
    print(f"  +---------------------------------------------+")
    print(f"  | [1] 表层动机: {chain.surface:<28} |")
    print(f"  |     v                                     |")
    print(f"  | [2] 深层动机: {chain.deep:<28} |")
    print(f"  |     v                                     |")
    print(f"  | [3] 核心动机: {chain.core:<27} |")
    print(f"  |     v                                     |")
    print(f"  | [4] 灵魂动机: {chain.soul:<27} |")
    print(f"  +---------------------------------------------+")


def demo_all_instincts():
    """演示所有7种本能驱动"""
    print_separator("7种本能驱动类型")
    
    print("\n本能类型列表:")
    print(f"  {'编号':<4} {'简称':<8} {'全称':<12} {'描述'}")
    print(f"  {'-'*4} {'-'*8} {'-'*12} {'-'*40}")
    
    for instinct in Instinct:
        short_name = INSTINCT_SHORT_NAMES.get(instinct, "?")
        name = instinct.name
        desc = INSTINCT_DESCRIPTIONS.get(instinct, "")[:40]
        print(f"  {instinct.value:<4} {short_name:<8} {name:<12} {desc}")
    
    print("\n本能优先级 (强度从高到低):")
    priorities = [
        ("求存本能", "最强", "生存安全是根本需求"),
        ("情欲本能", "很强", "情感亲密和繁殖本能"),
        ("舒适本能", "强", "追求愉悦避免痛苦"),
        ("表现本能", "中等", "展示自我获得认可"),
        ("求知本能", "中等", "好奇心和探索欲"),
        ("母性本能", "弱", "保护养育后代"),
        ("表达本能", "弱", "创造和艺术表达"),
    ]
    
    for name, level, desc in priorities:
        print(f"  {name}: {level} - {desc}")


def demo_motivation_chain_full(instinct, scene, role):
    """演示单个本能的动机链生成"""
    chain = generate_motivation_chain(instinct, scene, role)
    draw_motivation_chain(chain)
    
    # 解释每一层的含义
    print("\n  【层次解读】")
    print(f"    表层: 直接可见的行动目标")
    print(f"    深层: 内心真正的心理诉求")
    print(f"    核心: 根植于价值观的行动准则")
    print(f"    灵魂: 超越性的终极人生意义")


def demo_all_chains():
    """演示所有本能类型的动机链"""
    print_separator("7种本能 x 场景演示")
    
    scene = "面临重大人生抉择的关键时刻"
    role = "一个内心复杂的现代人"
    
    print(f"\n场景: {scene}")
    print(f"角色: {role}")
    
    instincts_to_demo = [
        (Instinct.SURVIVAL, "求存本能"),
        (Instinct.KNOWLEDGE, "求知本能"),
        (Instinct.EXPRESSION, "表现本能"),
        (Instinct.COMFORT, "舒适本能"),
        (Instinct.DESIRE, "情欲本能"),
        (Instinct.CREATIVE, "表达本能"),
        (Instinct.MATERNAL, "母性本能"),
    ]
    
    for instinct, name in instincts_to_demo:
        print(f"\n{'-'*60}")
        print(f"【{name}】")
        demo_motivation_chain_full(instinct, scene, role)


def demo_decision_framework():
    """演示决策框架"""
    print_separator("决策框架系统")
    
    print("\n7种决策框架:")
    print(f"  {'编号':<4} {'框架':<10} {'描述'}")
    print(f"  {'-'*4} {'-'*10} {'-'*40}")
    
    for framework in DecisionFramework:
        name = FRAMEWORK_NAMES.get(framework, "?")
        print(f"  {framework.value:<4} {name:<10} ...")
    
    print("\n\n角色类型->决策框架映射示例:")
    
    roles_to_test = [
        ("企业家", "利益优先"),
        ("艺术家", "情感优先"),
        ("科学家", "逻辑优先"),
        ("外交官", "社交优先"),
        ("保守者", "安全优先"),
        ("创业者", "成长优先"),
        ("政治家", "使命优先"),
    ]
    
    for role, expected in roles_to_test:
        profile = get_decision_framework(role)
        primary = FRAMEWORK_NAMES.get(profile.primary, "?")
        secondary = FRAMEWORK_NAMES.get(profile.secondary, "?")
        print(f"\n  【{role}】")
        print(f"    主要框架: {primary}")
        print(f"    次要框架: {secondary}")
        print(f"    灵活度: {profile.flexibility:.0%}")
        print(f"    权重: 利益={profile.weights.get(DecisionFramework.PROFIT, 0):.1f}, "
              f"情感={profile.weights.get(DecisionFramework.EMOTION, 0):.1f}, "
              f"逻辑={profile.weights.get(DecisionFramework.LOGIC, 0):.1f}")


def demo_scene_variations():
    """演示场景变化对动机链的影响"""
    print_separator("场景变化对动机链的影响")
    
    instinct = Instinct.KNOWLEDGE
    role = "一个执着的研究者"
    
    scenes = [
        ("日常研究工作", "平静的研究日常"),
        ("关键实验时刻", "实验即将出结果的关键时刻"),
        ("遇到重大难题", "研究遇到瓶颈,久攻不下"),
        ("紧急发表论文", "deadline临近,必须尽快发表"),
    ]
    
    for scene_name, scene_desc in scenes:
        print(f"\n{'-'*60}")
        print(f"场景: {scene_name}")
        print(f"描述: {scene_desc}")
        
        chain = generate_motivation_chain(instinct, scene_desc, role)
        print(f"\n  动机强度: {chain.intensity:.1f}%")
        print(f"  表层: {chain.surface}")
        print(f"  深层: {chain.deep}")
        print(f"  核心: {chain.core}")
        print(f"  灵魂: {chain.soul}")


def demo_depth_visualization():
    """演示4层深度的完整可视化"""
    print_separator("4层动机链深度演示")
    
    print("""
动机链的4个层次:

  层次        定义                示例(求知本能)
  --------------------------------------------------------------------------------
  [表层]      即时行动目标        "收集实验数据"
  v           直接可观察
  [深层]      内心真实诉求        "满足好奇心"
  v           不易被察觉
  [核心]      价值观体现          "知行合一"
  v           根植于人格
  [灵魂]      终极人生意义        "追求终极真理"

  说明:
  - 表层动机是最外层的可观察行为
  - 深层动机是内在的心理驱动
  - 核心动机反映核心价值观
  - 灵魂动机是超越性的生命意义
    """)
    
    # 实际演示
    instinct = Instinct.MATERNAL
    scene = "看到弱势群体需要帮助"
    role = "一个有社会责任感的公民"
    
    print(f"\n实际案例演示:")
    print(f"  场景: {scene}")
    print(f"  角色: {role}")
    
    chain = generate_motivation_chain(instinct, scene, role)
    
    print(f"""
  +------------------------------------------------+
  | [表层] {chain.surface:<40}|
  |   v    直接行动                                  |
  | [深层] {chain.deep:<40}|
  |   v    内心驱动                                  |
  | [核心] {chain.core:<40}|
  |   v    价值观导向                                |
  | [灵魂] {chain.soul:<40}|
  +------------------------------------------------+
    """)


def main():
    """主函数"""
    print("=" * 70)
    print("       逻辑动机链系统演示 - 7本能 x 4层次")
    print("=" * 70)
    
    # 1. 本能类型介绍
    demo_all_instincts()
    
    # 2. 单个本能的动机链演示
    print_separator("单一本能动机链演示")
    demo_motivation_chain_full(
        Instinct.SURVIVAL,
        "面对生存危机的抉择",
        "一个面临失业的职场人"
    )
    
    # 3. 所有本能的动机链
    demo_all_chains()
    
    # 4. 决策框架
    demo_decision_framework()
    
    # 5. 场景变化影响
    demo_scene_variations()
    
    # 6. 4层深度可视化
    demo_depth_visualization()
    
    print_separator("演示完成")
    print("\n系统说明:")
    print("  - 7种本能: 求存/求知/表现/舒适/情欲/表达/母性")
    print("  - 4层动机: 表层->深层->核心->灵魂")
    print("  - 7种决策框架: 利益/情感/逻辑/社交/安全/成长/使命")
    print("  - 场景和角色影响动机链的具体表达")


if __name__ == "__main__":
    main()
