#!/usr/bin/env python3
"""
demo_memory_system.py - 记忆系统演示
Demo: add 25 memories (mix of normal/abnormal), show rotation, show abnormal overload penalty

Demonstrates:
- Adding 25 memories (normal and abnormal mix)
- Memory rotation mechanism
- Abnormal memory overflow penalty (PTSD)
- Memory search and retrieval
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tiandao.memory import (
    MemorySystem, MemoryEntry, MemoryType
)


def print_separator(title=""):
    """打印分隔线"""
    width = 70
    if title:
        print(f"\n{'='*width}")
        print(f" {title}")
        print(f"{'='*width}")
    else:
        print("-" * width)


def create_sample_memories():
    """创建示例记忆数据"""
    memories = [
        # 常态记忆 (15个)
        ("日常工作", "work", "完成日常工作任务", 0.7, 0.2),
        ("团队会议", "social", "参加部门周会讨论项目进展", 0.6, 0.1),
        ("午餐时光", "life", "和同事一起吃午饭", 0.5, 0.3),
        ("学习新技术", "study", "学习Python高级特性", 0.8, 0.1),
        ("完成报告", "work", "提交季度工作总结报告", 0.7, 0.2),
        ("健身锻炼", "health", "健身房跑步30分钟", 0.6, 0.2),
        ("阅读书籍", "study", "阅读《设计模式》章节", 0.7, 0.1),
        ("家庭聚会", "family", "周末和家人聚餐", 0.8, 0.3),
        ("购物", "life", "超市购买生活用品", 0.4, 0.1),
        ("看电影", "entertainment", "周末观看科幻电影", 0.5, 0.2),
        ("朋友聊天", "social", "和老朋友电话聊天", 0.6, 0.2),
        ("项目讨论", "work", "与客户沟通需求细节", 0.7, 0.1),
        ("收到邮件", "work", "处理工作邮件40封", 0.5, 0.0),
        ("睡眠", "health", "正常睡眠7小时", 0.6, 0.1),
        ("晨跑", "health", "清晨公园慢跑", 0.6, 0.2),
        
        # 异常记忆 (10个)
        ("工作失误", "trauma", "重要会议迟到导致延误", 0.9, -0.6),
        ("被批评", "trauma", "方案被上级严厉批评", 0.8, -0.7),
        ("项目失败", "trauma", "关键项目未能按时交付", 0.9, -0.8),
        ("意外事故", "danger", "路上一辆车差点撞到我", 0.7, -0.5),
        ("争吵", "conflict", "与同事发生激烈争执", 0.8, -0.6),
        ("健康警报", "health", "体检发现需要复查的指标", 0.8, -0.7),
        ("失去机会", "regret", "错过重要的晋升机会", 0.9, -0.8),
        ("背叛", "trauma", "发现信任的朋友背后说坏话", 0.9, -0.9),
        ("失败演讲", "embarrass", "在公司大会演讲时忘词", 0.8, -0.6),
        ("财务损失", "trauma", "投资失败损失一个月的工资", 0.9, -0.8),
    ]
    
    return memories


def print_memory_stats(ms: MemorySystem):
    """打印记忆统计"""
    stats = ms.get_memory_stats()
    
    print(f"\n  记忆统计:")
    print(f"    总记忆数: {stats['total_memories_count']}")
    print(f"    常态记忆: {stats['normal_memories_count']}")
    print(f"    异常记忆: {stats['abnormal_memories_count']} (上限: {ms.ABNORMAL_MAX})")
    
    if stats['abnormal_overflow'] > 0:
        print(f"    ⚠️ 异常记忆溢出: {stats['abnormal_overflow']}条")
        print(f"    ⚠️ PTSD惩罚次数: {stats['stats']['ptsd_penalties_applied']}")
    
    print(f"    长期记忆: {stats['long_term_memories_count']} (上限: {ms.LONG_TERM_MAX})")
    print(f"    短期记忆: {stats['short_term_memories_count']} (上限: {ms.SHORT_TERM_MAX})")
    print(f"    基础Y值: {stats['y_base']:.2f}")
    print(f"    Y值偏移: {stats['base_y_offset']:+.2f}")
    print(f"    PTSD触发率: {stats['ptsd_trigger_rate']:.2%}")


def main():
    """主函数"""
    print("=" * 70)
    print("       记忆系统演示 - 25个记忆的添加与轮转")
    print("=" * 70)
    
    # 1. 创建记忆系统
    print_separator("Step 1: 创建记忆系统")
    ms = MemorySystem(y_base=50.0)
    print(f"  初始基础Y值: {ms.y_base}")
    print(f"  异常记忆上限: {ms.ABNORMAL_MAX}")
    print(f"  长期记忆上限: {ms.LONG_TERM_MAX}")
    print(f"  短期记忆上限: {ms.SHORT_TERM_MAX}")
    
    # 2. 创建记忆数据
    print_separator("Step 2: 准备25个记忆")
    memories = create_sample_memories()
    
    print(f"\n  常态记忆 ({len([m for m in memories[:15]])}个):")
    for i, (name, tag, content, weight, emotion) in enumerate(memories[:15], 1):
        emotion_str = "正面" if emotion > 0 else "负面" if emotion < 0 else "中性"
        print(f"    {i}. {name} [{tag}] - 权重:{weight:.1f} 情感:{emotion_str}")
    
    print(f"\n  异常记忆 ({len(memories[15:])}个):")
    for i, (name, tag, content, weight, emotion) in enumerate(memories[15:], 1):
        print(f"    {i}. {name} [{tag}] - 权重:{weight:.1f} 情感:负面({emotion:.1f})")
    
    # 3. 添加常态记忆
    print_separator("Step 3: 添加常态记忆 (前15个)")
    
    for i, (name, tag, content, weight, emotion) in enumerate(memories[:15], 1):
        entry = MemoryEntry(name=name, tag=tag, content=content, weight=weight, emotion=emotion)
        ms.add(entry, MemoryType.NORMAL)
        
        if i <= 5 or i == 15:
            print(f"  添加: {name} [类型:常态]")
        elif i == 6:
            print("  ... (继续添加)")
    
    print_memory_stats(ms)
    
    # 4. 添加异常记忆
    print_separator("Step 4: 添加异常记忆 (后10个) - 触发溢出惩罚")
    
    for i, (name, tag, content, weight, emotion) in enumerate(memories[15:], 1):
        entry = MemoryEntry(name=name, tag=tag, content=content, weight=weight, emotion=emotion)
        ms.add(entry, MemoryType.ABNORMAL)
        
        print(f"\n  添加异常记忆 #{i}: {name}")
        
        # 显示是否触发惩罚
        if len(ms.abnormal_memories) > ms.ABNORMAL_MAX:
            overflow = len(ms.abnormal_memories) - ms.ABNORMAL_MAX
            print(f"    ⚠️ 触发溢出惩罚! 溢出: {overflow}条")
            print(f"    ⚠️ Y值永久提升: +{ms.base_y_offset:.2f}")
            print(f"    ⚠️ PTSD触发率: {ms.ptsd_trigger_rate:.2%}")
    
    print(f"\n  异常记忆添加完成!")
    print(f"  异常记忆总数: {len(ms.abnormal_memories)}/{ms.ABNORMAL_MAX}")
    print(f"  累计惩罚次数: {ms.stats['ptsd_penalties_applied']}")
    
    # 5. 添加到短期记忆触发轮转
    print_separator("Step 5: 短期记忆轮转演示")
    
    print("\n  添加超过上限的短期记忆:")
    for i in range(1, 15):
        name = f"短期记忆项{i}"
        entry = MemoryEntry(name=name, tag="temp", content=f"临时记忆{i}", weight=0.5, emotion=0.0)
        result = ms.add(entry, MemoryType.SHORT_TERM)
        
        if i <= 5:
            print(f"    添加 #{i}: {name}")
            print(f"      短期记忆数: {len(ms.short_term_memories)}/{ms.SHORT_TERM_MAX}")
            if i >= 3:
                print(f"      ⚡ 触发轮转! 移除最旧记忆")
        elif i == 6:
            print("  ... (继续轮转)")
    
    print(f"\n  最终短期记忆数: {len(ms.short_term_memories)}")
    print(f"  轮转次数: {ms.stats['rotation_count']}")
    
    # 6. 记忆检索演示
    print_separator("Step 6: 记忆检索演示")
    
    # 按标签检索
    trauma_memories = ms.search(tag="trauma")
    print(f"\n  标签检索 [trauma]: 找到 {len(trauma_memories)} 条")
    for m in trauma_memories:
        print(f"    - {m.name} (权重:{m.weight:.1f}, 情感:{m.emotion:.1f})")
    
    # 关键词检索
    work_memories = ms.search(keyword="工作")
    print(f"\n  关键词检索 [工作]: 找到 {len(work_memories)} 条")
    for m in work_memories:
        print(f"    - {m.name}")
    
    # 7. 记忆强化演示
    print_separator("Step 7: 记忆强化演示")
    
    print("\n  强化标签 [work] 的记忆 (权重+0.1):")
    before_weights = [(m.name, m.weight) for m in ms.search(tag="work")]
    reinforced = ms.reinforce(tag="work", weight_boost=0.1)
    after_weights = [(m.name, m.weight) for m in ms.search(tag="work")]
    
    print(f"  强化了 {reinforced} 条记忆:")
    for (name, w1), (_, w2) in zip(before_weights, after_weights):
        print(f"    {name}: {w1:.2f} → {w2:.2f} ({w2-w1:+.2f})")
    
    # 8. 遗忘演示
    print_separator("Step 8: 遗忘机制演示")
    
    print(f"\n  应用遗忘机制 (衰减率:0.05, 最小权重:0.1):")
    before_count = len(ms.total_memories)
    forgotten = ms.forget(decay_rate=0.05, min_weight=0.1)
    after_count = len(ms.total_memories)
    
    print(f"  被遗忘的记忆: {forgotten} 条")
    print(f"  遗忘前总数: {before_count}, 遗忘后: {after_count}")
    
    # 9. 最终统计
    print_separator("Step 9: 最终记忆统计")
    print_memory_stats(ms)
    
    # 10. 异常记忆影响总结
    print_separator("异常记忆溢出影响分析")
    
    print("\n  【机制说明】")
    print("  - 异常记忆上限: 15条")
    print("  - 超限时自动触发PTSD惩罚:")
    print("    1. 基础Y值永久提升 (心理更加敏感)")
    print("    2. PTSD触发率增加 (更容易触发创伤反应)")
    print("    3. 惩罚值: 5~15 (随溢出量增加)")
    
    print("\n  【本次演示结果】")
    print(f"  - 异常记忆添加: 10条")
    print(f"  - 溢出量: {len(ms.abnormal_memories) - ms.ABNORMAL_MAX}条")
    print(f"  - Y值偏移: {ms.base_y_offset:.2f}")
    print(f"  - PTSD触发率: {ms.ptsd_trigger_rate:.2%}")
    
    print("\n  【长期影响】")
    print("  异常记忆过多会导致:")
    print("  1. 基础心理状态变得更加敏感脆弱")
    print("  2. PTSD触发概率显著提高")
    print("  3. 面对类似场景时更容易情绪波动")
    print("  4. 需要更多正向事件来平衡心理状态")
    
    print_separator("演示完成")
    print("\n  系统特性总结:")
    print("  ✓ 5种记忆类型分工明确")
    print("  ✓ 异常记忆超限自动惩罚")
    print("  ✓ 短期记忆自动轮转")
    print("  ✓ 支持搜索、强化、遗忘机制")
    print("  ✓ 可序列化存储")


if __name__ == "__main__":
    main()
