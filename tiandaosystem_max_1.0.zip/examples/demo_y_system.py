#!/usr/bin/env python3
"""
demo_y_system.py - Y值系统演示
Demo: create character with INTJ, run 10 Y-value transitions, show state changes and mechanism effects

Demonstrates the Y-Psychology Engine with:
- INTJ character profile integration
- 10 consecutive scene transitions
- State change tracking
- Trigger threshold mechanism
- Compensation and rebound effects
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tiandao.psychology import YPsychologyEngine, YState, STATE_NAMES_CN
from tiandao.mbti import MBTIProfile, get_mbti_weights


def print_separator(title=""):
    """打印分隔线"""
    width = 70
    if title:
        print(f"\n{'='*width}")
        print(f" {title}")
        print(f"{'='*width}")
    else:
        print("-" * width)


def main():
    print_separator("Y值心理引擎演示 - INTJ角色")
    
    # 1. 创建INTJ角色
    print("\n[Step 1] 创建INTJ角色档案")
    mbti_profile = MBTIProfile(mbti_type="INTJ")
    print(f"  MBTI类型: {mbti_profile.mbti_type} - {mbti_profile.name}")
    print(f"  性格特点: {', '.join(mbti_profile.traits)}")
    print(f"  决策倾向: {mbti_profile.behavior_tendency[0]}")
    
    # 根据INTJ特性调整基础Y值
    # INTJ通常较为冷静理性,基础Y值设为60
    base_y = 60.0
    
    # 2. 创建心理引擎
    print_separator("初始化心理引擎")
    engine = YPsychologyEngine(base_y=base_y)
    print(f"  基础Y值: {engine.base_y}")
    print(f"  初始状态: {STATE_NAMES_CN[engine.get_state()]}")
    print(f"  触发阈值: {engine.calculate_trigger_threshold()}")
    print(f"  初始状态条: {engine.format_state_bar()}")
    
    # 3. 定义10个场景事件
    scenes = [
        ("场景1: 日常清晨", 0, None),
        ("场景2: 工作任务布置", +5, None),
        ("场景3: 遭遇技术难题", -15, None),
        ("场景4: 深夜独自研究", 0, None),
        ("场景5: 取得突破进展", +20, None),
        ("场景6: 正向补偿效果", 0, +8),
        ("场景7: 外部干扰出现", -12, None),
        ("场景8: 团队协作分歧", -8, None),
        ("场景9: 情绪低谷期", -18, None),
        ("场景10: 最终决策时刻", 0, None),
    ]
    
    print_separator("10个Y值过渡场景演示")
    
    # 4. 运行10个场景
    for i, (scene_name, event_delta, compensation) in enumerate(scenes, 1):
        print(f"\n{'─'*60}")
        print(f"【{scene_name}】")
        
        # 应用补偿(如果有)
        if compensation is not None:
            engine.apply_compensation(compensation, duration=2)
            print(f"  [补偿效果] 获得 +{compensation} Y值补偿")
        
        # 记录事件前的Y值
        y_before = engine.profile.current_y
        
        # 更新Y值
        new_y = engine.update(event_delta=event_delta, scene_num=i)
        
        # 显示变化
        print(f"  事件影响: ΔY = {event_delta:+}")
        print(f"  Y值变化: {y_before:.1f} → {new_y:.1f} ({new_y - y_before:+.1f})")
        
        # 显示当前状态
        current_state = engine.get_state()
        print(f"  当前状态: {STATE_NAMES_CN[current_state]}")
        print(f"  触发阈值: {engine.calculate_trigger_threshold()}")
        print(f"  击穿判定: {'⚠️ 触发' if engine.profile.breakdown_triggered else '正常'}")
        print(f"  补偿状态: {engine.profile.compensation_value:+.1f} (剩余{engine.profile.compensation_remaining}场景)")
        print(f"  状态条: {engine.format_state_bar()}")
        
        # 显示行为倾向
        if i in [3, 9, 10]:  # 关键时刻显示详细行为倾向
            behaviors = engine.get_behavior_tendency()
            print(f"  行为倾向: {', '.join(behaviors[:3])}")
    
    # 5. 总结分析
    print_separator("状态变化总结")
    
    print("\n[INTJ角色心理波动分析]")
    print(f"  初始Y值: {base_y}")
    print(f"  最终Y值: {engine.profile.current_y:.1f}")
    print(f"  最大波动: {max(abs(engine.profile.delta_y)) if engine.profile.delta_y else 0:.1f}")
    
    # 计算各状态停留时间
    state_counts = {}
    for _, state in engine._state_history:
        state_counts[state] = state_counts.get(state, 0) + 1
    
    print("\n[状态分布统计]")
    for state, count in sorted(state_counts.items()):
        pct = count / len(engine._state_history) * 100
        bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
        print(f"  {STATE_NAMES_CN[state]:<6}: {bar} {count}次 ({pct:.0f}%)")
    
    # 机制效果分析
    print("\n[机制效果分析]")
    print("  - 触发机制: Y值越低触发阈值越高(更易波动)")
    print("  - 补偿机制: 事件补偿可暂时提升Y值")
    print("  - 回弹机制: Y值逐渐向基础值(base_y)回归")
    rebound_rate = 0.85
    print(f"  - 回弹公式: y = base_y + (y - base_y) × {rebound_rate}")
    
    # INTJ特定分析
    print("\n[INTJ心理特征]")
    print("  - 高求知欲: 面对难题时有强烈探索动机")
    print("  - 独立理性: 不易受外部情绪影响")
    print("  - 战略思维: 即使低谷也能保持一定理性")
    print("  - 预期行为: 压力下倾向于内省和独立解决")


if __name__ == "__main__":
    main()
