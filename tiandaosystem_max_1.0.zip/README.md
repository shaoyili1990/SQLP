# Tiandao System / 天道系统

Character Psychology & Motivation Analysis Framework
角色心理与动机分析框架

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

---

## 简介 / Introduction

Tiandao System 是一个综合性的角色心理与动机分析框架，整合了 MBTI 性格分析、Y 值情绪调节系统、记忆系统和动机链分析。

Tiandao System is a comprehensive framework for character psychology and motivation analysis, integrating MBTI personality analysis, Y-value emotional regulation system, memory system, and motivation chain analysis.

## 功能特性 / Features

- **PsychologyProfile (心理画像)** - Y-value based emotional regulation analysis
- **MBTIProfile (MBTI性格)** - 16 personality types with detailed descriptions
- **MemorySystem (记忆系统)** - Character experience and memory storage
- **MotivationChain (动机链)** - Hierarchical motivation analysis
- **CharacterProfile (角色画像)** - Unified profile combining all subsystems

## 安装 / Installation

### From Source (从源码安装)

```bash
# Clone the repository
git clone https://github.com/tiandao/tiandao-system.git
cd tiandao-system

# Install in development mode
pip install -e .
```

### Using pip

```bash
pip install tiandao-system
```

## 快速开始 / Quick Start

### CLI 使用 / CLI Usage

```bash
# Run demonstration
tiandao run-demo

# Y-value calculations
tiandao y-value calculate 0.75
tiandao y-value rebound 0.3 0.8
tiandao y-value compensate 0.5 0.2

# MBTI operations
tiandao mbti show INFP
tiandao mbti compare ENFP ISTJ

# Memory operations
tiandao memory add "Important event" --personality ENFP --tags event growth
tiandao memory list --personality ENFP
tiandao memory search "event"

# Motivation chain
tiandao motivation --add "Self-actualization" 0.9
tiandao motivation --show

# Author validation
tiandao author validate my_author_name
```

### Python API 使用 / Python API Usage

```python
from tiandao import CharacterProfile, create_profile, load_profile

# Create a new character profile
profile = create_profile("Alice", mbti_type="ENFP", base_y=0.7)

# Access subsystems
profile.mbti.get_description()  # "Extroverted | Intuition | Feeling | Perceiving"
profile.psychology.update_y(0.85)
profile.memory.add_memory("First adventure", tags=["action"])
profile.motivation.add_link("Achievement", 0.9)

# Save and load
save_profile(profile, "alice.json")
loaded = load_profile("alice.json")
print(loaded.get_summary())
```

## 模块说明 / Module Descriptions

### tiandao.profile

Unified character profile combining all analysis subsystems.

```python
from tiandao.profile import CharacterProfile, create_profile

# Create profile
profile = create_profile("Character Name", "INTJ")

# Update profile
profile.update_profile(base_y=0.8)

# Save/Load
save_profile(profile, "profile.json")
profile = load_profile("profile.json")
```

### tiandao.cli

Command-line interface for all system features.

```bash
# All available commands
tiandao --help
```

## 项目结构 / Project Structure

```
tiandao-system/
├── tiandao/
│   ├── __init__.py       # Package initialization
│   ├── cli.py            # CLI entry point
│   └── profile.py        # Character profile module
├── pyproject.toml        # Package configuration
├── README.md             # This file
└── LICENSE               # MIT License
```

## 开发 / Development

```bash
# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run with coverage
pytest --cov=tiandao
```

## 贡献 / Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

欢迎贡献！请随时提交 Pull Request。

## 许可证 / License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

本项目基于 MIT 许可证授权 - 详见 [LICENSE](LICENSE) 文件。

## 联系方式 / Contact

- GitHub Issues: https://github.com/tiandao/tiandao-system/issues
- Email: tiandao@example.com

---

**天道循环，万物归一。**
*The Dao cycles, all things return to unity.*
