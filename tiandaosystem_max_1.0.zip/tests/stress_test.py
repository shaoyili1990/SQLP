#!/usr/bin/env python3
"""天道系统MAX 1.0 - 压力测试套件"""
import sys, time, random, gc, os, tempfile, inspect
sys.path.insert(0, '/tmp/projects/tiandaosystem_max_1.0')

from tiandao.psychology import (
    YPsychologyEngine, y_to_state, calculate_rebound, calculate_trigger,
    BEHAVIOR_TENDENCIES, YState
)
from tiandao.mbti import (
    get_mbti_weights, get_behavior_tendency, get_profile,
    DESIRE_WEIGHTS_16, EMOTION_WEIGHTS_16
)
from tiandao.memory import MemorySystem, MemoryEntry, MemoryType
from tiandao.motivation import (
    generate_motivation_chain, Instinct
)
from tiandao.author import (
    generate_group_portrait_scene, resolve_conflict,
    ConflictType, ConflictLevel
)
from tiandao.profile import create_profile, save_profile, load_profile, CharacterProfile

print("=" * 60)
print("天道系统MAX 1.0 - 压力测试")
print("=" * 60)

errors = []

# ===== Test 1: Y值系统极端边界 =====
print("\n[1] Y值系统极端边界测试 (10000次)...")
start = time.time()
for i in range(10000):
    y = random.choice([0, 1, 15, 16, 30, 31, 70, 85, 86, 99, 100, -5, 105, 200])
    try:
        state = y_to_state(y)
        engine = YPsychologyEngine(base_y=y)
        threshold = calculate_trigger(y)
        assert 0 <= state.value <= 4
        assert 5 <= threshold <= 10
    except Exception as e:
        errors.append(f"Y边界 [{i}] y={y}: {e}")
elapsed = time.time() - start
print(f"    10000次: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 2: MBTI 16类型 =====
print("\n[2] MBTI 16类型全量 (10000次)...")
start = time.time()
mbti_types = list(DESIRE_WEIGHTS_16.keys())
for _ in range(10000):
    mbti = random.choice(mbti_types)
    try:
        result = get_mbti_weights(mbti)
        desire = result.get('desire_weights', {})
        emotion = result.get('emotion_weights', {})
        assert all(isinstance(v, (int, float)) and 0 <= v <= 1.0 for v in desire.values())
        assert all(isinstance(v, (int, float)) and 0 <= v <= 1.0 for v in emotion.values())
        tendency = get_behavior_tendency(mbti)
        assert len(tendency) > 0
    except Exception as e:
        errors.append(f"MBTI {mbti}: {e}")
elapsed = time.time() - start
print(f"    10000次: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 3: 记忆系统 =====
print("\n[3] 记忆系统海量操作...")
start = time.time()
ms = MemorySystem()
for i in range(5000):
    mem_type = random.choice(list(MemoryType))
    entry = MemoryEntry(
        name=f"mem_{i}", tag=random.choice(["日常", "工作", "情感", "创伤", "紧急"]),
        content=f"记忆内容{i} " + "x" * 100,
        weight=random.uniform(0.1, 1.0),
        emotion=random.choice(["喜", "怒", "忧", "思", "悲", "恐", "惊"])
    )
    try:
        ms.add(entry, mem_type)
    except Exception as e:
        errors.append(f"记忆添加 [{i}]: {e}")
for _ in range(2000):
    try:
        results = ms.search(keyword=random.choice(["日常", "工作", "mem_"]), tag=None)
    except Exception as e:
        errors.append(f"记忆搜索: {e}")
elapsed = time.time() - start
print(f"    5000次添加+2000次搜索: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 4: 动机链 (签名: instinct, scene, role) =====
print("\n[4] 动机链生成 (5000次)...")
start = time.time()
instincts = list(Instinct)
scenarios = ["紧急", "日常", "危机", "机遇", "社交", "独处", "挑战"]
roles = ["工程师", "艺术家", "商人", "科学家", "教师", "医生", "律师", "作家"]
for i in range(5000):
    instinct = random.choice(instincts)
    scenario = random.choice(scenarios)
    role = random.choice(roles)
    try:
        chain = generate_motivation_chain(instinct, scenario, role)
        assert len(chain.surface) > 0
        assert len(chain.deep) > 0
        assert len(chain.core) > 0
        assert len(chain.soul) > 0
    except Exception as e:
        errors.append(f"动机链 [{i}] {instinct.value}: {e}")
elapsed = time.time() - start
print(f"    5000次: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 5: 冲突解析 (签名: resolve_conflict(conflict_dict)) =====
print("\n[5] 冲突解析 (5000次)...")
start = time.time()
for i in range(5000):
    ct = random.choice(list(ConflictType))
    cl = random.choice(list(ConflictLevel))
    conflict = {"type": ct, "level": cl, "parties": ["A", "B"], "description": "测试冲突"}
    try:
        result = resolve_conflict(conflict)
        assert isinstance(result, dict)
    except Exception as e:
        errors.append(f"冲突 [{i}]: {e}")
elapsed = time.time() - start
print(f"    5000次: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 6: 群像场景 (签名: generate_group_portrait_scene(characters_list)) =====
print("\n[6] 群像场景生成 (1000次)...")
start = time.time()
for i in range(1000):
    chars = []
    for j in range(random.randint(2, 6)):
        prof = get_profile(random.choice(mbti_types))
        chars.append({"name": f"角色{j+1}", "profile": prof, "current_y": random.randint(20, 90)})
    try:
        scene = generate_group_portrait_scene(chars)
        assert len(scene) > 0
    except Exception as e:
        errors.append(f"群像 [{i}]: {e}")
elapsed = time.time() - start
print(f"    1000次: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 7: 全角色档案 (API: create_profile, profile.to_dict/from_dict, save_profile/load_profile) =====
print("\n[7] 全角色档案集成 (1000次)...")
start = time.time()
for i in range(1000):
    mbti = random.choice(mbti_types)
    try:
        profile = create_profile(f"角色_{i}", mbti)
        # Serialize/deserialize via dict
        data = profile.to_dict()
        profile2 = CharacterProfile.from_dict(data)
        assert profile2.name == profile.name
    except Exception as e:
        errors.append(f"角色档案 [{i}]: {e}")
elapsed = time.time() - start
print(f"    1000次: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 8: save/load 持久化 =====
print("\n[8] save/load 持久化 (500次)...")
start = time.time()
for i in range(500):
    mbti = random.choice(mbti_types)
    try:
        profile = create_profile(f"持久化角色_{i}", mbti)
        tmp = tempfile.mktemp(suffix=".json")
        save_profile(profile, tmp)
        loaded = load_profile(tmp)
        assert loaded.name == profile.name
        os.remove(tmp)
    except Exception as e:
        errors.append(f"save/load [{i}]: {e}")
elapsed = time.time() - start
print(f"    500次: {elapsed:.3f}s, 错误: {len(errors)}")

# ===== Test 9: 内存泄漏 =====
print("\n[9] 内存泄漏检测...")
gc.collect()
before = len(gc.get_objects())
for _ in range(100):
    ms = MemorySystem()
    for i in range(500):
        ms.add(MemoryEntry(name=f"m{i}", tag="test", content="x"*1000, weight=0.5, emotion="喜"), MemoryType.NORMAL)
    del ms
gc.collect()
after = len(gc.get_objects())
leaked = abs(after - before)
print(f"    GC前: {before}, GC后: {after}, 差值: {leaked} (可接受: <5000)")

# ===== Test 10: 极端并发安全 =====
print("\n[10] 快速连续操作 (10000次)...")
start = time.time()
count = 0
for i in range(10000):
    try:
        mbti = random.choice(mbti_types)
        profile = create_profile(f"快速角色_{i}", mbti)
        data = profile.to_dict()
        profile2 = CharacterProfile.from_dict(data)
        assert profile2.name == profile.name
        count += 1
    except Exception as e:
        errors.append(f"快速 [{i}]: {e}")
elapsed = time.time() - start
print(f"    10000次: {elapsed:.3f}s, 成功: {count}, 错误: {len(errors)}")

# ===== Summary =====
print("\n" + "=" * 60)
print("压力测试汇总")
print("=" * 60)
total_ops = 10000 + 10000 + 7000 + 5000 + 5000 + 1000 + 1000 + 500 + 10000
print(f"  总操作: {total_ops:,}")
print(f"  总错误: {len(errors)}")
if errors:
    unique_errors = {}
    for e in errors:
        key = str(e)[:80]
        unique_errors[key] = unique_errors.get(key, 0) + 1
    print(f"  不同错误类型: {len(unique_errors)}")
    print(f"  错误最多的前5种:")
    for k, v in sorted(unique_errors.items(), key=lambda x: -x[1])[:5]:
        print(f"    x{v}: {k}")
    print(f"\n  全部错误列表:")
    for e in errors[:20]:
        print(f"    - {e[:120]}")
print(f"\n  结论: {'✅ 全部通过压力测试' if len(errors)==0 else f'⚠️ {len(errors)}个错误'}")
print("=" * 60)
