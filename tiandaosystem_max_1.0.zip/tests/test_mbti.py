"""
Unit tests for MBTI system
Tests: all 16 types loadable, weights in valid range 0-1, behavior tendency not empty
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tiandao.mbti import (
    MBTIProfile, get_profile, get_mbti_weights, get_behavior_tendency,
    get_mbti_traits, parse_mbti_short, parse_mbti_long,
    MBTI_NAMES, DESIRE_WEIGHTS_16, EMOTION_WEIGHTS_16,
    SHORT_LETTERS, LONG_LETTERS
)


# All 16 MBTI types
ALL_16_TYPES = [
    'ISTJ', 'ISFJ', 'INFJ', 'INTJ',
    'ISTP', 'ISFP', 'INFP', 'INTP',
    'ESTP', 'ESFP', 'ENFP', 'ENTP',
    'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ'
]


class TestAll16TypesLoadable(unittest.TestCase):
    """Test all 16 MBTI types can be loaded"""

    def test_all_types_have_names(self):
        """Test all 16 types have names defined"""
        for mbti in ALL_16_TYPES:
            self.assertIn(mbti, MBTI_NAMES, f"{mbti} should have a name")

    def test_all_types_have_desire_weights(self):
        """Test all 16 types have desire weights"""
        for mbti in ALL_16_TYPES:
            self.assertIn(mbti, DESIRE_WEIGHTS_16, f"{mbti} should have desire weights")

    def test_all_types_have_emotion_weights(self):
        """Test all 16 types have emotion weights"""
        for mbti in ALL_16_TYPES:
            self.assertIn(mbti, EMOTION_WEIGHTS_16, f"{mbti} should have emotion weights")

    def test_get_profile_all_types(self):
        """Test get_profile works for all 16 types"""
        for mbti in ALL_16_TYPES:
            profile = get_profile(mbti)
            self.assertEqual(profile.mbti_type, mbti.upper())
            self.assertNotEqual(profile.name, '')
            self.assertIsNotNone(profile.letter_short)
            self.assertIsNotNone(profile.letter_long)

    def test_get_mbti_weights_all_types(self):
        """Test get_mbti_weights works for all 16 types"""
        for mbti in ALL_16_TYPES:
            weights = get_mbti_weights(mbti)
            self.assertEqual(weights['mbti'], mbti.upper())
            self.assertIn('desire_weights', weights)
            self.assertIn('emotion_weights', weights)


class TestWeightsValidRange(unittest.TestCase):
    """Test weights are in valid range 0-1"""

    def test_desire_weights_range(self):
        """Test all desire weights are between 0 and 1"""
        required_keys = {'survival', 'knowledge', 'expression', 'performance', 'comfort', 'sexual'}

        for mbti, weights in DESIRE_WEIGHTS_16.items():
            for key in required_keys:
                self.assertIn(key, weights, f"{mbti} should have '{key}' desire weight")
                value = weights[key]
                self.assertGreaterEqual(value, 0.0, f"{mbti}.{key} should be >= 0")
                self.assertLessEqual(value, 1.0, f"{mbti}.{key} should be <= 1")

    def test_emotion_weights_range(self):
        """Test all emotion weights are between 0 and 1"""
        required_keys = {'joy', 'anger', 'worry', 'thinking', 'sadness', 'fear', 'surprise'}

        for mbti, weights in EMOTION_WEIGHTS_16.items():
            for key in required_keys:
                self.assertIn(key, weights, f"{mbti} should have '{key}' emotion weight")
                value = weights[key]
                self.assertGreaterEqual(value, 0.0, f"{mbti}.{key} should be >= 0")
                self.assertLessEqual(value, 1.0, f"{mbti}.{key} should be <= 1")

    def test_profile_weights_range(self):
        """Test MBTIProfile has valid weights"""
        for mbti in ALL_16_TYPES:
            profile = get_profile(mbti)

            for value in profile.desire_weights.values():
                self.assertGreaterEqual(value, 0.0)
                self.assertLessEqual(value, 1.0)

            for value in profile.emotion_weights.values():
                self.assertGreaterEqual(value, 0.0)
                self.assertLessEqual(value, 1.0)


class TestBehaviorTendencyNotEmpty(unittest.TestCase):
    """Test behavior tendency is not empty"""

    def test_all_types_have_behavior_tendency(self):
        """Test all 16 types have behavior tendency list"""
        for mbti in ALL_16_TYPES:
            tendency = get_behavior_tendency(mbti)
            self.assertIsInstance(tendency, list)
            self.assertGreater(len(tendency), 0, f"{mbti} should have at least one behavior tendency")

    def test_profile_has_behavior_tendency(self):
        """Test MBTIProfile has behavior tendency"""
        for mbti in ALL_16_TYPES:
            profile = get_profile(mbti)
            self.assertIsInstance(profile.behavior_tendency, list)
            self.assertGreater(len(profile.behavior_tendency), 0)

    def test_all_tendencies_non_empty_strings(self):
        """Test all behavior tendency items are non-empty strings"""
        for mbti in ALL_16_TYPES:
            tendency = get_behavior_tendency(mbti)
            for item in tendency:
                self.assertIsInstance(item, str)
                self.assertGreater(len(item), 0)


class TestMBTITraits(unittest.TestCase):
    """Test MBTI traits"""

    def test_all_types_have_traits(self):
        """Test all 16 types have traits"""
        for mbti in ALL_16_TYPES:
            traits = get_mbti_traits(mbti)
            self.assertIsInstance(traits, list)
            self.assertGreater(len(traits), 0)

    def test_profile_has_traits(self):
        """Test MBTIProfile has traits"""
        for mbti in ALL_16_TYPES:
            profile = get_profile(mbti)
            self.assertIsInstance(profile.traits, list)
            self.assertGreater(len(profile.traits), 0)


class TestLetterParsing(unittest.TestCase):
    """Test MBTI letter parsing"""

    def test_parse_mbti_short(self):
        """Test short letter parsing"""
        result = parse_mbti_short('INTJ')
        self.assertIn('I=', result)
        self.assertIn('N=', result)
        self.assertIn('T=', result)
        self.assertIn('J=', result)

    def test_parse_mbti_long(self):
        """Test long letter parsing (Chinese)"""
        result = parse_mbti_long('INTJ')
        self.assertIn('内向', result)
        self.assertIn('直觉', result)
        self.assertIn('思考', result)
        self.assertIn('判断', result)

    def test_parse_invalid_length(self):
        """Test parsing with invalid length returns empty string"""
        self.assertEqual(parse_mbti_short('INT'), '')
        self.assertEqual(parse_mbti_long('INTJ5'), '')


class TestShortAndLongLetters(unittest.TestCase):
    """Test short and long letter definitions"""

    def test_short_letters_complete(self):
        """Test all 8 MBTI letters have short definitions"""
        for letter in ['E', 'I', 'S', 'N', 'T', 'F', 'J', 'P']:
            self.assertIn(letter, SHORT_LETTERS)
            self.assertNotEqual(SHORT_LETTERS[letter], '')

    def test_long_letters_complete(self):
        """Test all 8 MBTI letters have long (Chinese) definitions"""
        for letter in ['E', 'I', 'S', 'N', 'T', 'F', 'J', 'P']:
            self.assertIn(letter, LONG_LETTERS)
            self.assertNotEqual(LONG_LETTERS[letter], '')


class TestMBTIProfileCreation(unittest.TestCase):
    """Test MBTIProfile creation and auto-fill"""

    def test_profile_auto_fill_name(self):
        """Test profile auto-fills name from MBTI_NAMES"""
        profile = MBTIProfile(mbti_type='ENFP')
        self.assertEqual(profile.name, MBTI_NAMES['ENFP'])

    def test_profile_auto_fill_letters(self):
        """Test profile auto-fills letter parsing"""
        profile = MBTIProfile(mbti_type='INTJ')
        self.assertIn('I=', profile.letter_short)
        self.assertIn('内向', profile.letter_long)

    def test_profile_auto_fill_weights(self):
        """Test profile auto-fills weights from dictionaries"""
        profile = MBTIProfile(mbti_type='ISTJ')
        self.assertIn('survival', profile.desire_weights)
        self.assertIn('joy', profile.emotion_weights)

    def test_profile_custom_values_override(self):
        """Test custom values override auto-fill"""
        custom_name = "Custom Name"
        profile = MBTIProfile(mbti_type='INTJ', name=custom_name)
        self.assertEqual(profile.name, custom_name)


if __name__ == '__main__':
    unittest.main()