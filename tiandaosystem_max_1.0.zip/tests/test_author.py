"""
Unit tests for author constraint system
Tests: constraint checks, group portrait generation, conflict resolution, character validation
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tiandao.author import (
    AuthorConstraint, AIConstraint, EnsembleConstraint,
    ConflictVariable, TCMConstraint,
    ConflictType, ConflictLevel,
    generate_group_portrait_scene, resolve_conflict,

)


class TestConstraintChecks(unittest.TestCase):
    """Test constraint checking functionality"""

    def test_ai_god_complex_check(self):
        """Test AI god complex detection"""
        # Should detect god patterns
        self.assertTrue(AIConstraint.check_god_complex("全知视角观察"))
        self.assertTrue(AIConstraint.check_god_complex("完美决策无错误"))
        self.assertTrue(AIConstraint.check_god_complex("无条件拯救所有人"))

        # Should pass normal content
        self.assertFalse(AIConstraint.check_god_complex("角色做出选择"))
        self.assertFalse(AIConstraint.check_god_complex("正常叙事"))

    def test_no_perfect_ending_validation(self):
        """Test perfect ending validation"""
        # Should reject perfect endings
        self.assertFalse(AIConstraint.validate_no_perfect_ending("完美无缺毫无代价"))
        self.assertFalse(AIConstraint.validate_no_perfect_ending("全员获救零牺牲"))

        # Should accept reasonable endings
        self.assertTrue(AIConstraint.validate_no_perfect_ending("角色面临艰难选择"))
        self.assertTrue(AIConstraint.validate_no_perfect_ending("有牺牲但值得"))

    def test_enforce_character_limitations(self):
        """Test character limitation enforcement"""
        character = {"name": "Test"}
        result = AIConstraint.enforce_character_limitations(character)

        self.assertIn("limitations", result)
        self.assertGreater(len(result["limitations"]), 0)
        self.assertIn("failure_modes", result)
        self.assertGreater(len(result["failure_modes"]), 0)

    def test_author_constraint_check(self):
        """Test AuthorConstraint.check_constraint"""
        ac = AuthorConstraint()

        # Should reject god complex
        self.assertFalse(ac.check_constraint("全知视角决定一切"))

        # Should accept normal
        self.assertTrue(ac.check_constraint("角色正常行动"))

    def test_apply_all_constraints(self):
        """Test applying all constraints to characters"""
        ac = AuthorConstraint()
        characters = [
            {"name": "Character1"},
            {"name": "Character2"}
        ]

        result = ac.apply_all_constraints(characters)

        self.assertEqual(len(result), 2)
        for char in result:
            self.assertIn("limitations", char)


class TestGroupPortraitGeneration(unittest.TestCase):
    """Test group portrait/scene generation"""

    def test_generate_empty_group(self):
        """Test generating scene with no characters"""
        scene = generate_group_portrait_scene([])
        self.assertEqual(scene, "空场景：无角色在场")

    def test_generate_single_character(self):
        """Test generating scene with one character"""
        characters = [{"name": "Solo", "type": "neutral"}]
        scene = generate_group_portrait_scene(characters)
        self.assertIn("1人聚集", scene)

    def test_generate_multiple_characters(self):
        """Test generating scene with multiple characters"""
        characters = [
            {"name": "Leader", "type": "leader"},
            {"name": "Follower", "type": "follower"},
            {"name": "Observer", "type": "neutral"}
        ]
        scene = generate_group_portrait_scene(characters)
        self.assertIn("3人聚集", scene)
        self.assertIsNotNone(scene)

    def test_scene_includes_tension(self):
        """Test scene includes tension indicators"""
        characters = [
            {"name": "A", "type": "aggressive"},
            {"name": "B", "type": "passive"},
            {"name": "C", "type": "active"}
        ]
        scene = generate_group_portrait_scene(characters)
        self.assertIsNotNone(scene)
        # Should include tension elements
        self.assertTrue(len(scene) > 20)

    def test_scene_yin_yang_separation(self):
        """Test scene describes yin/yang character separation"""
        characters = [
            {"name": "Active1", "type": "leader"},
            {"name": "Active2", "type": "aggressive"},
            {"name": "Passive1", "type": "follower"}
        ]
        scene = generate_group_portrait_scene(characters)
        # Should mention action vs observation division
        self.assertIn("行动派", scene)


class TestConflictResolution(unittest.TestCase):
    """Test conflict resolution functionality"""

    def test_resolve_goal_conflict_latent(self):
        """Test resolving latent goal conflict"""
        conflict = {
            "type": ConflictType.GOAL_CONFLICT,
            "level": ConflictLevel.LATENT,
            "parties": ["A", "B"]
        }
        resolution = resolve_conflict(conflict)
        self.assertIsInstance(resolution, dict)
        self.assertIn("immediate_action", resolution)

    def test_resolve_value_conflict_manifest(self):
        """Test resolving manifest value conflict"""
        conflict = {
            "type": ConflictType.VALUE_CONFLICT,
            "level": ConflictLevel.MANIFEST,
            "parties": ["A", "B", "C"]
        }
        resolution = resolve_conflict(conflict)
        self.assertIsInstance(resolution, dict)
        self.assertIn("immediate_action", resolution)

    def test_resolve_information_conflict(self):
        """Test resolving information conflict"""
        conflict = {
            "type": ConflictType.INFORMATION_CONFLICT,
            "level": ConflictLevel.LATENT,
            "parties": ["X", "Y"]
        }
        resolution = resolve_conflict(conflict)
        self.assertIsNotNone(resolution)

    def test_resolve_relationship_conflict_erupt(self):
        """Test resolving erupt relationship conflict"""
        conflict = {
            "type": ConflictType.RELATIONSHIP_CONFLICT,
            "level": ConflictLevel.ERUPT,
            "parties": ["P1", "P2"]
        }
        resolution = resolve_conflict(conflict)
        self.assertIsNotNone(resolution)
        self.assertIsInstance(resolution, dict)
        self.assertIn("immediate_action", resolution)

    def test_resolve_default_type(self):
        """Test resolving with default type"""
        conflict = {}  # Empty, will use defaults
        resolution = resolve_conflict(conflict)
        self.assertIsNotNone(resolution)


class TestCharacterValidation(unittest.TestCase):
    """Test character validation and constraint application"""

    def test_de_divinize(self):
        """Test de-divinize removes perfect attributes"""
        character = {
            "name": "Perfect",
            "abilities": ["全知", "全能", "正常能力"]
        }
        result = EnsembleConstraint.de_divinize(character)

        # Should remove omnipotent abilities
        ability_names = [str(a) for a in result.get("abilities", [])]
        self.assertNotIn("全知", ability_names)
        self.assertNotIn("全能", ability_names)

        # Should add human flaws
        self.assertIn("flaws", result)
        self.assertGreater(len(result["flaws"]), 0)

    def test_de_instrumentalize(self):
        """Test de-instrumentalize adds autonomy"""
        character = {"name": "Tool"}
        result = EnsembleConstraint.de_instrumentalize(character)

        self.assertIn("personal_agenda", result)
        self.assertIn("private_motive", result)

    def test_ensemble_out_of_control(self):
        """Test ensemble out of control adds autonomy"""
        characters = [
            {"name": "A"},
            {"name": "B"}
        ]
        result = EnsembleConstraint.ensemble_out_of_control(characters)

        for char in result:
            self.assertTrue(char.get("can_go_rogue", False))
            self.assertIn("autonomy_level", char)
            self.assertIn("break_points", char)


class TestConflictVariable(unittest.TestCase):
    """Test conflict variable library"""

    def test_get_conflict_description(self):
        """Test getting conflict descriptions"""
        desc = ConflictVariable.get_conflict_description(
            ConflictType.GOAL_CONFLICT,
            ConflictLevel.LATENT
        )
        self.assertIsInstance(desc, str)
        self.assertNotEqual(desc, "未知冲突状态")

        desc = ConflictVariable.get_conflict_description(
            ConflictType.VALUE_CONFLICT,
            ConflictLevel.ERUPT
        )
        self.assertIsInstance(desc, str)

    def test_get_triggers(self):
        """Test getting conflict triggers"""
        triggers = ConflictVariable.get_triggers(
            ConflictType.GOAL_CONFLICT,
            ConflictLevel.MANIFEST
        )
        self.assertIsInstance(triggers, list)
        self.assertGreater(len(triggers), 0)

    def test_escalate_conflict(self):
        """Test conflict escalation"""
        level = ConflictVariable.escalate_conflict(ConflictLevel.LATENT)
        self.assertEqual(level, ConflictLevel.MANIFEST)

        level = ConflictVariable.escalate_conflict(ConflictLevel.MANIFEST)
        self.assertEqual(level, ConflictLevel.ERUPT)

        # Can't escalate beyond ERUPT
        level = ConflictVariable.escalate_conflict(ConflictLevel.ERUPT)
        self.assertEqual(level, ConflictLevel.ERUPT)

    def test_all_conflict_type_combinations(self):
        """Test all 4 conflict types with 3 levels"""
        for cf_type in ConflictType:
            for cf_level in ConflictLevel:
                desc = ConflictVariable.get_conflict_description(cf_type, cf_level)
                self.assertIsInstance(desc, str)


class TestTCMConstraint(unittest.TestCase):
    """Test Traditional Chinese Medicine constraint model"""

    def test_diagnose_group_dynamics_basic(self):
        """Test basic group dynamics diagnosis"""
        characters = [
            {"name": "A", "temperament": "aggressive"},
            {"name": "B", "temperament": "passive"}
        ]
        dynamics = TCMConstraint.diagnose_group_dynamics(characters)

        self.assertIn("整体状态", dynamics)
        self.assertIn("失衡点", dynamics)
        self.assertIn("需要调和", dynamics)

    def test_diagnose_group_dynamics_balanced(self):
        """Test balanced group diagnosis"""
        characters = [
            {"name": "A", "temperament": "aggressive"},
            {"name": "B", "temperament": "passive"},
            {"name": "C", "temperament": "active"},
            {"name": "D", "temperament": "introverted"}
        ]
        dynamics = TCMConstraint.diagnose_group_dynamics(characters)
        self.assertIn("整体状态", dynamics)

    def test_prescribe_treatment(self):
        """Test treatment prescription"""
        dynamics = {
            "整体状态": "严重失衡",
            "失衡点": ["阴阳比例偏阳"],
            "需要调和": []
        }
        prescriptions = TCMConstraint.prescribe_treatment(dynamics)

        self.assertIsInstance(prescriptions, list)
        self.assertGreater(len(prescriptions), 0)


class TestAuthorConstraintClass(unittest.TestCase):
    """Test AuthorConstraint dataclass"""

    def test_default_enabled(self):
        """Test default constraints are enabled"""
        ac = AuthorConstraint()
        self.assertTrue(ac.limit_ai_god_complex)
        self.assertTrue(ac.enable_ensemble_thinking)
        self.assertTrue(ac.enable_conflict_library)
        self.assertTrue(ac.enable_tcm_model)

    def test_custom_settings(self):
        """Test custom constraint settings"""
        ac = AuthorConstraint(
            limit_ai_god_complex=False,
            enable_ensemble_thinking=False
        )
        self.assertFalse(ac.limit_ai_god_complex)
        self.assertFalse(ac.enable_ensemble_thinking)

    def test_constraints_applied_log(self):
        """Test constraints applied are logged"""
        ac = AuthorConstraint()
        result = ac.check_constraint("全知视角")  # Should trigger constraint
        self.assertFalse(result)


if __name__ == '__main__':
    unittest.main()