"""
Unit tests for motivation system
Tests: all 7 instinct types generate chains, 7 decision frameworks, motivation strength calculation
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tiandao.motivation import (
    Instinct,
    DecisionFramework,
    MotivationChain, DecisionFrameworkProfile,
    generate_motivation_chain, get_decision_framework,
    INSTINCT_NAMES, INSTINCT_DESCRIPTIONS,
    FRAMEWORK_NAMES, FRAMEWORK_DESCRIPTIONS
)


# All 7 instinct types
ALL_7_INSTINCTS = [
    Instinct.SURVIVAL, Instinct.KNOWLEDGE, Instinct.EXPRESSION,
    Instinct.COMFORT, Instinct.DESIRE, Instinct.CREATIVE, Instinct.MATERNAL
]


class TestAll7InstinctTypesGenerateChains(unittest.TestCase):
    """Test all 7 instinct types can generate motivation chains"""

    def test_all_instincts_have_names(self):
        """Test all 7 instincts have names defined"""
        for instinct in ALL_7_INSTINCTS:
            self.assertIn(instinct, INSTINCT_NAMES)

    def test_all_instincts_have_descriptions(self):
        """Test all 7 instincts have descriptions"""
        for instinct in ALL_7_INSTINCTS:
            self.assertIn(instinct, INSTINCT_DESCRIPTIONS)
            self.assertNotEqual(INSTINCT_DESCRIPTIONS[instinct], '')

    def test_generate_chain_all_instincts(self):
        """Test generate_motivation_chain works for all 7 instincts"""
        scene = "面对挑战场景"
        role = "勇敢的角色"

        for instinct in ALL_7_INSTINCTS:
            chain = generate_motivation_chain(instinct, scene, role)
            self.assertIsInstance(chain, MotivationChain)
            self.assertEqual(chain.instinct, instinct)
            self.assertIsNotNone(chain.surface)
            self.assertIsNotNone(chain.deep)
            self.assertIsNotNone(chain.core)
            self.assertIsNotNone(chain.soul)

    def test_chain_has_valid_intensity(self):
        """Test motivation chain has intensity in valid range"""
        scene = "紧急场景"
        role = "坚定的角色"

        for instinct in ALL_7_INSTINCTS:
            chain = generate_motivation_chain(instinct, scene, role)
            self.assertGreaterEqual(chain.intensity, 0.0)
            self.assertLessEqual(chain.intensity, 100.0)

    def test_chain_has_valid_confidence(self):
        """Test motivation chain has confidence in valid range"""
        scene = "普通场景"
        role = "普通的角色"

        for instinct in ALL_7_INSTINCTS:
            chain = generate_motivation_chain(instinct, scene, role)
            self.assertGreaterEqual(chain.confidence, 0.0)
            self.assertLessEqual(chain.confidence, 1.0)

    def test_chain_surface_not_empty(self):
        """Test motivation chain surface motivation is not empty"""
        scene = "测试场景"
        role = "测试角色"

        for instinct in ALL_7_INSTINCTS:
            chain = generate_motivation_chain(instinct, scene, role)
            self.assertIsInstance(chain.surface, str)
            self.assertGreater(len(chain.surface), 0)


class Test7DecisionFrameworks(unittest.TestCase):
    """Test 7 decision frameworks"""

    def test_all_7_frameworks_defined(self):
        """Test all 7 decision frameworks are defined"""
        expected = [
            DecisionFramework.PROFIT,
            DecisionFramework.EMOTION,
            DecisionFramework.LOGIC,
            DecisionFramework.SOCIAL,
            DecisionFramework.SAFETY,
            DecisionFramework.GROWTH,
            DecisionFramework.MISSION
        ]

        for framework in expected:
            self.assertIn(framework, [f for f in DecisionFramework])

    def test_all_frameworks_have_names(self):
        """Test all 7 frameworks have names"""
        frameworks = [
            DecisionFramework.PROFIT, DecisionFramework.EMOTION,
            DecisionFramework.LOGIC, DecisionFramework.SOCIAL,
            DecisionFramework.SAFETY, DecisionFramework.GROWTH,
            DecisionFramework.MISSION
        ]

        for fw in frameworks:
            self.assertIn(fw, FRAMEWORK_NAMES)
            self.assertNotEqual(FRAMEWORK_NAMES[fw], '')

    def test_all_frameworks_have_descriptions(self):
        """Test all 7 frameworks have descriptions"""
        frameworks = [
            DecisionFramework.PROFIT, DecisionFramework.EMOTION,
            DecisionFramework.LOGIC, DecisionFramework.SOCIAL,
            DecisionFramework.SAFETY, DecisionFramework.GROWTH,
            DecisionFramework.MISSION
        ]

        for fw in frameworks:
            self.assertIn(fw, FRAMEWORK_DESCRIPTIONS)
            self.assertNotEqual(FRAMEWORK_DESCRIPTIONS[fw], '')

    def test_get_decision_framework_basic(self):
        """Test get_decision_framework returns valid profile"""
        profile = get_decision_framework("企业家")
        self.assertIsInstance(profile, DecisionFrameworkProfile)
        self.assertIsInstance(profile.primary, DecisionFramework)
        self.assertIsInstance(profile.secondary, DecisionFramework)
        self.assertIsInstance(profile.weights, dict)

    def test_framework_weights_valid(self):
        """Test decision framework weights are in valid range"""
        profile = get_decision_framework("商人")

        for fw, weight in profile.weights.items():
            self.assertGreaterEqual(weight, 0.0)
            self.assertLessEqual(weight, 1.0)

    def test_framework_flexibility_valid(self):
        """Test framework flexibility is in valid range"""
        profile = get_decision_framework("普通角色")
        self.assertGreaterEqual(profile.flexibility, 0.0)
        self.assertLessEqual(profile.flexibility, 1.0)


class TestMotivationStrengthCalculation(unittest.TestCase):
    """Test motivation strength/intensity calculation"""

    def test_basic_intensity_calculation(self):
        """Test basic intensity is in range"""
        chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "普通场景",
            "普通角色"
        )
        self.assertGreaterEqual(chain.intensity, 0)
        self.assertLessEqual(chain.intensity, 100)

    def test_emergency_scene_increases_intensity(self):
        """Test emergency keywords increase intensity"""
        normal_chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "普通场景",
            "普通角色"
        )

        emergency_chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "紧急危险场景",
            "坚定角色"
        )

        # Emergency scene should have higher intensity
        self.assertGreater(
            emergency_chain.intensity,
            normal_chain.intensity
        )

    def test_decisive_role_increases_confidence(self):
        """Test decisive role keywords increase confidence"""
        normal_chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "普通场景",
            "普通角色"
        )

        decisive_chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "普通场景",
            "坚定的角色"
        )

        self.assertGreaterEqual(
            decisive_chain.confidence,
            normal_chain.confidence
        )

    def test_confidence_reduced_in_complex_scene(self):
        """Test complex scenes reduce confidence"""
        simple_chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "简单场景",
            "角色"
        )

        complex_chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "两难选择场景",
            "角色"
        )

        self.assertGreater(
            simple_chain.confidence,
            complex_chain.confidence
        )


class TestMotivationChainStructure(unittest.TestCase):
    """Test motivation chain structure"""

    def test_chain_four_layers(self):
        """Test chain has all four motivation layers"""
        chain = generate_motivation_chain(
            Instinct.SURVIVAL,
            "测试场景",
            "测试角色"
        )

        self.assertIsNotNone(chain.surface)  # 表层动机
        self.assertIsNotNone(chain.deep)     # 深层动机
        self.assertIsNotNone(chain.core)     # 核心动机
        self.assertIsNotNone(chain.soul)     # 灵魂动机

    def test_chain_layers_are_strings(self):
        """Test all chain layers are non-empty strings"""
        chain = generate_motivation_chain(
            Instinct.KNOWLEDGE,
            "探索未知",
            "求知者"
        )

        for layer_name in ['surface', 'deep', 'core', 'soul']:
            layer_value = getattr(chain, layer_name)
            self.assertIsInstance(layer_value, str)
            self.assertGreater(len(layer_value), 0)

    def test_chain_instinct_matches(self):
        """Test chain instinct matches input"""
        for instinct in ALL_7_INSTINCTS:
            chain = generate_motivation_chain(instinct, "scene", "role")
            self.assertEqual(chain.instinct, instinct)


class TestRoleBasedFramework(unittest.TestCase):
    """Test role-based decision framework mapping"""

    def test_business_role_maps_profit(self):
        """Test business roles map to profit framework"""
        profile = get_decision_framework("商人")
        self.assertEqual(profile.primary, DecisionFramework.PROFIT)

        profile = get_decision_framework("投资者")
        self.assertEqual(profile.primary, DecisionFramework.PROFIT)

    def test_artist_role_maps_emotion(self):
        """Test artist roles map to emotion framework"""
        profile = get_decision_framework("艺术家")
        self.assertEqual(profile.primary, DecisionFramework.EMOTION)

        profile = get_decision_framework("诗人")
        self.assertEqual(profile.primary, DecisionFramework.EMOTION)

    def test_scientist_role_maps_logic(self):
        """Test scientist roles map to logic framework"""
        profile = get_decision_framework("科学家")
        self.assertEqual(profile.primary, DecisionFramework.LOGIC)

        profile = get_decision_framework("工程师")
        self.assertEqual(profile.primary, DecisionFramework.LOGIC)

    def test_leader_role_maps_mission(self):
        """Test leader roles map to mission framework"""
        profile = get_decision_framework("领导者")
        self.assertEqual(profile.primary, DecisionFramework.MISSION)

        profile = get_decision_framework("政治家")
        self.assertEqual(profile.primary, DecisionFramework.MISSION)


class TestMotivationChainClass(unittest.TestCase):
    """Test MotivationChain dataclass"""

    def test_default_values(self):
        """Test default intensity and confidence"""
        chain = MotivationChain(
            instinct=Instinct.SURVIVAL,
            surface="get food",
            deep="survive",
            core="existence",
            soul="life continues"
        )

        self.assertEqual(chain.intensity, 75.0)  # default
        self.assertEqual(chain.confidence, 0.8)  # default

    def test_intensity_clamping(self):
        """Test intensity is clamped to 0-100"""
        chain = MotivationChain(
            instinct=Instinct.SURVIVAL,
            surface="s", deep="d", core="c", soul="s",
            intensity=150.0  # above 100
        )
        self.assertEqual(chain.intensity, 100.0)

        chain2 = MotivationChain(
            instinct=Instinct.SURVIVAL,
            surface="s", deep="d", core="c", soul="s",
            intensity=-50.0  # below 0
        )
        self.assertEqual(chain2.intensity, 0.0)

    def test_confidence_clamping(self):
        """Test confidence is clamped to 0-1"""
        chain = MotivationChain(
            instinct=Instinct.SURVIVAL,
            surface="s", deep="d", core="c", soul="s",
            confidence=2.0  # above 1
        )
        self.assertEqual(chain.confidence, 1.0)


if __name__ == '__main__':
    unittest.main()