"""
Unit tests for memory system
Tests: add/rotate/forget, abnormal memory cap (15), serialization round-trip
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tiandao.memory import (
    MemorySystem, MemoryEntry, MemoryType
)


class TestMemoryEntry(unittest.TestCase):
    """Test MemoryEntry dataclass"""

    def test_create_entry(self):
        """Test basic entry creation"""
        entry = MemoryEntry(name="Test", tag="test", content="Test content")
        self.assertEqual(entry.name, "Test")
        self.assertEqual(entry.tag, "test")
        self.assertEqual(entry.content, "Test content")
        self.assertEqual(entry.weight, 0.5)
        self.assertEqual(entry.emotion, 0.0)

    def test_entry_with_params(self):
        """Test entry with custom params"""
        entry = MemoryEntry(name="A", tag="b", content="c", weight=0.8, emotion=-0.5)
        self.assertEqual(entry.weight, 0.8)
        self.assertEqual(entry.emotion, -0.5)

    def test_to_dict(self):
        """Test to_dict conversion"""
        entry = MemoryEntry(name="Test", tag="tag", content="content")
        d = entry.to_dict()
        self.assertIsInstance(d, dict)
        self.assertEqual(d['name'], "Test")
        self.assertEqual(d['tag'], "tag")

    def test_from_dict(self):
        """Test from_dict creation"""
        data = {'name': 'A', 'tag': 'B', 'content': 'C', 'weight': 0.7, 'emotion': 0.3, 'created_at': 12345}
        entry = MemoryEntry.from_dict(data)
        self.assertEqual(entry.name, 'A')
        self.assertEqual(entry.weight, 0.7)


class TestMemoryAddRotateForget(unittest.TestCase):
    """Test memory add, rotate, forget operations"""

    def setUp(self):
        """Set up test memory system"""
        self.ms = MemorySystem()

    def test_add_normal_memory(self):
        """Test adding normal memory"""
        entry = MemoryEntry(name="normal1", tag="test", content="content")
        result = self.ms.add(entry, MemoryType.NORMAL)
        self.assertTrue(result)
        self.assertEqual(len(self.ms.total_memories), 1)
        self.assertEqual(len(self.ms.normal_memories), 1)

    def test_add_long_term_memory(self):
        """Test adding long term memory with limit"""
        for i in range(20):
            entry = MemoryEntry(name=f"lt{i}", tag="test", content=f"content{i}")
            self.ms.add(entry, MemoryType.LONG_TERM)

        # Should only keep max 20
        self.assertLessEqual(len(self.ms.long_term_memories), 20)

    def test_add_short_term_memory_rotation(self):
        """Test short term memory rotation at max=10"""
        for i in range(15):
            entry = MemoryEntry(name=f"st{i}", tag="test", content=f"content{i}")
            self.ms.add(entry, MemoryType.SHORT_TERM)

        # Should have max 10, oldest removed
        self.assertEqual(len(self.ms.short_term_memories), 10)

        # Check rotation happened
        self.assertGreater(self.ms.stats['rotation_count'], 0)

    def test_rotate_short_term(self):
        """Test rotate operation removes oldest"""
        for i in range(5):
            entry = MemoryEntry(name=f"mem{i}", tag="test", content=f"content{i}")
            self.ms.add(entry, MemoryType.SHORT_TERM)

        self.assertEqual(len(self.ms.short_term_memories), 5)

        rotated = self.ms.rotate(MemoryType.SHORT_TERM)
        self.assertIsNotNone(rotated)
        self.assertEqual(rotated.name, "mem0")  # First added
        self.assertEqual(len(self.ms.short_term_memories), 4)

    def test_rotate_empty(self):
        """Test rotating empty short term memory"""
        result = self.ms.rotate(MemoryType.SHORT_TERM)
        self.assertIsNone(result)

    def test_forget_decay(self):
        """Test forget mechanism decays weights"""
        entry = MemoryEntry(name="fade", tag="test", content="content", weight=0.5)
        self.ms.add(entry, MemoryType.NORMAL)

        # Forget with decay
        forgotten = self.ms.forget(decay_rate=0.2, min_weight=0.4)

        # Entry weight 0.5 - 0.2 = 0.3 < 0.4, should be forgotten
        self.assertEqual(forgotten, 1)
        self.assertEqual(len(self.ms.total_memories), 0)

    def test_delete_memory(self):
        """Test delete operation"""
        entry = MemoryEntry(name="todelete", tag="test", content="content")
        self.ms.add(entry, MemoryType.NORMAL)

        deleted = self.ms.delete(name="todelete")
        self.assertGreaterEqual(deleted, 1)
        self.assertEqual(len(self.ms.total_memories), 0)


class TestAbnormalMemoryCap15(unittest.TestCase):
    """Test abnormal memory cap at 15 and PTSD penalty"""

    def setUp(self):
        """Set up test memory system"""
        self.ms = MemorySystem()

    def test_abnormal_max_15(self):
        """Test abnormal memory maximum is 15"""
        self.assertEqual(self.ms.ABNORMAL_MAX, 15)

    def test_abnormal_adds_beyond_cap(self):
        """Test abnormal memories can still be added beyond cap"""
        for i in range(20):
            entry = MemoryEntry(name=f"ab{i}", tag="trauma", content=f"trauma{i}")
            self.ms.add(entry, MemoryType.ABNORMAL)

        # Still added to list, just triggers penalty
        self.assertEqual(len(self.ms.abnormal_memories), 20)

    def test_ptsd_penalty_on_overflow(self):
        """Test PTSD penalty when exceeding cap"""
        initial_y_base = self.ms.y_base

        # Add 16 abnormal memories to trigger overflow
        for i in range(16):
            entry = MemoryEntry(name=f"trauma{i}", tag="trauma", content=f"trauma{i}")
            self.ms.add(entry, MemoryType.ABNORMAL)

        # Should have applied PTSD penalty
        self.assertGreater(self.ms.stats['ptsd_penalties_applied'], 0)
        self.assertGreater(self.ms.y_base, initial_y_base)

    def test_ptsd_increases_base_y_offset(self):
        """Test PTSD increases base_y_offset"""
        for i in range(18):
            entry = MemoryEntry(name=f"severe{i}", tag="trauma", content=f"severe{i}")
            self.ms.add(entry, MemoryType.ABNORMAL)

        self.assertGreater(self.ms.base_y_offset, 0)

    def test_abnormal_overflow_tracking(self):
        """Test overflow is tracked correctly"""
        stats = self.ms.get_memory_stats()
        self.assertEqual(stats['abnormal_overflow'], 0)

        for i in range(18):
            entry = MemoryEntry(name=f"trauma{i}", tag="trauma", content=f"trauma{i}")
            self.ms.add(entry, MemoryType.ABNORMAL)

        stats = self.ms.get_memory_stats()
        self.assertEqual(stats['abnormal_overflow'], 3)


class TestSerializationRoundTrip(unittest.TestCase):
    """Test serialization and deserialization round-trip"""

    def setUp(self):
        """Set up test memory system"""
        self.ms = MemorySystem()

    def test_serialize_basic(self):
        """Test basic serialization"""
        entry = MemoryEntry(name="serialize", tag="test", content="content")
        self.ms.add(entry, MemoryType.NORMAL)

        json_str = self.ms.serialize()
        self.assertIsInstance(json_str, str)
        self.assertIn('"total_memories"', json_str)
        self.assertIn('"serialize"', json_str)

    def test_deserialize_basic(self):
        """Test basic deserialization"""
        entry = MemoryEntry(name="deserialize", tag="test", content="content")
        self.ms.add(entry, MemoryType.NORMAL)

        json_str = self.ms.serialize()

        # Create new system and deserialize
        new_ms = MemorySystem()
        result = new_ms.deserialize(json_str)

        self.assertTrue(result)
        self.assertEqual(len(new_ms.total_memories), 1)

    def test_round_trip_preserves_data(self):
        """Test round-trip preserves all memory data"""
        # Add various memory types
        self.ms.add(MemoryEntry(name="n1", tag="normal", content="c1"), MemoryType.NORMAL)
        self.ms.add(MemoryEntry(name="ab1", tag="trauma", content="c2"), MemoryType.ABNORMAL)
        self.ms.add(MemoryEntry(name="lt1", tag="long", content="c3"), MemoryType.LONG_TERM)
        self.ms.add(MemoryEntry(name="st1", tag="short", content="c4"), MemoryType.SHORT_TERM)

        json_str = self.ms.serialize()
        new_ms = MemorySystem()
        new_ms.deserialize(json_str)

        # Check all memories preserved
        self.assertEqual(len(new_ms.total_memories), 4)
        self.assertEqual(len(new_ms.normal_memories), 1)
        self.assertEqual(len(new_ms.abnormal_memories), 1)
        self.assertEqual(len(new_ms.long_term_memories), 1)
        self.assertEqual(len(new_ms.short_term_memories), 1)

    def test_round_trip_preserves_y_base(self):
        """Test round-trip preserves y_base state"""
        # Add abnormal memories to change y_base
        for i in range(18):
            self.ms.add(MemoryEntry(name=f"t{i}", tag="trauma", content=f"c{i}"), MemoryType.ABNORMAL)

        original_y_base = self.ms.y_base

        json_str = self.ms.serialize()
        new_ms = MemorySystem()
        new_ms.deserialize(json_str)

        self.assertEqual(new_ms.y_base, original_y_base)
        self.assertEqual(new_ms.base_y_offset, self.ms.base_y_offset)

    def test_round_trip_preserves_stats(self):
        """Test round-trip preserves stats"""
        for i in range(10):
            self.ms.add(MemoryEntry(name=f"m{i}", tag="test", content=f"c{i}"), MemoryType.NORMAL)

        json_str = self.ms.serialize()
        new_ms = MemorySystem()
        new_ms.deserialize(json_str)

        self.assertEqual(new_ms.stats['total_added'], 10)

    def test_deserialize_invalid_json(self):
        """Test deserialization with invalid JSON returns False"""
        new_ms = MemorySystem()
        result = new_ms.deserialize("not valid json {")
        self.assertFalse(result)


class TestMemorySearch(unittest.TestCase):
    """Test memory search functionality"""

    def setUp(self):
        """Set up test memory system"""
        self.ms = MemorySystem()
        self.ms.add(MemoryEntry(name="apple", tag="fruit", content="red fruit"), MemoryType.NORMAL)
        self.ms.add(MemoryEntry(name="banana", tag="fruit", content="yellow fruit"), MemoryType.NORMAL)
        self.ms.add(MemoryEntry(name="carrot", tag="vegetable", content="orange vegetable"), MemoryType.NORMAL)

    def test_search_by_keyword(self):
        """Test search by keyword"""
        results = self.ms.search(keyword="red")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "apple")

    def test_search_by_tag(self):
        """Test search by tag"""
        results = self.ms.search(tag="fruit")
        self.assertEqual(len(results), 2)

    def test_search_combined(self):
        """Test search combined keyword and tag"""
        results = self.ms.search(keyword="red", tag="fruit")
        self.assertEqual(len(results), 1)


class TestMemoryStats(unittest.TestCase):
    """Test memory statistics"""

    def setUp(self):
        """Set up test memory system"""
        self.ms = MemorySystem()

    def test_initial_stats(self):
        """Test initial stats are zero"""
        stats = self.ms.get_memory_stats()
        self.assertEqual(stats['total_memories_count'], 0)
        self.assertEqual(stats['normal_memories_count'], 0)
        self.assertEqual(stats['abnormal_memories_count'], 0)

    def test_stats_after_add(self):
        """Test stats update after adding memories"""
        self.ms.add(MemoryEntry(name="m1", tag="test", content="c1"), MemoryType.NORMAL)
        self.ms.add(MemoryEntry(name="m2", tag="test", content="c2"), MemoryType.NORMAL)

        stats = self.ms.get_memory_stats()
        self.assertEqual(stats['total_memories_count'], 2)
        self.assertEqual(stats['stats']['total_added'], 2)


if __name__ == '__main__':
    unittest.main()