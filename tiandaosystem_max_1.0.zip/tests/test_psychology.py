"""
Unit tests for Y-value psychology system
Tests: y bounds (0-100), trigger threshold formula, compensation, rebound, state transitions, delta_y breakthrough
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tiandao.psychology import (
    YPsychologyEngine, PsychologyProfile, YState,
    STATE_THRESHOLDS, calculate_trigger, calculate_rebound,
    y_to_state, get_state_info
)


class TestYBounds(unittest.TestCase):
    """Test Y value bounds (0-100)"""

    def test_default_y_in_bounds(self):
        """Test default Y value is within 0-100"""
        engine = YPsychologyEngine()
        self.assertGreaterEqual(engine.profile.current_y, 0)
        self.assertLessEqual(engine.profile.current_y, 100)

    def test_base_y_clamping(self):
        """Test base_y is clamped to 0-100"""
        engine1 = YPsychologyEngine(base_y=-50)
        self.assertEqual(engine1.base_y, 0)

        engine2 = YPsychologyEngine(base_y=150)
        self.assertEqual(engine2.base_y, 100)

        engine3 = YPsychologyEngine(base_y=50)
        self.assertEqual(engine3.base_y, 50)

    def test_y_update_bounds(self):
        """Test Y value stays in bounds after updates"""
        engine = YPsychologyEngine(base_y=50)

        # Large negative event
        engine.update(event_delta=-200)
        self.assertGreaterEqual(engine.profile.current_y, 0)

        # Large positive event
        engine.update(event_delta=200)
        self.assertLessEqual(engine.profile.current_y, 100)


class TestTriggerThreshold(unittest.TestCase):
    """Test trigger threshold formula: max(5, floor((100-y)/10))"""

    def test_threshold_formula_y_50(self):
        """Test threshold for Y=50: floor((100-50)/10)=5, max(5,5)=5"""
        engine = YPsychologyEngine(base_y=50)
        self.assertEqual(engine.calculate_trigger_threshold(50), 5)

    def test_threshold_formula_y_0(self):
        """Test threshold for Y=0: floor((100-0)/10)=10, max(5,10)=10"""
        engine = YPsychologyEngine(base_y=50)
        self.assertEqual(engine.calculate_trigger_threshold(0), 10)

    def test_threshold_formula_y_100(self):
        """Test threshold for Y=100: floor((100-100)/10)=0, max(5,0)=5"""
        engine = YPsychologyEngine(base_y=50)
        self.assertEqual(engine.calculate_trigger_threshold(100), 5)

    def test_threshold_minimum_5(self):
        """Test minimum threshold is always 5"""
        engine = YPsychologyEngine(base_y=50)
        # At Y=95: floor((100-95)/10)=0, max(5,0)=5
        self.assertEqual(engine.calculate_trigger_threshold(95), 5)

    def test_utility_function(self):
        """Test calculate_trigger utility function"""
        self.assertEqual(calculate_trigger(50), 5)
        self.assertEqual(calculate_trigger(0), 10)
        self.assertEqual(calculate_trigger(30), 7)


class TestCompensation(unittest.TestCase):
    """Test compensation mechanism"""

    def test_apply_compensation_basic(self):
        """Test basic compensation application"""
        engine = YPsychologyEngine(base_y=50)
        value = engine.apply_compensation(5, 2)
        self.assertEqual(value, 5)
        self.assertEqual(engine.profile.compensation_value, 5)
        self.assertEqual(engine.profile.compensation_remaining, 2)

    def test_compensation_clamping(self):
        """Test compensation value clamping to -10 to +10"""
        engine = YPsychologyEngine()
        engine.apply_compensation(15, 1)
        self.assertEqual(engine.profile.compensation_value, 10)

        engine.apply_compensation(-15, 1)
        self.assertEqual(engine.profile.compensation_value, -10)

    def test_compensation_duration_decay(self):
        """Test compensation duration decays correctly"""
        engine = YPsychologyEngine(base_y=50)
        engine.apply_compensation(5, 3)

        self.assertEqual(engine.profile.compensation_remaining, 3)

        engine.update(event_delta=0, scene_num=1)
        self.assertEqual(engine.profile.compensation_remaining, 2)

        engine.update(event_delta=0, scene_num=2)
        self.assertEqual(engine.profile.compensation_remaining, 1)

        engine.update(event_delta=0, scene_num=3)
        self.assertEqual(engine.profile.compensation_remaining, 0)
        self.assertEqual(engine.profile.compensation_value, 0.0)

    def test_compensation_applied_to_y(self):
        """Test compensation actually affects Y value"""
        engine = YPsychologyEngine(base_y=50)
        initial_y = engine.profile.current_y

        engine.apply_compensation(10, 1)
        engine.update(event_delta=0, scene_num=1)

        # Y should increase due to compensation
        self.assertGreater(engine.profile.current_y, initial_y)


class TestRebound(unittest.TestCase):
    """Test rebound mechanism: y = base_y + (y - base_y) * 0.85"""

    def test_rebound_formula(self):
        """Test rebound calculation formula"""
        engine = YPsychologyEngine(base_y=50)

        # Y above base
        new_y = engine.apply_rebound(60)
        expected = 50 + (60 - 50) * 0.85  # 58.5
        self.assertAlmostEqual(new_y, expected, places=1)

    def test_rebound_at_base(self):
        """Test rebound when Y equals base (no change)"""
        engine = YPsychologyEngine(base_y=50)
        new_y = engine.apply_rebound(50)
        self.assertEqual(new_y, 50)

    def test_rebound_below_base(self):
        """Test rebound when Y below base"""
        engine = YPsychologyEngine(base_y=50)
        new_y = engine.apply_rebound(30)
        expected = 50 + (30 - 50) * 0.85  # 33
        self.assertAlmostEqual(new_y, expected, places=1)

    def test_utility_function(self):
        """Test calculate_rebound utility function"""
        result = calculate_rebound(60, 50)
        self.assertAlmostEqual(result, 58.5, places=1)


class TestStateTransitions(unittest.TestCase):
    """Test Y state transitions"""

    def test_collapse_state(self):
        """Test Y in collapse range (0-15)"""
        engine = YPsychologyEngine(base_y=10)
        self.assertEqual(engine.get_state(10), YState.COLLAPSE)
        self.assertEqual(engine.get_state(0), YState.COLLAPSE)
        self.assertEqual(engine.get_state(15), YState.COLLAPSE)

    def test_low_pressure_state(self):
        """Test Y in low pressure range (16-30)"""
        engine = YPsychologyEngine(base_y=25)
        self.assertEqual(engine.get_state(16), YState.LOW_PRESSURE)
        self.assertEqual(engine.get_state(25), YState.LOW_PRESSURE)
        self.assertEqual(engine.get_state(30), YState.LOW_PRESSURE)

    def test_stable_state(self):
        """Test Y in stable range (31-70)"""
        engine = YPsychologyEngine(base_y=50)
        self.assertEqual(engine.get_state(31), YState.STABLE)
        self.assertEqual(engine.get_state(50), YState.STABLE)
        self.assertEqual(engine.get_state(70), YState.STABLE)

    def test_high_drive_state(self):
        """Test Y in high drive range (71-85)"""
        engine = YPsychologyEngine(base_y=80)
        self.assertEqual(engine.get_state(71), YState.HIGH_DRIVE)
        self.assertEqual(engine.get_state(80), YState.HIGH_DRIVE)
        self.assertEqual(engine.get_state(85), YState.HIGH_DRIVE)

    def test_eruption_state(self):
        """Test Y in eruption range (86-100)"""
        engine = YPsychologyEngine(base_y=90)
        self.assertEqual(engine.get_state(86), YState.ERUPTION)
        self.assertEqual(engine.get_state(90), YState.ERUPTION)
        self.assertEqual(engine.get_state(100), YState.ERUPTION)

    def test_state_boundary(self):
        """Test state at boundaries"""
        self.assertEqual(y_to_state(15), YState.COLLAPSE)
        self.assertEqual(y_to_state(16), YState.LOW_PRESSURE)
        self.assertEqual(y_to_state(30), YState.LOW_PRESSURE)
        self.assertEqual(y_to_state(31), YState.STABLE)
        self.assertEqual(y_to_state(70), YState.STABLE)
        self.assertEqual(y_to_state(71), YState.HIGH_DRIVE)
        self.assertEqual(y_to_state(85), YState.HIGH_DRIVE)
        self.assertEqual(y_to_state(86), YState.ERUPTION)


class TestDeltaYBreakthrough(unittest.TestCase):
    """Test delta_y breakthrough detection"""

    def test_no_breakdown_small_delta(self):
        """Test no breakdown when delta_y is small"""
        engine = YPsychologyEngine(base_y=50)
        engine.profile.last_y = 50
        engine.profile.current_y = 52
        engine.profile.delta_y = 2

        # Y=52, threshold = max(5, floor((100-52)/10)) = max(5, 4) = 5
        # |delta_y| = 2 < 5 * 2 = 10, no breakdown
        threshold = engine.calculate_trigger_threshold(52)
        is_breakdown = abs(2) > threshold * 2
        self.assertFalse(is_breakdown)

    def test_breakdown_large_delta(self):
        """Test breakdown when delta_y exceeds threshold*2"""
        engine = YPsychologyEngine(base_y=50)
        engine.profile.last_y = 50
        engine.profile.current_y = 70
        engine.profile.delta_y = 20

        # Y=70, threshold = 5 (since floor((100-70)/10)=3 < 5)
        # |delta_y| = 20 > 5 * 2 = 10, breakdown triggered
        threshold = engine.calculate_trigger_threshold(70)
        is_breakdown = abs(20) > threshold * 2
        self.assertTrue(is_breakdown)

    def test_update_tracks_delta_y(self):
        """Test update method correctly tracks delta_y"""
        engine = YPsychologyEngine(base_y=50)
        engine.profile.current_y = 50

        engine.update(event_delta=15, scene_num=1)

        self.assertEqual(engine.profile.last_y, 50)
        self.assertNotEqual(engine.profile.delta_y, 0)


class TestPsychologyProfile(unittest.TestCase):
    """Test PsychologyProfile dataclass"""

    def test_default_values(self):
        """Test default profile values"""
        profile = PsychologyProfile()
        self.assertEqual(profile.base_y, 50.0)
        self.assertEqual(profile.current_y, 50.0)
        self.assertEqual(profile.compensation_value, 0.0)
        self.assertEqual(profile.compensation_remaining, 0)
        self.assertEqual(profile.delta_y, 0.0)
        self.assertEqual(profile.breakdown_triggered, False)
        self.assertEqual(profile.event_history, [])

    def test_post_init_sets_last_y(self):
        """Test post_init sets last_y to current_y"""
        profile = PsychologyProfile(base_y=60, current_y=65)
        self.assertEqual(profile.last_y, 65)


if __name__ == '__main__':
    unittest.main()