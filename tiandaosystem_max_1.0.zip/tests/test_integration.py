"""
Integration tests for the complete Tiandao system
Tests: create full character profile, simulate 10 evolution rounds,
verify Y-value transitions, verify memory accumulation
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tiandao.psychology import YPsychologyEngine, YState
from tiandao.mbti import get_profile as get_mbti_profile
from tiandao.memory import MemorySystem, MemoryEntry, MemoryType
from tiandao.motivation import (
    Instinct, generate_motivation_chain, get_decision_framework
)
from tiandao.author import AuthorConstraint, generate_group_portrait_scene


class TestCreateFullCharacterProfile(unittest.TestCase):
    """Test creating a complete character profile with all systems"""

    def setUp(self):
        """Set up complete character"""
        self.mbti_type = "INTJ"
        self.name = "Test Character"

    def test_create_psychology_profile(self):
        """Test creating psychology profile"""
        engine = YPsychologyEngine(base_y=55)
        self.assertIsNotNone(engine.profile)
        self.assertEqual(engine.base_y, 55)
        self.assertGreaterEqual(engine.profile.current_y, 0)
        self.assertLessEqual(engine.profile.current_y, 100)

    def test_create_mbti_profile(self):
        """Test creating MBTI profile"""
        profile = get_mbti_profile(self.mbti_type)
        self.assertEqual(profile.mbti_type, "INTJ")
        self.assertIn("behavior_tendency", profile.__dict__)
        # Check weights are valid
        for w in profile.desire_weights.values():
            self.assertGreaterEqual(w, 0.0)
            self.assertLessEqual(w, 1.0)

    def test_create_memory_system(self):
        """Test creating memory system"""
        ms = MemorySystem(y_base=55)
        self.assertEqual(len(ms.total_memories), 0)
        self.assertEqual(ms.y_base, 55)

    def test_create_motivation_chain(self):
        """Test creating motivation chain"""
        chain = generate_motivation_chain(
            Instinct.KNOWLEDGE,
            "面对学术挑战",
            "INTJ型角色"
        )
        self.assertIsNotNone(chain.surface)
        self.assertIsNotNone(chain.deep)
        self.assertIsNotNone(chain.core)
        self.assertIsNotNone(chain.soul)

    def test_create_decision_framework(self):
        """Test creating decision framework"""
        profile = get_decision_framework("策划者")
        self.assertIsNotNone(profile.primary)
        self.assertIsNotNone(profile.secondary)
        self.assertIn(profile.primary, list(range(1, 8)))  # 7 frameworks

    def test_full_profile_integration(self):
        """Test integrating all components into full profile"""
        # Create components
        psychology = YPsychologyEngine(base_y=60)
        mbti = get_mbti_profile("ENFP")
        memory = MemorySystem(y_base=60)
        motivation = generate_motivation_chain(
            Instinct.EXPRESSION,
            "社交场景",
            "ENFP型角色"
        )
        decision = get_decision_framework("激励者")

        # Verify all components are valid
        self.assertIsNotNone(psychology.profile)
        self.assertIsNotNone(mbti.mbti_type)
        self.assertIsNotNone(memory.y_base)
        self.assertIsNotNone(motivation.instinct)
        self.assertIsNotNone(decision.primary)


class TestSimulate10EvolutionRounds(unittest.TestCase):
    """Test simulating 10 rounds of character evolution"""

    def setUp(self):
        """Set up character for simulation"""
        self.engine = YPsychologyEngine(base_y=50)
        self.memory = MemorySystem(y_base=50)

    def test_10_rounds_psychology_updates(self):
        """Test psychology updates over 10 rounds"""
        initial_y = self.engine.profile.current_y
        y_values = [initial_y]

        for round_num in range(1, 11):
            # Simulate various events
            if round_num <= 3:
                delta = -10  # Negative events
            elif round_num <= 6:
                delta = 5   # Recovery
            else:
                delta = 2   # Gentle fluctuation

            new_y = self.engine.update(event_delta=delta, scene_num=round_num)
            y_values.append(new_y)

        # Verify Y stayed in bounds
        for y in y_values:
            self.assertGreaterEqual(y, 0)
            self.assertLessEqual(y, 100)

        # Verify updates happened
        self.assertEqual(len(y_values), 11)

    def test_10_rounds_memory_accumulation(self):
        """Test memory accumulation over 10 rounds"""
        for i in range(10):
            entry = MemoryEntry(
                name=f"Event_{i}",
                tag="experience",
                content=f"Experience from round {i}",
                weight=0.5 + (i * 0.05),
                emotion=0.1 if i < 5 else -0.1
            )
            self.memory.add(entry, MemoryType.NORMAL)

        self.assertEqual(len(self.memory.total_memories), 10)

    def test_10_rounds_state_transitions(self):
        """Test state transitions over 10 rounds"""
        states = []

        for round_num in range(1, 11):
            # Simulate varying events to trigger state changes
            if round_num == 1:
                delta = -35  # Should go to LOW_PRESSURE
            elif round_num == 4:
                delta = 30   # Should go to STABLE
            elif round_num == 7:
                delta = 35   # Should go to HIGH_DRIVE
            else:
                delta = 0

            self.engine.update(event_delta=delta, scene_num=round_num)
            state = self.engine.get_state()
            states.append(state)

        # Verify we had state changes
        unique_states = set(states)
        self.assertGreater(len(unique_states), 1)

    def test_10_rounds_compensation_decay(self):
        """Test compensation decay over 10 rounds"""
        # Apply compensation in early rounds
        if self.engine.profile.compensation_remaining == 0:
            self.engine.apply_compensation(8, 3)

        initial_comp = self.engine.profile.compensation_value

        for i in range(10):
            self.engine.update(event_delta=0, scene_num=i)

        # Compensation should have decayed
        if initial_comp > 0:
            # After enough updates, compensation should be gone
            self.assertLessEqual(
                self.engine.profile.compensation_remaining,
                3  # Original duration
            )


class TestYValueTransitions(unittest.TestCase):
    """Test Y-value transitions in detail"""

    def setUp(self):
        """Set up psychology engine"""
        self.engine = YPsychologyEngine(base_y=50)

    def test_negative_event_transitions(self):
        """Test Y drops correctly with negative events"""
        self.engine.update(event_delta=-20, scene_num=1)
        # 50 - 20 = 30, then rebound 50 + (30-50)*0.85 = 33
        self.assertLess(self.engine.profile.current_y, 50)

    def test_positive_event_transitions(self):
        """Test Y rises correctly with positive events"""
        self.engine.update(event_delta=20, scene_num=1)
        # 50 + 20 = 70, then rebound 50 + (70-50)*0.85 = 67
        self.assertGreater(self.engine.profile.current_y, 50)

    def test_delta_y_tracking(self):
        """Test delta_y is tracked correctly"""
        self.engine.profile.current_y = 50

        self.engine.update(event_delta=15, scene_num=1)

        # last_y should be 50, current_y should be updated
        self.assertEqual(self.engine.profile.last_y, 50)
        self.assertNotEqual(self.engine.profile.delta_y, 0)

    def test_state_consistency(self):
        """Test state is consistent with Y value"""
        # Test various Y values and their states
        test_cases = [
            (10, YState.COLLAPSE),
            (20, YState.LOW_PRESSURE),
            (50, YState.STABLE),
            (80, YState.HIGH_DRIVE),
            (90, YState.ERUPTION)
        ]

        for y_value, expected_state in test_cases:
            self.engine.profile.current_y = y_value
            actual_state = self.engine.get_state()
            self.assertEqual(
                actual_state, expected_state,
                f"Y={y_value} should be {expected_state}, got {actual_state}"
            )


class TestMemoryAccumulation(unittest.TestCase):
    """Test memory accumulation mechanisms"""

    def setUp(self):
        """Set up memory system"""
        self.memory = MemorySystem()

    def test_normal_memory_accumulation(self):
        """Test normal memories accumulate without limit"""
        for i in range(50):
            entry = MemoryEntry(name=f"n{i}", tag="normal", content=f"c{i}")
            self.memory.add(entry, MemoryType.NORMAL)

        self.assertEqual(len(self.memory.normal_memories), 50)
        self.assertEqual(len(self.memory.total_memories), 50)

    def test_long_term_memory_capped(self):
        """Test long term memory is capped at 20"""
        for i in range(25):
            entry = MemoryEntry(name=f"lt{i}", tag="long", content=f"c{i}")
            self.memory.add(entry, MemoryType.LONG_TERM)

        self.assertLessEqual(len(self.memory.long_term_memories), 20)

    def test_short_term_rotation(self):
        """Test short term memory rotates at max 10"""
        for i in range(25):
            entry = MemoryEntry(name=f"st{i}", tag="short", content=f"c{i}")
            self.memory.add(entry, MemoryType.SHORT_TERM)

        self.assertEqual(len(self.memory.short_term_memories), 10)
        # Oldest entries should be rotated out
        self.assertFalse(any(e.name == "st0" for e in self.memory.short_term_memories))

    def test_abnormal_memory_overflow_penalty(self):
        """Test abnormal memory overflow triggers PTSD penalty"""
        initial_y_base = self.memory.y_base

        # Add 18 abnormal memories (beyond cap of 15)
        for i in range(18):
            entry = MemoryEntry(name=f"ab{i}", tag="trauma", content=f"t{i}")
            self.memory.add(entry, MemoryType.ABNORMAL)

        # Should have overflow penalty
        self.assertGreater(self.memory.y_base, initial_y_base)
        self.assertGreater(self.memory.base_y_offset, 0)

    def test_memory_search_accumulation(self):
        """Test search works with accumulated memories"""
        for i in range(30):
            entry = MemoryEntry(
                name=f"mem{i}",
                tag="search" if i % 2 == 0 else "other",
                content=f"content{i}"
            )
            self.memory.add(entry, MemoryType.NORMAL)

        results = self.memory.search(tag="search")
        self.assertEqual(len(results), 15)  # Half of 30

    def test_memory_stats_accumulation(self):
        """Test stats reflect accumulation correctly"""
        for i in range(15):
            entry = MemoryEntry(name=f"stat{i}", tag="test", content=f"c{i}")
            self.memory.add(entry, MemoryType.NORMAL)

        stats = self.memory.get_memory_stats()
        self.assertEqual(stats['stats']['total_added'], 15)


class TestFullIntegrationScenario(unittest.TestCase):
    """Test complete integration scenario"""

    def test_complete_character_lifecycle(self):
        """Test full character lifecycle with all systems"""

        # 1. Create character with all systems
        psychology = YPsychologyEngine(base_y=55)
        memory = MemorySystem(y_base=55)
        mbti = get_mbti_profile("INTJ")

        # 2. Simulate 10 evolution rounds
        for round_num in range(1, 11):
            # Generate motivation for the round
            instinct = Instinct((round_num % 7) + 1)
            chain = generate_motivation_chain(
                instinct,
                f"场景{round_num}",
                "INTJ角色"
            )

            # Calculate event impact based on motivation
            event_delta = (chain.intensity - 50) / 10  # Convert to delta

            # Update psychology
            new_y = psychology.update(event_delta=event_delta, scene_num=round_num)

            # Add memory for this round
            entry = MemoryEntry(
                name=f"Round_{round_num}",
                tag="evolution",
                content=f"Round {round_num}: Y={new_y:.1f}, chain={chain.surface}",
                weight=0.5 + (round_num * 0.03),
                emotion=1.0 if new_y > 50 else -1.0
            )
            memory.add(entry, MemoryType.NORMAL)

        # 3. Verify Y-value transitions
        self.assertIsNotNone(psychology.profile.current_y)
        self.assertGreaterEqual(psychology.profile.current_y, 0)
        self.assertLessEqual(psychology.profile.current_y, 100)

        # 4. Verify memory accumulation
        self.assertEqual(len(memory.total_memories), 10)
        self.assertEqual(memory.stats['total_added'], 10)

        # 5. Verify MBTI weights still valid
        for w in mbti.desire_weights.values():
            self.assertGreaterEqual(w, 0.0)
            self.assertLessEqual(w, 1.0)

    def test_conflict_scenario_integration(self):
        """Test conflict scenario with multiple characters"""

        # Create group of characters
        characters = [
            {"name": "Leader", "type": "leader", "temperament": "aggressive"},
            {"name": "Thinker", "type": "follower", "temperament": "introverted"},
            {"name": "Actor", "type": "active", "temperament": "active"}
        ]

        # Generate group scene
        scene = generate_group_portrait_scene(characters)
        self.assertIsNotNone(scene)
        self.assertIn("行动派", scene)

        # Apply constraints to all characters
        ac = AuthorConstraint()
        constrained = ac.apply_all_constraints(characters)
        self.assertEqual(len(constrained), 3)

        # Verify constraints applied
        for char in constrained:
            self.assertIn("limitations", char)
            self.assertIn("can_go_rogue", char)

    def test_motivation_memory_integration(self):
        """Test motivation affects memory formation"""
        memory = MemorySystem()

        # Generate chains for different instincts
        for instinct in [Instinct.SURVIVAL, Instinct.KNOWLEDGE, Instinct.EXPRESSION]:
            chain = generate_motivation_chain(
                instinct,
                "测试场景",
                "测试角色"
            )

            # Create memory based on motivation
            entry = MemoryEntry(
                name=f"{instinct.name}事件",
                tag="motivation",
                content=f"动机链: {chain.surface} -> {chain.deep}",
                weight=chain.intensity / 100,  # Higher intensity = stronger memory
                emotion=1.0 if chain.intensity > 70 else 0.0
            )
            memory.add(entry, MemoryType.NORMAL)

        # Verify memories created with appropriate weights
        self.assertEqual(len(memory.total_memories), 3)

        # Survival should have higher intensity (survival is strongest)
        survival_entry = next(
            e for e in memory.total_memories
            if "SURVIVAL" in e.name or "求存" in e.name
        )
        # Intensity should be highest for survival
        self.assertGreaterEqual(survival_entry.weight, 0.6)


class TestSystemResilience(unittest.TestCase):
    """Test system resilience under stress"""

    def test_extreme_y_values(self):
        """Test system handles extreme Y values"""
        engine = YPsychologyEngine(base_y=50)

        # Very negative event
        engine.update(event_delta=-500, scene_num=1)
        self.assertGreaterEqual(engine.profile.current_y, 0)

        # Very positive event
        engine.update(event_delta=500, scene_num=2)
        self.assertLessEqual(engine.profile.current_y, 100)

    def test_massive_memory_addition(self):
        """Test system handles massive memory addition"""
        memory = MemorySystem()

        # Add 100 normal memories
        for i in range(100):
            entry = MemoryEntry(name=f"m{i}", tag="stress", content=f"c{i}")
            memory.add(entry, MemoryType.NORMAL)

        self.assertEqual(len(memory.total_memories), 100)

        # Add 30 abnormal (should trigger multiple PTSD penalties)
        for i in range(30):
            entry = MemoryEntry(name=f"ab{i}", tag="trauma", content=f"t{i}")
            memory.add(entry, MemoryType.ABNORMAL)

        self.assertGreater(memory.stats['ptsd_penalties_applied'], 0)
        self.assertGreater(memory.base_y_offset, 0)

    def test_rapid_state_changes(self):
        """Test system handles rapid state changes"""
        engine = YPsychologyEngine(base_y=50)

        # Rapid oscillation
        for i in range(10):
            if i % 2 == 0:
                engine.update(event_delta=-30, scene_num=i)
            else:
                engine.update(event_delta=30, scene_num=i)

        # System should remain stable (no crashes)
        self.assertIsNotNone(engine.profile.current_y)


if __name__ == '__main__':
    unittest.main()