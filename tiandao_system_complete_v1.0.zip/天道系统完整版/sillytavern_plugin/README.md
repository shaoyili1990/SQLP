# Tiandao System - SillyTavern Plugin

A production-ready SillyTavern plugin that integrates the **Tiandao psychological system** for enhanced character interactions, real-time psychological analysis, and emotional state tracking.

## Features

### Core Features
- **Real-time Psychological Analysis** - Analyze character personalities and messages on the fly
- **Y-Value Tracking** - Monitor and visualize the character's moral/ethical baseline
- **MBTI Profile** - Automatic MBTI personality type inference
- **Memory System** - Track and retrieve relevant memories
- **Motivation Tracking** - Monitor active motivations and instincts
- **PTSD Detection** - Identify trauma triggers
- **Emotional State Visualization** - Visual overlay showing emotional intensity

### UI Features
- **Settings Panel** - Full configuration options
- **Status Bar** - Quick view of connection status and Y-value
- **Psychology Display** - Detailed view of psychological state
- **Toast Notifications** - Non-intrusive alerts
- **Emotional Overlay** - Subtle visual feedback

### Integration
- **Slash Commands** - `/tiandao` commands for quick access
- **System Prompt Injection** - Add psychological context to prompts
- **Character Auto-Analysis** - Analyze on character load
- **Message Auto-Analysis** - Analyze on each message

## Installation

### Prerequisites
1. SillyTavern (v1.11.0 or later)
2. Tiandao Backend Server (running on port 5000 by default)

### Steps

1. **Download the Plugin**
   ```bash
   # Clone or download the plugin files to:
   # SillyTavern/plugins/tiandao_plugin/
   
   # Directory structure should be:
   # SillyTavern/plugins/tiandao_plugin/
   # ├── manifest.json
   # ├── tiandao_plugin.js
   # └── README.md
   ```

2. **Install Backend (if not already installed)**
   ```bash
   cd /tmp/final_workspace/sillytavern_backend
   pip install -r requirements.txt
   python server.py
   ```
   
   The backend will start on `http://localhost:5000`

3. **Enable Plugin in SillyTavern**
   - Open SillyTavern
   - Go to **Settings** → **Extensions** or **Plugins**
   - Find **Tiandao System** in the list
   - Enable the plugin

4. **Configure Backend URL**
   - Click the **Settings** button in the status bar
   - Enter your backend URL (default: `http://localhost:5000`)
   - Click **Test Connection** to verify

## Usage

### Quick Start

1. **Open the Panel** - Click the gear icon in the status bar or type `/tiandao`
2. **Load a Character** - The plugin will automatically analyze the character
3. **Start Chatting** - Messages are analyzed automatically

### Slash Commands

| Command | Description |
|---------|-------------|
| `/tiandao` | Open the settings panel |
| `/tiandao analyze` | Analyze current situation |
| `/tiandao report` | Get full psychology report |
| `/tiandao yvalue` | Show current Y-value |
| `/tiandao reset` | Reset the psychology engine |
| `/tiandao test` | Test backend connection |

**Keyboard Shortcut:** `Ctrl+Shift+T` - Toggle settings panel

### Settings Reference

#### Connection
- **Backend URL** - Address of the Tiandao backend server
- **Test Connection** - Verify connectivity

#### Analysis
- **Enable automatic analysis** - Master switch for auto-analysis
- **Analyze on each message** - Process user/character messages
- **Analyze on character load** - Analyze when switching characters
- **Analysis Depth**:
  - *Quick* - Fast, minimal data
  - *Standard* - Balanced (recommended)
  - *Deep* - Comprehensive analysis

#### Display
- **Show emotional overlay** - Visual emotional feedback
- **Inject context to system prompt** - Add psychology data to prompts

#### Performance
- **Enable response caching** - Cache API responses
- **Debug mode** - Verbose console logging

## API Reference

The plugin communicates with the backend via REST API:

### Endpoints Used

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/api/v1/psychology/calculate` | POST | Calculate psychology response |
| `/api/v1/psychology/y-value` | GET | Get current Y-value |
| `/api/v1/psychology/y-value/trigger` | POST | Trigger Y-value events |
| `/api/v1/psychology/memory` | POST | Add a memory |
| `/api/v1/psychology/memory/retrieve` | POST | Retrieve memories |
| `/api/v1/psychology/ptsd/check` | POST | Check PTSD triggers |
| `/api/v1/psychology/motivation` | GET | Get motivation profile |
| `/api/v1/psychology/full-report` | GET | Get full psychology report |
| `/api/v1/message/format` | POST | Format message with context |
| `/api/v1/system/config` | GET | Get system configuration |

### Request Example

```javascript
// Calculate psychology
POST /api/v1/psychology/calculate
{
  "situation": "The character just witnessed a traumatic event",
  "context": {
    "type": "message_analysis",
    "sender": "character"
  },
  "engine_id": "st_123456_abc123"
}
```

### Response Example

```javascript
{
  "success": true,
  "data": {
    "y_value": 65,
    "emotional_state": {
      "primary_emotion": "fear",
      "morale": 40,
      "stress": 75,
      "intensity": 0.8
    },
    "behavioral_tendency": "defensive",
    "active_motivations": ["survival", "self-preservation"],
    "triggered_memories": [
      {"id": "mem_001", "content": "Previous trauma...", "relevance": 0.9}
    ],
    "moral_adjustment": -5.2,
    "overflow_warning": false,
    "messages": ["You feel your heart racing as the memory surfaces..."]
  }
}
```

## Y-Value System

The Y-value represents a character's moral/ethical baseline (0-100):

| Range | Description |
|-------|-------------|
| 80-100 | High morale, ethical behavior |
| 60-79 | Moderate, balanced |
| 40-59 | Neutral |
| 20-39 | Low, questionable ethics |
| 0-19 | Critical, potentially harmful |

### Triggers
- **Breakthrough** - Major ethical achievement
- **PTSD** - Trauma response
- **Major Event** - Significant moral/dramatic event
- **Emotional Extreme** - Intense emotional state

## Troubleshooting

### Connection Failed
1. Ensure the backend server is running: `python server.py`
2. Check the URL in settings matches the backend address
3. Verify CORS settings in backend config
4. Check browser console for errors

### Analysis Not Working
1. Enable Debug Mode in settings
2. Check browser console for error messages
3. Verify backend logs for request handling
4. Try resetting the engine: `/tiandao reset`

### Plugin Not Loading
1. Verify SillyTavern version (requires 1.11.0+)
2. Check plugin directory structure
3. Enable the plugin in SillyTavern settings
4. Check browser console for JavaScript errors

## File Structure

```
sillytavern_plugin/
├── manifest.json          # Plugin manifest and metadata
├── tiandao_plugin.js      # Main plugin code
├── README.md              # This file
├── example_config.json    # Example configuration
└── sample_character.json  # Sample character for testing
```

## Development

### Adding Custom Analysis
```javascript
// Access the plugin instance
const plugin = window.tiandaoPlugin;

// Custom analysis
const result = await plugin.api.calculatePsychology(
    "Custom situation description",
    { type: "custom", metadata: "value" }
);
```

### Event Hooks
```javascript
// Listen for events
eventBus.on('tiandao:y-value-changed', (data) => {
    console.log('Y-value changed to:', data.y_value);
});
```

## License

MIT License - See LICENSE file for details.

## Support

- **GitHub Issues**: Report bugs and feature requests
- **Documentation**: See the Tiandao System documentation
- **Discord**: Join the community for support

## Credits

- **Tiandao Core**: Psychological engine implementation
- **SillyTavern**: Platform that powers the plugin

---

**Version:** 1.0.0  
**Last Updated:** 2026-04-27
