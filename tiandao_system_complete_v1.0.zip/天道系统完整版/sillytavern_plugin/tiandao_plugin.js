/**
 * SillyTavern Tiandao System Plugin v1.0.0
 * 
 * A production-ready SillyTavern plugin that integrates the Tiandao
 * psychological system for enhanced character interactions.
 * 
 * Features:
 * - Real-time psychological analysis
 * - Character personality tracking (Y-value, MBTI, Memory)
 * - Emotional state visualization
 * - Author constraint enforcement
 * - Memory context injection
 * - Settings panel with full configuration
 * - WebSocket/EventSource for real-time updates
 * - Comprehensive error handling and logging
 * 
 * @author Tiandao System
 * @version 1.0.0
 * @license MIT
 */

(function() {
    'use strict';

    // ==================== CONSTANTS ====================
    
    const PLUGIN_NAME = 'Tiandao System';
    const PLUGIN_VERSION = '1.0.0';
    const PLUGIN_ID = 'tiandao-psychology-plugin';
    
    // Default configuration
    const DEFAULT_CONFIG = {
        backendUrl: 'http://localhost:5000',
        apiBase: '/api/v1',
        autoAnalyze: true,
        autoAnalyzeOnMessage: true,
        autoAnalyzeOnCharacterLoad: true,
        analysisDepth: 'standard', // 'quick', 'standard', 'deep'
        enableCaching: true,
        cacheExpiry: 300000, // 5 minutes
        debugMode: false,
        injectToSystemPrompt: false,
        showEmotionalOverlay: true,
        enableWebSocket: false,
        reconnectInterval: 5000,
        maxRetries: 3,
        requestTimeout: 30000
    };

    // Analysis depth settings
    const ANALYSIS_DEPTHS = {
        quick: {
            endpoint: '/psychology/calculate',
            includeMemories: false,
            includeMotivations: false
        },
        standard: {
            endpoint: '/psychology/calculate',
            includeMemories: true,
            includeMotivations: true
        },
        deep: {
            endpoint: '/psychology/full-report',
            includeMemories: true,
            includeMotivations: true,
            includeDetailedEmotions: true
        }
    };

    // ==================== LOGGER ====================
    
    class TiandaoLogger {
        constructor(prefix = '[Tiandao]') {
            this.prefix = prefix;
            this.enabled = true;
        }

        log(...args) {
            if (this.enabled) {
                console.log(this.prefix, ...args);
            }
        }

        info(...args) {
            if (this.enabled) {
                console.info(this.prefix, '[INFO]', ...args);
            }
        }

        warn(...args) {
            console.warn(this.prefix, '[WARN]', ...args);
        }

        error(...args) {
            console.error(this.prefix, '[ERROR]', ...args);
        }

        debug(...args) {
            if (this.config && this.config.debugMode) {
                console.debug(this.prefix, '[DEBUG]', ...args);
            }
        }

        setConfig(config) {
            this.config = config;
            this.enabled = config.debugMode || true;
        }
    }

    const logger = new TiandaoLogger();

    // ==================== API CLIENT ====================
    
    class TiandaoAPIClient {
        constructor(baseUrl, config) {
            this.baseUrl = baseUrl;
            this.config = config;
            this.engineId = this.generateEngineId();
            this.cache = new Map();
            this.requestController = new AbortController();
        }

        generateEngineId() {
            return `st_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }

        getEndpoint(path) {
            return `${this.baseUrl}${this.config.apiBase}${path}`;
        }

        getCached(key) {
            if (!this.config.enableCaching) return null;
            
            const cached = this.cache.get(key);
            if (cached && Date.now() - cached.timestamp < this.config.cacheExpiry) {
                logger.debug(`Cache hit: ${key}`);
                return cached.data;
            }
            this.cache.delete(key);
            return null;
        }

        setCache(key, data) {
            if (this.config.enableCaching) {
                this.cache.set(key, { data, timestamp: Date.now() });
            }
        }

        clearCache() {
            this.cache.clear();
            logger.info('Cache cleared');
        }

        async request(method, endpoint, data = null, options = {}) {
            const url = endpoint.startsWith('http') ? endpoint : this.getEndpoint(endpoint);
            const cacheKey = `${method}:${url}:${JSON.stringify(data || {})}`;
            
            // Check cache for GET requests
            if (method === 'GET') {
                const cached = this.getCached(cacheKey);
                if (cached) return cached;
            }

            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 
                options.timeout || this.config.requestTimeout);

            try {
                const fetchOptions = {
                    method,
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    signal: controller.signal
                };

                if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
                    fetchOptions.body = JSON.stringify(data);
                }

                logger.debug(`${method} ${url}`, data);

                const response = await fetch(url, fetchOptions);
                clearTimeout(timeoutId);

                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new TiandaoAPIError(
                        errorData.error?.message || `HTTP ${response.status}`,
                        response.status,
                        errorData.error?.code
                    );
                }

                const result = await response.json();
                
                // Cache successful responses
                if (method === 'GET' && result.success !== false) {
                    this.setCache(cacheKey, result);
                }

                return result;
            } catch (error) {
                clearTimeout(timeoutId);
                
                if (error.name === 'AbortError') {
                    throw new TiandaoAPIError('Request timeout', 408, 'TIMEOUT');
                }
                
                if (error instanceof TiandaoAPIError) {
                    throw error;
                }
                
                throw new TiandaoAPIError(error.message, 0, 'NETWORK_ERROR');
            }
        }

        async get(endpoint, options = {}) {
            return this.request('GET', endpoint, null, options);
        }

        async post(endpoint, data, options = {}) {
            return this.request('POST', endpoint, data, options);
        }

        async put(endpoint, data, options = {}) {
            return this.request('PUT', endpoint, data, options);
        }

        async delete(endpoint, options = {}) {
            return this.request('DELETE', endpoint, null, options);
        }

        // Health check
        async healthCheck() {
            try {
                const result = await this.get('/health');
                return result.status === 'healthy';
            } catch (error) {
                logger.error('Health check failed:', error.message);
                return false;
            }
        }

        // Psychology API
        async calculatePsychology(situation, context = {}) {
            const depth = ANALYSIS_DEPTHS[this.config.analysisDepth];
            
            const payload = {
                situation,
                context,
                engine_id: this.engineId
            };

            return this.post(depth.endpoint, payload);
        }

        async getPsychologyReport() {
            return this.get(`/psychology/full-report?engine_id=${this.engineId}`);
        }

        async getYValue() {
            return this.get(`/psychology/y-value?engine_id=${this.engineId}`);
        }

        async triggerYEvent(triggerType, data = {}) {
            return this.post('/psychology/y-value/trigger', {
                ...data,
                trigger_type: triggerType,
                engine_id: this.engineId
            });
        }

        async getMemorySummary() {
            return this.get(`/psychology/memory/summary?engine_id=${this.engineId}`);
        }

        async addMemory(content, options = {}) {
            return this.post('/psychology/memory', {
                content,
                engine_id: this.engineId,
                ...options
            });
        }

        async retrieveMemories(query, options = {}) {
            return this.post('/psychology/memory/retrieve', {
                query,
                engine_id: this.engineId,
                ...options
            });
        }

        async checkPTSD(event) {
            return this.post('/psychology/ptsd/check', {
                event,
                engine_id: this.engineId
            });
        }

        async getMotivationProfile() {
            return this.get(`/psychology/motivation?engine_id=${this.engineId}`);
        }

        async getMBTIProfile() {
            return this.get('/psychology/mbti');
        }

        // Character API
        async createCharacter(characterData) {
            return this.post('/characters', characterData);
        }

        async getCharacter(charId) {
            return this.get(`/characters/${charId}`);
        }

        async analyzeCharacter(charId, text) {
            return this.post(`/characters/${charId}/analyze`, { text });
        }

        // Message formatting
        async formatMessage(content, psychologyOutput = {}, context = {}) {
            return this.post('/message/format', {
                content,
                psychology_output: psychologyOutput,
                context
            });
        }

        async wrapWithContext(content, psychologyOutput = {}, context = {}) {
            return this.post('/message/wrap', {
                content,
                psychology_output: psychologyOutput,
                context
            });
        }

        // System
        async getSystemConfig() {
            return this.get('/system/config');
        }

        async getSystemStats() {
            return this.get('/system/stats');
        }
    }

    // Custom error class
    class TiandaoAPIError extends Error {
        constructor(message, statusCode, code) {
            super(message);
            this.name = 'TiandaoAPIError';
            this.statusCode = statusCode;
            this.code = code;
        }
    }

    // ==================== UI MANAGER ====================
    
    class TiandaoUI {
        constructor(plugin) {
            this.plugin = plugin;
            this.container = null;
            this.statusBar = null;
            this.emotionalOverlay = null;
            this.panel = null;
            this.isInitialized = false;
        }

        async init() {
            if (this.isInitialized) return;

            // Create main container
            this.createMainContainer();
            
            // Create status bar
            this.createStatusBar();
            
            // Create settings panel
            this.createSettingsPanel();
            
            // Create emotional overlay
            if (this.plugin.config.showEmotionalOverlay) {
                this.createEmotionalOverlay();
            }

            // Create psychology display
            this.createPsychologyDisplay();

            this.isInitialized = true;
            logger.info('UI initialized');
        }

        createMainContainer() {
            this.container = document.createElement('div');
            this.container.id = `${PLUGIN_ID}-container`;
            this.container.className = 'tiandao-container';
            
            // Inject styles
            this.injectStyles();
            
            // Append to SillyTavern's main container
            const mainContainer = document.querySelector('#main-window') || 
                                  document.querySelector('.main-window') ||
                                  document.querySelector('body');
            
            if (mainContainer) {
                mainContainer.appendChild(this.container);
            }
        }

        injectStyles() {
            const style = document.createElement('style');
            style.id = `${PLUGIN_ID}-styles`;
            style.textContent = `
                /* Tiandao System Plugin Styles */
                .tiandao-container {
                    --tiandao-primary: #6366f1;
                    --tiandao-secondary: #8b5cf6;
                    --tiandao-success: #22c55e;
                    --tiandao-warning: #f59e0b;
                    --tiandao-error: #ef4444;
                    --tiandao-bg: rgba(30, 30, 40, 0.95);
                    --tiandao-border: rgba(99, 102, 241, 0.3);
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }

                /* Status Bar */
                .tiandao-status-bar {
                    position: fixed;
                    bottom: 10px;
                    right: 320px;
                    background: var(--tiandao-bg);
                    border: 1px solid var(--tiandao-border);
                    border-radius: 8px;
                    padding: 8px 16px;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    font-size: 12px;
                    color: #e2e8f0;
                    z-index: 1000;
                    backdrop-filter: blur(10px);
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                }

                .tiandao-status-bar.connected {
                    border-color: var(--tiandao-success);
                }

                .tiandao-status-bar.disconnected {
                    border-color: var(--tiandao-error);
                }

                .tiandao-status-indicator {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: var(--tiandao-error);
                }

                .tiandao-status-bar.connected .tiandao-status-indicator {
                    background: var(--tiandao-success);
                    box-shadow: 0 0 8px var(--tiandao-success);
                }

                .tiandao-status-text {
                    font-weight: 500;
                }

                .tiandao-status-y-value {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    padding: 4px 8px;
                    background: rgba(99, 102, 241, 0.2);
                    border-radius: 4px;
                }

                .tiandao-y-badge {
                    font-weight: 600;
                    color: var(--tiandao-primary);
                }

                .tiandao-open-panel-btn {
                    background: var(--tiandao-primary);
                    border: none;
                    color: white;
                    padding: 6px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 12px;
                    transition: background 0.2s;
                }

                .tiandao-open-panel-btn:hover {
                    background: var(--tiandao-secondary);
                }

                /* Settings Panel */
                .tiandao-panel {
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    width: 600px;
                    max-height: 80vh;
                    background: var(--tiandao-bg);
                    border: 1px solid var(--tiandao-border);
                    border-radius: 12px;
                    z-index: 2000;
                    display: none;
                    flex-direction: column;
                    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
                }

                .tiandao-panel.open {
                    display: flex;
                }

                .tiandao-panel-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 16px 20px;
                    border-bottom: 1px solid var(--tiandao-border);
                }

                .tiandao-panel-title {
                    font-size: 18px;
                    font-weight: 600;
                    color: #f8fafc;
                    margin: 0;
                }

                .tiandao-panel-close {
                    background: transparent;
                    border: none;
                    color: #94a3b8;
                    font-size: 24px;
                    cursor: pointer;
                    padding: 0;
                    line-height: 1;
                }

                .tiandao-panel-close:hover {
                    color: #f8fafc;
                }

                .tiandao-panel-content {
                    padding: 20px;
                    overflow-y: auto;
                    flex: 1;
                }

                .tiandao-panel-footer {
                    padding: 16px 20px;
                    border-top: 1px solid var(--tiandao-border);
                    display: flex;
                    justify-content: flex-end;
                    gap: 12px;
                }

                /* Form Elements */
                .tiandao-form-group {
                    margin-bottom: 16px;
                }

                .tiandao-form-label {
                    display: block;
                    font-size: 13px;
                    font-weight: 500;
                    color: #e2e8f0;
                    margin-bottom: 6px;
                }

                .tiandao-form-input {
                    width: 100%;
                    padding: 10px 12px;
                    background: rgba(15, 15, 25, 0.8);
                    border: 1px solid var(--tiandao-border);
                    border-radius: 6px;
                    color: #f8fafc;
                    font-size: 14px;
                    box-sizing: border-box;
                }

                .tiandao-form-input:focus {
                    outline: none;
                    border-color: var(--tiandao-primary);
                }

                .tiandao-form-select {
                    width: 100%;
                    padding: 10px 12px;
                    background: rgba(15, 15, 25, 0.8);
                    border: 1px solid var(--tiandao-border);
                    border-radius: 6px;
                    color: #f8fafc;
                    font-size: 14px;
                    cursor: pointer;
                }

                .tiandao-form-checkbox {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    cursor: pointer;
                }

                .tiandao-form-checkbox input {
                    width: 18px;
                    height: 18px;
                    cursor: pointer;
                }

                .tiandao-form-hint {
                    font-size: 11px;
                    color: #64748b;
                    margin-top: 4px;
                }

                /* Section Headers */
                .tiandao-section {
                    margin-bottom: 24px;
                }

                .tiandao-section-title {
                    font-size: 14px;
                    font-weight: 600;
                    color: var(--tiandao-primary);
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    margin-bottom: 12px;
                    padding-bottom: 8px;
                    border-bottom: 1px solid var(--tiandao-border);
                }

                /* Buttons */
                .tiandao-btn {
                    padding: 10px 20px;
                    border-radius: 6px;
                    font-size: 14px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                    border: none;
                }

                .tiandao-btn-primary {
                    background: var(--tiandao-primary);
                    color: white;
                }

                .tiandao-btn-primary:hover {
                    background: var(--tiandao-secondary);
                }

                .tiandao-btn-secondary {
                    background: transparent;
                    border: 1px solid var(--tiandao-border);
                    color: #e2e8f0;
                }

                .tiandao-btn-secondary:hover {
                    background: rgba(99, 102, 241, 0.1);
                }

                .tiandao-btn-danger {
                    background: var(--tiandao-error);
                    color: white;
                }

                /* Psychology Display */
                .tiandao-psychology-display {
                    position: fixed;
                    top: 80px;
                    right: 320px;
                    width: 280px;
                    background: var(--tiandao-bg);
                    border: 1px solid var(--tiandao-border);
                    border-radius: 8px;
                    padding: 16px;
                    display: none;
                    z-index: 900;
                    backdrop-filter: blur(10px);
                }

                .tiandao-psychology-display.visible {
                    display: block;
                }

                .tiandao-psych-display-title {
                    font-size: 13px;
                    font-weight: 600;
                    color: var(--tiandao-primary);
                    margin-bottom: 12px;
                }

                .tiandao-metric {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 10px;
                    font-size: 12px;
                }

                .tiandao-metric-label {
                    color: #94a3b8;
                }

                .tiandao-metric-value {
                    font-weight: 600;
                    color: #f8fafc;
                }

                .tiandao-emotion-bar {
                    height: 6px;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 3px;
                    margin-top: 4px;
                    overflow: hidden;
                }

                .tiandao-emotion-fill {
                    height: 100%;
                    border-radius: 3px;
                    transition: width 0.3s ease;
                }

                .tiandao-motivation-tag {
                    display: inline-block;
                    padding: 3px 8px;
                    background: rgba(99, 102, 241, 0.2);
                    border-radius: 4px;
                    font-size: 11px;
                    color: #c4b5fd;
                    margin: 2px;
                }

                /* Emotional Overlay */
                .tiandao-emotional-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    pointer-events: none;
                    z-index: 1;
                    opacity: 0;
                    transition: opacity 1s ease;
                }

                .tiandao-emotional-overlay.active {
                    opacity: 1;
                }

                /* Toast Notifications */
                .tiandao-toast-container {
                    position: fixed;
                    bottom: 80px;
                    right: 20px;
                    z-index: 3000;
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                }

                .tiandao-toast {
                    padding: 12px 20px;
                    border-radius: 8px;
                    color: white;
                    font-size: 13px;
                    animation: tiandao-slide-in 0.3s ease;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                }

                .tiandao-toast.success {
                    background: var(--tiandao-success);
                }

                .tiandao-toast.error {
                    background: var(--tiandao-error);
                }

                .tiandao-toast.warning {
                    background: var(--tiandao-warning);
                }

                .tiandao-toast.info {
                    background: var(--tiandao-primary);
                }

                @keyframes tiandao-slide-in {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }

                /* Modal Overlay */
                .tiandao-modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 0, 0, 0.6);
                    z-index: 1999;
                    display: none;
                }

                .tiandao-modal-overlay.visible {
                    display: block;
                }

                /* Responsive */
                @media (max-width: 768px) {
                    .tiandao-panel {
                        width: 95%;
                        max-height: 90vh;
                    }

                    .tiandao-psychology-display {
                        display: none !important;
                    }
                }
            `;
            
            document.head.appendChild(style);
        }

        createStatusBar() {
            this.statusBar = document.createElement('div');
            this.statusBar.className = 'tiandao-status-bar disconnected';
            this.statusBar.innerHTML = `
                <div class="tiandao-status-indicator"></div>
                <span class="tiandao-status-text">Disconnected</span>
                <div class="tiandao-status-y-value" style="display: none;">
                    <span>Y:</span>
                    <span class="tiandao-y-badge">--</span>
                </div>
                <button class="tiandao-open-panel-btn" title="Open Tiandao Panel">
                    ⚙️ Settings
                </button>
            `;

            // Event listeners
            const btn = this.statusBar.querySelector('.tiandao-open-panel-btn');
            btn.addEventListener('click', () => this.togglePanel());

            document.body.appendChild(this.statusBar);
        }

        createSettingsPanel() {
            // Create modal overlay
            const overlay = document.createElement('div');
            overlay.className = 'tiandao-modal-overlay';
            overlay.id = `${PLUGIN_ID}-modal-overlay`;
            overlay.addEventListener('click', () => this.closePanel());

            // Create panel
            this.panel = document.createElement('div');
            this.panel.className = 'tiandao-panel';
            this.panel.innerHTML = `
                <div class="tiandao-panel-header">
                    <h2 class="tiandao-panel-title">⚙️ Tiandao System Settings</h2>
                    <button class="tiandao-panel-close">&times;</button>
                </div>
                <div class="tiandao-panel-content">
                    <!-- Connection Section -->
                    <div class="tiandao-section">
                        <h3 class="tiandao-section-title">Connection</h3>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-label">Backend URL</label>
                            <input type="text" class="tiandao-form-input" id="tiandao-backend-url" 
                                   placeholder="http://localhost:5000">
                            <p class="tiandao-form-hint">The URL of the Tiandao backend server</p>
                        </div>
                        <div class="tiandao-form-group">
                            <button class="tiandao-btn tiandao-btn-secondary" id="tiandao-test-connection">
                                Test Connection
                            </button>
                            <span id="tiandao-connection-status" style="margin-left: 12px;"></span>
                        </div>
                    </div>

                    <!-- Analysis Section -->
                    <div class="tiandao-section">
                        <h3 class="tiandao-section-title">Analysis</h3>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-checkbox">
                                <input type="checkbox" id="tiandao-auto-analyze" checked>
                                <span>Enable automatic analysis</span>
                            </label>
                        </div>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-checkbox">
                                <input type="checkbox" id="tiandao-analyze-on-message" checked>
                                <span>Analyze on each message</span>
                            </label>
                        </div>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-checkbox">
                                <input type="checkbox" id="tiandao-analyze-on-load" checked>
                                <span>Analyze on character load</span>
                            </label>
                        </div>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-label">Analysis Depth</label>
                            <select class="tiandao-form-select" id="tiandao-analysis-depth">
                                <option value="quick">Quick (Fast, minimal data)</option>
                                <option value="standard" selected>Standard (Balanced)</option>
                                <option value="deep">Deep (Comprehensive)</option>
                            </select>
                        </div>
                    </div>

                    <!-- Display Section -->
                    <div class="tiandao-section">
                        <h3 class="tiandao-section-title">Display</h3>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-checkbox">
                                <input type="checkbox" id="tiandao-show-overlay" checked>
                                <span>Show emotional overlay</span>
                            </label>
                        </div>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-checkbox">
                                <input type="checkbox" id="tiandao-inject-system">
                                <span>Inject context to system prompt</span>
                            </label>
                        </div>
                    </div>

                    <!-- Performance Section -->
                    <div class="tiandao-section">
                        <h3 class="tiandao-section-title">Performance</h3>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-checkbox">
                                <input type="checkbox" id="tiandao-enable-cache" checked>
                                <span>Enable response caching</span>
                            </label>
                        </div>
                        <div class="tiandao-form-group">
                            <label class="tiandao-form-checkbox">
                                <input type="checkbox" id="tiandao-debug-mode">
                                <span>Debug mode (verbose logging)</span>
                            </label>
                        </div>
                        <div class="tiandao-form-group">
                            <button class="tiandao-btn tiandao-btn-secondary" id="tiandao-clear-cache">
                                Clear Cache
                            </button>
                        </div>
                    </div>

                    <!-- Actions Section -->
                    <div class="tiandao-section">
                        <h3 class="tiandao-section-title">Actions</h3>
                        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                            <button class="tiandao-btn tiandao-btn-secondary" id="tiandao-analyze-current">
                                🔍 Analyze Current State
                            </button>
                            <button class="tiandao-btn tiandao-btn-secondary" id="tiandao-get-report">
                                📊 Get Full Report
                            </button>
                            <button class="tiandao-btn tiandao-btn-secondary" id="tiandao-reset-engine">
                                🔄 Reset Engine
                            </button>
                        </div>
                    </div>
                </div>
                <div class="tiandao-panel-footer">
                    <button class="tiandao-btn tiandao-btn-secondary" id="tiandao-save-defaults">
                        Save as Defaults
                    </button>
                    <button class="tiandao-btn tiandao-btn-primary" id="tiandao-save-settings">
                        Save Settings
                    </button>
                </div>
            `;

            // Add to DOM
            document.body.appendChild(overlay);
            document.body.appendChild(this.panel);

            // Bind event listeners
            this.bindSettingsEvents();
        }

        bindSettingsEvents() {
            const panel = this.panel;
            
            // Close button
            panel.querySelector('.tiandao-panel-close').addEventListener('click', () => this.closePanel());
            
            // Test connection
            panel.querySelector('#tiandao-test-connection').addEventListener('click', async () => {
                const statusEl = panel.querySelector('#tiandao-connection-status');
                statusEl.textContent = 'Testing...';
                statusEl.style.color = '#f59e0b';
                
                try {
                    const url = panel.querySelector('#tiandao-backend-url').value;
                    const testApi = new TiandaoAPIClient(url, { apiBase: '/api/v1', enableCaching: false });
                    const healthy = await testApi.healthCheck();
                    
                    if (healthy) {
                        statusEl.textContent = '✅ Connected';
                        statusEl.style.color = '#22c55e';
                        this.showToast('Successfully connected to backend!', 'success');
                    } else {
                        throw new Error('Health check failed');
                    }
                } catch (error) {
                    statusEl.textContent = '❌ Failed';
                    statusEl.style.color = '#ef4444';
                    this.showToast(`Connection failed: ${error.message}`, 'error');
                }
            });

            // Clear cache
            panel.querySelector('#tiandao-clear-cache').addEventListener('click', () => {
                this.plugin.api.clearCache();
                this.showToast('Cache cleared', 'info');
            });

            // Analyze current
            panel.querySelector('#tiandao-analyze-current').addEventListener('click', async () => {
                await this.plugin.analyzeCurrentSituation();
            });

            // Get report
            panel.querySelector('#tiandao-get-report').addEventListener('click', async () => {
                await this.plugin.getFullReport();
            });

            // Reset engine
            panel.querySelector('#tiandao-reset-engine').addEventListener('click', async () => {
                this.plugin.resetEngine();
                this.showToast('Engine reset', 'info');
            });

            // Save settings
            panel.querySelector('#tiandao-save-settings').addEventListener('click', () => {
                this.saveSettingsFromUI();
                this.closePanel();
                this.showToast('Settings saved!', 'success');
            });

            // Save as defaults
            panel.querySelector('#tiandao-save-defaults').addEventListener('click', () => {
                this.saveSettingsFromUI();
                this.plugin.saveAsDefaults();
                this.showToast('Settings saved as defaults!', 'success');
            });
        }

        saveSettingsFromUI() {
            const panel = this.panel;
            
            this.plugin.updateConfig({
                backendUrl: panel.querySelector('#tiandao-backend-url').value,
                autoAnalyze: panel.querySelector('#tiandao-auto-analyze').checked,
                autoAnalyzeOnMessage: panel.querySelector('#tiandao-analyze-on-message').checked,
                autoAnalyzeOnCharacterLoad: panel.querySelector('#tiandao-analyze-on-load').checked,
                analysisDepth: panel.querySelector('#tiandao-analysis-depth').value,
                showEmotionalOverlay: panel.querySelector('#tiandao-show-overlay').checked,
                injectToSystemPrompt: panel.querySelector('#tiandao-inject-system').checked,
                enableCaching: panel.querySelector('#tiandao-enable-cache').checked,
                debugMode: panel.querySelector('#tiandao-debug-mode').checked
            });

            this.plugin.reinitializeAPI();
        }

        loadSettingsToUI() {
            const panel = this.panel;
            const config = this.plugin.config;
            
            panel.querySelector('#tiandao-backend-url').value = config.backendUrl;
            panel.querySelector('#tiandao-auto-analyze').checked = config.autoAnalyze;
            panel.querySelector('#tiandao-analyze-on-message').checked = config.autoAnalyzeOnMessage;
            panel.querySelector('#tiandao-analyze-on-load').checked = config.autoAnalyzeOnCharacterLoad;
            panel.querySelector('#tiandao-analysis-depth').value = config.analysisDepth;
            panel.querySelector('#tiandao-show-overlay').checked = config.showEmotionalOverlay;
            panel.querySelector('#tiandao-inject-system').checked = config.injectToSystemPrompt;
            panel.querySelector('#tiandao-enable-cache').checked = config.enableCaching;
            panel.querySelector('#tiandao-debug-mode').checked = config.debugMode;
        }

        togglePanel() {
            if (this.panel.classList.contains('open')) {
                this.closePanel();
            } else {
                this.openPanel();
            }
        }

        openPanel() {
            this.loadSettingsToUI();
            this.panel.classList.add('open');
            document.getElementById(`${PLUGIN_ID}-modal-overlay`).classList.add('visible');
        }

        closePanel() {
            this.panel.classList.remove('open');
            document.getElementById(`${PLUGIN_ID}-modal-overlay`).classList.remove('visible');
        }

        createEmotionalOverlay() {
            this.emotionalOverlay = document.createElement('div');
            this.emotionalOverlay.className = 'tiandao-emotional-overlay';
            document.body.appendChild(this.emotionalOverlay);
        }

        createPsychologyDisplay() {
            const display = document.createElement('div');
            display.className = 'tiandao-psychology-display';
            display.id = `${PLUGIN_ID}-psychology-display`;
            display.innerHTML = `
                <div class="tiandao-psych-display-title">Psychological State</div>
                <div class="tiandao-metric">
                    <span class="tiandao-metric-label">Y-Value</span>
                    <span class="tiandao-metric-value" id="tiandao-display-y">--</span>
                </div>
                <div class="tiandao-metric">
                    <span class="tiandao-metric-label">Morale</span>
                    <div class="tiandao-emotion-bar">
                        <div class="tiandao-emotion-fill" id="tiandao-morale-bar" style="width: 50%; background: #6366f1;"></div>
                    </div>
                </div>
                <div class="tiandao-metric">
                    <span class="tiandao-metric-label">Stress</span>
                    <div class="tiandao-emotion-bar">
                        <div class="tiandao-emotion-fill" id="tiandao-stress-bar" style="width: 0%; background: #ef4444;"></div>
                    </div>
                </div>
                <div style="margin-top: 12px;">
                    <span class="tiandao-metric-label">Active Motivations</span>
                    <div id="tiandao-motivations" style="margin-top: 6px;"></div>
                </div>
            `;

            document.body.appendChild(display);
        }

        updateConnectionStatus(connected, message = '') {
            const indicator = this.statusBar.querySelector('.tiandao-status-indicator');
            const text = this.statusBar.querySelector('.tiandao-status-text');
            const yValueContainer = this.statusBar.querySelector('.tiandao-status-y-value');

            if (connected) {
                this.statusBar.classList.remove('disconnected');
                this.statusBar.classList.add('connected');
                text.textContent = message || 'Connected';
                yValueContainer.style.display = 'flex';
            } else {
                this.statusBar.classList.remove('connected');
                this.statusBar.classList.add('disconnected');
                text.textContent = message || 'Disconnected';
                yValueContainer.style.display = 'none';
            }
        }

        updateYValue(yValue) {
            const badge = this.statusBar.querySelector('.tiandao-y-badge');
            badge.textContent = yValue;

            // Color based on Y value
            let color = '#6366f1';
            if (yValue >= 80) color = '#22c55e';
            else if (yValue >= 60) color = '#6366f1';
            else if (yValue >= 40) color = '#f59e0b';
            else color = '#ef4444';

            badge.style.color = color;
        }

        updatePsychologyDisplay(data) {
            const display = document.getElementById(`${PLUGIN_ID}-psychology-display`);
            if (!display) return;

            if (data.y_value !== undefined) {
                display.querySelector('#tiandao-display-y').textContent = data.y_value;
            }

            if (data.emotional_state) {
                const morale = data.emotional_state.morale || 50;
                const stress = data.emotional_state.stress || 0;

                display.querySelector('#tiandao-morale-bar').style.width = `${morale}%`;
                display.querySelector('#tiandao-stress-bar').style.width = `${stress}%`;
            }

            if (data.active_motivations && data.active_motivations.length > 0) {
                const motivContainer = display.querySelector('#tiandao-motivations');
                motivContainer.innerHTML = data.active_motivations
                    .slice(0, 3)
                    .map(m => `<span class="tiandao-motivation-tag">${m}</span>`)
                    .join('');
            }

            display.classList.add('visible');
        }

        showPsychologyDisplay() {
            const display = document.getElementById(`${PLUGIN_ID}-psychology-display`);
            if (display) display.classList.add('visible');
        }

        hidePsychologyDisplay() {
            const display = document.getElementById(`${PLUGIN_ID}-psychology-display`);
            if (display) display.classList.remove('visible');
        }

        setEmotionalOverlay(intensity, hue = 240) {
            if (!this.emotionalOverlay) return;
            
            this.emotionalOverlay.style.background = 
                `radial-gradient(ellipse at center, 
                  hsla(${hue}, 70%, 50%, ${intensity * 0.3}) 0%, 
                  transparent 70%)`;
            
            if (intensity > 0.1) {
                this.emotionalOverlay.classList.add('active');
            } else {
                this.emotionalOverlay.classList.remove('active');
            }
        }

        showToast(message, type = 'info') {
            let container = document.querySelector('.tiandao-toast-container');
            if (!container) {
                container = document.createElement('div');
                container.className = 'tiandao-toast-container';
                document.body.appendChild(container);
            }

            const toast = document.createElement('div');
            toast.className = `tiandao-toast ${type}`;
            toast.textContent = message;
            container.appendChild(toast);

            setTimeout(() => {
                toast.style.animation = 'tiandao-slide-in 0.3s ease reverse';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        destroy() {
            if (this.container) this.container.remove();
            if (this.statusBar) this.statusBar.remove();
            if (this.panel) this.panel.remove();
            if (this.emotionalOverlay) this.emotionalOverlay.remove();
            
            const display = document.getElementById(`${PLUGIN_ID}-psychology-display`);
            if (display) display.remove();
            
            const overlay = document.getElementById(`${PLUGIN_ID}-modal-overlay`);
            if (overlay) overlay.remove();
            
            const styles = document.getElementById(`${PLUGIN_ID}-styles`);
            if (styles) styles.remove();
            
            const toasts = document.querySelector('.tiandao-toast-container');
            if (toasts) toasts.remove();
        }
    }

    // ==================== EVENT HANDLERS ====================
    
    class TiandaoEventHandlers {
        constructor(plugin) {
            this.plugin = plugin;
            this.boundHandlers = {};
        }

        register() {
            logger.info('Registering event handlers...');

            // Character load
            this.boundHandlers.onCharacterLoaded = this.onCharacterLoaded.bind(this);
            document.addEventListener('click', this.boundHandlers.onCharacterLoaded);

            // Message sent/received
            this.boundHandlers.onMessageSent = this.onMessageSent.bind(this);
            this.boundHandlers.onMessageReceived = this.onMessageReceived.bind(this);
            
            // Use SillyTavern's event system if available
            if (window.eventBus) {
                window.eventBus.on('ai-message', this.boundHandlers.onMessageReceived);
                window.eventBus.on('user-message', this.boundHandlers.onMessageSent);
                window.eventBus.on('character-updated', this.boundHandlers.onCharacterLoaded);
            }

            // Mutation observer for dynamic content
            this.setupMutationObserver();

            // Keyboard shortcuts
            this.boundHandlers.onKeyDown = this.onKeyDown.bind(this);
            document.addEventListener('keydown', this.boundHandlers.onKeyDown);

            logger.info('Event handlers registered');
        }

        setupMutationObserver() {
            const observer = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        for (const node of mutation.addedNodes) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                this.processNewElement(node);
                            }
                        }
                    }
                }
            });

            observer.observe(document.body, { childList: true, subtree: true });
        }

        processNewElement(element) {
            // Find send button and attach listener if not already done
            const sendButton = element.querySelector?.('#send_new_form button') || 
                              element.querySelector?.('.btn-send') ||
                              element.querySelector?.('[id*="send"]');

            if (sendButton && !sendButton.hasAttribute('data-tiandao-bound')) {
                sendButton.setAttribute('data-tiandao-bound', 'true');
                sendButton.addEventListener('click', () => {
                    // Small delay to allow message to be added to DOM
                    setTimeout(() => this.onMessageSent(), 100);
                });
            }
        }

        async onCharacterLoaded(event) {
            // Check if this is a character-related click
            const target = event.target;
            if (!target.closest) return;

            const characterButton = target.closest('[class*="character"], [id*="character"], .character-select');
            if (!characterButton) return;

            // Add small delay to allow character data to load
            setTimeout(async () => {
                if (this.plugin.config.autoAnalyzeOnCharacterLoad) {
                    await this.plugin.analyzeCharacterCard();
                }
            }, 500);
        }

        async onMessageSent() {
            if (!this.plugin.config.autoAnalyzeOnMessage) return;

            try {
                const messageInput = await this.getMessageInput();
                if (messageInput) {
                    const message = messageInput.value.trim();
                    if (message) {
                        await this.plugin.analyzeMessage(message, 'user');
                    }
                }
            } catch (error) {
                logger.warn('Could not get message input:', error.message);
            }
        }

        async onMessageReceived(message) {
            if (!this.plugin.config.autoAnalyzeOnMessage) return;

            try {
                if (typeof message === 'string') {
                    await this.plugin.analyzeMessage(message, 'character');
                }
            } catch (error) {
                logger.warn('Could not analyze received message:', error.message);
            }
        }

        async getMessageInput() {
            // Try multiple selectors
            const selectors = [
                '#prompt_input',
                '#send_new_form textarea',
                '.prompt-input',
                '[id*="prompt"]',
                '[class*="prompt"]'
            ];

            for (const selector of selectors) {
                const element = document.querySelector(selector);
                if (element && element.tagName === 'TEXTAREA') {
                    return element;
                }
            }

            return null;
        }

        onKeyDown(event) {
            // Ctrl+Shift+T to toggle panel
            if (event.ctrlKey && event.shiftKey && event.key === 'T') {
                event.preventDefault();
                this.plugin.ui.togglePanel();
            }
        }

        unregister() {
            document.removeEventListener('click', this.boundHandlers.onCharacterLoaded);
            document.removeEventListener('keydown', this.boundHandlers.onKeyDown);

            if (window.eventBus) {
                window.eventBus.off('ai-message', this.boundHandlers.onMessageReceived);
                window.eventBus.off('user-message', this.boundHandlers.onMessageSent);
                window.eventBus.off('character-updated', this.boundHandlers.onCharacterLoaded);
            }

            logger.info('Event handlers unregistered');
        }
    }

    // ==================== MAIN PLUGIN CLASS ====================
    
    class TiandaoPlugin {
        constructor() {
            this.config = { ...DEFAULT_CONFIG };
            this.api = null;
            this.ui = null;
            this.eventHandlers = null;
            this.isInitialized = false;
            this.currentCharacter = null;
            this.lastAnalysis = null;
        }

        async init() {
            logger.info('Initializing Tiandao System Plugin...');

            try {
                // Load saved configuration
                this.loadConfig();

                // Initialize API client
                this.reinitializeAPI();

                // Initialize UI
                this.ui = new TiandaoUI(this);
                await this.ui.init();

                // Test backend connection
                await this.testConnection();

                // Register event handlers
                this.eventHandlers = new TiandaoEventHandlers(this);
                this.eventHandlers.register();

                // Add slash commands
                this.registerSlashCommands();

                this.isInitialized = true;
                logger.info('Tiandao System Plugin initialized successfully');

            } catch (error) {
                logger.error('Failed to initialize plugin:', error);
                throw error;
            }
        }

        loadConfig() {
            try {
                const saved = localStorage.getItem(`${PLUGIN_ID}_config`);
                if (saved) {
                    const parsed = JSON.parse(saved);
                    this.config = { ...DEFAULT_CONFIG, ...parsed };
                    logger.info('Configuration loaded from storage');
                }
            } catch (error) {
                logger.warn('Failed to load config, using defaults:', error.message);
            }
            
            logger.setConfig(this.config);
        }

        saveConfig() {
            try {
                localStorage.setItem(`${PLUGIN_ID}_config`, JSON.stringify(this.config));
                logger.info('Configuration saved');
            } catch (error) {
                logger.error('Failed to save config:', error);
            }
        }

        saveAsDefaults() {
            try {
                localStorage.setItem(`${PLUGIN_ID}_defaults`, JSON.stringify(this.config));
                this.saveConfig();
                this.ui.showToast('Default settings saved!', 'success');
            } catch (error) {
                logger.error('Failed to save defaults:', error);
            }
        }

        updateConfig(updates) {
            this.config = { ...this.config, ...updates };
            this.saveConfig();
            logger.setConfig(this.config);
            logger.info('Configuration updated:', Object.keys(updates));
        }

        reinitializeAPI() {
            if (this.api) {
                // Clean up old API instance
            }
            this.api = new TiandaoAPIClient(this.config.backendUrl, this.config);
            logger.info(`API client initialized with backend: ${this.config.backendUrl}`);
        }

        async testConnection() {
            try {
                const healthy = await this.api.healthCheck();
                if (healthy) {
                    this.ui.updateConnectionStatus(true, 'Connected');
                    logger.info('Backend connection successful');
                    return true;
                }
            } catch (error) {
                this.ui.updateConnectionStatus(false, 'Connection failed');
                logger.warn('Backend connection failed:', error.message);
                return false;
            }
        }

        async analyzeCharacterCard() {
            logger.info('Analyzing character card...');

            try {
                // Get character data from SillyTavern
                const characterData = await this.getCurrentCharacterData();
                if (!characterData) {
                    logger.warn('No character data found');
                    return null;
                }

                // Combine relevant fields for analysis
                const analysisText = [
                    characterData.name,
                    characterData.description,
                    characterData.personality,
                    characterData.first_message,
                    characterData.scenario
                ].filter(Boolean).join('\n\n');

                const result = await this.api.calculatePsychology(analysisText, {
                    type: 'character_analysis',
                    character_name: characterData.name
                });

                if (result.success) {
                    this.currentCharacter = characterData;
                    this.lastAnalysis = result.data;
                    this.ui.updateYValue(result.data.y_value);
                    this.ui.updatePsychologyDisplay(result.data);
                    
                    if (this.config.injectToSystemPrompt) {
                        await this.injectPsychologyContext(result.data);
                    }

                    logger.info('Character analysis complete:', result.data.y_value);
                    this.ui.showToast('Character analyzed!', 'success');
                }

                return result;

            } catch (error) {
                logger.error('Character analysis failed:', error);
                this.ui.showToast('Analysis failed: ' + error.message, 'error');
                return null;
            }
        }

        async analyzeMessage(message, sender = 'unknown') {
            logger.debug(`Analyzing ${sender} message:`, message.substring(0, 100));

            try {
                const context = {
                    type: 'message_analysis',
                    sender,
                    character_name: this.currentCharacter?.name || 'Unknown'
                };

                const result = await this.api.calculatePsychology(message, context);

                if (result.success) {
                    this.lastAnalysis = result.data;
                    this.ui.updateYValue(result.data.y_value);
                    this.ui.updatePsychologyDisplay(result.data);

                    // Update emotional overlay based on intensity
                    if (result.data.emotional_state?.intensity) {
                        this.ui.setEmotionalOverlay(
                            result.data.emotional_state.intensity,
                            this.getEmotionHue(result.data.emotional_state.primary_emotion)
                        );
                    }

                    // Check for overflow warnings
                    if (result.data.overflow_warning) {
                        this.ui.showToast('⚠️ Emotional overflow detected!', 'warning');
                    }

                    // Check for PTSD triggers
                    if (result.data.ptsd_triggered) {
                        this.ui.showToast('⚠️ PTSD trigger detected!', 'warning');
                    }
                }

                return result;

            } catch (error) {
                logger.error('Message analysis failed:', error);
                return null;
            }
        }

        async analyzeCurrentSituation() {
            logger.info('Analyzing current situation...');

            try {
                // Try to get context from current chat
                const chatContext = await this.getChatContext();
                const situation = chatContext || 'General interaction';

                const result = await this.api.calculatePsychology(situation, {
                    type: 'situation_analysis'
                });

                if (result.success) {
                    this.lastAnalysis = result.data;
                    this.ui.updateYValue(result.data.y_value);
                    this.ui.updatePsychologyDisplay(result.data);
                    this.ui.showPsychologyDisplay();
                    this.ui.showToast('Analysis complete!', 'success');
                }

                return result;

            } catch (error) {
                logger.error('Situation analysis failed:', error);
                this.ui.showToast('Analysis failed: ' + error.message, 'error');
                return null;
            }
        }

        async getFullReport() {
            logger.info('Getting full psychology report...');

            try {
                const result = await this.api.getPsychologyReport();

                if (result.success) {
                    this.ui.showPsychologyDisplay();
                    this.ui.showToast('Report generated!', 'success');
                    console.log('[Tiandao] Full Report:', result.data);
                }

                return result;

            } catch (error) {
                logger.error('Failed to get report:', error);
                this.ui.showToast('Report failed: ' + error.message, 'error');
                return null;
            }
        }

        async getCurrentCharacterData() {
            // Try to get character from SillyTavern's global state
            try {
                if (window.characterData) {
                    return window.characterData;
                }
                if (window.this_chat) {
                    return window.this_chat;
                }
                
                // Try to find character data in the DOM
                const charElement = document.querySelector('[data-character-id]');
                if (charElement) {
                    return charElement.dataset;
                }
            } catch (error) {
                logger.debug('Could not retrieve character data:', error.message);
            }

            return null;
        }

        async getChatContext() {
            // Try to get recent messages for context
            try {
                const messages = [];
                const messageElements = document.querySelectorAll('.message, .mes');

                for (const el of messageElements) {
                    const role = el.classList.contains('user') ? 'user' : 'character';
                    const content = el.querySelector('.message-content, .mes_text')?.textContent;
                    if (content) {
                        messages.push({ role, content });
                    }
                }

                if (messages.length > 0) {
                    return messages.slice(-5).map(m => `${m.role}: ${m.content}`).join('\n');
                }
            } catch (error) {
                logger.debug('Could not get chat context:', error.message);
            }

            return null;
        }

        async injectPsychologyContext(psychologyData) {
            logger.info('Injecting psychology context to system prompt...');

            try {
                const context = this.formatPsychologyContext(psychologyData);
                
                // Find system prompt input
                const systemPromptInput = document.querySelector('#systemPrompt textarea, #system_prompt textarea');
                if (systemPromptInput) {
                    const currentValue = systemPromptInput.value;
                    const injection = `\n\n[Tiandao Psychology Context]\n${context}\n[/Tiandao Psychology Context]\n`;
                    
                    if (!currentValue.includes('[Tiandao Psychology Context]')) {
                        systemPromptInput.value = currentValue + injection;
                        systemPromptInput.dispatchEvent(new Event('input', { bubbles: true }));
                        logger.info('Psychology context injected');
                    }
                }

            } catch (error) {
                logger.error('Failed to inject context:', error);
            }
        }

        formatPsychologyContext(data) {
            const lines = [];
            
            if (data.y_value !== undefined) {
                lines.push(`Y-Value: ${data.y_value}`);
            }
            if (data.emotional_state?.primary_emotion) {
                lines.push(`Primary Emotion: ${data.emotional_state.primary_emotion}`);
            }
            if (data.behavioral_tendency) {
                lines.push(`Behavioral Tendency: ${data.behavioral_tendency}`);
            }
            if (data.active_motivations?.length > 0) {
                lines.push(`Active Motivations: ${data.active_motivations.join(', ')}`);
            }
            if (data.overflow_warning) {
                lines.push('⚠️ Emotional state is critical');
            }

            return lines.join('\n');
        }

        getEmotionHue(emotion) {
            const emotionHues = {
                joy: 50,
                sadness: 220,
                anger: 0,
                fear: 280,
                surprise: 60,
                disgust: 120,
                trust: 200,
                anticipation: 30
            };
            return emotionHues[emotion?.toLowerCase()] || 240;
        }

        resetEngine() {
            this.api.engineId = this.api.generateEngineId();
            this.api.clearCache();
            this.lastAnalysis = null;
            this.ui.hidePsychologyDisplay();
            logger.info('Engine reset');
        }

        registerSlashCommands() {
            // Register /tiandao commands
            const commands = [
                { cmd: '/tiandao', desc: 'Open Tiandao panel', handler: () => this.ui.openPanel() },
                { cmd: '/tiandao analyze', desc: 'Analyze current state', handler: () => this.analyzeCurrentSituation() },
                { cmd: '/tiandao report', desc: 'Get full psychology report', handler: () => this.getFullReport() },
                { cmd: '/tiandao yvalue', desc: 'Show current Y-value', handler: () => this.showYValue() },
                { cmd: '/tiandao reset', desc: 'Reset psychology engine', handler: () => this.resetEngine() },
                { cmd: '/tiandao test', desc: 'Test backend connection', handler: () => this.testConnection() }
            ];

            // Store commands for later use
            this.commands = commands;
            logger.info('Slash commands registered:', commands.map(c => c.cmd).join(', '));
        }

        async showYValue() {
            try {
                const result = await this.api.getYValue();
                if (result.success) {
                    this.ui.showToast(`Current Y-Value: ${result.data.current_y}`, 'info');
                }
            } catch (error) {
                this.ui.showToast('Failed to get Y-Value', 'error');
            }
        }

        async addMemory(content, options = {}) {
            try {
                const result = await this.api.addMemory(content, options);
                if (result.success) {
                    this.ui.showToast('Memory added!', 'success');
                }
                return result;
            } catch (error) {
                logger.error('Failed to add memory:', error);
                this.ui.showToast('Failed to add memory', 'error');
                return null;
            }
        }

        async retrieveRelevantMemories(query, options = {}) {
            try {
                return await this.api.retrieveMemories(query, options);
            } catch (error) {
                logger.error('Failed to retrieve memories:', error);
                return null;
            }
        }

        async checkPTSDTriggers(event) {
            try {
                const result = await this.api.checkPTSD(event);
                if (result.success && result.data.triggered) {
                    this.ui.showToast('⚠️ PTSD triggers detected!', 'warning');
                }
                return result;
            } catch (error) {
                logger.error('PTSD check failed:', error);
                return null;
            }
        }

        async triggerBreakthrough(targetY) {
            try {
                const result = await this.api.triggerYEvent('breakthrough', { value: targetY });
                if (result.success) {
                    this.ui.updateYValue(result.data.new_y);
                    this.ui.showToast(`Breakthrough triggered! Y: ${result.data.old_y} → ${result.data.new_y}`, 'success');
                }
                return result;
            } catch (error) {
                logger.error('Breakthrough trigger failed:', error);
                return null;
            }
        }

        async triggerPTSD(traumaY) {
            try {
                const result = await this.api.triggerYEvent('ptsd', { value: traumaY });
                if (result.success) {
                    this.ui.updateYValue(result.data.new_y);
                    this.ui.showToast(`PTSD triggered! Y: ${result.data.old_y} → ${result.data.new_y}`, 'warning');
                }
                return result;
            } catch (error) {
                logger.error('PTSD trigger failed:', error);
                return null;
            }
        }

        unload() {
            logger.info('Unloading Tiandao System Plugin...');

            if (this.eventHandlers) {
                this.eventHandlers.unregister();
            }

            if (this.ui) {
                this.ui.destroy();
            }

            this.saveConfig();
            
            // Remove from global scope
            delete window.tiandaoPlugin;
            
            logger.info('Plugin unloaded');
        }
    }

    // ==================== PLUGIN ENTRY POINT ====================
    
    // Create and initialize the plugin
    let pluginInstance = null;

    async function initializePlugin() {
        try {
            pluginInstance = new TiandaoPlugin();
            await pluginInstance.init();
            
            // Expose to global scope for external access
            window.tiandaoPlugin = pluginInstance;
            
            logger.info('Tiandao System Plugin ready!');
            console.log(`
%c╔═══════════════════════════════════════════════════╗
║  ⚡ Tiandao System Plugin v${PLUGIN_VERSION} Loaded ⚡        ║
║                                                   ║
║  Type /tiandao to open the settings panel        ║
║  Ctrl+Shift+T to toggle panel                    ║
║                                                   ║
║  Backend: ${pluginInstance.config.backendUrl.padEnd(27)}║
╚═══════════════════════════════════════════════════╝
`, 'color: #6366f1; font-weight: bold;');

            return pluginInstance;

        } catch (error) {
            console.error('[Tiandao] Plugin initialization failed:', error);
            throw error;
        }
    }

    // Auto-initialize when SillyTavern is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializePlugin);
    } else {
        // DOM already loaded, initialize with small delay to ensure SillyTavern is ready
        setTimeout(initializePlugin, 1000);
    }

    // Export for module usage
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = { TiandaoPlugin, TiandaoAPIClient, TiandaoUI, TiandaoAPIError };
    }

})();
