"""
Test Configuration and Fixtures
"""

import pytest
import sys
import os

# Add tiandao core to path
sys.path.insert(0, '/tmp/final_workspace/tiandao_core')
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server import create_app
from tiandao.core.psychology import PsychologyEngine
from tiandao.core.profile import CharacterProfile


@pytest.fixture
def app():
    """Create application for testing"""
    app = create_app()
    app.config['TESTING'] = True
    return app


@pytest.fixture
def client(app):
    """Create test client"""
    return app.test_client()


@pytest.fixture
def psychology_engine():
    """Create a fresh psychology engine"""
    return PsychologyEngine(base_y=50, mbti_type="INTJ")


@pytest.fixture
def character_profile():
    """Create a sample character profile"""
    return CharacterProfile.create(
        character_id="test_char",
        name="Test Character",
        base_y=50,
        mbti_type="INTJ",
        tags=["测试", "理性"],
        description="A test character"
    )


@pytest.fixture
def sample_situation():
    """Sample situation for testing"""
    return "角色被突然出现的敌人袭击，需要立即做出反应"


@pytest.fixture
def sample_character_data():
    """Sample character creation data"""
    return {
        "name": "测试角色",
        "description": "这是一个测试角色",
        "tags": ["测试", "勇敢"],
        "base_y": 50,
        "mbti_type": "ENTJ",
        "trauma_level": 0.2
    }


@pytest.fixture
def sample_memory_data():
    """Sample memory creation data"""
    return {
        "content": "这是一段重要的记忆",
        "memory_type": "episodic",
        "emotional_intensity": 0.7,
        "importance": 0.8,
        "is_traumatic": False,
        "trauma_level": 0.0
    }


@pytest.fixture
def sample_psychology_data():
    """Sample psychology calculation data"""
    return {
        "situation": "角色面对一个艰难的抉择",
        "context": {"previous_emotion": "neutral"},
        "interaction_y": 60
    }
