"""
Tests for Message Formatting API
"""

import pytest
import json


class TestMessageFormat:
    """Test message formatting endpoints"""
    
    def test_format_message_basic(self, client):
        """Test basic message formatting"""
        response = client.post(
            '/api/v1/message/format',
            json={
                'content': '这是一条测试消息',
                'psychology_output': {
                    'y_value': 50,
                    'behavioral_tendency': '稳定型',
                    'emotional_state': {
                        'valence': 0.3,
                        'arousal': 0.5,
                        'dominance': 0.5
                    }
                },
                'context': {
                    'speaker_id': 'test_speaker'
                }
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'emotional_coloring' in data['data']
        assert 'behavior_tags' in data['data']
        assert 'tiandao_hints' in data['data']
    
    def test_format_message_no_content(self, client):
        """Test formatting without content"""
        response = client.post(
            '/api/v1/message/format',
            json={'psychology_output': {}}
        )
        
        assert response.status_code == 400
    
    def test_format_message_empty_body(self, client):
        """Test formatting with empty body"""
        response = client.post(
            '/api/v1/message/format',
            json={},
            content_type='application/json'
        )
        
        assert response.status_code == 400


class TestMessageWrap:
    """Test message wrapping endpoints"""
    
    def test_wrap_message(self, client):
        """Test wrapping message with context"""
        response = client.post(
            '/api/v1/message/wrap',
            json={
                'content': '角色说: "你好"',
                'psychology_output': {
                    'y_value': 50,
                    'behavioral_tendency': '主导型',
                    'overflow_warning': False
                },
                'context': {
                    'speaker_id': 'test_speaker',
                    'situation': '初次见面'
                }
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'wrapped_content' in data['data']
    
    def test_wrap_message_with_overflow(self, client):
        """Test wrapping with overflow warning"""
        response = client.post(
            '/api/v1/message/wrap',
            json={
                'content': '角色非常激动',
                'psychology_output': {
                    'y_value': 85,
                    'behavioral_tendency': '压制型',
                    'overflow_warning': True
                }
            }
        )
        
        assert response.status_code == 200


class TestTagExtraction:
    """Test tag extraction"""
    
    def test_extract_tiandao_tags(self, client):
        """Test extracting Tiandao tags from text"""
        response = client.post(
            '/api/v1/message/extract-tags',
            json={
                'text': 'Y=75, [主导型], 情绪:愤怒'
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'tags' in data['data']
    
    def test_extract_tags_empty(self, client):
        """Test extracting from plain text"""
        response = client.post(
            '/api/v1/message/extract-tags',
            json={'text': '普通文本没有标签'}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert isinstance(data['data']['tags'], list)


class TestResponseContext:
    """Test response context creation"""
    
    def test_create_response_context(self, client):
        """Test creating response context"""
        response = client.post(
            '/api/v1/message/create-context',
            json={
                'speaker_profile': {
                    'info': {
                        'name': 'Test Speaker',
                        'mbti_type': 'INTJ',
                        'base_y': 50
                    }
                },
                'situation': '在紧张的对话中',
                'recent_history': [
                    {'emotional_state': {'valence': -0.2}},
                    {'emotional_state': {'valence': 0.1}}
                ]
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'situation' in data['data']
        assert 'speaker' in data['data']
        assert 'suggested_tone' in data['data']
    
    def test_create_context_minimal(self, client):
        """Test creating context with minimal data"""
        response = client.post(
            '/api/v1/message/create-context',
            json={'speaker_profile': {}}
        )
        
        assert response.status_code == 200


class TestMessageFormatterUnit:
    """Unit tests for MessageFormatter"""
    
    def test_format_message_unit(self, psychology_engine):
        """Test message formatter directly"""
        from message_formatter import MessageFormatter, MessageContext
        
        formatter = MessageFormatter()
        context = MessageContext(
            speaker_id='test',
            situation='测试场景'
        )
        
        result = formatter.format_message(
            content='测试内容',
            context=context,
            psychology_output={
                'y_value': 50,
                'behavioral_tendency': '稳定型',
                'emotional_state': {'valence': 0.5, 'arousal': 0.5, 'dominance': 0.5}
            }
        )
        
        assert result.content == '测试内容'
        assert 'joy' in result.emotional_coloring
        assert 'calm' in result.behavior_tags
    
    def test_seven_emotions_derivation(self, psychology_engine):
        """Test seven emotions derivation"""
        from message_formatter import MessageFormatter
        
        formatter = MessageFormatter()
        
        seven = formatter._derive_seven_emotions({
            'valence': 0.5,
            'arousal': 0.7,
            'dominance': 0.6
        })
        
        assert seven['joy'] > 0
        assert seven['thought'] > 0
    
    def test_tiandao_hints_generation(self, psychology_engine):
        """Test Tiandao hints generation"""
        from message_formatter import MessageFormatter
        
        formatter = MessageFormatter()
        
        hints = formatter._generate_tiandao_hints(
            psychology_output={
                'y_value': 50,
                'behavioral_tendency': '主导型',
                'overflow_warning': False,
                'triggered_memories': ['mem1', 'mem2']
            },
            seven_emotions={'joy': 5, 'anger': 2, 'sadness': 1}
        )
        
        assert hints['y_value'] == 50
        assert hints['dominant_emotion'] == 'joy'
        assert hints['triggered_memory_count'] == 2
    
    def test_extract_tags_unit(self, psychology_engine):
        """Test tag extraction"""
        from message_formatter import MessageFormatter
        
        formatter = MessageFormatter()
        
        tags = formatter.extract_tiandao_tags(
            'Y=80, [压制型], 情绪:愤怒, 触发记忆:3'
        )
        
        assert any('y_value:80' in t for t in tags)
        assert any('emotion:anger' in t for t in tags)
