"""
Tests for Psychology API Endpoints
"""

import pytest
import json


class TestPsychologyCalculate:
    """Test psychology calculation endpoint"""
    
    def test_calculate_basic(self, client, sample_psychology_data):
        """Test basic psychology calculation"""
        response = client.post(
            '/api/v1/psychology/calculate',
            json=sample_psychology_data
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'data' in data
        assert 'y_value' in data['data']
        assert 'emotional_state' in data['data']
    
    def test_calculate_empty_situation(self, client):
        """Test calculation with empty situation"""
        response = client.post(
            '/api/v1/psychology/calculate',
            json={'situation': ''}
        )
        
        assert response.status_code == 422
    
    def test_calculate_no_body(self, client):
        """Test calculation with no request body"""
        response = client.post(
            '/api/v1/psychology/calculate',
            data='',
            content_type='application/json'
        )
        
        assert response.status_code == 400


class TestYValue:
    """Test Y-value endpoints"""
    
    def test_get_y_value(self, client):
        """Test getting Y-value"""
        response = client.get('/api/v1/psychology/y-value')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'current_y' in data['data']
        assert 'baseline_y' in data['data']
    
    def test_trigger_breakthrough(self, client):
        """Test triggering breakthrough"""
        response = client.post(
            '/api/v1/psychology/y-value/trigger',
            json={
                'trigger_type': 'breakthrough',
                'value': 80
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'new_y' in data['data']
    
    def test_trigger_ptsd(self, client):
        """Test triggering PTSD"""
        response = client.post(
            '/api/v1/psychology/y-value/trigger',
            json={
                'trigger_type': 'ptsd',
                'value': 75
            }
        )
        
        assert response.status_code == 200
    
    def test_trigger_invalid_type(self, client):
        """Test triggering with invalid type"""
        response = client.post(
            '/api/v1/psychology/y-value/trigger',
            json={
                'trigger_type': 'invalid_type'
            }
        )
        
        assert response.status_code == 422
    
    def test_calculate_influence(self, client):
        """Test influence calculation"""
        response = client.post(
            '/api/v1/psychology/y-value/influence',
            json={'target_y': 70}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'influence_level' in data['data']


class TestMBTI:
    """Test MBTI endpoints"""
    
    def test_get_mbti_profile(self, client):
        """Test getting MBTI profile"""
        response = client.get('/api/v1/psychology/mbti')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'mbti_type' in data['data']
        assert 'big_five' in data['data']
    
    def test_get_mbti_with_type(self, client):
        """Test getting specific MBTI type"""
        response = client.get('/api/v1/psychology/mbti?type=ENFP')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['data']['mbti_type'] == 'ENFP'
    
    def test_infer_mbti_from_tags(self, client):
        """Test inferring MBTI from tags"""
        response = client.post(
            '/api/v1/psychology/mbti/from-tags',
            json={
                'tags': ['理性', '逻辑', '独立', '完美主义']
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'mbti_type' in data['data']


class TestMemory:
    """Test memory endpoints"""
    
    def test_add_memory(self, client, sample_memory_data):
        """Test adding a memory"""
        response = client.post(
            '/api/v1/psychology/memory',
            json=sample_memory_data
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'id' in data['data']
        assert data['data']['content'] == sample_memory_data['content']
    
    def test_add_memory_empty_content(self, client):
        """Test adding memory with empty content"""
        response = client.post(
            '/api/v1/psychology/memory',
            json={'content': ''}
        )
        
        assert response.status_code == 422
    
    def test_retrieve_memories(self, client, sample_memory_data):
        """Test retrieving memories"""
        # First add a memory
        client.post('/api/v1/psychology/memory', json=sample_memory_data)
        
        # Retrieve
        response = client.post(
            '/api/v1/psychology/memory/retrieve',
            json={'query': '重要'}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'data' in data
    
    def test_get_memory_summary(self, client):
        """Test getting memory summary"""
        response = client.get('/api/v1/psychology/memory/summary')
        
        assert response.status_code == 200
    
    def test_ptsd_check(self, client, sample_memory_data):
        """Test PTSD check"""
        # Add a traumatic memory first
        traumatic_memory = sample_memory_data.copy()
        traumatic_memory['is_traumatic'] = True
        traumatic_memory['trauma_level'] = 0.8
        client.post('/api/v1/psychology/memory', json=traumatic_memory)
        
        # Check PTSD
        response = client.post(
            '/api/v1/psychology/ptsd/check',
            json={'event': '战斗'}
        )
        
        assert response.status_code == 200


class TestMotivation:
    """Test motivation endpoints"""
    
    def test_get_motivation_profile(self, client):
        """Test getting motivation profile"""
        response = client.get('/api/v1/psychology/motivation')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'instincts' in data['data'] or 'profile' in data['data']
    
    def test_activate_instinct(self, client):
        """Test activating an instinct"""
        response = client.post(
            '/api/v1/psychology/motivation/activate',
            json={
                'instinct': 'survival',
                'intensity_modifier': 1.5
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['data']['instinct'] == 'survival'
    
    def test_activate_invalid_instinct(self, client):
        """Test activating invalid instinct"""
        response = client.post(
            '/api/v1/psychology/motivation/activate',
            json={'instinct': 'invalid'}
        )
        
        assert response.status_code == 422


class TestEmotions:
    """Test emotion endpoints"""
    
    def test_get_seven_emotions(self, client):
        """Test getting seven emotions"""
        response = client.get('/api/v1/psychology/emotions/seven')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        emotions = ['joy', 'anger', 'worry', 'thought', 'sadness', 'fear', 'shock']
        for emotion in emotions:
            assert emotion in data['data']
    
    def test_get_vad_state(self, client):
        """Test getting VAD state"""
        response = client.get('/api/v1/psychology/emotions/vad')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'valence' in data['data']
        assert 'arousal' in data['data']
        assert 'dominance' in data['data']


class TestEngineManagement:
    """Test engine management endpoints"""
    
    def test_create_engine(self, client):
        """Test creating a new engine"""
        response = client.post(
            '/api/v1/psychology/engine/create',
            json={
                'engine_id': 'test_engine',
                'base_y': 60,
                'mbti_type': 'ENFP'
            }
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['data']['engine_id'] == 'test_engine'
    
    def test_create_duplicate_engine(self, client):
        """Test creating duplicate engine"""
        # Create first
        client.post(
            '/api/v1/psychology/engine/create',
            json={'engine_id': 'dup_test'}
        )
        
        # Try duplicate
        response = client.post(
            '/api/v1/psychology/engine/create',
            json={'engine_id': 'dup_test'}
        )
        
        assert response.status_code == 409
    
    def test_list_engines(self, client):
        """Test listing engines"""
        response = client.get('/api/v1/psychology/engine/list')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'engines' in data['data']
        assert 'count' in data['data']
    
    def test_reset_engine(self, client):
        """Test resetting engine"""
        response = client.post(
            '/api/v1/psychology/engine/reset',
            json={'engine_id': 'default'}
        )
        
        assert response.status_code == 200
