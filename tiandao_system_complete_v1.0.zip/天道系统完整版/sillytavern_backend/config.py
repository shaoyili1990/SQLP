"""
Configuration Management for SillyTavern Tiandao Backend

Environment-based configuration with validation and defaults.
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional
from dotenv import load_dotenv

# Load .env file if present
load_dotenv()


@dataclass
class FlaskConfig:
    """Flask application configuration"""
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"
    TESTING: bool = os.getenv("TESTING", "false").lower() == "true"
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "5000"))
    
    # CORS settings
    CORS_ORIGINS: List[str] = field(default_factory=lambda: os.getenv("CORS_ORIGINS", "*").split(","))
    CORS_METHODS: List[str] = field(default_factory=lambda: os.getenv("CORS_METHODS", "GET,POST,PUT,DELETE,OPTIONS").split(","))
    CORS_HEADERS: List[str] = field(default_factory=lambda: os.getenv("CORS_HEADERS", "Content-Type,Authorization").split(","))


@dataclass
class CacheConfig:
    """Cache configuration"""
    TYPE: str = os.getenv("CACHE_TYPE", "simple")
    CACHE_DIR: str = os.getenv("CACHE_DIR", "/tmp/tiandao_cache")
    CACHE_DEFAULT_TIMEOUT: int = int(os.getenv("CACHE_DEFAULT_TIMEOUT", "300"))


@dataclass
class DatabaseConfig:
    """Database configuration (for future use)"""
    URL: str = os.getenv("DATABASE_URL", "sqlite:///tiandao.db")
    POOL_SIZE: int = int(os.getenv("DB_POOL_SIZE", "10"))


@dataclass
class TiandaoConfig:
    """Tiandao core system configuration"""
    DEFAULT_BASE_Y: int = int(os.getenv("DEFAULT_BASE_Y", "50"))
    DEFAULT_MBTI: str = os.getenv("DEFAULT_MBTI", "INTJ")
    MEMORY_DECAY_DAYS: float = float(os.getenv("MEMORY_DECAY_DAYS", "7.0"))
    PTSD_TRIGGER_THRESHOLD: float = float(os.getenv("PTSD_TRIGGER_THRESHOLD", "0.6"))
    
    # System limits
    MAX_CHARACTERS: int = int(os.getenv("MAX_CHARACTERS", "1000"))
    MAX_MEMORIES_PER_CHARACTER: int = int(os.getenv("MAX_MEMORIES_PER_CHARACTER", "10000"))
    MAX_REQUEST_SIZE: int = int(os.getenv("MAX_REQUEST_SIZE", "1048576"))  # 1MB


@dataclass
class AppConfig:
    """Complete application configuration"""
    flask: FlaskConfig = field(default_factory=FlaskConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    tiandao: TiandaoConfig = field(default_factory=TiandaoConfig)
    
    @classmethod
    def from_env(cls) -> "AppConfig":
        """Create configuration from environment variables"""
        return cls(
            flask=FlaskConfig(),
            cache=CacheConfig(),
            database=DatabaseConfig(),
            tiandao=TiandaoConfig()
        )


# Global configuration instance
config = AppConfig.from_env()


def get_config() -> AppConfig:
    """Get the global configuration instance"""
    return config


def validate_config() -> List[str]:
    """
    Validate configuration and return list of warnings.
    
    Returns:
        List of warning messages (empty if all valid)
    """
    warnings = []
    
    # Check for production issues
    if config.flask.DEBUG and config.flask.SECRET_KEY == "dev-secret-key-change-in-production":
        warnings.append("SECRET_KEY is using default value in DEBUG mode")
    
    if config.flask.HOST == "0.0.0.0":
        warnings.append("Server is listening on all interfaces (0.0.0.0)")
    
    if "*" in config.flask.CORS_ORIGINS:
        warnings.append("CORS is allowing all origins (*)")
    
    # Validate numeric ranges
    if not (1 <= config.tiandao.DEFAULT_BASE_Y <= 100):
        warnings.append(f"DEFAULT_BASE_Y should be between 1-100, got {config.tiandao.DEFAULT_BASE_Y}")
    
    return warnings
