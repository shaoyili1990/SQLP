"""
SillyTavern Tiandao Backend - Main Server

A production-ready Flask backend that integrates the Tiandao
psychological system with SillyTavern character management.

Features:
- Psychology API (Y-value, MBTI, memory, motivation, emotions)
- Character CRUD with Tiandao integration
- Message formatting with emotional context
- Author constraint validation
- CORS support
- Comprehensive error handling
"""

import logging
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
import sys
import os

# Add the tiandao core to path
sys.path.insert(0, '/tmp/final_workspace/tiandao_core')

# Import configuration
from config import config, get_config, validate_config

# Import API blueprints
from psychology_api import psychology_bp
from character_api import character_bp
from message_formatter import MessageFormatter

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    """
    Application factory for creating Flask app instance.
    
    Returns:
        Configured Flask application
    """
    app = Flask(__name__)
    
    # Configure app from config
    app.config['SECRET_KEY'] = config.flask.SECRET_KEY
    app.config['DEBUG'] = config.flask.DEBUG
    app.config['TESTING'] = config.flask.TESTING
    app.config['MAX_CONTENT_LENGTH'] = config.tiandao.MAX_REQUEST_SIZE
    
    # Setup CORS
    CORS(app, 
         origins=config.flask.CORS_ORIGINS,
         methods=config.flask.CORS_METHODS,
         allow_headers=config.flask.CORS_HEADERS)
    
    # Register blueprints
    app.register_blueprint(psychology_bp)
    app.register_blueprint(character_bp)
    
    # Initialize message formatter
    app.message_formatter = MessageFormatter()
    
    # Register error handlers
    register_error_handlers(app)
    
    # Register routes
    register_routes(app)
    
    # Log startup
    warnings = validate_config()
    for warning in warnings:
        logger.warning(f"Configuration warning: {warning}")
    
    logger.info("SillyTavern Tiandao Backend initialized")
    
    return app


def register_error_handlers(app: Flask) -> None:
    """Register global error handlers"""
    from werkzeug.exceptions import BadRequest
    
    @app.errorhandler(400)
    @app.errorhandler(BadRequest)
    def bad_request(error):
        message = str(error.description) if hasattr(error, 'description') else "Invalid request"
        return jsonify({
            "success": False,
            "error": {
                "message": message,
                "code": "BAD_REQUEST",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }), 400
    
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            "success": False,
            "error": {
                "message": "Resource not found",
                "code": "NOT_FOUND",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }), 404
    
    @app.errorhandler(405)
    def method_not_allowed(error):
        return jsonify({
            "success": False,
            "error": {
                "message": "Method not allowed",
                "code": "METHOD_NOT_ALLOWED",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }), 405
    
    @app.errorhandler(413)
    def request_entity_too_large(error):
        return jsonify({
            "success": False,
            "error": {
                "message": "Request entity too large",
                "code": "PAYLOAD_TOO_LARGE",
                "max_size": config.tiandao.MAX_REQUEST_SIZE,
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }), 413
    
    @app.errorhandler(422)
    def unprocessable_entity(error):
        return jsonify({
            "success": False,
            "error": {
                "message": "Unprocessable entity",
                "code": "VALIDATION_ERROR",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }), 422
    
    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Internal server error: {error}", exc_info=True)
        return jsonify({
            "success": False,
            "error": {
                "message": "Internal server error",
                "code": "INTERNAL_ERROR",
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }), 500


def register_routes(app: Flask) -> None:
    """Register main application routes"""
    
    # Health check
    @app.route('/health', methods=['GET'])
    def health_check():
        """Health check endpoint"""
        return jsonify({
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "version": "1.0.0",
            "services": {
                "psychology": "operational",
                "character": "operational",
                "formatter": "operational"
            }
        }), 200
    
    # API version info
    @app.route('/api/v1', methods=['GET'])
    @app.route('/api', methods=['GET'])
    def api_info():
        """API information endpoint"""
        return jsonify({
            "name": "SillyTavern Tiandao Backend",
            "version": "1.0.0",
            "description": "Psychological analysis and character management API",
            "endpoints": {
                "psychology": {
                    "base": "/api/v1/psychology",
                    "endpoints": [
                        "/calculate",
                        "/y-value",
                        "/mbti",
                        "/memory",
                        "/motivation",
                        "/emotions/seven",
                        "/emotions/vad"
                    ]
                },
                "character": {
                    "base": "/api/v1/characters",
                    "endpoints": [
                        "GET/POST /",
                        "GET/PUT/DELETE /<id>",
                        "/<id>/calculate",
                        "/<id>/memories",
                        "/<id>/ptsd",
                        "/<id>/y-value",
                        "/import"
                    ]
                },
                "message": {
                    "base": "/api/v1/message",
                    "endpoints": [
                        "/format",
                        "/context"
                    ]
                }
            },
            "documentation": "/api/v1/docs"
        }), 200
    
    # Message formatting API
    @app.route('/api/v1/message/format', methods=['POST'])
    def format_message():
        """
        Format a message with Tiandao psychological context.
        
        Request body:
        {
            "content": str,
            "psychology_output": {},
            "context": {
                "speaker_id": str,
                "situation": str,
                "emotional_intensity": float
            }
        }
        """
        data = request.get_json()
        
        if not data or 'content' not in data:
            return jsonify({
                "success": False,
                "error": {"message": "Content is required"}
            }), 400
        
        from message_formatter import MessageContext
        
        context_data = data.get('context', {})
        context = MessageContext(
            speaker_id=context_data.get('speaker_id', 'unknown'),
            situation=context_data.get('situation', ''),
            emotional_intensity=context_data.get('emotional_intensity', 0.5)
        )
        
        formatted = app.message_formatter.format_message(
            content=data['content'],
            context=context,
            psychology_output=data.get('psychology_output', {})
        )
        
        return jsonify({
            "success": True,
            "message": "Message formatted",
            "data": {
                "content": formatted.content,
                "emotional_coloring": formatted.emotional_coloring,
                "behavior_tags": formatted.behavior_tags,
                "tiandao_hints": formatted.tiandao_hints
            }
        }), 200
    
    @app.route('/api/v1/message/wrap', methods=['POST'])
    def wrap_message():
        """
        Wrap content with full Tiandao context.
        
        Request body:
        {
            "content": str,
            "psychology_output": {},
            "context": {...}
        }
        """
        data = request.get_json()
        
        if not data or 'content' not in data:
            return jsonify({
                "success": False,
                "error": {"message": "Content is required"}
            }), 400
        
        from message_formatter import MessageContext
        
        context_data = data.get('context', {})
        context = MessageContext(
            speaker_id=context_data.get('speaker_id', 'unknown'),
            situation=context_data.get('situation', '')
        )
        
        wrapped = app.message_formatter.wrap_with_tiandao_context(
            content=data['content'],
            psychology_output=data.get('psychology_output', {}),
            context=context
        )
        
        return jsonify({
            "success": True,
            "data": {"wrapped_content": wrapped}
        }), 200
    
    @app.route('/api/v1/message/extract-tags', methods=['POST'])
    def extract_tags():
        """
        Extract Tiandao tags from text.
        
        Request body:
        {
            "text": str
        }
        """
        data = request.get_json()
        
        if not data or 'text' not in data:
            return jsonify({
                "success": False,
                "error": {"message": "Text is required"}
            }), 400
        
        tags = app.message_formatter.extract_tiandao_tags(data['text'])
        
        return jsonify({
            "success": True,
            "data": {"tags": tags}
        }), 200
    
    @app.route('/api/v1/message/create-context', methods=['POST'])
    def create_response_context():
        """
        Create context for generating a response.
        
        Request body:
        {
            "speaker_profile": {},
            "situation": str,
            "recent_history": [...]
        }
        """
        data = request.get_json()
        
        if not data:
            return jsonify({
                "success": False,
                "error": {"message": "Request body is required"}
            }), 400
        
        context = app.message_formatter.create_response_context(
            speaker_profile=data.get('speaker_profile', {}),
            situation=data.get('situation', ''),
            recent_history=data.get('recent_history', [])
        )
        
        return jsonify({
            "success": True,
            "data": context
        }), 200
    
    # System endpoints
    @app.route('/api/v1/system/config', methods=['GET'])
    def get_system_config():
        """Get non-sensitive system configuration"""
        return jsonify({
            "success": True,
            "data": {
                "version": "1.0.0",
                "max_characters": config.tiandao.MAX_CHARACTERS,
                "max_request_size": config.tiandao.MAX_REQUEST_SIZE,
                "default_base_y": config.tiandao.DEFAULT_BASE_Y,
                "debug_mode": config.flask.DEBUG,
                "cors_enabled": True
            }
        }), 200
    
    @app.route('/api/v1/system/stats', methods=['GET'])
    def get_system_stats():
        """Get system statistics"""
        from psychology_api import _engines
        from character_api import _characters
        
        return jsonify({
            "success": True,
            "data": {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "active_engines": len(_engines),
                "stored_characters": len(_characters),
                "memory_usage": "N/A",  # Would require psutil
                "uptime": "N/A"  # Would require tracking start time
            }
        }), 200


# Create the application instance
app = create_app()


if __name__ == '__main__':
    logger.info(f"Starting server on {config.flask.HOST}:{config.flask.PORT}")
    logger.info(f"Debug mode: {config.flask.DEBUG}")
    
    app.run(
        host=config.flask.HOST,
        port=config.flask.PORT,
        debug=config.flask.DEBUG
    )
