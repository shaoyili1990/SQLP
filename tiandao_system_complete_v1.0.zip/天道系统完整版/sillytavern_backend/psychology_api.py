"""
Psychology API Module

REST API endpoints for personality analysis using the Tiandao
psychology engine (Y-value, MBTI, memory, motivation systems).
"""

from typing import Any, Dict, List, Optional
from flask import Blueprint, request
from functools import wraps
import logging

# Import tiandao core
from tiandao.core.psychology import PsychologyEngine, MoralSensitivity
from tiandao.core.y_value import YValueSystem, TriggerType
from tiandao.core.mbti import MBTISystem
from tiandao.core.memory import MemorySystem, MemoryType
from tiandao.core.motivation import MotivationSystem, InstinctType

# Import utilities
from utils.responses import success_response, error_response, validation_error_response
from utils.validators import validate_situation, validate_memory_data
from utils.formatters import format_psychology_output, format_memory_node, sanitize_string

logger = logging.getLogger(__name__)

# Create blueprint
psychology_bp = Blueprint('psychology', __name__, url_prefix='/api/v1/psychology')

# Thread-local storage for psychology engines
_engines: Dict[str, PsychologyEngine] = {}


def get_engine(engine_id: str = "default") -> PsychologyEngine:
    """Get or create a psychology engine instance"""
    if engine_id not in _engines:
        _engines[engine_id] = PsychologyEngine(base_y=50, mbti_type="INTJ")
    return _engines[engine_id]


def reset_engine(engine_id: str = "default") -> None:
    """Reset a psychology engine"""
    if engine_id in _engines:
        del _engines[engine_id]


def handle_errors(f):
    """Decorator for error handling"""
    from werkzeug.exceptions import BadRequest
    @wraps(f)
    def decorated(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except BadRequest as e:
            logger.warning(f"Bad request: {e}")
            return error_response(str(e.description) if hasattr(e, 'description') else "Invalid request", status_code=400, error_code="BAD_REQUEST")
        except ValueError as e:
            logger.warning(f"Validation error: {e}")
            return error_response(str(e), status_code=422, error_code="VALIDATION_ERROR")
        except KeyError as e:
            logger.warning(f"Resource not found: {e}")
            return error_response(f"Resource not found: {e}", status_code=404)
        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            return error_response("Internal server error", status_code=500)
    return decorated


# ========== Main Psychology Endpoints ==========

@psychology_bp.route('/calculate', methods=['POST'])
@handle_errors
def calculate_psychology():
    """
    Calculate psychology response for a situation.
    
    Request body:
    {
        "situation": "str - The situation to analyze",
        "context": {} - Optional context dict,
        "interaction_y": 50 - Optional interaction Y value,
        "engine_id": "default" - Optional engine ID for stateful sessions
    }
    
    Returns:
    {
        "y_value": int,
        "emotional_state": {...},
        "behavioral_tendency": str,
        "active_motivations": [...],
        "triggered_memories": [...],
        "moral_adjustment": float,
        "overflow_warning": bool,
        "messages": [...]
    }
    """
    data = request.get_json()
    
    if not data:
        return error_response("Request body is required", status_code=400)
    
    situation = data.get('situation', '')
    is_valid, error_msg = validate_situation(situation)
    if not is_valid:
        return error_response(error_msg, status_code=422)
    
    context = data.get('context', {})
    interaction_y = data.get('interaction_y')
    engine_id = data.get('engine_id', 'default')
    
    engine = get_engine(engine_id)
    result = engine.calculate(
        situation=situation,
        context=context,
        interaction_y=interaction_y
    )
    
    return success_response(
        data=format_psychology_output(result),
        message="Psychology calculation completed"
    )


@psychology_bp.route('/full-report', methods=['GET'])
@handle_errors
def get_full_report():
    """
    Get complete psychology report for an engine.
    
    Query params:
    - engine_id: str - Engine ID (default: "default")
    
    Returns complete report including all subsystems.
    """
    engine_id = request.args.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    report = engine.get_full_report()
    
    return success_response(
        data=report,
        message="Full psychology report generated"
    )


# ========== Y-Value Endpoints ==========

@psychology_bp.route('/y-value', methods=['GET'])
@handle_errors
def get_y_value():
    """
    Get current Y-value state.
    
    Query params:
    - engine_id: str - Engine ID
    """
    engine_id = request.args.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    return success_response(
        data={
            "current_y": engine.y_system.Y,
            "baseline_y": engine.y_system.state.baseline_y,
            "threshold": engine.y_system.get_threshold(),
            "is_compensating": engine.y_system.state.is_compensating
        },
        message="Y-value retrieved"
    )


@psychology_bp.route('/y-value/trigger', methods=['POST'])
@handle_errors
def trigger_y_event():
    """
    Trigger a Y-value event (breakthrough, PTSD, major event).
    
    Request body:
    {
        "trigger_type": "breakthrough|ptsd|major_event|emotional_extreme",
        "value": int - Y value for breakthrough/PTSD,
        "event_type": str - For major_event: "trauma|redemption|bottom_line",
        "emotion_type": str - For emotional_extreme
    }
    """
    data = request.get_json()
    
    if not data:
        return error_response("Request body is required", status_code=400)
    
    trigger_type = data.get('trigger_type')
    engine_id = data.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    if trigger_type == 'breakthrough':
        attacker_y = data.get('value', 70)
        result = engine.y_system.trigger_breakthrough(attacker_y)
    elif trigger_type == 'ptsd':
        trauma_y = data.get('value', 70)
        result = engine.y_system.trigger_ptsd(trauma_y)
    elif trigger_type == 'major_event':
        event_type = data.get('event_type', 'trauma')
        intensity = data.get('intensity', 1)
        result = engine.y_system.trigger_major_event(event_type, intensity)
    elif trigger_type == 'emotional_extreme':
        emotion_type = data.get('emotion_type', 'guilt')
        result = engine.y_system.trigger_emotional_extreme(emotion_type)
    else:
        return error_response(f"Unknown trigger type: {trigger_type}", status_code=422)
    
    return success_response(
        data={
            "triggered": result.triggered,
            "trigger_type": result.trigger_type.value if result.trigger_type else None,
            "old_y": result.old_y,
            "new_y": result.new_y,
            "delta_y": result.delta_y,
            "message": result.message
        },
        message="Y-value trigger processed"
    )


@psychology_bp.route('/y-value/influence', methods=['POST'])
@handle_errors
def calculate_influence():
    """
    Calculate influence level against a target Y-value.
    
    Request body:
    {
        "target_y": int - Target character's Y value
    }
    """
    data = request.get_json()
    
    if not data:
        return error_response("Request body is required", status_code=400)
    
    target_y = data.get('target_y', 50)
    engine_id = data.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    influence = engine.y_system.get_influence_level(target_y)
    
    return success_response(
        data={
            "current_y": engine.y_system.Y,
            "target_y": target_y,
            "influence_level": influence,
            "delta": engine.y_system.Y - target_y
        },
        message="Influence calculated"
    )


# ========== MBTI Endpoints ==========

@psychology_bp.route('/mbti', methods=['GET'])
@handle_errors
def get_mbti_profile():
    """
    Get MBTI profile.
    
    Query params:
    - type: str - MBTI type (e.g., "INTJ")
    """
    mbti_type = request.args.get('type')
    
    if mbti_type:
        mbti = MBTISystem(mbti_type)
    else:
        engine_id = request.args.get('engine_id', 'default')
        engine = get_engine(engine_id)
        mbti = engine.mbti_system
    
    return success_response(
        data=mbti.get_full_profile(),
        message="MBTI profile retrieved"
    )


@psychology_bp.route('/mbti/from-tags', methods=['POST'])
@handle_errors
def infer_mbti_from_tags():
    """
    Infer MBTI type from tags.
    
    Request body:
    {
        "tags": ["理性", "内耗", "独立", ...]
    }
    """
    data = request.get_json()
    
    if not data or 'tags' not in data:
        return error_response("Tags list is required", status_code=400)
    
    tags = data['tags']
    mbti = MBTISystem.from_tags(tags)
    
    return success_response(
        data=mbti.get_full_profile(),
        message="MBTI inferred from tags"
    )


# ========== Memory Endpoints ==========

@psychology_bp.route('/memory', methods=['POST'])
@handle_errors
def add_memory():
    """
    Add a memory to the engine.
    
    Request body:
    {
        "content": str,
        "memory_type": "episodic|procedural|semantic|emotional|sensory",
        "emotional_intensity": float,
        "importance": float,
        "is_traumatic": bool,
        "trauma_level": float,
        "triggers": [str]
    }
    """
    data = request.get_json()
    
    if not data:
        return error_response("Request body is required", status_code=400)
    
    is_valid, errors = validate_memory_data(data)
    if not is_valid:
        return validation_error_response(errors)
    
    memory_type_str = data.get('memory_type', 'episodic')
    memory_type = MemoryType(memory_type_str)
    
    engine_id = data.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    memory = engine.add_memory(
        content=sanitize_string(data['content'], 10000),
        memory_type=memory_type,
        emotional_intensity=data.get('emotional_intensity', 0.5),
        importance=data.get('importance', 0.5),
        is_traumatic=data.get('is_traumatic', False),
        trauma_level=data.get('trauma_level', 0.0),
        triggers=data.get('triggers', [])
    )
    
    return success_response(
        data=format_memory_node(memory),
        message="Memory added"
    )


@psychology_bp.route('/memory/retrieve', methods=['POST'])
@handle_errors
def retrieve_memories():
    """
    Retrieve relevant memories.
    
    Request body:
    {
        "query": str,
        "memory_types": ["episodic", ...] - Optional filter,
        "limit": int,
        "include_traumatic": bool
    }
    """
    data = request.get_json()
    
    if not data or 'query' not in data:
        return error_response("Query is required", status_code=400)
    
    query = data['query']
    memory_types = None
    if 'memory_types' in data:
        memory_types = [MemoryType(t) for t in data['memory_types']]
    
    limit = data.get('limit', 10)
    include_traumatic = data.get('include_traumatic', True)
    engine_id = data.get('engine_id', 'default')
    
    engine = get_engine(engine_id)
    results = engine.memory_system.retrieve(
        query=query,
        memory_types=memory_types,
        limit=limit,
        include_traumatic=include_traumatic
    )
    
    memories = [
        {
            "id": r.memory.id,
            "content": r.memory.content,
            "type": r.memory.memory_type.value,
            "relevance": r.relevance,
            "strength": r.memory.strength,
            "is_traumatic": r.memory.is_traumatic
        }
        for r in results
    ]
    
    return success_response(
        data=memories,
        message=f"Retrieved {len(memories)} memories"
    )


@psychology_bp.route('/memory/summary', methods=['GET'])
@handle_errors
def get_memory_summary():
    """
    Get memory system summary.
    
    Query params:
    - engine_id: str
    - memory_type: str - Optional filter
    """
    engine_id = request.args.get('engine_id', 'default')
    memory_type_str = request.args.get('memory_type')
    
    engine = get_engine(engine_id)
    
    memory_type = None
    if memory_type_str:
        memory_type = MemoryType(memory_type_str)
    
    summary = engine.memory_system.get_memory_summary(memory_type)
    
    return success_response(
        data=summary,
        message="Memory summary retrieved"
    )


@psychology_bp.route('/ptsd/check', methods=['POST'])
@handle_errors
def check_ptsd():
    """
    Check PTSD triggers.
    
    Request body:
    {
        "event": str - Event description
    }
    """
    data = request.get_json()
    
    if not data or 'event' not in data:
        return error_response("Event description is required", status_code=400)
    
    event = data['event']
    engine_id = data.get('engine_id', 'default')
    
    engine = get_engine(engine_id)
    triggered, memories, strength = engine.memory_system.check_ptsd_triggers(
        event, engine.y_system.Y
    )
    
    return success_response(
        data={
            "triggered": triggered,
            "strength": strength,
            "triggered_memories": [
                {
                    "id": m.memory.id,
                    "content": m.memory.content,
                    "trauma_level": m.memory.trauma_level
                }
                for m in memories
            ]
        },
        message="PTSD check completed"
    )


# ========== Motivation Endpoints ==========

@psychology_bp.route('/motivation', methods=['GET'])
@handle_errors
def get_motivation_profile():
    """
    Get motivation system profile.
    
    Query params:
    - engine_id: str
    """
    engine_id = request.args.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    profile = engine.motivation_system.get_motivation_profile()
    
    return success_response(
        data=profile,
        message="Motivation profile retrieved"
    )


@psychology_bp.route('/motivation/activate', methods=['POST'])
@handle_errors
def activate_instinct():
    """
    Activate an instinct/motivation.
    
    Request body:
    {
        "instinct": "survival|belonging|power|meaning|pleasure|safety|growth",
        "intensity_modifier": float,
        "context": str
    }
    """
    data = request.get_json()
    
    if not data or 'instinct' not in data:
        return error_response("Instinct type is required", status_code=400)
    
    instinct_str = data['instinct']
    try:
        instinct = InstinctType(instinct_str)
    except ValueError:
        valid = [i.value for i in InstinctType]
        return error_response(f"Invalid instinct. Valid: {valid}", status_code=422)
    
    intensity_modifier = data.get('intensity_modifier', 1.0)
    context = data.get('context')
    engine_id = data.get('engine_id', 'default')
    
    engine = get_engine(engine_id)
    motivation = engine.motivation_system.activate_instinct(
        instinct, intensity_modifier, context
    )
    
    return success_response(
        data={
            "instinct": motivation.instinct_type.value,
            "intensity": motivation.intensity,
            "active": motivation.is_active,
            "layer": motivation.layer.value
        },
        message="Instinct activated"
    )


# ========== Emotional State Endpoints ==========

@psychology_bp.route('/emotions/seven', methods=['GET'])
@handle_errors
def get_seven_emotions():
    """
    Get current seven emotions state.
    
    Query params:
    - engine_id: str
    """
    engine_id = request.args.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    return success_response(
        data={
            "joy": engine.seven_emotions.joy,
            "anger": engine.seven_emotions.anger,
            "worry": engine.seven_emotions.worry,
            "thought": engine.seven_emotions.thought,
            "sadness": engine.seven_emotions.sadness,
            "fear": engine.seven_emotions.fear,
            "shock": engine.seven_emotions.shock
        },
        message="Seven emotions retrieved"
    )


@psychology_bp.route('/emotions/vad', methods=['GET'])
@handle_errors
def get_vad_state():
    """
    Get VAD (Valence-Arousal-Dominance) emotional state.
    
    Query params:
    - engine_id: str
    """
    engine_id = request.args.get('engine_id', 'default')
    engine = get_engine(engine_id)
    
    return success_response(
        data={
            "valence": engine.emotional_state.valence,
            "arousal": engine.emotional_state.arousal,
            "dominance": engine.emotional_state.dominance,
            "intensity": engine.emotional_state.intensity
        },
        message="VAD state retrieved"
    )


# ========== Moral Sensitivity Endpoint ==========

@psychology_bp.route('/moral-sensitivity', methods=['POST'])
@handle_errors
def set_moral_sensitivity():
    """
    Set moral sensitivity level.
    
    Request body:
    {
        "sensitivity": "low|normal|high"
    }
    """
    data = request.get_json()
    
    if not data or 'sensitivity' not in data:
        return error_response("Sensitivity level is required", status_code=400)
    
    sensitivity_str = data['sensitivity']
    try:
        sensitivity = MoralSensitivity(sensitivity_str)
    except ValueError:
        valid = [s.value for s in MoralSensitivity]
        return error_response(f"Invalid sensitivity. Valid: {valid}", status_code=422)
    
    engine_id = data.get('engine_id', 'default')
    engine = get_engine(engine_id)
    engine.set_moral_sensitivity(sensitivity)
    
    return success_response(
        data={"sensitivity": sensitivity.value},
        message="Moral sensitivity updated"
    )


# ========== Engine Management ==========

@psychology_bp.route('/engine/reset', methods=['POST'])
@handle_errors
def reset_psychology_engine():
    """
    Reset a psychology engine.
    
    Request body:
    {
        "engine_id": str
    }
    """
    data = request.get_json() or {}
    engine_id = data.get('engine_id', 'default')
    
    reset_engine(engine_id)
    
    return success_response(
        data={"engine_id": engine_id},
        message=f"Engine '{engine_id}' has been reset"
    )


@psychology_bp.route('/engine/create', methods=['POST'])
@handle_errors
def create_engine():
    """
    Create a new psychology engine with specific parameters.
    
    Request body:
    {
        "engine_id": str,
        "base_y": int,
        "mbti_type": str
    }
    """
    data = request.get_json() or {}
    
    engine_id = data.get('engine_id', 'default')
    base_y = data.get('base_y', 50)
    mbti_type = data.get('mbti_type', 'INTJ')
    
    if engine_id in _engines:
        return error_response(f"Engine '{engine_id}' already exists", status_code=409)
    
    engine = PsychologyEngine(base_y=base_y, mbti_type=mbti_type)
    _engines[engine_id] = engine
    
    return success_response(
        data={
            "engine_id": engine_id,
            "base_y": base_y,
            "mbti_type": mbti_type
        },
        message=f"Engine '{engine_id}' created"
    )


@psychology_bp.route('/engine/list', methods=['GET'])
@handle_errors
def list_engines():
    """
    List all active psychology engines.
    """
    return success_response(
        data={
            "engines": list(_engines.keys()),
            "count": len(_engines)
        },
        message="Engine list retrieved"
    )
