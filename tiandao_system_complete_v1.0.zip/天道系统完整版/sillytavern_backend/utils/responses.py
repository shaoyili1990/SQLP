"""
Standard API response utilities
"""

from typing import Any, Dict, List, Optional, Union
from flask import jsonify, Response
from datetime import datetime


def success_response(
    data: Any = None,
    message: str = "Success",
    status_code: int = 200,
    meta: Optional[Dict] = None
) -> tuple[Response, int]:
    """
    Create a standardized success response.
    
    Args:
        data: The response payload
        message: Human-readable message
        status_code: HTTP status code
        meta: Additional metadata
        
    Returns:
        Tuple of (Flask Response, status code)
    """
    response = {
        "success": True,
        "message": message,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    
    if data is not None:
        response["data"] = data
    
    if meta:
        response["meta"] = meta
    
    return jsonify(response), status_code


def error_response(
    message: str,
    status_code: int = 400,
    error_code: Optional[str] = None,
    details: Optional[Dict] = None
) -> tuple[Response, int]:
    """
    Create a standardized error response.
    
    Args:
        message: Human-readable error message
        status_code: HTTP status code
        error_code: Machine-readable error code
        details: Additional error details
        
    Returns:
        Tuple of (Flask Response, status code)
    """
    response = {
        "success": False,
        "error": {
            "message": message,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
    }
    
    if error_code:
        response["error"]["code"] = error_code
    
    if details:
        response["error"]["details"] = details
    
    return jsonify(response), status_code


def paginated_response(
    items: List[Any],
    total: int,
    page: int = 1,
    per_page: int = 20,
    message: str = "Success"
) -> tuple[Response, int]:
    """
    Create a standardized paginated response.
    
    Args:
        items: List of items for current page
        total: Total number of items
        page: Current page number (1-indexed)
        per_page: Items per page
        message: Human-readable message
        
    Returns:
        Tuple of (Flask Response, status code)
    """
    total_pages = (total + per_page - 1) // per_page if per_page > 0 else 0
    
    response = {
        "success": True,
        "message": message,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "data": items,
        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": total_pages,
            "has_next": page < total_pages,
            "has_prev": page > 1
        }
    }
    
    return jsonify(response), 200


def validation_error_response(
    errors: Dict[str, List[str]]
) -> tuple[Response, int]:
    """
    Create a validation error response.
    
    Args:
        errors: Dictionary of field -> list of error messages
        
    Returns:
        Tuple of (Flask Response, status code)
    """
    return error_response(
        message="Validation failed",
        status_code=422,
        error_code="VALIDATION_ERROR",
        details={"fields": errors}
    )
