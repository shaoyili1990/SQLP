#!/usr/bin/env python3
"""
Tiandao CLI - 天道系统命令行工具

Usage:
    python -m tiandao.cli <command> [options]

Commands:
    create      Create a new character
    calculate   Calculate psychological response
    memory      Manage character memories
    profile     Show character profile
    yvalue      Y值系统操作
    mbti        MBTI系统操作
    motivation  动机系统操作
    author      作者约束操作
"""

import argparse
import json
import sys
from typing import Optional

from tiandao.core import (
    YValueSystem, MBTISystem, MemorySystem, MotivationSystem,
    AuthorConstraintSystem, CharacterProfile, PsychologyEngine
)
from tiandao.core.memory import MemoryType
from tiandao.core.motivation import InstinctType


def cmd_create(args):
    """创建新角色"""
    profile = CharacterProfile.create(
        character_id=args.id or args.name,
        name=args.name,
        base_y=args.y,
        mbti_type=args.mbti,
        tags=args.tags.split(",") if args.tags else [],
        description=args.description or ""
    )
    
    print(json.dumps(profile.get_full_profile(), indent=2, ensure_ascii=False))


def cmd_calculate(args):
    """计算心理反应"""
    profile = CharacterProfile.create(
        character_id=args.character,
        name=args.character,
        base_y=args.y or 50,
        mbti_type=args.mbti or "INTJ"
    )
    
    result = profile.calculate_response(
        situation=args.situation,
        interaction_y=args.interaction_y
    )
    
    print(json.dumps(result, indent=2, ensure_ascii=False))


def cmd_memory(args):
    """记忆管理"""
    if args.action == "add":
        profile = CharacterProfile.create(
            character_id=args.character,
            name=args.character
        )
        
        memory_type = MemoryType(args.type) if args.type else MemoryType.EPISODIC
        memory = profile.add_memory(
            content=args.content,
            memory_type=memory_type,
            emotional_intensity=args.emotion or 0.5,
            is_traumatic=args.traumatic,
            trauma_level=args.trauma or 0.0
        )
        
        print(f"Memory added: {memory.id}")
    
    elif args.action == "search":
        profile = CharacterProfile.create(
            character_id=args.character,
            name=args.character
        )
        
        results = profile.retrieve_memories(args.query, limit=args.limit)
        print(json.dumps(results, indent=2, ensure_ascii=False))
    
    elif args.action == "ptsd":
        profile = CharacterProfile.create(
            character_id=args.character,
            name=args.character
        )
        
        result = profile.check_ptsd(args.event)
        print(json.dumps(result, indent=2, ensure_ascii=False))


def cmd_profile(args):
    """显示角色画像"""
    profile = CharacterProfile.create(
        character_id=args.character,
        name=args.character,
        base_y=args.y or 50,
        mbti_type=args.mbti or "INTJ"
    )
    
    if args.format == "json":
        print(profile.to_json())
    else:
        full = profile.get_full_profile()
        print(f"=== 角色画像: {profile.info.name} ===")
        print(f"ID: {profile.info.id}")
        print(f"MBTI: {profile.info.mbti_type}")
        print(f"Y值: {full['y_value']['current_y']}")
        print(f"基线Y: {full['y_value']['baseline_y']}")
        print(f"记忆数量: {full['memory']['total_memories']}")
        print(f"活跃动机: {full['motivation']['active_count']}")


def cmd_yvalue(args):
    """Y值系统操作"""
    y_system = YValueSystem()
    
    if args.action == "status":
        print(json.dumps(y_system.get_state_report(), indent=2))
    
    elif args.action == "set":
        y_system.state.current_y = args.value
        y_system.state.baseline_y = args.baseline or args.value
        print(f"Y值设置为: {y_system.Y}")
    
    elif args.action == "breakthrough":
        result = y_system.trigger_breakthrough(args.attacker, args.defender)
        print(json.dumps({
            "triggered": result.triggered,
            "old_y": result.old_y,
            "new_y": result.new_y,
            "message": result.message
        }, indent=2))
    
    elif args.action == "influence":
        level = y_system.get_influence_level(args.target)
        print(f"对目标Y={args.target}的影响力: {level}")


def cmd_mbti(args):
    """MBTI系统操作"""
    mbti = MBTISystem(args.type)
    
    if args.action == "profile":
        print(json.dumps(mbti.get_full_profile(), indent=2, ensure_ascii=False))
    
    elif args.action == "baseline":
        baseline = mbti.get_baseline_y(args.base or 50)
        print(f"MBTI {args.type} 的Y值基线: {baseline}")
        print(f"回弹区间: {mbti.get_rebound_range()}")
    
    elif args.action == "reaction":
        print(f"反应风格: {mbti.get_reaction_style()}")
    
    elif args.action == "from_tags":
        mbti_from = MBTISystem.from_tags(args.tags.split(","))
        print(f"从标签推断MBTI: {mbti_from.mbti_type} ({mbti_from._get_type_name()})")


def cmd_motivation(args):
    """动机系统操作"""
    mot_system = MotivationSystem()
    
    if args.action == "activate":
        instinct = InstinctType(args.instinct)
        result = mot_system.activate_instinct(instinct, args.modifier or 1.0)
        print(json.dumps({
            "instinct": result.instinct_type.value,
            "intensity": result.intensity,
            "active": result.is_active
        }, indent=2))
    
    elif args.action == "profile":
        print(json.dumps(mot_system.get_motivation_profile(), indent=2, ensure_ascii=False))
    
    elif args.action == "conflicts":
        conflicts = mot_system.check_conflicts()
        print(f"检测到 {len(conflicts)} 个动机冲突")
        for c in conflicts:
            print(f"  - {c.motivation_1} vs {c.motivation_2} ({c.conflict_type})")
    
    elif args.action == "dominant":
        dominant = mot_system.get_dominant_motivation()
        if dominant:
            print(f"主导动机: {dominant.instinct_type.value} (强度: {dominant.intensity:.2f})")
        else:
            print("无活跃动机")


def cmd_author(args):
    """作者约束操作"""
    author = AuthorConstraintSystem()
    
    if args.action == "validate":
        result = author.validate_behavior(args.behavior)
        print(json.dumps(result, indent=2))
    
    elif args.action == "report":
        print(json.dumps(author.get_system_report(), indent=2, ensure_ascii=False))
    
    elif args.action == "constraint":
        constraint = author.generate_character_constraint(args.mbti, args.trauma)
        print(json.dumps({
            "can_fail": constraint.can_fail,
            "can_be_wrong": constraint.can_be_wrong,
            "can_not_know": constraint.can_not_know,
            "allow_blanks": constraint.allow_blanks,
            "no_definition": constraint.no_definition,
            "no_explanation": constraint.no_explanation
        }, indent=2))


def main():
    parser = argparse.ArgumentParser(
        description="天道系统 CLI - Tiandao System Command Line Interface",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m tiandao.cli create --name "枫" --mbti INTJ --y 70
  python -m tiandao.cli calculate --character "枫" --situation "战友牺牲了"
  python -m tiandao.cli memory add --character "枫" --content "创伤记忆" --type episodic --traumatic
  python -m tiandao.cli yvalue status
  python -m tiandao.cli mbti profile --type INTJ
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # create
    p_create = subparsers.add_parser("create", help="Create a new character")
    p_create.add_argument("--id", help="Character ID")
    p_create.add_argument("--name", required=True, help="Character name")
    p_create.add_argument("--y", type=int, default=50, help="Base Y value")
    p_create.add_argument("--mbti", default="INTJ", help="MBTI type")
    p_create.add_argument("--tags", help="Comma-separated tags")
    p_create.add_argument("--description", help="Character description")
    
    # calculate
    p_calc = subparsers.add_parser("calculate", help="Calculate psychological response")
    p_calc.add_argument("--character", required=True, help="Character name/ID")
    p_calc.add_argument("--situation", required=True, help="Situation description")
    p_calc.add_argument("--y", type=int, help="Override base Y")
    p_calc.add_argument("--mbti", help="Override MBTI")
    p_calc.add_argument("--interaction-y", type=int, help="Interacting character's Y")
    
    # memory
    p_mem = subparsers.add_parser("memory", help="Manage memories")
    p_mem.add_argument("--action", required=True, choices=["add", "search", "ptsd"])
    p_mem.add_argument("--character", required=True)
    p_mem.add_argument("--content", help="Memory content")
    p_mem.add_argument("--type", help="Memory type")
    p_mem.add_argument("--emotion", type=float, help="Emotional intensity")
    p_mem.add_argument("--traumatic", action="store_true")
    p_mem.add_argument("--trauma", type=float)
    p_mem.add_argument("--query", help="Search query")
    p_mem.add_argument("--event", help="PTSD check event")
    p_mem.add_argument("--limit", type=int, default=10)
    
    # profile
    p_prof = subparsers.add_parser("profile", help="Show character profile")
    p_prof.add_argument("--character", required=True)
    p_prof.add_argument("--y", type=int)
    p_prof.add_argument("--mbti")
    p_prof.add_argument("--format", choices=["json", "text"], default="text")
    
    # yvalue
    p_y = subparsers.add_parser("yvalue", help="Y-value system operations")
    p_y.add_argument("--action", required=True, choices=["status", "set", "breakthrough", "influence"])
    p_y.add_argument("--value", type=int, help="Y value to set")
    p_y.add_argument("--baseline", type=int, help="Baseline Y value")
    p_y.add_argument("--attacker", type=int, help="Attacker Y value")
    p_y.add_argument("--defender", type=int, help="Defender Y value")
    p_y.add_argument("--target", type=int, help="Target Y value")
    
    # mbti
    p_m = subparsers.add_parser("mbti", help="MBTI system operations")
    p_m.add_argument("--action", required=True, choices=["profile", "baseline", "reaction", "from_tags"])
    p_m.add_argument("--type", default="INTJ", help="MBTI type")
    p_m.add_argument("--base", type=int, help="Base Y value")
    p_m.add_argument("--tags", help="Comma-separated tags")
    
    # motivation
    p_mot = subparsers.add_parser("motivation", help="Motivation system operations")
    p_mot.add_argument("--action", required=True, choices=["activate", "profile", "conflicts", "dominant"])
    p_mot.add_argument("--instinct", help="Instinct type")
    p_mot.add_argument("--modifier", type=float, help="Intensity modifier")
    
    # author
    p_auth = subparsers.add_parser("author", help="Author constraint operations")
    p_auth.add_argument("--action", required=True, choices=["validate", "report", "constraint"])
    p_auth.add_argument("--behavior", help="Behavior to validate")
    p_auth.add_argument("--mbti", help="MBTI type")
    p_auth.add_argument("--trauma", type=float, help="Trauma level")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # 执行命令
    commands = {
        "create": cmd_create,
        "calculate": cmd_calculate,
        "memory": cmd_memory,
        "profile": cmd_profile,
        "yvalue": cmd_yvalue,
        "mbti": cmd_mbti,
        "motivation": cmd_motivation,
        "author": cmd_author
    }
    
    commands[args.command](args)


if __name__ == "__main__":
    main()
