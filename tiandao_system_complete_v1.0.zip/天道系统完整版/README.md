# 天道系统完整版 - Tiandao System Complete Package

## 项目概述

本包是**天道系统三位一体完整落地包**，整合了三个层次：

```
┌─────────────────────────────────────────────────────┐
│  第1层: tiandao_core    Python核心库 (独立运行)        │
│  第2层: sillytavern_backend  Flask API服务层         │
│  第3层: sillytavern_plugin   SillyTavern JS插件      │
└─────────────────────────────────────────────────────┘
```

## 目录结构

```
tiandao_system_complete/
├── tiandao_core/              # 第1层: Python核心
│   ├── tiandao/               #   核心包
│   │   ├── __init__.py
│   │   ├── cli.py             #   命令行工具
│   │   ├── core/              #   核心子系统
│   │   │   ├── y_value.py     #   Y值系统
│   │   │   ├── mbti.py        #   MBTI系统
│   │   │   ├── memory.py      #   记忆系统
│   │   │   ├── motivation.py  #   动机链系统
│   │   │   ├── author.py      #   作者约束系统
│   │   │   ├── psychology.py  #   心理学引擎
│   │   │   └── profile.py     #   角色画像聚合
│   │   └── utils/
│   ├── tests/                 #   测试套件
│   └── README.md
│
├── sillytavern_backend/        # 第2层: Flask后端
│   ├── server.py              #   主服务器
│   ├── psychology_api.py      #   心理分析API
│   ├── character_api.py       #   角色管理API
│   ├── character_manager.py   #   角色卡解析
│   ├── message_formatter.py   #   消息格式化
│   ├── config.py              #   配置管理
│   ├── utils/                 #   工具函数
│   ├── tests/                 #   测试套件
│   └── requirements.txt
│
├── sillytavern_plugin/        # 第3层: SillyTavern插件
│   ├── tiandao_plugin.js      #   主插件 (72KB)
│   ├── manifest.json          #   插件清单
│   ├── README.md              #   插件使用说明
│   ├── example_config.json    #   示例配置
│   └── sample_character.json  #   示例角色卡
│
└── README.md                  #   本文件
```

## 安装与使用

### 方法一：一键启动（推荐）

```bash
# 1. 解压本包
unzip 天道系统完整版.zip
cd 天道系统完整版

# 2. 安装Python核心
cd tiandao_core
pip install -e .

# 3. 安装后端依赖
cd ../sillytavern_backend
pip install -r requirements.txt

# 4. 启动后端
python server.py
# 后端运行在 http://localhost:5000

# 5. 安装SillyTavern插件
# 复制 sillytavern_plugin/ 整个目录到你的 SillyTavern/scripts/extensions/plugins/
```

### 方法二：单独使用Python核心

```bash
cd tiandao_core
pip install -e .

# 命令行使用
tiandao y-value calculate 75
tiandao mbti show ENFP
tiandao memory add "重要事件" --type episodic
tiandao motivation --list
tiandao run-demo

# Python API
python -c "
from tiandao import create_profile
p = create_profile('角色名', mbti_type='ENFP', base_y=70)
print(p.get_full_profile())
"
```

### 方法三：只运行后端API

```bash
cd sillytavern_backend
pip install -r requirements.txt
python server.py

# API文档: http://localhost:5000/api/docs
```

## 功能概览

### Python核心 (tiandao_core)

| 子系统 | 功能 |
|--------|------|
| Y值系统 | 主观意识凝练强度计算，情绪反弹/补偿/PTSD机制 |
| MBTI系统 | 16种人格权重分析，大五人格推导 |
| 记忆系统 | 5型记忆分层，短期/长期/情感/创伤记忆 |
| 动机链系统 | 7本能×4层级动机链，动机冲突检测 |
| 作者约束 | 群像冲突解析，叙事一致性约束 |
| 角色画像 | 统一聚合以上所有子系统 |

### Flask API (sillytavern_backend)

| 端点前缀 | 功能 |
|----------|------|
| `/api/v1/psychology/` | 心理分析、Y值、MBTI、情绪计算 |
| `/api/v1/characters/` | 角色CRUD、记忆管理、PTSD检查 |
| `/api/v1/message/` | 消息格式化、上下文注入 |

### SillyTavern插件 (sillytavern_plugin)

| 功能 | 说明 |
|------|------|
| 角色分析 | 加载时自动分析角色心理 |
| Y值追踪 | 实时显示情绪状态 |
| PTSD检测 | 创伤触发词检测与提示 |
| 记忆注入 | 自动将相关记忆注入对话上下文 |
| 动机可视化 | 显示当前激活的动机链 |
| 消息标注 | 对话中显示情绪/心理标注 |
| 斜杠命令 | `/tiandao` 系列命令 |

## 配置说明

### 后端环境变量

复制 `.env.example` 为 `.env` 并配置：

```env
FLASK_ENV=development
PORT=5000
HOST=0.0.0.0
CORS_ORIGINS=*
LOG_LEVEL=INFO
```

### 插件配置

在 SillyTavern 界面 > 设置 > 扩展 > 插件 > Tiandao System 中配置：

- `backend_url`: 后端地址（默认 `http://localhost:5000`）
- `auto_analyze`: 加载时自动分析角色
- `analysis_depth`: 分析深度（quick/standard/deep）
- `inject_context`: 注入上下文到提示词
- `show_y_value`: 在界面显示Y值
- `enable_cache`: 启用结果缓存
- `debug_mode`: 调试模式

## 系统要求

- Python 3.10+
- SillyTavern 1.11+
- 建议 4GB+ RAM

## 技术支持

GitHub: https://github.com/shaoyili1990/SQLP

## 版本历史

- v1.0.0 - 完整版发布，三位一体整合
