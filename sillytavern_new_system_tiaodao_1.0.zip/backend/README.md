# Backend API

Backend API for SillyTavern character chat system with psychological analysis support.

## Features

- Character card parsing (V1 and V2 formats)
- Message formatting and display
- Psychological analysis API (Big Five personality traits)
- MBTI type detection and analysis
- Emotional state calculation
- Context generation for prompt injection
- RESTful API design
- CORS support for SillyTavern integration

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

Create a `.env` file based on environment variables:

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| HOST | Server host | 0.0.0.0 |
| PORT | Server port | 5000 |
| DEBUG | Debug mode | True |
| FLASK_ENV | Environment | development |
| PSYCHOLOGY_ENABLED | Enable psychology analysis | True |
| PERSONALITY_MODEL | Analysis model | keyword |
| CORS_ORIGINS | Allowed CORS origins | * |
| LOG_LEVEL | Logging level | INFO |

## Running the Server

```bash
# Development
python server.py

# Production (using gunicorn)
gunicorn -w 4 -b 0.0.0.0:5000 server:app
```

## API Endpoints

### Health & Status

#### GET /api/health
Health check endpoint for monitoring.

```bash
curl http://localhost:5000/api/health
```

Response:
```json
{
  "status": "healthy",
  "service": "tiandao-backend",
  "version": "1.0.0",
  "timestamp": 1234567890.123
}
```

#### GET /api/status
Extended status check with module states.

```bash
curl http://localhost:5000/api/status
```

### Character Card Endpoints

#### POST /api/characters
Parse a character card from request data.

```bash
curl -X POST http://localhost:5000/api/characters \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Character Name",
    "description": "Character description...",
    "personality": "Personality traits...",
    "scenario": "The scenario..."
  }'
```

Response:
```json
{
  "success": true,
  "data": {
    "name": "Character Name",
    "description": "...",
    "personality": "...",
    "version": "v2"
  }
}
```

#### POST /api/characters/validate
Validate a character card structure.

```bash
curl -X POST http://localhost:5000/api/characters/validate \
  -H "Content-Type: application/json" \
  -d '{"name": "Test"}'
```

#### POST /api/characters/extract
Extract characteristics from character description.

```bash
curl -X POST http://localhost:5000/api/characters/extract \
  -H "Content-Type: application/json" \
  -d '{"description": "A kind and caring person..."}'
```

### Message Formatting Endpoints

#### POST /api/format-message
Format a single chat message.

```bash
curl -X POST http://localhost:5000/api/format-message \
  -H "Content-Type: application/json" \
  -d '{
    "role": "user",
    "content": "Hello!"
  }'
```

#### POST /api/format-conversation
Format multiple messages in a conversation.

```bash
curl -X POST http://localhost:5000/api/format-conversation \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Hello"},
      {"role": "assistant", "content": "Hi there!"}
    ]
  }'
```

### Context Generation Endpoints

#### POST /api/context/generate
Generate character context for prompt injection.

```bash
curl -X POST http://localhost:5000/api/context/generate \
  -H "Content-Type: application/json" \
  -d '{
    "character_id": "char123",
    "profile": {
      "mbti": "ENFJ",
      "traits": {"openness": 0.8, "conscientiousness": 0.6}
    },
    "format": "default"
  }'
```

### Psychology API Endpoints

#### POST /api/psychology/analyze
Analyze character personality from description. Returns Big Five personality traits, MBTI type, and psychological profile.

```bash
curl -X POST http://localhost:5000/api/psychology/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Character Name",
    "description": "A creative and artistic person who loves adventure...",
    "depth": "standard"
  }'
```

Response:
```json
{
  "success": true,
  "data": {
    "name": "Character Name",
    "mbti": {
      "type": "ENFP",
      "name": "The Campaigner",
      "description": "Enthusiastic and creative..."
    },
    "traits": {
      "openness": 0.8,
      "conscientiousness": 0.5,
      "extraversion": 0.7,
      "agreeableness": 0.6,
      "neuroticism": 0.4
    },
    "motivation": {
      "primary": "affiliation",
      "all": ["affiliation", "meaning"]
    },
    "fears": ["rejection"],
    "attachment_style": "secure",
    "confidence": 0.85
  }
}
```

#### POST /api/psychology/analyze-message
Analyze a message for psychological consistency.

```bash
curl -X POST http://localhost:5000/api/psychology/analyze-message \
  -H "Content-Type: application/json" \
  -d '{
    "message": {"content": "I am so happy today!"},
    "profile": {"mbti": "ENFJ"}
  }'
```

#### GET /api/psychology/moods
Get available mood options for characters.

```bash
curl http://localhost:5000/api/psychology/moods
```

#### POST /api/psychology/emotional-state
Calculate emotional state based on conversation context.

```bash
curl -X POST http://localhost:5000/api/psychology/emotional-state \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"content": "Hello!"},
      {"content": "Hi! How are you?"}
    ],
    "character": {"mbti": "ENFJ"},
    "depth": "standard"
  }'
```

#### GET /api/psychology/mbti
Get all MBTI types with descriptions.

```bash
curl http://localhost:5000/api/psychology/mbti
```

#### GET /api/psychology/mbti/{type_code}
Get details for a specific MBTI type.

```bash
curl http://localhost:5000/api/psychology/mbti/INTJ
```

## Modules

- `server.py` - Main Flask application with all endpoints
- `config.py` - Configuration management with environment variables
- `character_card_parser.py` - Character card parsing (V1/V2 support)
- `message_formatter.py` - Message formatting utilities
- `psychology_api.py` - Psychological analysis and MBTI detection

## Testing

```bash
# Run tests
pytest

# Run with coverage
pytest --cov=backend --cov-report=html

# Run specific test file
pytest tests/test_backend.py -v
```

## Docker

```bash
# Build
docker build -t tiandao-backend ./backend

# Run
docker run -p 5000:5000 tiandao-backend
```

## License

MIT License
