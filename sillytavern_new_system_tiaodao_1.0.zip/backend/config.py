"""
Configuration Module
Central configuration settings for the backend
"""

import os
from typing import List, Dict, Any

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not installed, use environment variables directly


class Config:
    """Application configuration"""
    
    # Server settings
    HOST = os.getenv('HOST', '0.0.0.0')
    PORT = int(os.getenv('PORT', 5000))
    DEBUG = os.getenv('DEBUG', 'True').lower() == 'true'
    FLASK_ENV = os.getenv('FLASK_ENV', 'development')
    
    # API settings
    API_PREFIX = '/api'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    JSON_SORT_KEYS = False
    
    # Psychology API settings
    PSYCHOLOGY_ENABLED = os.getenv('PSYCHOLOGY_ENABLED', 'True').lower() == 'true'
    PERSONALITY_MODEL = os.getenv('PERSONALITY_MODEL', 'keyword')
    ANALYSIS_DEPTH_DEFAULT = os.getenv('ANALYSIS_DEPTH_DEFAULT', 'standard')
    
    # Character card settings
    MAX_CHARACTER_CARDS = int(os.getenv('MAX_CHARACTER_CARDS', 100))
    CARD_VERSION_DEFAULT = os.getenv('CARD_VERSION_DEFAULT', 'v2')
    ENABLE_CARD_VALIDATION = os.getenv('ENABLE_CARD_VALIDATION', 'True').lower() == 'true'
    
    # Message settings
    MAX_MESSAGE_LENGTH = int(os.getenv('MAX_MESSAGE_LENGTH', 10000))
    MESSAGE_HISTORY_LIMIT = int(os.getenv('MESSAGE_HISTORY_LIMIT', 50))
    MAX_CONVERSATION_MESSAGES = int(os.getenv('MAX_CONVERSATION_MESSAGES', 200))
    
    # External API settings
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    ANTHROPIC_API_KEY = os.getenv('ANTHROPIC_API_KEY', '')
    EXTERNAL_API_TIMEOUT = int(os.getenv('EXTERNAL_API_TIMEOUT', 30))
    
    # CORS settings
    CORS_ORIGINS = os.getenv('CORS_ORIGINS', '*').split(',')
    CORS_ALLOW_HEADERS = os.getenv('CORS_ALLOW_HEADERS', 
                                   'Content-Type,Authorization').split(',')
    CORS_EXPOSE_HEADERS = os.getenv('CORS_EXPOSE_HEADERS', '').split(',')
    
    # Rate limiting
    ENABLE_RATE_LIMITING = os.getenv('ENABLE_RATE_LIMITING', 'True').lower() == 'true'
    RATE_LIMIT_PER_MINUTE = int(os.getenv('RATE_LIMIT_PER_MINUTE', 60))
    RATE_LIMIT_PER_HOUR = int(os.getenv('RATE_LIMIT_PER_HOUR', 1000))
    
    # Cache settings
    ENABLE_CACHING = os.getenv('ENABLE_CACHING', 'True').lower() == 'true'
    CACHE_TYPE = os.getenv('CACHE_TYPE', 'simple')  # simple, redis, memcached
    CACHE_DEFAULT_TIMEOUT = int(os.getenv('CACHE_DEFAULT_TIMEOUT', 300))
    
    # Redis settings (if using Redis cache)
    REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
    REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
    REDIS_DB = int(os.getenv('REDIS_DB', 0))
    REDIS_PASSWORD = os.getenv('REDIS_PASSWORD', '')
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FORMAT = os.getenv('LOG_FORMAT', 
                          '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    LOG_DATE_FORMAT = os.getenv('LOG_DATE_FORMAT', '%Y-%m-%d %H:%M:%S')
    LOG_FILE = os.getenv('LOG_FILE', '')
    
    # Security
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    SESSION_COOKIE_SECURE = os.getenv('SESSION_COOKIE_SECURE', 'False').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = os.getenv('SESSION_COOKIE_HTTPONLY', 'True').lower() == 'true'
    SESSION_COOKIE_SAMESITE = os.getenv('SESSION_COOKIE_SAMESITE', 'Lax')
    
    # Database (if using)
    DATABASE_URL = os.getenv('DATABASE_URL', '')
    DATABASE_POOL_SIZE = int(os.getenv('DATABASE_POOL_SIZE', 10))
    
    # Feature flags
    FEATURE_CONTEXT_INJECTION = os.getenv('FEATURE_CONTEXT_INJECTION', 'True').lower() == 'true'
    FEATURE_EMOTIONAL_TRACKING = os.getenv('FEATURE_EMOTIONAL_TRACKING', 'True').lower() == 'true'
    FEATURE_MESSAGE_ANALYSIS = os.getenv('FEATURE_MESSAGE_ANALYSIS', 'True').lower() == 'true'
    
    # Response settings
    RESPONSE_INCLUDE_TIMESTAMP = os.getenv('RESPONSE_INCLUDE_TIMESTAMP', 'True').lower() == 'true'
    RESPONSE_INCLUDE_METADATA = os.getenv('RESPONSE_INCLUDE_METADATA', 'True').lower() == 'true'


class DevelopmentConfig(Config):
    """Development environment configuration"""
    DEBUG = True
    FLASK_ENV = 'development'
    LOG_LEVEL = 'DEBUG'
    
    # More relaxed settings for development
    ENABLE_CARD_VALIDATION = True
    ENABLE_RATE_LIMITING = False


class ProductionConfig(Config):
    """Production environment configuration"""
    DEBUG = False
    FLASK_ENV = 'production'
    LOG_LEVEL = 'WARNING'
    
    # Strict settings for production
    ENABLE_CARD_VALIDATION = True
    ENABLE_RATE_LIMITING = True
    
    # Security settings
    SESSION_COOKIE_SECURE = True


class TestConfig(Config):
    """Test environment configuration"""
    TESTING = True
    DEBUG = True
    FLASK_ENV = 'testing'
    LOG_LEVEL = 'DEBUG'
    
    # Testing settings
    ENABLE_CACHING = False
    ENABLE_RATE_LIMITING = False
    MAX_CONTENT_LENGTH = 1 * 1024 * 1024  # 1MB for tests


# Configuration registry
config_by_name: Dict[str, Config] = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'test': TestConfig,
    'default': Config
}


def get_config(env_name: str = None) -> Config:
    """Get configuration for specified environment"""
    if env_name is None:
        env_name = os.getenv('FLASK_ENV', 'development')
    
    return config_by_name.get(env_name, Config)


def get_config_dict() -> Dict[str, Any]:
    """Get configuration as dictionary (for debugging)"""
    config = get_config()
    return {
        key: getattr(config, key)
        for key in dir(config)
        if not key.startswith('_') and not callable(getattr(config, key))
    }


# Create default config instance
config = get_config()
