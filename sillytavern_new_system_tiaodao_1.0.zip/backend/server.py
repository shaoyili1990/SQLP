"""
SillyTavern Backend Server
Main entry point for the tiandao psychology system API
"""

from flask import Flask, request, jsonify, g
from flask_cors import CORS
import logging
import time
from functools import wraps

from config import Config, get_config
from psychology_api import psychology_bp
from character_card_parser import CharacterCardParser
from message_formatter import MessageFormatter

# Create Flask app
app = Flask(__name__)

# Load configuration
env = Config
app.config.from_object(env)

# Enable CORS
CORS(app, resources={
    r"/api/*": {
        "origins": env.CORS_ORIGINS,
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

# Configure logging
logging.basicConfig(
    level=getattr(logging, env.LOG_LEVEL),
    format=env.LOG_FORMAT
)
logger = logging.getLogger(__name__)

# Initialize modules
character_parser = CharacterCardParser()
message_formatter = MessageFormatter()

# Request timing decorator
def timing_decorator(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        result = f(*args, **kwargs)
        elapsed = time.time() - start_time
        logger.debug(f"{f.__name__} completed in {elapsed:.3f}s")
        return result
    return decorated_function


# ============================================
# Health & Status Endpoints
# ============================================

@app.route('/api/health', methods=['GET'])
@timing_decorator
def health_check():
    """Health check endpoint for monitoring"""
    return jsonify({
        'status': 'healthy',
        'service': 'tiandao-backend',
        'version': '1.0.0',
        'timestamp': time.time()
    })


@app.route('/api/status', methods=['GET'])
@timing_decorator
def status_check():
    """Extended status check with module states"""
    return jsonify({
        'status': 'healthy',
        'modules': {
            'psychology': Config.PSYCHOLOGY_ENABLED,
            'character_parser': True,
            'message_formatter': True
        },
        'config': {
            'debug': Config.DEBUG,
            'cors_origins': Config.CORS_ORIGINS
        }
    })


# ============================================
# Character Card Endpoints
# ============================================

@app.route('/api/characters', methods=['POST'])
@timing_decorator
def parse_character():
    """Parse a character card from request data"""
    try:
        data = request.get_json(force=True, silent=True)
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        if 'name' not in data:
            return jsonify({
                'success': False,
                'error': 'Character name is required'
            }), 400
        
        result = character_parser.parse_character(data)
        
        logger.info(f"Parsed character: {result.get('name', 'Unknown')}")
        
        return jsonify({
            'success': True,
            'data': result
        })
        
    except ValueError as e:
        logger.error(f"Validation error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400
    except Exception as e:
        logger.error(f"Error parsing character: {e}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500


@app.route('/api/characters/validate', methods=['POST'])
@timing_decorator
def validate_character():
    """Validate a character card structure"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'valid': False,
                'errors': ['No data provided']
            }), 400
        
        is_valid, errors = character_parser.validate_card(data)
        
        return jsonify({
            'valid': is_valid,
            'errors': errors
        })
        
    except Exception as e:
        logger.error(f"Validation error: {e}")
        return jsonify({
            'valid': False,
            'errors': [str(e)]
        }), 500


@app.route('/api/characters/extract', methods=['POST'])
@timing_decorator
def extract_characteristics():
    """Extract characteristics from character description"""
    try:
        data = request.get_json()
        description = data.get('description', '')
        
        if not description:
            return jsonify({
                'success': False,
                'error': 'Description is required'
            }), 400
        
        characteristics = character_parser.extract_characteristics(description)
        
        return jsonify({
            'success': True,
            'data': characteristics
        })
        
    except Exception as e:
        logger.error(f"Extraction error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================
# Message Formatting Endpoints
# ============================================

@app.route('/api/format-message', methods=['POST'])
@timing_decorator
def format_message():
    """Format a chat message for display"""
    try:
        data = request.get_json(force=True, silent=True)
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        result = message_formatter.format_message(data)
        
        return jsonify({
            'success': True,
            'data': result
        })
        
    except Exception as e:
        logger.error(f"Formatting error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/format-conversation', methods=['POST'])
@timing_decorator
def format_conversation():
    """Format multiple messages in a conversation"""
    try:
        data = request.get_json()
        messages = data.get('messages', [])
        
        if not messages:
            return jsonify({
                'success': False,
                'error': 'No messages provided'
            }), 400
        
        results = message_formatter.format_conversation(messages)
        
        return jsonify({
            'success': True,
            'data': {
                'messages': results,
                'count': len(results)
            }
        })
        
    except Exception as e:
        logger.error(f"Conversation formatting error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================
# Context Generation Endpoints
# ============================================

@app.route('/api/context/generate', methods=['POST'])
@timing_decorator
def generate_context():
    """Generate character context for prompt injection"""
    try:
        data = request.get_json(force=True, silent=True)
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        character_id = data.get('character_id')
        profile = data.get('profile')
        format_type = data.get('format', 'default')
        
        # Generate context based on profile
        context = _generate_character_context(profile, format_type)
        
        return jsonify({
            'success': True,
            'data': {
                'context': context,
                'character_id': character_id
            }
        })
        
    except Exception as e:
        logger.error(f"Context generation error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


def _generate_character_context(profile, format_type='default'):
    """Generate formatted character context string"""
    if not profile:
        return ''
    
    parts = []
    
    if format_type in ['default', 'full']:
        parts.append('[Character Psychology Context]')
        
        # MBTI
        if profile.get('mbti'):
            mbti = profile['mbti']
            mbti_type = mbti.get('type', mbti) if isinstance(mbti, dict) else mbti
            parts.append(f"MBTI Type: {mbti_type}")
        
        # Big Five Traits
        if profile.get('traits'):
            traits = profile['traits']
            trait_parts = []
            for trait, value in traits.items():
                level = 'High' if value > 0.7 else 'Moderate' if value > 0.3 else 'Low'
                trait_parts.append(f"{trait.title()}: {level} ({value:.0%})")
            if trait_parts:
                parts.append(f"Personality Traits: {', '.join(trait_parts)}")
        
        # Core Motivation
        if profile.get('motivation'):
            motivation = profile['motivation']
            if isinstance(motivation, dict):
                motivation = motivation.get('primary', str(motivation))
            parts.append(f"Core Motivation: {motivation}")
        
        # Psychology
        if profile.get('psychology'):
            psych = profile['psychology']
            psych_text = psych.get('core', psych) if isinstance(psych, dict) else psych
            parts.append(f"Psychological Profile: {psych_text}")
        
        # Attachment Style
        if profile.get('attachment_style'):
            parts.append(f"Attachment Style: {profile['attachment_style']}")
        
        # Fears
        if profile.get('fears'):
            parts.append(f"Core Fears: {', '.join(profile['fears'])}")
        
        parts.append('[/Character Psychology Context]')
    
    elif format_type == 'compact':
        # Compact format for tokens
        if profile.get('mbti'):
            mbti = profile['mbti']
            mbti_type = mbti.get('type', mbti) if isinstance(mbti, dict) else mbti
            parts.append(f"[MBTI: {mbti_type}]")
        
        if profile.get('motivation'):
            motivation = profile['motivation']
            if isinstance(motivation, dict):
                motivation = motivation.get('primary', str(motivation))
            parts.append(f"[Motivation: {motivation}]")
    
    return '\n'.join(parts)


# ============================================
# Error Handlers
# ============================================

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        'success': False,
        'error': 'Endpoint not found'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    logger.error(f"Internal error: {error}")
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500


@app.errorhandler(413)
def request_too_large(error):
    """Handle file too large errors"""
    return jsonify({
        'success': False,
        'error': 'Request entity too large'
    }), 413


# ============================================
# Request Logging Middleware
# ============================================

@app.before_request
def log_request():
    """Log incoming requests"""
    g.start_time = time.time()
    logger.debug(f"{request.method} {request.path}")


@app.after_request
def log_response(response):
    """Log outgoing responses"""
    if hasattr(g, 'start_time'):
        elapsed = time.time() - g.start_time
        logger.debug(f"{request.method} {request.path} - {response.status_code} ({elapsed:.3f}s)")
    return response


# Register blueprints
app.register_blueprint(psychology_bp, url_prefix='/api/psychology')


# ============================================
# Application Entry Point
# ============================================

if __name__ == '__main__':
    logger.info(f"Starting Tiandao Backend Server")
    logger.info(f"Debug mode: {Config.DEBUG}")
    logger.info(f"Host: {Config.HOST}:{Config.PORT}")
    
    app.run(
        host=Config.HOST,
        port=Config.PORT,
        debug=Config.DEBUG,
        threaded=True
    )
