"""
Psychology API Module
Handles psychological analysis and personality traits for characters
"""

from flask import Blueprint, request, jsonify
import logging
import re
from typing import Dict, Any, List, Optional

psychology_bp = Blueprint('psychology', __name__)
logger = logging.getLogger(__name__)

# MBTI type descriptions
MBTI_TYPES = {
    'ISTJ': {
        'name': 'The Inspector',
        'traits': ['Responsible', 'Organized', 'Practical', 'Detailed', 'Reliable'],
        'description': 'Quiet, serious, and dependable. Values traditions and loyalty.'
    },
    'ISFJ': {
        'name': 'The Protector',
        'traits': ['Warm', 'Considerate', 'Careful', 'Helpful', 'Devoted'],
        'description': 'Quiet, friendly, responsible, and conscientious. Works behind the scenes.'
    },
    'INFJ': {
        'name': 'The Advocate',
        'traits': ['Idealistic', 'Principled', 'Creative', 'Compassionate', 'Insightful'],
        'description': 'Quiet, inspired, and creative. Seeks meaning and authentic connections.'
    },
    'INTJ': {
        'name': 'The Architect',
        'traits': ['Strategic', 'Independent', 'Logical', 'Decisive', 'High Standards'],
        'description': 'Independent, strategic thinker with vision and determination.'
    },
    'ISTP': {
        'name': 'The Craftsman',
        'traits': ['Practical', 'Logical', 'Spontaneous', 'Action-oriented', 'Curious'],
        'description': 'Quiet and reserved. Interested in how things work.'
    },
    'ISFP': {
        'name': 'The Adventurer',
        'traits': ['Artistic', 'Sensitive', 'Adaptable', 'Gentle', 'Present'],
        'description': 'Quiet, friendly, and sensitive. Values authenticity and freedom.'
    },
    'INFP': {
        'name': 'The Mediator',
        'traits': ['Idealistic', 'Curious', 'Creative', 'Compassionate', 'Loyal'],
        'description': 'Quiet, thoughtful, and compassionate. Seeks authentic self-expression.'
    },
    'INTP': {
        'name': 'The Thinker',
        'traits': ['Logical', 'Analytical', 'Abstract', 'Theoretical', 'Objective'],
        'description': 'Quiet and reserved. Loves theoretical concepts and abstract thinking.'
    },
    'ESTP': {
        'name': 'The Entrepreneur',
        'traits': ['Energetic', 'Practical', 'Spontaneous', 'Social', 'Adaptable'],
        'description': 'Flexible and tolerant. Takes a pragmatic approach focused on immediate results.'
    },
    'ESFP': {
        'name': 'The Entertainer',
        'traits': ['Enthusiastic', 'Social', 'Spontaneous', 'Generous', 'Fun-loving'],
        'description': 'Outgoing, friendly, and accepting. Loves being the center of attention.'
    },
    'ENFP': {
        'name': 'The Campaigner',
        'traits': ['Enthusiastic', 'Creative', 'Social', 'Optimistic', 'Inspiring'],
        'description': 'Enthusi and creative. Sees possibilities and connects with people.'
    },
    'ENTP': {
        'name': 'The Debater',
        'traits': ['Inventive', 'Curious', 'Outgoing', 'Strategic', 'Verbal'],
        'description': 'Quick and witty. Loves intellectual debates and new ideas.'
    },
    'ESTJ': {
        'name': 'The Director',
        'traits': ['Practical', 'Realistic', 'Decisive', 'Logical', 'Organized'],
        'description': 'Takes charge and gets things done. Values efficiency and order.'
    },
    'ESFJ': {
        'name': 'The Provider',
        'traits': ['Caring', 'Social', 'Popular', 'Cooperative', 'Conscientious'],
        'description': 'Warm-hearted, popular, and conscientious. Wants everyone to be happy.'
    },
    'ENFJ': {
        'name': 'The Protagonist',
        'traits': ['Charismatic', 'Inspiring', 'Empathetic', 'Leadership', 'Idealistic'],
        'description': 'Charismatic and inspiring. Leads and motivates others toward common goals.'
    },
    'ENTJ': {
        'name': 'The Commander',
        'traits': ['Bold', 'Imaginative', 'Commanding', 'Strategic', 'Decisive'],
        'description': 'Commanding leader with strong opinions. Loves challenges and strategic planning.'
    }
}

# Keywords for trait analysis
TRAIT_KEYWORDS = {
    'openness': {
        'high': ['creative', 'curious', 'artistic', 'imaginative', 'adventurous', 'innovative', 
                 'philosophical', 'experimental', 'unconventional', 'visionary', 'open-minded'],
        'low': ['traditional', 'conventional', 'practical', 'routine', 'cautious', 'conservative']
    },
    'conscientiousness': {
        'high': ['organized', 'disciplined', 'reliable', 'responsible', 'careful', 'thorough',
                 'efficient', 'goal-oriented', 'diligent', 'methodical', 'punctual'],
        'low': ['careless', 'disorganized', 'impulsive', 'spontaneous', 'flexible', 'relaxed']
    },
    'extraversion': {
        'high': ['outgoing', 'social', 'energetic', 'talkative', 'assertive', 'adventurous',
                 'enthusiastic', 'friendly', 'charismatic', 'bold', 'confident'],
        'low': ['introverted', 'quiet', 'reserved', 'shy', 'solitary', 'withdrawn', 'private']
    },
    'agreeableness': {
        'high': ['kind', 'trusting', 'helpful', 'cooperative', 'compassionate', 'sympathetic',
                 'generous', 'forgiving', 'empathetic', 'warm', 'understanding'],
        'low': ['competitive', 'challenging', 'critical', 'skeptical', 'detached', 'ruthless']
    },
    'neuroticism': {
        'high': ['anxious', 'worried', 'moody', 'emotional', 'sensitive', 'stressed',
                 'insecure', 'nervous', 'reactive', 'unstable', 'paranoid'],
        'low': ['calm', 'stable', 'confident', 'relaxed', 'even-tempered', 'balanced']
    }
}

# Motivation patterns
MOTIVATION_PATTERNS = {
    'achievement': ['accomplish', 'succeed', 'goal', 'win', 'excellence', 'challenge', 'master'],
    'affiliation': ['connect', 'belong', 'friend', 'relationship', 'together', 'community', 'harmony'],
    'power': ['control', 'lead', 'influence', 'authority', 'dominate', 'status', 'recognition'],
    'security': ['safe', 'protect', 'stability', 'predictable', 'reliable', 'order', 'certainty'],
    'autonomy': ['independent', 'freedom', 'self-reliant', 'personal', 'liberty', 'choice'],
    'meaning': ['purpose', 'meaningful', 'impact', 'contribution', 'legacy', 'values', 'belief']
}

# Fear patterns
FEAR_PATTERNS = {
    'rejection': ['reject', 'abandon', 'alone', 'abandoned', 'left out', 'unloved', 'ignored'],
    'failure': ['fail', 'incompetent', 'embarrass', 'disappoint', 'shame', 'humiliate'],
    'loss': ['lose', 'death', 'end', 'gone', 'taken away', 'deprive'],
    'vulnerability': ['weak', 'hurt', 'exposed', 'defenseless', 'attack', 'harm'],
    'chaos': ['disorder', 'chaos', 'unpredictable', 'uncertainty', 'out of control'],
    'inauthenticity': ['fake', 'phony', 'inauthentic', 'betray self', 'conform', 'lose identity']
}

# Attachment style indicators
ATTACHMENT_PATTERNS = {
    'secure': ['trust', 'comfortable', 'close', 'available', 'responsive', 'depend'],
    'anxious': ['worried', 'cling', 'fear', 'abandon', 'jealous', 'reassurance', 'need'],
    'avoidant': ['independent', 'distant', 'self-sufficient', 'uncomfortable', 'space', 'freedom'],
    'disorganized': ['confused', 'contradict', 'unpredictable', 'intense', 'fear', 'approach-avoidance']
}


@psychology_bp.route('/analyze', methods=['POST'])
def analyze_personality():
    """
    Analyze character personality from description
    Returns MBTI type, Big Five traits, and psychological profile
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        name = data.get('name', 'Unknown')
        description = data.get('description', '')
        personality = data.get('personality', '')
        scenario = data.get('scenario', '')
        first_message = data.get('first_message', '')
        depth = data.get('depth', 'standard')
        
        # Combine text for analysis
        full_text = f"{description} {personality} {scenario} {first_message}".strip()
        
        if not full_text:
            return jsonify({
                'success': False,
                'error': 'No text provided for analysis'
            }), 400
        
        # Analyze Big Five traits
        traits = analyze_big_five(full_text)
        
        # Determine MBTI type
        mbti = determine_mbti(traits, full_text)
        
        # Generate psychological profile
        profile = generate_psychological_profile(full_text, traits, mbti, depth)
        
        # Extract core motivations
        motivations = extract_motivations(full_text)
        
        # Extract fears
        fears = extract_fears(full_text)
        
        # Determine attachment style
        attachment = determine_attachment_style(full_text)
        
        result = {
            'name': name,
            'mbti': mbti,
            'traits': traits,
            'profile': profile,
            'motivation': {
                'primary': motivations[0] if motivations else 'unknown',
                'all': motivations
            },
            'fears': fears,
            'attachment_style': attachment,
            'confidence': calculate_confidence(traits)
        }
        
        logger.info(f"Analyzed personality for: {name}")
        
        return jsonify({
            'success': True,
            'data': result
        })
        
    except Exception as e:
        logger.error(f"Error analyzing personality: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@psychology_bp.route('/analyze-message', methods=['POST'])
def analyze_message_psychology():
    """Analyze a message for psychological consistency"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        message = data.get('message', {})
        profile = data.get('profile', {})
        
        content = message.get('content', '') if isinstance(message, dict) else str(message)
        
        # Simple sentiment analysis
        sentiment = analyze_sentiment(content)
        
        # Check consistency with profile
        consistency = check_profile_consistency(content, profile)
        
        # Detect emotional state
        emotional_indicators = detect_emotional_indicators(content)
        
        return jsonify({
            'success': True,
            'data': {
                'sentiment': sentiment,
                'consistency_score': consistency,
                'emotional_indicators': emotional_indicators
            }
        })
        
    except Exception as e:
        logger.error(f"Error analyzing message: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@psychology_bp.route('/mbti', methods=['GET'])
def get_mbti_types():
    """Get all MBTI types with descriptions"""
    return jsonify({
        'success': True,
        'data': MBTI_TYPES
    })


@psychology_bp.route('/mbti/<type_code>', methods=['GET'])
def get_mbti_detail(type_code):
    """Get details for a specific MBTI type"""
    type_code = type_code.upper()
    
    if type_code not in MBTI_TYPES:
        return jsonify({
            'success': False,
            'error': f'MBTI type {type_code} not found'
        }), 404
    
    return jsonify({
        'success': True,
        'data': MBTI_TYPES[type_code]
    })


@psychology_bp.route('/moods', methods=['GET'])
def get_moods():
    """Get available mood options for characters"""
    moods = [
        {'id': 'happy', 'name': 'Happy', 'emoji': '😊', 'valence': 0.8},
        {'id': 'content', 'name': 'Content', 'emoji': '😌', 'valence': 0.5},
        {'id': 'sad', 'name': 'Sad', 'emoji': '😢', 'valence': -0.6},
        {'id': 'angry', 'name': 'Angry', 'emoji': '😠', 'valence': -0.7},
        {'id': 'fearful', 'name': 'Fearful', 'emoji': '😨', 'valence': -0.5},
        {'id': 'anxious', 'name': 'Anxious', 'emoji': '😰', 'valence': -0.4},
        {'id': 'surprised', 'name': 'Surprised', 'emoji': '😲', 'valence': 0.2},
        {'id': 'disgusted', 'name': 'Disgusted', 'emoji': '🤢', 'valence': -0.6},
        {'id': 'confused', 'name': 'Confused', 'emoji': '😕', 'valence': -0.1},
        {'id': 'neutral', 'name': 'Neutral', 'emoji': '😐', 'valence': 0.0},
        {'id': 'excited', 'name': 'Excited', 'emoji': '🤩', 'valence': 0.9},
        {'id': 'tired', 'name': 'Tired', 'emoji': '😴', 'valence': -0.2}
    ]
    return jsonify({
        'success': True,
        'data': moods
    })


@psychology_bp.route('/emotional-state', methods=['POST'])
def calculate_emotional_state():
    """Calculate emotional state based on conversation context"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        messages = data.get('messages', [])
        character = data.get('character', {})
        depth = data.get('depth', 'standard')
        
        emotional_state = calculate_from_context(messages, character, depth)
        
        return jsonify({
            'success': True,
            'data': emotional_state
        })
        
    except Exception as e:
        logger.error(f"Error calculating emotional state: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


# ============================================
# Analysis Functions
# ============================================

def analyze_big_five(text: str) -> Dict[str, float]:
    """Analyze Big Five personality traits from text description"""
    text_lower = text.lower()
    traits = {
        'openness': 0.5,
        'conscientiousness': 0.5,
        'extraversion': 0.5,
        'agreeableness': 0.5,
        'neuroticism': 0.5
    }
    
    for trait, keywords in TRAIT_KEYWORDS.items():
        high_matches = sum(1 for kw in keywords['high'] if kw in text_lower)
        low_matches = sum(1 for kw in keywords['low'] if kw in text_lower)
        
        # Calculate trait value
        if high_matches + low_matches > 0:
            base = high_matches / (high_matches + low_matches)
            # Add some randomness for realism
            adjustment = (high_matches - low_matches) * 0.1
            traits[trait] = max(0.1, min(0.9, base + adjustment))
        else:
            # Default to moderate
            traits[trait] = 0.5
    
    return traits


def determine_mbti(traits: Dict[str, float], text: str) -> Dict[str, Any]:
    """Determine MBTI type based on Big Five traits and text analysis"""
    text_lower = text.lower()
    
    # Determine E/I (Extraversion vs Introversion)
    if traits['extraversion'] > 0.6:
        e_i = 'E'
    elif traits['extraversion'] < 0.4:
        e_i = 'I'
    else:
        # Check text for more clues
        e_keywords = ['outgoing', 'social', 'talkative', 'energetic', 'extroverted']
        i_keywords = ['quiet', 'reserved', 'private', 'introverted', 'solitary']
        
        e_count = sum(1 for kw in e_keywords if kw in text_lower)
        i_count = sum(1 for kw in i_keywords if kw in text_lower)
        
        e_i = 'E' if e_count > i_count else 'I'
    
    # Determine S/N (Sensing vs Intuition)
    if traits['openness'] > 0.6:
        s_n = 'N'
    elif traits['openness'] < 0.4:
        s_n = 'S'
    else:
        n_keywords = ['imagine', 'intuitive', 'creative', 'abstract', 'philosophical', 'theoretical']
        s_keywords = ['practical', 'concrete', 'sensory', 'realistic', 'actual', 'factual']
        
        n_count = sum(1 for kw in n_keywords if kw in text_lower)
        s_count = sum(1 for kw in s_keywords if kw in text_lower)
        
        s_n = 'N' if n_count > s_count else 'S'
    
    # Determine T/F (Thinking vs Feeling)
    if traits['agreeableness'] < 0.4:
        t_f = 'T'
    elif traits['agreeableness'] > 0.6:
        t_f = 'F'
    else:
        t_keywords = ['logical', 'objective', 'rational', 'analytical', 'fair', 'justice']
        f_keywords = ['emotional', 'compassionate', 'caring', 'harmony', 'values', 'feelings']
        
        t_count = sum(1 for kw in t_keywords if kw in text_lower)
        f_count = sum(1 for kw in f_keywords if kw in text_lower)
        
        t_f = 'T' if t_count > f_count else 'F'
    
    # Determine J/P (Judging vs Perceiving)
    if traits['conscientiousness'] > 0.6:
        j_p = 'J'
    elif traits['conscientiousness'] < 0.4:
        j_p = 'P'
    else:
        j_keywords = ['organized', 'planned', 'structured', 'decisive', 'scheduled', 'routine']
        p_keywords = ['flexible', 'spontaneous', 'adaptable', 'open', 'casual', 'impromptu']
        
        j_count = sum(1 for kw in j_keywords if kw in text_lower)
        p_count = sum(1 for kw in p_keywords if kw in text_lower)
        
        j_p = 'J' if j_count > p_count else 'P'
    
    type_code = f"{e_i}{s_n}{t_f}{j_p}"
    type_info = MBTI_TYPES.get(type_code, {})
    
    return {
        'type': type_code,
        'name': type_info.get('name', 'Unknown'),
        'description': type_info.get('description', ''),
        'key_traits': type_info.get('traits', [])
    }


def generate_psychological_profile(text: str, traits: Dict, mbti: Dict, depth: str) -> Dict:
    """Generate detailed psychological profile"""
    profile = {
        'primary_traits': [],
        'secondary_traits': [],
        'core_characteristics': [],
        'communication_style': '',
        'relationship_patterns': ''
    }
    
    # Determine primary traits (top 2 highest)
    sorted_traits = sorted(traits.items(), key=lambda x: x[1], reverse=True)
    for trait, value in sorted_traits[:2]:
        if value > 0.6:
            profile['primary_traits'].append({
                'trait': trait,
                'level': 'high',
                'value': round(value, 2)
            })
        elif value < 0.4:
            profile['secondary_traits'].append({
                'trait': trait,
                'level': 'low',
                'value': round(value, 2)
            })
    
    # Core characteristics based on MBTI
    mbti_type = mbti.get('type', '')
    if mbti_type and mbti_type in MBTI_TYPES:
        type_info = MBTI_TYPES[mbti_type]
        profile['core_characteristics'] = type_info.get('traits', [])
    
    # Communication style
    if traits['extraversion'] > 0.6:
        profile['communication_style'] = 'Direct, expressive, and engaging'
    elif traits['extraversion'] < 0.4:
        profile['communication_style'] = 'Thoughtful, measured, and reserved'
    else:
        profile['communication_style'] = 'Balanced and adaptive'
    
    # Relationship patterns
    if traits['agreeableness'] > 0.6:
        profile['relationship_patterns'] = 'Warm, supportive, and cooperative'
    elif traits['agreeableness'] < 0.4:
        profile['relationship_patterns'] = 'Independent, challenging, and competitive'
    else:
        profile['relationship_patterns'] = 'Selective and balanced in relationships'
    
    if depth == 'deep':
        profile['deep_analysis'] = {
            'strengths': generate_strengths(traits, mbti),
            'weaknesses': generate_weaknesses(traits, mbti),
            'growth_areas': suggest_growth_areas(traits, mbti)
        }
    
    return profile


def extract_motivations(text: str) -> List[str]:
    """Extract core motivations from text"""
    text_lower = text.lower()
    motivations_found = []
    
    for motivation, keywords in MOTIVATION_PATTERNS.items():
        matches = sum(1 for kw in keywords if kw in text_lower)
        if matches >= 2:
            motivations_found.append(motivation)
    
    # If no strong matches, infer from traits
    if not motivations_found:
        motivations_found.append('meaning')  # Default
    
    return motivations_found[:3]  # Return top 3


def extract_fears(text: str) -> List[str]:
    """Extract core fears from text"""
    text_lower = text.lower()
    fears_found = []
    
    for fear, keywords in FEAR_PATTERNS.items():
        matches = sum(1 for kw in keywords if kw in text_lower)
        if matches >= 1:
            fears_found.append(fear)
    
    return fears_found[:3]  # Return top 3


def determine_attachment_style(text: str) -> str:
    """Determine attachment style from text"""
    text_lower = text.lower()
    
    scores = {style: 0 for style in ATTACHMENT_PATTERNS}
    
    for style, keywords in ATTACHMENT_PATTERNS.items():
        scores[style] = sum(1 for kw in keywords if kw in text_lower)
    
    if max(scores.values()) == 0:
        return 'secure'  # Default
    
    return max(scores, key=scores.get)


def analyze_sentiment(text: str) -> Dict[str, Any]:
    """Simple sentiment analysis"""
    text_lower = text.lower()
    
    positive_words = ['happy', 'joy', 'love', 'great', 'wonderful', 'excellent', 'good', 
                      'beautiful', 'amazing', 'fantastic', 'excited', 'pleased', 'glad']
    negative_words = ['sad', 'angry', 'hate', 'terrible', 'awful', 'bad', 'horrible',
                      'disgusting', 'depressed', 'anxious', 'worried', 'fear', 'upset']
    
    pos_count = sum(1 for w in positive_words if w in text_lower)
    neg_count = sum(1 for w in negative_words if w in text_lower)
    
    total = pos_count + neg_count
    if total == 0:
        valence = 0.0
    else:
        valence = (pos_count - neg_count) / total
    
    return {
        'valence': round(valence, 2),
        'positive_count': pos_count,
        'negative_count': neg_count,
        'label': 'positive' if valence > 0.2 else 'negative' if valence < -0.2 else 'neutral'
    }


def check_profile_consistency(message: str, profile: Dict) -> float:
    """Check if message is consistent with character profile"""
    if not profile:
        return 0.5  # Unknown
    
    # Simple consistency check based on traits
    traits = profile.get('traits', {})
    
    # For now, return a moderate score
    # A real implementation would do more sophisticated analysis
    return 0.7


def detect_emotional_indicators(text: str) -> List[str]:
    """Detect emotional indicators in text"""
    text_lower = text.lower()
    indicators = []
    
    emotion_patterns = {
        'joy': ['happy', 'joy', 'excited', 'delighted', 'pleased', 'glad'],
        'sadness': ['sad', 'unhappy', 'depressed', 'miserable', 'disappointed'],
        'anger': ['angry', 'furious', 'annoyed', 'frustrated', 'irritated'],
        'fear': ['afraid', 'scared', 'worried', 'anxious', 'nervous', 'terrified'],
        'surprise': ['surprised', 'amazed', 'shocked', 'astonished'],
        'disgust': ['disgusted', 'repulsed', 'revolted', 'sickened'],
        'trust': ['trust', 'believe', 'confident', 'rely', 'faith'],
        'anticipation': ['expect', 'hope', 'looking forward', 'eager']
    }
    
    for emotion, keywords in emotion_patterns.items():
        if any(kw in text_lower for kw in keywords):
            indicators.append(emotion)
    
    return indicators


def calculate_from_context(messages: List, character: Dict, depth: str) -> Dict:
    """Calculate emotional state from conversation context"""
    if not messages:
        return {
            'current_mood': 'neutral',
            'intensity': 0.5,
            'triggers': [],
            'valence': 0.0,
            'arousal': 0.5
        }
    
    # Analyze recent messages for emotional trends
    recent_messages = messages[-10:] if len(messages) > 10 else messages
    all_content = ' '.join(
        m.get('content', '') if isinstance(m, dict) else str(m)
        for m in recent_messages
    )
    
    sentiment = analyze_sentiment(all_content)
    indicators = detect_emotional_indicators(all_content)
    
    # Determine dominant mood
    mood_scores = {}
    for indicator in indicators:
        mood_scores[indicator] = mood_scores.get(indicator, 0) + 1
    
    current_mood = max(mood_scores, key=mood_scores.get) if mood_scores else 'neutral'
    
    # Calculate intensity based on sentiment magnitude
    intensity = min(1.0, abs(sentiment['valence']) + 0.3)
    
    emotional_state = {
        'current_mood': current_mood,
        'intensity': round(intensity, 2),
        'triggers': indicators,
        'valence': sentiment['valence'],
        'arousal': 0.5  # Could be enhanced with more analysis
    }
    
    if depth == 'deep':
        emotional_state['mood_history'] = analyze_mood_history(recent_messages)
        emotional_state['recommendations'] = suggest_response_approach(character, emotional_state)
    
    return emotional_state


def analyze_mood_history(messages: List) -> Dict:
    """Analyze mood patterns over message history"""
    moods_over_time = []
    
    for i, msg in enumerate(messages):
        content = msg.get('content', '') if isinstance(msg, dict) else str(msg)
        sentiment = analyze_sentiment(content)
        moods_over_time.append({
            'index': i,
            'valence': sentiment['valence'],
            'label': sentiment['label']
        })
    
    # Calculate trend
    if len(moods_over_time) >= 2:
        first_half_avg = sum(m['valence'] for m in moods_over_time[:len(moods_over_time)//2]) / (len(moods_over_time)//2)
        second_half_avg = sum(m['valence'] for m in moods_over_time[len(moods_over_time)//2:]) / (len(moods_over_time) - len(moods_over_time)//2)
        trend = 'improving' if second_half_avg > first_half_avg else 'declining' if second_half_avg < first_half_avg else 'stable'
    else:
        trend = 'stable'
    
    return {
        'history': moods_over_time,
        'trend': trend
    }


def suggest_response_approach(character: Dict, emotional_state: Dict) -> List[str]:
    """Suggest response approaches based on character and emotional state"""
    suggestions = []
    
    mbti = character.get('mbti', {})
    mbti_type = mbti.get('type', '') if isinstance(mbti, dict) else str(mbti)
    
    # General suggestions based on emotional state
    if emotional_state['current_mood'] == 'fear':
        suggestions.append('Provide reassurance and safety')
        suggestions.append('Be calm and patient')
    elif emotional_state['current_mood'] == 'anger':
        suggestions.append('Allow space for expression')
        suggestions.append('Avoid being defensive')
    elif emotional_state['current_mood'] == 'sadness':
        suggestions.append('Show empathy and understanding')
        suggestions.append('Offer comfort without dismissing feelings')
    
    # MBTI-specific suggestions
    if mbti_type:
        if 'F' in mbti_type:
            suggestions.append('Lead with emotional acknowledgment')
        elif 'T' in mbti_type:
            suggestions.append('Offer logical perspective')
        
        if 'I' in mbti_type:
            suggestions.append('Allow for reflection time')
        elif 'E' in mbti_type:
            suggestions.append('Encourage expression')
    
    return suggestions[:4]


def calculate_confidence(traits: Dict[str, float]) -> float:
    """Calculate confidence score for the analysis"""
    # Higher confidence when traits are more extreme
    variance = sum((v - 0.5) ** 2 for v in traits.values()) / len(traits)
    confidence = min(0.95, 0.5 + variance * 2)
    return round(confidence, 2)


def generate_strengths(traits: Dict, mbti: Dict) -> List[str]:
    """Generate character strengths based on traits"""
    strengths = []
    
    if traits['openness'] > 0.6:
        strengths.append('Creative and imaginative')
    if traits['conscientiousness'] > 0.6:
        strengths.append('Reliable and thorough')
    if traits['extraversion'] > 0.6:
        strengths.append('Energetic and charismatic')
    if traits['agreeableness'] > 0.6:
        strengths.append('Warm and supportive')
    if traits['neuroticism'] < 0.4:
        strengths.append('Emotionally stable')
    
    return strengths


def generate_weaknesses(traits: Dict, mbti: Dict) -> List[str]:
    """Generate character weaknesses based on traits"""
    weaknesses = []
    
    if traits['openness'] < 0.4:
        weaknesses.append('May be seen as rigid or inflexible')
    if traits['conscientiousness'] < 0.4:
        weaknesses.append('May struggle with follow-through')
    if traits['extraversion'] < 0.4:
        weaknesses.append('May come across as distant')
    if traits['agreeableness'] < 0.4:
        weaknesses.append('May be perceived as harsh')
    if traits['neuroticism'] > 0.6:
        weaknesses.append('May be prone to worry')
    
    return weaknesses


def suggest_growth_areas(traits: Dict, mbti: Dict) -> List[str]:
    """Suggest personal growth areas"""
    growth = []
    
    if traits['openness'] < 0.5:
        growth.append('Practice embracing new experiences')
    if traits['conscientiousness'] < 0.5:
        growth.append('Work on establishing routines')
    if traits['extraversion'] < 0.5:
        growth.append('Challenge yourself to engage more socially')
    if traits['agreeableness'] < 0.5:
        growth.append('Practice perspective-taking')
    if traits['neuroticism'] > 0.5:
        growth.append('Develop stress management techniques')
    
    return growth
