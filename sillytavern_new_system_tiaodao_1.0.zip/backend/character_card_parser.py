"""
Character Card Parser Module
Parses SillyTavern character cards (JSON format)
"""

import json
import re
import logging
from typing import Dict, Any, Optional, Tuple, List

logger = logging.getLogger(__name__)


class CharacterCardParser:
    """Parser for SillyTavern character card format"""
    
    def __init__(self):
        self.supported_versions = ['1.0', '2.0', 'v2', 'v1']
        self.required_fields_v1 = ['name']
        self.required_fields_v2 = ['name', 'description']
        
        # Speech pattern indicators
        self.speech_indicators = {
            'formal': ['speaks formally', 'proper language', 'educated', 'refined'],
            'casual': ['speaks casually', 'informal', 'relaxed', 'casual'],
            'technical': ['technical', 'scientific', 'uses jargon', 'precise'],
            'emotional': ['emotional', 'passionate', 'dramatic', 'expressive'],
            'reserved': ['quiet', 'minimal words', 'terse', 'laconic'],
            'verbose': ['talks a lot', 'verbose', 'long-winded', 'detailed']
        }
        
        # Background indicator patterns
        self.background_indicators = [
            'background', 'history', 'past', 'grew up', 'childhood', 
            'family', 'origin', 'upbringing', 'was born', 'raised'
        ]
        
        # Interest/topic patterns
        self.interest_patterns = [
            'interested in', 'enjoys', 'loves', 'passionate about',
            'hobby', 'hobbies', 'fascinated by', 'obsessed with'
        ]
    
    def parse_character(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse a character card and extract relevant information
        
        Args:
            data: Character card data (dict or JSON string)
            
        Returns:
            Parsed character data with normalized fields
        """
        try:
            if isinstance(data, str):
                data = json.loads(data)
            
            version = self._detect_version(data)
            
            if version == 'v2':
                result = self._parse_v2(data)
            else:
                result = self._parse_v1(data)
            
            # Extract additional metadata
            result['metadata'] = self._extract_metadata(data)
            
            return result
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}")
            raise ValueError(f"Invalid JSON format: {e}")
        except Exception as e:
            logger.error(f"Error parsing character: {e}")
            raise
    
    def _detect_version(self, data: Dict[str, Any]) -> str:
        """Detect the character card version"""
        # Check for V2 indicators
        if 'spec' in data or 'spec_version' in data:
            return 'v2'
        if 'chat_history' in data or 'creator' in data:
            return 'v2'
        if 'extensions' in data:
            return 'v2'
        
        # Check version field
        version = data.get('version', data.get('spec', ''))
        if version in ['2.0', 'v2', 2]:
            return 'v2'
        
        # Default to v1
        return 'v1'
    
    def _parse_v2(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Parse V2 character card format"""
        result = {
            'name': self._safe_get(data, 'name', 'Unknown'),
            'description': self._safe_get(data, 'description', ''),
            'personality': self._safe_get(data, 'personality', ''),
            'scenario': self._safe_get(data, 'scenario', ''),
            'first_message': self._safe_get(data, 'first_mes', 
                                self._safe_get(data, 'first_message', '')),
            'avatar': self._safe_get(data, 'avatar', ''),
            'tags': self._safe_get(data, 'tags', []),
            'creator': self._parse_creator(data.get('creator', {})),
            'version': 'v2',
            'spec_version': data.get('spec_version', '2.0')
        }
        
        # Parse chat history if present
        if 'chat_history' in data:
            chat_history = data['chat_history']
            if isinstance(chat_history, dict):
                result['chat_messages'] = chat_history.get('messages', [])
            else:
                result['chat_messages'] = chat_history
        
        # Parse extensions if present
        if 'extensions' in data:
            result['extensions'] = data['extensions']
        
        # Extract additional fields
        result['alternative_greetings'] = data.get('alternative_greetings', [])
        result['character_book'] = data.get('character_book', {})
        
        return result
    
    def _parse_v1(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Parse V1 character card format"""
        return {
            'name': self._safe_get(data, 'name', 'Unknown'),
            'description': self._safe_get(data, 'description', ''),
            'personality': self._safe_get(data, 'personality', ''),
            'scenario': self._safe_get(data, 'scenario', ''),
            'first_message': self._safe_get(data, 'first_mes', 
                                self._safe_get(data, 'first_message', '')),
            'avatar': self._safe_get(data, 'avatar', ''),
            'version': 'v1'
        }
    
    def _safe_get(self, data: Dict, key: str, default: Any = None) -> Any:
        """Safely get a value from dict, checking multiple key variations"""
        # Try direct key
        if key in data:
            return data[key]
        
        # Try common variations
        variations = [
            key,
            key.lower(),
            key.upper(),
            key.replace('_', ''),
            key.replace('-', ''),
            key.replace('_', '-'),
            key.replace('-', '_')
        ]
        
        for var in variations:
            if var in data:
                return data[var]
        
        return default
    
    def _parse_creator(self, creator_data: Any) -> Dict[str, Any]:
        """Parse creator information"""
        if isinstance(creator_data, dict):
            return {
                'name': creator_data.get('name', 'Unknown'),
                'url': creator_data.get('url', ''),
                'description': creator_data.get('description', '')
            }
        elif isinstance(creator_data, str):
            return {'name': creator_data}
        else:
            return {'name': 'Unknown'}
    
    def _extract_metadata(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metadata from character card"""
        metadata = {}
        
        # Creation info
        if 'created_at' in data:
            metadata['created_at'] = data['created_at']
        if 'modified_at' in data:
            metadata['modified_at'] = data['modified_at']
        
        # Source info
        if 'source' in data:
            metadata['source'] = data['source']
        
        # Custom fields
        if 'custom_data' in data:
            metadata['custom_data'] = data['custom_data']
        
        # Rating info
        if 'rating' in data:
            metadata['rating'] = data['rating']
        
        return metadata
    
    def validate_card(self, data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validate if the character card has required fields
        
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        if not data:
            return False, ['Empty data provided']
        
        # Check name
        if 'name' not in data or not data['name']:
            errors.append('Character name is required')
        
        # Check description for V2
        version = self._detect_version(data)
        if version == 'v2':
            if 'description' not in data or not data['description']:
                errors.append('Description is required for V2 cards')
        
        # Validate JSON structure
        try:
            if isinstance(data, str):
                json.loads(data)
        except json.JSONDecodeError as e:
            errors.append(f'Invalid JSON: {str(e)}')
        
        return len(errors) == 0, errors
    
    def extract_characteristics(self, description: str) -> Dict[str, Any]:
        """
        Extract characteristics from description text
        
        Returns:
            Dict with traits, interests, speech_pattern, and background
        """
        if not description:
            return {
                'traits': [],
                'interests': [],
                'speech_pattern': 'neutral',
                'background': ''
            }
        
        desc_lower = description.lower()
        
        # Extract traits
        traits = self._extract_traits(description)
        
        # Extract interests
        interests = self._extract_interests(description)
        
        # Determine speech pattern
        speech_pattern = self._determine_speech_pattern(description)
        
        # Extract background
        background = self._extract_background(description)
        
        return {
            'traits': traits,
            'interests': interests,
            'speech_pattern': speech_pattern,
            'background': background
        }
    
    def _extract_traits(self, text: str) -> List[str]:
        """Extract personality traits from text"""
        text_lower = text.lower()
        traits = []
        
        trait_keywords = [
            'kind', 'caring', 'compassionate', 'empathetic',
            'cold', 'calculating', 'ruthless', 'ambitious',
            'brave', 'courageous', 'fearless', 'adventurous',
            'shy', 'introverted', 'reserved', 'quiet',
            'outgoing', 'extroverted', 'social', 'friendly',
            'intelligent', 'clever', 'wise', 'knowledgeable',
            'playful', 'mischievous', 'humorous', 'witty',
            'serious', 'stoic', 'serious-minded', 'solemn',
            'mysterious', 'enigmatic', 'secretive', 'hidden',
            'loyal', 'faithful', 'devoted', 'dedicated',
            'aggressive', 'assertive', 'dominant', 'powerful',
            'gentle', 'soft', 'tender', 'delicate',
            'stubborn', 'headstrong', 'determined', 'persistent',
            'adaptable', 'flexible', 'versatile', 'resourceful',
            'paranoid', 'suspicious', 'cautious', 'wary',
            'naive', 'innocent', 'pure', 'trusting'
        ]
        
        for trait in trait_keywords:
            if trait in text_lower:
                traits.append(trait)
        
        return list(set(traits))  # Remove duplicates
    
    def _extract_interests(self, text: str) -> List[str]:
        """Extract interests and hobbies from text"""
        text_lower = text.lower()
        interests = []
        
        for pattern in self.interest_patterns:
            # Find sentences containing the pattern
            sentences = text.split('.')
            for sentence in sentences:
                if pattern in sentence.lower():
                    # Extract the interest
                    interest = self._extract_interest_from_sentence(sentence, pattern)
                    if interest:
                        interests.append(interest)
        
        # Also check for known interests
        known_interests = [
            'reading', 'writing', 'music', 'art', 'gaming', 'cooking',
            'sports', 'science', 'technology', 'nature', 'animals',
            'movies', 'travel', 'history', 'philosophy', 'gaming',
            'anime', 'manga', 'books', 'fashion', 'gardening'
        ]
        
        for interest in known_interests:
            if interest in text_lower:
                interests.append(interest)
        
        return list(set(interests))
    
    def _extract_interest_from_sentence(self, sentence: str, pattern: str) -> Optional[str]:
        """Extract interest from a sentence containing the pattern"""
        sentence_lower = sentence.lower()
        idx = sentence_lower.find(pattern)
        
        if idx == -1:
            return None
        
        # Get text after the pattern
        remaining = sentence[idx + len(pattern):].strip()
        
        # Extract until next punctuation or conjunction
        words = re.split(r'[,;:]', remaining)
        if words:
            interest = words[0].strip()
            # Clean up
            interest = re.sub(r'^(in|about|with|the|a|an)\s+', '', interest, flags=re.IGNORECASE)
            return interest if len(interest) > 2 else None
        
        return None
    
    def _determine_speech_pattern(self, text: str) -> str:
        """Determine speech pattern from text"""
        text_lower = text.lower()
        
        scores = {pattern: 0 for pattern in self.speech_indicators}
        
        for pattern, keywords in self.speech_indicators.items():
            for keyword in keywords:
                if keyword in text_lower:
                    scores[pattern] += 1
        
        if max(scores.values()) == 0:
            return 'neutral'
        
        return max(scores, key=scores.get)
    
    def _extract_background(self, text: str) -> str:
        """Extract background information from text"""
        sentences = text.split('.')
        background_parts = []
        
        for sentence in sentences:
            sentence_lower = sentence.lower()
            for indicator in self.background_indicators:
                if indicator in sentence_lower:
                    background_parts.append(sentence.strip())
                    break
        
        return ' '.join(background_parts) if background_parts else ''
    
    def extract_first_message(self, data: Dict[str, Any]) -> str:
        """Extract first message from character card"""
        # Try various field names
        for field in ['first_mes', 'first_message', 'firstMes', 'firstMessage']:
            if field in data and data[field]:
                return data[field]
        
        # Try from extensions
        if 'extensions' in data and isinstance(data['extensions'], dict):
            for field in ['firstMes', 'first_message']:
                if field in data['extensions']:
                    return data['extensions'][field]
        
        return ''
    
    def normalize_card(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize a character card to standard format"""
        parsed = self.parse_character(data)
        
        return {
            'name': parsed['name'],
            'description': parsed['description'],
            'personality': parsed['personality'],
            'scenario': parsed['scenario'],
            'first_message': parsed['first_message'],
            'avatar': parsed.get('avatar', ''),
            'version': parsed['version']
        }
