"""
Backend Test Suite
Tests for the Tiandao backend API
"""

import pytest
import json
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server import app


@pytest.fixture
def client():
    """Create test client"""
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client


@pytest.fixture
def sample_character():
    """Sample character card data"""
    return {
        'name': 'Test Character',
        'description': 'A kind and caring person who loves helping others. ' +
                      'They are introverted but warm when you get to know them. ' +
                      'Very organized and detail-oriented.',
        'personality': 'Kind, caring, introverted, organized',
        'scenario': 'Meeting in a coffee shop',
        'first_mes': 'Hello! Nice to meet you!'
    }


@pytest.fixture
def sample_message():
    """Sample message data"""
    return {
        'role': 'user',
        'content': 'Hello! How are you today?'
    }


@pytest.fixture
def sample_messages():
    """Sample conversation messages"""
    return [
        {'role': 'user', 'content': 'Hello!'},
        {'role': 'assistant', 'content': 'Hi there! How are you?'},
        {'role': 'user', 'content': "I'm doing great, thanks!"}
    ]


class TestHealthEndpoints:
    """Test health and status endpoints"""
    
    def test_health_check(self, client):
        """Test health endpoint returns healthy status"""
        response = client.get('/api/health')
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['status'] == 'healthy'
        assert 'service' in data
        assert 'timestamp' in data
    
    def test_status_check(self, client):
        """Test status endpoint returns module states"""
        response = client.get('/api/status')
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['status'] == 'healthy'
        assert 'modules' in data


class TestCharacterEndpoints:
    """Test character card endpoints"""
    
    def test_parse_character(self, client, sample_character):
        """Test parsing a character card"""
        response = client.post(
            '/api/characters',
            data=json.dumps(sample_character),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['data']['name'] == 'Test Character'
    
    def test_parse_character_v2(self, client):
        """Test parsing V2 character card format"""
        character = {
            'name': 'V2 Character',
            'description': 'A test character',
            'spec': 'chara_card_v2',
            'tags': ['test', 'v2']
        }
        
        response = client.post(
            '/api/characters',
            data=json.dumps(character),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['data']['version'] == 'v2'
    
    def test_validate_character(self, client, sample_character):
        """Test character card validation"""
        response = client.post(
            '/api/characters/validate',
            data=json.dumps(sample_character),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['valid'] is True
        assert len(data['errors']) == 0
    
    def test_validate_invalid_character(self, client):
        """Test validation fails for missing name"""
        response = client.post(
            '/api/characters/validate',
            data=json.dumps({'description': 'Test'}),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['valid'] is False
        assert len(data['errors']) > 0
    
    def test_extract_characteristics(self, client):
        """Test characteristic extraction"""
        response = client.post(
            '/api/characters/extract',
            data=json.dumps({
                'description': 'A kind and artistic person who speaks formally'
            }),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'speech_pattern' in data['data']


class TestMessageFormatting:
    """Test message formatting endpoints"""
    
    def test_format_message(self, client, sample_message):
        """Test formatting a single message"""
        response = client.post(
            '/api/format-message',
            data=json.dumps(sample_message),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['data']['role'] == 'user'
        assert 'id' in data['data']
        assert 'timestamp' in data['data']
    
    def test_format_conversation(self, client, sample_messages):
        """Test formatting multiple messages"""
        response = client.post(
            '/api/format-conversation',
            data=json.dumps({'messages': sample_messages}),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['data']['count'] == 3
        assert len(data['data']['messages']) == 3


class TestPsychologyEndpoints:
    """Test psychology analysis endpoints"""
    
    def test_analyze_personality(self, client, sample_character):
        """Test personality analysis"""
        response = client.post(
            '/api/psychology/analyze',
            data=json.dumps({
                'name': sample_character['name'],
                'description': sample_character['description']
            }),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'mbti' in data['data']
        assert 'traits' in data['data']
        assert 'confidence' in data['data']
    
    def test_analyze_deep(self, client, sample_character):
        """Test deep personality analysis"""
        response = client.post(
            '/api/psychology/analyze',
            data=json.dumps({
                'name': sample_character['name'],
                'description': sample_character['description'],
                'depth': 'deep'
            }),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        # Deep analysis includes additional fields
        assert 'motivation' in data['data']
    
    def test_get_moods(self, client):
        """Test getting available moods"""
        response = client.get('/api/psychology/moods')
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert len(data['data']) > 0
        # Check mood structure
        mood = data['data'][0]
        assert 'id' in mood
        assert 'name' in mood
        assert 'emoji' in mood
    
    def test_calculate_emotional_state(self, client, sample_messages):
        """Test emotional state calculation"""
        response = client.post(
            '/api/psychology/emotional-state',
            data=json.dumps({
                'messages': sample_messages
            }),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'current_mood' in data['data']
        assert 'intensity' in data['data']
        assert 'valence' in data['data']
    
    def test_get_all_mbti_types(self, client):
        """Test getting all MBTI types"""
        response = client.get('/api/psychology/mbti')
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'INTJ' in data['data']
        assert 'ENFP' in data['data']
    
    def test_get_specific_mbti(self, client):
        """Test getting specific MBTI type details"""
        response = client.get('/api/psychology/mbti/INTJ')
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert data['data']['name'] == 'The Architect'
    
    def test_get_invalid_mbti(self, client):
        """Test getting invalid MBTI type returns 404"""
        response = client.get('/api/psychology/mbti/INVALID')
        data = json.loads(response.data)
        
        assert response.status_code == 404
        assert data['success'] is False


class TestContextGeneration:
    """Test context generation endpoints"""
    
    def test_generate_context(self, client):
        """Test context generation"""
        response = client.post(
            '/api/context/generate',
            data=json.dumps({
                'character_id': 'test123',
                'profile': {
                    'mbti': 'ENFJ',
                    'traits': {
                        'openness': 0.8,
                        'conscientiousness': 0.6
                    }
                },
                'format': 'default'
            }),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True
        assert 'MBTI' in data['data']['context']
    
    def test_generate_compact_context(self, client):
        """Test compact context generation"""
        response = client.post(
            '/api/context/generate',
            data=json.dumps({
                'profile': {'mbti': 'INTJ'},
                'format': 'compact'
            }),
            content_type='application/json'
        )
        data = json.loads(response.data)
        
        assert response.status_code == 200
        assert data['success'] is True


class TestErrorHandling:
    """Test error handling"""
    
    def test_404_error(self, client):
        """Test 404 error handling"""
        response = client.get('/api/nonexistent')
        data = json.loads(response.data)
        
        assert response.status_code == 404
        assert data['success'] is False
    
    def test_empty_body(self, client):
        """Test handling of empty request body"""
        response = client.post(
            '/api/characters',
            data='',
            content_type='application/json'
        )
        assert response.status_code == 400


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
