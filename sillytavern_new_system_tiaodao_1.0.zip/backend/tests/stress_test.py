"""压力测试 - SillyTavern天道系统后端"""
import time, json
import pytest
from server import app


@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as c:
        yield c


class TestStress:
    """压力测试套件"""

    def test_rapid_health_checks(self, client):
        """快速健康检查压力测试"""
        start = time.time()
        results = []
        for _ in range(100):
            response = client.get('/api/health')
            results.append(response.status_code == 200)
        elapsed = time.time() - start
        print(f"\n100 health checks completed in {elapsed:.2f}s")
        assert all(results)

    def test_rapid_psychology_analyze(self, client):
        """快速人格分析压力测试"""
        characters = [
            {'name': f'Character{i}', 'description': f'A creative person {i} who loves adventure'}
            for i in range(100)
        ]
        start = time.time()
        results = []
        for char in characters:
            response = client.post(
                '/api/psychology/analyze',
                data=json.dumps(char),
                content_type='application/json'
            )
            results.append(response.status_code == 200)
        elapsed = time.time() - start
        print(f"\n100 psychology analyses completed in {elapsed:.2f}s")
        assert all(results)

    def test_large_message_batch(self, client):
        """大批量消息格式化"""
        messages = [{'role': 'user', 'content': f'Message {i}' * 10} for i in range(100)]
        start = time.time()
        response = client.post(
            '/api/format-conversation',
            data=json.dumps({'messages': messages}),
            content_type='application/json'
        )
        elapsed = time.time() - start
        print(f"\n100 messages formatted in {elapsed:.3f}s")
        assert response.status_code == 200

    def test_large_character_parsing(self, client):
        """大角色卡解析"""
        char_data = {
            'name': 'Test Character',
            'description': 'A ' + 'very ' * 500 + 'long description',
            'personality': 'Trait1, Trait2, ' * 100,
            'first_mes': 'Hello ' * 50,
            'mes_example': 'Example ' * 50
        }
        start = time.time()
        response = client.post(
            '/api/characters',
            data=json.dumps(char_data),
            content_type='application/json'
        )
        elapsed = time.time() - start
        print(f"\nLarge character parsed in {elapsed:.3f}s")
        assert response.status_code == 200

    def test_memory_cached_profiles(self, client):
        """内存缓存性能测试"""
        char = {'name': 'CachedChar', 'description': 'A test character'}
        start = time.time()
        client.post('/api/characters', data=json.dumps(char), content_type='application/json')
        first = time.time() - start
        cached_times = []
        for _ in range(50):
            t0 = time.time()
            client.get('/api/status')
            cached_times.append(time.time() - t0)
        print(f"\nFirst call: {first*1000:.2f}ms, Avg cached: {sum(cached_times)/len(cached_times)*1000:.2f}ms")
        assert sum(cached_times) / len(cached_times) < first

    def test_mixed_operations(self, client):
        """混合操作压力测试"""
        total_ops = 1000
        start = time.time()
        results = {'health': 0, 'status': 0, 'analyze': 0, 'format': 0}
        for i in range(total_ops):
            op = i % 4
            if op == 0:
                r = client.get('/api/health')
                if r.status_code == 200:
                    results['health'] += 1
            elif op == 1:
                r = client.get('/api/status')
                if r.status_code == 200:
                    results['status'] += 1
            elif op == 2:
                r = client.post('/api/psychology/analyze',
                    data=json.dumps({'name': f'C{i}', 'description': 'Test'}),
                    content_type='application/json')
                if r.status_code == 200:
                    results['analyze'] += 1
            else:
                r = client.post('/api/format-conversation',
                    data=json.dumps({'messages': [{'role': 'user', 'content': 'hi'}]}),
                    content_type='application/json')
                if r.status_code == 200:
                    results['format'] += 1
        elapsed = time.time() - start
        total_success = sum(results.values())
        print(f"\n{total_ops} mixed ops in {elapsed:.2f}s, {total_success} succeeded")
        print(f"  health:{results['health']} status:{results['status']} analyze:{results['analyze']} format:{results['format']}")
        assert total_success >= total_ops * 0.95
