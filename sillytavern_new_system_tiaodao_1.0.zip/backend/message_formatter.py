"""
Message Formatter Module
Formats chat messages for display in SillyTavern
"""

import re
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from html import escape

logger = logging.getLogger(__name__)


class MessageFormatter:
    """Handles formatting of chat messages"""
    
    def __init__(self):
        self.default_format = {
            'trim_whitespace': True,
            'preserve_order': True,
            'escape_newlines': False,
            'sanitize_html': True,
            'max_length': None
        }
        
        # Emotion indicators
        self.emotion_patterns = {
            'happy': r'\b(happy|joy|glad|excited|wonderful|great|amazing)\b',
            'sad': r'\b(sad|depressed|miserable|unhappy|disappointed|cry)\b',
            'angry': r'\b(angry|furious|mad|frustrated|annoyed|hate)\b',
            'fearful': r'\b(afraid|scared|worried|anxious|nervous|fear)\b',
            'surprised': r'\b(surprised|shocked|amazed|astonished|wow)\b'
        }
        
        # Speech act patterns
        self.speech_acts = {
            'question': r'\?$',
            'exclamation': r'!$',
            'statement': r'\.$'
        }
    
    def format_message(self, data: Dict[str, Any], format_options: Dict = None) -> Dict[str, Any]:
        """
        Format a message for display
        
        Args:
            data: Message data with role, content, and metadata
            format_options: Optional formatting options
            
        Returns:
            Formatted message ready for display
        """
        options = {**self.default_format, **(format_options or {})}
        
        role = data.get('role', 'user')
        content = data.get('content', '')
        metadata = data.get('metadata', {})
        
        # Apply content processing
        if options.get('trim_whitespace', True):
            content = self._clean_content(content)
        
        # Apply length limit
        max_length = options.get('max_length')
        if max_length and len(content) > max_length:
            content = content[:max_length] + '...'
        
        formatted = {
            'id': self._generate_message_id(),
            'role': role,
            'content': content,
            'timestamp': datetime.now().isoformat(),
            'metadata': metadata
        }
        
        # Add detected attributes
        formatted['detected_emotion'] = self._detect_emotion(content)
        formatted['speech_act'] = self._detect_speech_act(content)
        
        return formatted
    
    def format_conversation(self, messages: List[Dict[str, Any]], 
                          format_options: Dict = None) -> List[Dict[str, Any]]:
        """Format multiple messages in a conversation"""
        formatted_messages = []
        
        for msg in messages:
            try:
                formatted_msg = self.format_message(msg, format_options)
                formatted_messages.append(formatted_msg)
            except Exception as e:
                logger.error(f"Error formatting message: {e}")
                continue
        
        return formatted_messages
    
    def format_for_api(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Format messages for API response"""
        return [
            {
                'role': msg.get('role', 'user'),
                'content': msg.get('content', ''),
                'name': msg.get('name'),
                'metadata': msg.get('metadata', {})
            }
            for msg in messages
        ]
    
    def format_system_message(self, content: str, 
                             message_type: str = 'info') -> Dict[str, Any]:
        """Format a system message"""
        type_icons = {
            'info': 'ℹ️',
            'warning': '⚠️',
            'error': '❌',
            'success': '✅'
        }
        
        return {
            'id': self._generate_message_id(),
            'role': 'system',
            'content': f"{type_icons.get(message_type, '')} {content}",
            'timestamp': datetime.now().isoformat(),
            'message_type': message_type
        }
    
    def _clean_content(self, content: str) -> str:
        """Clean and sanitize message content"""
        if not content:
            return ''
        
        # Remove excessive whitespace
        cleaned = re.sub(r'\s+', ' ', content)
        
        # Trim leading/trailing whitespace
        cleaned = cleaned.strip()
        
        return cleaned
    
    def _generate_message_id(self) -> str:
        """Generate a unique message ID"""
        timestamp = int(datetime.now().timestamp() * 1000)
        return f"msg_{timestamp}"
    
    def _detect_emotion(self, content: str) -> Optional[str]:
        """Detect emotion in message content"""
        content_lower = content.lower()
        
        for emotion, pattern in self.emotion_patterns.items():
            if re.search(pattern, content_lower):
                return emotion
        
        return None
    
    def _detect_speech_act(self, content: str) -> str:
        """Detect speech act type"""
        if not content:
            return 'statement'
        
        content = content.strip()
        
        for act, pattern in self.speech_acts.items():
            if re.search(pattern, content):
                return act
        
        return 'statement'
    
    def apply_formatting(self, content: str, format_type: str = 'default') -> str:
        """Apply specific formatting to message content"""
        if format_type == 'markdown':
            return self._apply_markdown(content)
        elif format_type == 'html':
            return self._apply_html(content)
        elif format_type == 'plain':
            return self._apply_plain(content)
        elif format_type == 'slate':
            return self._apply_slate(content)
        else:
            return content
    
    def _apply_markdown(self, content: str) -> str:
        """Apply markdown formatting"""
        # Bold
        content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
        content = re.sub(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)', r'<em>\1</em>', content)
        
        # Headers
        content = re.sub(r'^### (.+)$', r'<h3>\1</h3>', content, flags=re.MULTILINE)
        content = re.sub(r'^## (.+)$', r'<h2>\1</h2>', content, flags=re.MULTILINE)
        content = re.sub(r'^# (.+)$', r'<h1>\1</h1>', content, flags=re.MULTILINE)
        
        # Lists
        content = re.sub(r'^- (.+)$', r'<li>\1</li>', content, flags=re.MULTILINE)
        
        # Code blocks
        content = re.sub(r'```(\w+)?\n(.+?)```', r'<pre><code>\2</code></pre>', 
                        content, flags=re.DOTALL)
        content = re.sub(r'`(.+?)`', r'<code>\1</code>', content)
        
        return content
    
    def _apply_html(self, content: str) -> str:
        """Convert content to HTML format"""
        # Escape HTML first
        safe_content = escape(content)
        
        # Convert newlines to breaks
        html = safe_content.replace('\n', '<br>')
        
        # Wrap in message div
        return f'<div class="message">{html}</div>'
    
    def _apply_plain(self, content: str) -> str:
        """Remove all formatting, return plain text"""
        # Remove markdown formatting
        plain = re.sub(r'\*\*(.+?)\*\*', r'\1', content)
        plain = re.sub(r'\*(.+?)\*', r'\1', content)
        plain = re.sub(r'__(.+?)__', r'\1', plain)
        plain = re.sub(r'_(.+?)_', r'\1', plain)
        
        # Remove HTML tags
        plain = re.sub(r'<[^>]+>', '', plain)
        
        # Remove extra whitespace
        plain = re.sub(r'\s+', ' ', plain)
        
        return plain.strip()
    
    def _apply_slate(self, content: str) -> List[Dict[str, Any]]:
        """Convert content to Slate.js format"""
        # Split into paragraphs
        paragraphs = content.split('\n\n')
        
        slate_content = []
        for para in paragraphs:
            if para.strip():
                slate_content.append({
                    'type': 'paragraph',
                    'children': [{'text': para.strip()}]
                })
        
        return slate_content
    
    def wrap_message(self, message: Dict[str, Any], 
                    wrapper_class: str = 'chat-message') -> str:
        """Wrap formatted message in HTML"""
        role = message.get('role', 'unknown')
        content = message.get('content', '')
        emotion = message.get('detected_emotion')
        
        classes = [wrapper_class, f'role-{role}']
        if emotion:
            classes.append(f'emotion-{emotion}')
        
        return f'''
        <div class="{' '.join(classes)}" data-role="{role}">
            <div class="message-header">
                <span class="role-label">{role.capitalize()}</span>
                <span class="timestamp">{message.get('timestamp', '')}</span>
            </div>
            <div class="message-content">
                {self._apply_html(content)}
            </div>
        </div>
        '''
    
    def format_batch(self, messages: List[Dict[str, Any]], 
                    batch_size: int = 10) -> List[List[Dict[str, Any]]]:
        """Split messages into batches for processing"""
        batches = []
        
        for i in range(0, len(messages), batch_size):
            batch = messages[i:i + batch_size]
            batches.append(self.format_conversation(batch))
        
        return batches
    
    def interpolate_variables(self, content: str, 
                             variables: Dict[str, str]) -> str:
        """Replace variables in message content"""
        result = content
        
        for key, value in variables.items():
            # Support various variable formats
            patterns = [
                f'{{{key}}}',
                f'${key}',
                f'%{key}%',
                f'{{{key.upper()}}}',
                f'{{{key.lower()}}}'
            ]
            
            for pattern in patterns:
                if pattern in result:
                    result = result.replace(pattern, value)
        
        return result
    
    def extract_mentions(self, content: str) -> List[str]:
        """Extract @mentions from message content"""
        # Match @name patterns
        mentions = re.findall(r'@(\w+)', content)
        return list(set(mentions))
    
    def extract_hashtags(self, content: str) -> List[str]:
        """Extract #hashtags from message content"""
        # Match #tag patterns
        hashtags = re.findall(r'#(\w+)', content)
        return list(set(hashtags))
    
    def create_summary(self, messages: List[Dict[str, Any]], 
                      max_length: int = 200) -> str:
        """Create a summary of conversation messages"""
        if not messages:
            return ''
        
        # Get last few messages
        recent = messages[-5:] if len(messages) > 5 else messages
        
        parts = []
        for msg in recent:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            if content:
                # Truncate long messages
                if len(content) > 100:
                    content = content[:100] + '...'
                parts.append(f"{role}: {content}")
        
        summary = ' | '.join(parts)
        
        if len(summary) > max_length:
            summary = summary[:max_length] + '...'
        
        return summary
