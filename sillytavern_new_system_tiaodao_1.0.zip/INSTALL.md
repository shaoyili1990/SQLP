# Tiandao System for SillyTavern - Installation Guide

## Prerequisites

- SillyTavern installed and running
- Node.js 16+ (for development/testing)
- Python 3.9+ (for backend server)
- pip (Python package manager)

## Installation Steps

### 1. Backend Setup

```bash
cd backend

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your settings
```

### 2. SillyTavern Plugin Installation

Copy the plugin file to your SillyTavern plugins directory:

```bash
# For SillyTavern standard installation
cp sillytavern_plugin/tiandao_plugin.js /path/to/sillytavern/scripts/extensions/plugins/

# Or create a symlink
ln -s "$(pwd)/sillytavern_plugin/tiandao_plugin.js" /path/to/sillytavern/scripts/extensions/plugins/tiandao_plugin.js
```

### 3. Start the Backend Server

```bash
cd backend

# Development mode
python server.py

# Or with gunicorn for production
gunicorn -w 4 -b 0.0.0.0:5000 server:app
```

### 4. Verify Installation

1. Open SillyTavern in your browser
2. Go to Settings > Extensions > Plugins
3. Find "Tiandao System" in the list
4. Ensure it's enabled

## Docker Installation (Optional)

```bash
# Build the image
docker build -t tiandao-backend .

# Run the container
docker run -p 5000:5000 \
  -e DEBUG=False \
  -e PORT=5000 \
  tiandao-backend
```

## Docker Compose (Recommended)

Create a `docker-compose.yml`:

```yaml
version: '3.8'

services:
  tiandao-backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      - DEBUG=False
      - FLASK_ENV=production
    restart: unless-stopped
```

Run with:
```bash
docker-compose up -d
```

## Troubleshooting

### Plugin not loading
- Check browser console for errors (F12)
- Ensure the plugin file is in the correct directory
- Verify JavaScript syntax is valid

### API connection errors
- Verify backend server is running: `curl http://localhost:5000/api/health`
- Check CORS settings in backend/config.py
- Ensure the API endpoint in plugin config matches

### Character analysis not working
- Make sure the character has a description
- Check backend logs for parsing errors
- Verify network connectivity between plugin and backend

## Updating

```bash
# Pull latest changes
git pull

# Update backend dependencies
pip install -r requirements.txt --upgrade

# Restart backend server
```

## Uninstallation

1. Remove plugin file from SillyTavern plugins directory
2. Stop backend server
3. Optionally remove database/data files created
