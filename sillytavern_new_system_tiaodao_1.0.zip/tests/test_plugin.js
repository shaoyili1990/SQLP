/**
 * Tiandao System Plugin Tests
 * Tests for the SillyTavern plugin functionality
 */

describe('Tiandao Plugin Tests', () => {
    
    // Mock SillyTavern globals
    const mockCharacters = {
        0: {
            name: 'Test Character',
            description: 'A kind and caring person who loves helping others',
            personality: 'Friendly and compassionate',
            scenario: 'In a cozy coffee shop',
            first_mes: 'Hello! Nice to meet you!'
        }
    };

    beforeEach(() => {
        // Reset modules and state before each test
        jest.resetModules();
        
        // Mock global variables
        global.eventManager = {
            on: jest.fn(),
            off: jest.fn(),
            emit: jest.fn()
        };
        global.eventNames = {
            CHAT_CHANGED: 'chatloaded',
            MESSAGE_SENT: 'messageadded',
            CHARACTER_DELETED: 'character_deleting'
        };
        global.characters = mockCharacters;
        global.characterId = 0;
        global.localStorage = {
            getItem: jest.fn().mockReturnValue(null),
            setItem: jest.fn()
        };
        global.document = {
            readyState: 'complete',
            addEventListener: jest.fn(),
            body: {
                insertAdjacentHTML: jest.fn()
            },
            head: {
                appendChild: jest.fn()
            },
            getElementById: jest.fn().mockReturnValue(null),
            querySelector: jest.fn()
        };
        global.fetch = jest.fn();
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('Plugin Initialization', () => {
        it('should create plugin API object', () => {
            // Require the plugin module
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            expect(tiandaoPlugin).toBeDefined();
            expect(tiandaoPlugin.init).toBeDefined();
            expect(tiandaoPlugin.getPluginInfo).toBeDefined();
            expect(tiandaoPlugin.analyzeCharacter).toBeDefined();
        });

        it('should return correct plugin info', () => {
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            const info = tiandaoPlugin.getPluginInfo();
            
            expect(info.name).toBe('Tiandao System');
            expect(info.version).toBe('1.0.0');
            expect(info.id).toBe('tiandao-system');
        });
    });

    describe('Configuration Management', () => {
        it('should have default configuration', () => {
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            const config = tiandaoPlugin.getConfig();
            
            expect(config.apiEndpoint).toBeDefined();
            expect(config.debugMode).toBe(false);
            expect(config.autoAnalyze).toBe(true);
            expect(config.cacheEnabled).toBe(true);
        });

        it('should update configuration', () => {
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            tiandaoPlugin.updateConfig({ debugMode: true });
            
            const config = tiandaoPlugin.getConfig();
            expect(config.debugMode).toBe(true);
        });
    });

    describe('Character Analysis', () => {
        it('should analyze character successfully', async () => {
            const mockResponse = {
                ok: true,
                json: () => Promise.resolve({
                    success: true,
                    data: {
                        mbti: { type: 'ENFJ', name: 'The Protagonist' },
                        traits: {
                            openness: 0.7,
                            conscientiousness: 0.6,
                            extraversion: 0.8,
                            agreeableness: 0.9,
                            neuroticism: 0.3
                        }
                    }
                })
            };
            
            global.fetch.mockResolvedValueOnce(mockResponse);
            
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            const profile = await tiandaoPlugin.analyzeCharacter(0);
            
            expect(profile).toBeDefined();
            expect(profile.mbti.type).toBe('ENFJ');
            expect(profile.traits.agreeableness).toBeGreaterThan(0.8);
        });

        it('should use cached profile when available', async () => {
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            // First analysis
            const mockResponse = {
                ok: true,
                json: () => Promise.resolve({
                    success: true,
                    data: { mbti: { type: 'INTJ' }, traits: {} }
                })
            };
            global.fetch.mockResolvedValueOnce(mockResponse);
            
            await tiandaoPlugin.analyzeCharacter(0);
            
            // Second call should use cache
            const profile = await tiandaoPlugin.analyzeCharacter(0);
            
            expect(profile).toBeDefined();
            expect(global.fetch).toHaveBeenCalledTimes(1);
        });
    });

    describe('Context Formatting', () => {
        it('should format character context correctly', () => {
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            const profile = {
                mbti: { type: 'INTJ' },
                traits: {
                    openness: 0.8,
                    conscientiousness: 0.7
                },
                motivation: 'achievement',
                psychology: { core: 'Strategic thinker' }
            };
            
            const context = tiandaoPlugin.formatCharacterContext(profile);
            
            expect(context).toContain('MBTI Type: INTJ');
            expect(context).toContain('Strategic thinker');
            expect(context).toContain('[Character Psychology Context]');
        });
    });

    describe('Cache Management', () => {
        it('should clear cache correctly', () => {
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            tiandaoPlugin.clearCache();
            
            expect(tiandaoPlugin.getCacheSize()).toBe(0);
        });

        it('should track cache size', async () => {
            const mockResponse = {
                ok: true,
                json: () => Promise.resolve({
                    success: true,
                    data: { mbti: { type: 'ISTJ' }, traits: {} }
                })
            };
            global.fetch.mockResolvedValue(mockResponse);
            
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            await tiandaoPlugin.analyzeCharacter(0);
            
            expect(tiandaoPlugin.getCacheSize()).toBe(1);
        });
    });

    describe('Event Handling', () => {
        it('should register event listeners on init', () => {
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            tiandaoPlugin.init();
            
            expect(global.eventManager.on).toHaveBeenCalled();
        });
    });

    describe('Message Analysis', () => {
        it('should analyze message for consistency', async () => {
            const mockProfileResponse = {
                ok: true,
                json: () => Promise.resolve({
                    success: true,
                    data: { mbti: { type: 'ENFP' }, traits: {} }
                })
            };
            const mockMessageResponse = {
                ok: true,
                json: () => Promise.resolve({
                    success: true,
                    data: { consistency_score: 0.85 }
                })
            };
            
            global.fetch
                .mockResolvedValueOnce(mockProfileResponse)
                .mockResolvedValueOnce(mockMessageResponse);
            
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            // First cache the profile
            await tiandaoPlugin.analyzeCharacter(0);
            
            const analysis = await tiandaoPlugin.analyzeMessage({ content: 'Test message' });
            
            expect(analysis).toBeDefined();
        });
    });

    describe('Emotional State Calculation', () => {
        it('should calculate emotional state', async () => {
            const mockResponse = {
                ok: true,
                json: () => Promise.resolve({
                    success: true,
                    data: {
                        current_mood: 'happy',
                        intensity: 0.7,
                        valence: 0.6
                    }
                })
            };
            
            global.fetch.mockResolvedValueOnce(mockResponse);
            
            const tiandaoPlugin = require('../sillytavern_plugin/tiandao_plugin.js');
            
            const messages = [
                { content: 'I am so happy today!' },
                { content: 'This is wonderful!' }
            ];
            
            const state = await tiandaoPlugin.calculateEmotionalState(messages, 0);
            
            expect(state).toBeDefined();
            expect(state.current_mood).toBe('happy');
        });
    });
});

// Mock fetch helper for tests
global.mockFetch = (response, times = 1) => {
    global.fetch = jest.fn().mockResolvedValue(response);
};
