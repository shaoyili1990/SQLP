/**
 * Tiandao System SillyTavern Plugin
 * Integrates the tiandao character psychology system with SillyTavern
 * 
 * This plugin provides:
 * - Character psychology profile analysis
 * - MBTI personality type detection
 * - Emotional state tracking
 * - Prompt injection for consistent character portrayal
 * - Real-time message analysis
 * - Settings UI for configuration
 */

(function() {
    'use strict';

    // Plugin metadata
    const PLUGIN_NAME = 'Tiandao System';
    const PLUGIN_VERSION = '1.0.0';
    const PLUGIN_ID = 'tiandao-system';
    const PLUGIN_PREFIX = '[Tiandao]';

    // Configuration defaults
    const DEFAULT_CONFIG = {
        apiEndpoint: 'http://localhost:5000/api',
        debugMode: false,
        autoAnalyze: true,
        cacheEnabled: true,
        injectContext: true,
        showNotifications: true,
        analysisDepth: 'standard', // 'basic', 'standard', 'deep'
        personalityModel: 'keyword', // 'keyword', 'ml', 'hybrid'
        maxCacheSize: 100,
        requestTimeout: 10000
    };

    // State management
    let state = {
        initialized: false,
        config: { ...DEFAULT_CONFIG },
        characterProfiles: new Map(),
        pendingRequests: new Map(),
        eventListeners: new Map(),
        uiElements: new Map()
    };

    // MBTI type descriptions for context injection
    const MBTI_DESCRIPTIONS = {
        'ISTJ': 'Responsible, serious, quiet leader who values traditions and loyalty',
        'ISFJ': 'Warm, protective, faithful friend who prioritizes others\' needs',
        'INFJ': 'Insightful, creative idealist with strong personal values',
        'INTJ': 'Strategic thinker with high standards and independent judgment',
        'ISTP': 'Practical problem-solver who enjoys exploring how things work',
        'ISFP': 'Gentle, sensitive artist who values authenticity and freedom',
        'INFP': 'Poetic, idealistic mediator who seeks meaning and authenticity',
        'INTP': 'Logical innovator who loves theoretical concepts and abstract thinking',
        'ESTP': 'Energetic, practical problem-solver who enjoys adventure and action',
        'ESFP': 'Enthusiastic entertainer who loves being the center of attention',
        'ENFP': 'Creative inspirer who sees possibilities and connects with people',
        'ENTP': 'Inventive entrepreneur who loves intellectual debates and new ideas',
        'ESTJ': 'Efficient organizer who values logic, decisiveness, and structure',
        'ESFJ': 'Caring host who values harmony and wants everyone to be happy',
        'ENFJ': 'Charismatic leader who inspires others and values cooperation',
        'ENTJ': 'Bold, commanding leader who loves challenges and strategic planning'
    };

    // ============================================
    // Core Initialization
    // ============================================

    async function init() {
        if (state.initialized) {
            log('Plugin already initialized');
            return;
        }

        log(`Initializing v${PLUGIN_VERSION}...`);

        try {
            // Load saved configuration
            loadConfig();

            // Register event listeners for SillyTavern
            registerEventListeners();

            // Create settings UI
            createSettingsUI();

            // Test API connection
            await testConnection();

            state.initialized = true;
            log('Initialization complete');

            if (state.config.showNotifications) {
                showNotification('Tiandao System plugin loaded');
            }
        } catch (error) {
            logError('Initialization failed', error);
        }
    }

    // ============================================
    // Event Listeners
    // ============================================

    function registerEventListeners() {
        log('Registering event listeners...');

        // Chat events
        on('chatloaded', handleChatLoaded);
        on('chat:loaded', handleChatLoaded);
        on('chatIdChanged', handleChatChanged);
        
        // Message events
        on('messageadded', handleMessageAdded);
        on('message_send', handleMessageSend);
        on('chat_generate', handleChatGenerate);
        
        // Character events
        on('character_deleting', handleCharacterDeleting);
        on('character_deleted', handleCharacterDeleted);
        on('characterswapped', handleCharacterSwapped);
        
        // Prompt events
        on('prompting_complete', handlePromptComplete);
        on('context_prompt', handleContextPrompt);
        
        // Settings events
        on('settings_ready', handleSettingsReady);
        
        // Generate events (for AI response interception)
        on('generate_after', handleGenerateAfter);
        on('generate_before', handleGenerateBefore);

        log('Event listeners registered');
    }

    function on(eventName, callback) {
        if (!state.eventListeners.has(eventName)) {
            state.eventListeners.set(eventName, []);
        }
        state.eventListeners.get(eventName).push(callback);
        
        // Register with SillyTavern's event manager if available
        if (typeof eventManager !== 'undefined' && eventManager.on) {
            eventManager.on(eventName, callback);
        }
    }

    function emit(eventName, ...args) {
        const listeners = state.eventListeners.get(eventName) || [];
        listeners.forEach(callback => {
            try {
                callback(...args);
            } catch (error) {
                logError(`Error in ${eventName} handler`, error);
            }
        });
    }

    // ============================================
    // Chat Event Handlers
    // ============================================

    async function handleChatLoaded(data) {
        log('Chat loaded event received');
        
        if (!state.config.autoAnalyze) return;

        const characterId = getCurrentCharacterId();
        if (characterId) {
            await analyzeCharacter(characterId);
        }
    }

    async function handleChatChanged(chatId) {
        log(`Chat changed: ${chatId}`);
        
        if (!state.config.autoAnalyze) return;

        const characterId = getCurrentCharacterId();
        if (characterId) {
            await analyzeCharacter(characterId);
        }
    }

    async function handleCharacterSwapped(data) {
        log('Character swapped');
        
        // Clear old profile cache for previous character
        const prevCharId = data?.previousCharacterId;
        if (prevCharId) {
            state.characterProfiles.delete(prevCharId);
        }

        if (state.config.autoAnalyze) {
            const newCharId = getCurrentCharacterId();
            if (newCharId) {
                await analyzeCharacter(newCharId);
            }
        }
    }

    // ============================================
    // Message Event Handlers
    // ============================================

    async function handleMessageAdded(message) {
        log('New message added');
        
        if (!state.config.autoAnalyze) return;

        try {
            const analysis = await analyzeMessage(message);
            if (analysis && state.config.debugMode) {
                log('Message analysis:', analysis);
            }
        } catch (error) {
            logError('Error analyzing message', error);
        }
    }

    async function handleMessageSend(message) {
        log('Message being sent');
        // User messages are handled similarly
        if (state.config.autoAnalyze) {
            await analyzeMessage(message);
        }
    }

    async function handleChatGenerate(data) {
        log('Chat generation triggered');
        
        if (state.config.injectContext) {
            injectCharacterContext(data);
        }
    }

    async function handleGenerateBefore(data) {
        log('Pre-generation hook');
        
        if (state.config.injectContext) {
            injectCharacterContext(data);
        }
    }

    async function handleGenerateAfter(data) {
        log('Post-generation hook');
        // Can analyze AI response here if needed
    }

    // ============================================
    // Character Event Handlers
    // ============================================

    function handleCharacterDeleting(characterId) {
        log(`Character deleting: ${characterId}`);
        
        // Pre-delete: clear cache
        if (state.characterProfiles.has(characterId)) {
            state.characterProfiles.delete(characterId);
            log('Profile cache cleared');
        }
    }

    function handleCharacterDeleted(characterId) {
        log(`Character deleted: ${characterId}`);
        
        // Already cleared in handleCharacterDeleting
        // Additional cleanup if needed
    }

    // ============================================
    // Prompt Event Handlers
    // ============================================

    function handlePromptComplete(promptData) {
        log('Prompt completion event');
        
        if (state.config.injectContext) {
            injectCharacterContext(promptData);
        }
    }

    function handleContextPrompt(contextData) {
        log('Context prompt event');
        
        const characterId = getCurrentCharacterId();
        const profile = state.characterProfiles.get(characterId);
        
        if (profile) {
            const tiandaoContext = formatCharacterContext(profile);
            contextData.prompt = `${tiandaoContext}\n\n${contextData.prompt}`;
        }
    }

    function handleSettingsReady() {
        log('Settings ready');
        updateSettingsUI();
    }

    // ============================================
    // API Communication
    // ============================================

    async function testConnection() {
        try {
            const response = await apiRequest('/health', { method: 'GET' });
            
            if (response.ok) {
                const data = await response.json();
                log(`API connection verified: ${data.service}`);
                return true;
            } else {
                log(`API returned status ${response.status}`);
                return false;
            }
        } catch (error) {
            log('API not available, will use offline mode');
            return false;
        }
    }

    async function apiRequest(endpoint, options = {}) {
        const url = `${state.config.apiEndpoint}${endpoint}`;
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), state.config.requestTimeout);

        try {
            const response = await fetch(url, {
                ...options,
                signal: controller.signal,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });
            return response;
        } finally {
            clearTimeout(timeoutId);
        }
    }

    // ============================================
    // Character Analysis
    // ============================================

    async function analyzeCharacter(characterId) {
        log(`Analyzing character: ${characterId}`);

        // Check cache first
        if (state.config.cacheEnabled && state.characterProfiles.has(characterId)) {
            log('Using cached profile');
            return state.characterProfiles.get(characterId);
        }

        try {
            // Get character data from SillyTavern
            const characterData = getCharacterData(characterId);
            if (!characterData) {
                logError('Could not retrieve character data');
                return null;
            }

            // Send to backend for analysis
            const response = await apiRequest('/psychology/analyze', {
                method: 'POST',
                body: JSON.stringify({
                    name: characterData.name,
                    description: characterData.description,
                    personality: characterData.personality,
                    scenario: characterData.scenario,
                    first_message: characterData.first_mes,
                    depth: state.config.analysisDepth
                })
            });

            if (response.ok) {
                const result = await response.json();
                const profile = result.data;

                // Store in cache
                if (state.config.cacheEnabled) {
                    cacheProfile(characterId, profile);
                }

                log('Character analysis complete');
                return profile;
            } else {
                logError(`Analysis failed with status ${response.status}`);
                return null;
            }
        } catch (error) {
            logError('Character analysis error', error);
            return null;
        }
    }

    function getCharacterData(characterId) {
        // SillyTavern global variables
        if (typeof characters !== 'undefined' && characters[characterId]) {
            return characters[characterId];
        }
        
        // Try to get current character
        if (typeof characterId !== 'undefined' && characters[characterId]) {
            return characters[characterId];
        }
        
        return null;
    }

    function getCurrentCharacterId() {
        // SillyTavern global for current character index
        if (typeof characterId !== 'undefined') {
            return characterId;
        }
        return null;
    }

    function cacheProfile(characterId, profile) {
        // Enforce cache size limit
        if (state.characterProfiles.size >= state.config.maxCacheSize) {
            const firstKey = state.characterProfiles.keys().next().value;
            state.characterProfiles.delete(firstKey);
        }
        
        state.characterProfiles.set(characterId, profile);
    }

    // ============================================
    // Message Analysis
    // ============================================

    async function analyzeMessage(message) {
        const characterId = getCurrentCharacterId();
        const profile = state.characterProfiles.get(characterId);

        if (!profile) {
            // Try to get profile if not cached
            const newProfile = await analyzeCharacter(characterId);
            if (!newProfile) return null;
        }

        try {
            const response = await apiRequest('/psychology/analyze-message', {
                method: 'POST',
                body: JSON.stringify({
                    message: message,
                    profile: profile || state.characterProfiles.get(characterId)
                })
            });

            if (response.ok) {
                return await response.json();
            }
        } catch (error) {
            logError('Message analysis error', error);
        }

        return null;
    }

    // ============================================
    // Context Injection
    // ============================================

    function injectCharacterContext(data) {
        const characterId = getCurrentCharacterId();
        if (!characterId) return;

        const profile = state.characterProfiles.get(characterId);
        if (!profile) return;

        const context = formatCharacterContext(profile);
        
        if (data.prompt) {
            data.prompt = `${context}\n\n${data.prompt}`;
        } else if (data.context) {
            data.context = `${context}\n\n${data.context}`;
        }
    }

    function formatCharacterContext(profile) {
        const parts = ['[Character Psychology Context]'];

        // MBTI Type
        if (profile.mbti) {
            const mbtiType = profile.mbti.type || profile.mbti;
            const description = MBTI_DESCRIPTIONS[mbtiType] || '';
            parts.push(`MBTI Type: ${mbtiType}${description ? ` - ${description}` : ''}`);
        }

        // Big Five Traits
        if (profile.traits) {
            const traitDescriptions = [];
            const traitLabels = {
                openness: 'Openness',
                conscientiousness: 'Conscientiousness',
                extraversion: 'Extraversion',
                agreeableness: 'Agreeableness',
                neuroticism: 'Neuroticism'
            };

            for (const [trait, value] of Object.entries(profile.traits)) {
                const label = traitLabels[trait] || trait;
                const level = value > 0.7 ? 'High' : value > 0.3 ? 'Moderate' : 'Low';
                traitDescriptions.push(`${label}: ${level} (${Math.round(value * 100)}%)`);
            }

            if (traitDescriptions.length > 0) {
                parts.push(`Big Five Traits: ${traitDescriptions.join(', ')}`);
            }
        }

        // Core Motivation
        if (profile.motivation) {
            const motivation = typeof profile.motivation === 'string' 
                ? profile.motivation 
                : profile.motivation.primary;
            parts.push(`Core Motivation: ${motivation}`);
        }

        // Psychology Core
        if (profile.psychology) {
            const psychology = typeof profile.psychology === 'string' 
                ? profile.psychology 
                : profile.psychology.core;
            if (psychology) {
                parts.push(`Psychological Profile: ${psychology}`);
            }
        }

        // Attachment Style
        if (profile.attachment_style) {
            parts.push(`Attachment Style: ${profile.attachment_style}`);
        }

        // Fears and Motivations
        if (profile.fears && profile.fears.length > 0) {
            parts.push(`Core Fears: ${profile.fears.join(', ')}`);
        }

        parts.push('[/Character Psychology Context]');

        return parts.join('\n');
    }

    // ============================================
    // Psychology API Integration
    // ============================================

    async function getCharacterPsychology(characterId) {
        const profile = await analyzeCharacter(characterId);
        if (!profile) return null;

        return {
            mbti: profile.mbti,
            traits: profile.traits,
            motivation: profile.motivation,
            psychology: profile.psychology,
            attachment_style: profile.attachment_style,
            fears: profile.fears,
            author: profile.author
        };
    }

    async function calculateEmotionalState(messages, characterId) {
        try {
            const response = await apiRequest('/psychology/emotional-state', {
                method: 'POST',
                body: JSON.stringify({
                    messages: messages,
                    character: state.characterProfiles.get(characterId)
                })
            });

            if (response.ok) {
                const result = await response.json();
                return result.data;
            }
        } catch (error) {
            logError('Emotional state calculation error', error);
        }

        return null;
    }

    // ============================================
    // Settings Management
    // ============================================

    function loadConfig() {
        try {
            const saved = localStorage.getItem(`${PLUGIN_ID}_config`);
            if (saved) {
                state.config = { ...DEFAULT_CONFIG, ...JSON.parse(saved) };
                log('Configuration loaded from storage');
            }
        } catch (error) {
            logError('Error loading config', error);
        }
    }

    function saveConfig() {
        try {
            localStorage.setItem(`${PLUGIN_ID}_config`, JSON.stringify(state.config));
            log('Configuration saved');
        } catch (error) {
            logError('Error saving config', error);
        }
    }

    function updateConfig(newConfig) {
        state.config = { ...state.config, ...newConfig };
        saveConfig();
    }

    // ============================================
    // Settings UI
    // ============================================

    function createSettingsUI() {
        // Create settings panel in SillyTavern's settings area
        const settingsHtml = `
            <div id="tiandao-settings" class="tiandao-settings">
                <div class="tiandao-settings-header">
                    <h3>Tiandao System Settings</h3>
                </div>
                
                <div class="tiandao-settings-content">
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" id="tiandao_auto_analyze" 
                                ${state.config.autoAnalyze ? 'checked' : ''}>
                            Auto-analyze characters on load
                        </label>
                    </div>
                    
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" id="tiandao_inject_context" 
                                ${state.config.injectContext ? 'checked' : ''}>
                            Inject psychology context into prompts
                        </label>
                    </div>
                    
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" id="tiandao_debug_mode" 
                                ${state.config.debugMode ? 'checked' : ''}>
                            Debug mode
                        </label>
                    </div>
                    
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" id="tiandao_cache" 
                                ${state.config.cacheEnabled ? 'checked' : ''}>
                            Enable profile caching
                        </label>
                    </div>
                    
                    <div class="setting-group">
                        <label>
                            <input type="checkbox" id="tiandao_notifications" 
                                ${state.config.showNotifications ? 'checked' : ''}>
                            Show notifications
                        </label>
                    </div>
                    
                    <div class="setting-group">
                        <label>API Endpoint</label>
                        <input type="text" id="tiandao_api_endpoint" 
                            value="${state.config.apiEndpoint}" 
                            placeholder="http://localhost:5000/api">
                    </div>
                    
                    <div class="setting-group">
                        <label>Analysis Depth</label>
                        <select id="tiandao_depth">
                            <option value="basic" 
                                ${state.config.analysisDepth === 'basic' ? 'selected' : ''}>
                                Basic
                            </option>
                            <option value="standard" 
                                ${state.config.analysisDepth === 'standard' ? 'selected' : ''}>
                                Standard
                            </option>
                            <option value="deep" 
                                ${state.config.analysisDepth === 'deep' ? 'selected' : ''}>
                                Deep
                            </option>
                        </select>
                    </div>
                    
                    <div class="setting-group">
                        <button id="tiandao_clear_cache" class="tiandao-btn">
                            Clear Profile Cache
                        </button>
                    </div>
                    
                    <div class="setting-group">
                        <button id="tiandao_test_connection" class="tiandao-btn">
                            Test API Connection
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Inject styles
        injectStyles();

        // Try to add to SillyTavern settings
        try {
            const settingsContainer = document.getElementById('extensions_settings');
            if (settingsContainer) {
                settingsContainer.insertAdjacentHTML('beforeend', settingsHtml);
                bindSettingsEvents();
            }
        } catch (error) {
            log('Could not add to settings UI, will use fallback');
            // Fallback: add to body for manual access
            document.body.insertAdjacentHTML('beforeend', settingsHtml);
            bindSettingsEvents();
        }

        state.uiElements.set('settings', document.getElementById('tiandao-settings'));
    }

    function injectStyles() {
        const styles = `
            .tiandao-settings {
                background: var(--background-primary, #1a1a1a);
                border: 1px solid var(--background-secondary, #2d2d2d);
                border-radius: 8px;
                padding: 16px;
                margin: 16px 0;
            }
            
            .tiandao-settings-header h3 {
                margin: 0 0 16px 0;
                color: var(--text-primary, #fff);
            }
            
            .tiandao-settings-content {
                display: flex;
                flex-direction: column;
                gap: 12px;
            }
            
            .setting-group {
                display: flex;
                flex-direction: column;
                gap: 4px;
            }
            
            .setting-group label {
                color: var(--text-secondary, #ccc);
                font-size: 14px;
            }
            
            .setting-group input[type="text"] {
                background: var(--background-input, #2d2d2d);
                border: 1px solid var(--border-color, #3d3d3d);
                color: var(--text-primary, #fff);
                padding: 8px 12px;
                border-radius: 4px;
                font-size: 14px;
            }
            
            .setting-group select {
                background: var(--background-input, #2d2d2d);
                border: 1px solid var(--border-color, #3d3d3d);
                color: var(--text-primary, #fff);
                padding: 8px 12px;
                border-radius: 4px;
                font-size: 14px;
            }
            
            .tiandao-btn {
                background: var(--background-secondary, #2d2d2d);
                border: 1px solid var(--border-color, #3d3d3d);
                color: var(--text-primary, #fff);
                padding: 8px 16px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 14px;
                transition: background 0.2s;
            }
            
            .tiandao-btn:hover {
                background: var(--background-tertiary, #3d3d3d);
            }
            
            #tiandao-notification {
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: var(--background-secondary, #2d2d2d);
                border: 1px solid var(--accent-color, #4a9eff);
                color: var(--text-primary, #fff);
                padding: 12px 20px;
                border-radius: 8px;
                z-index: 10000;
                animation: tiandao-slide-in 0.3s ease;
            }
            
            @keyframes tiandao-slide-in {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;

        const styleElement = document.createElement('style');
        styleElement.id = 'tiandao-styles';
        styleElement.textContent = styles;
        document.head.appendChild(styleElement);
    }

    function bindSettingsEvents() {
        // Checkboxes
        const checkboxes = [
            { id: 'tiandao_auto_analyze', key: 'autoAnalyze' },
            { id: 'tiandao_inject_context', key: 'injectContext' },
            { id: 'tiandao_debug_mode', key: 'debugMode' },
            { id: 'tiandao_cache', key: 'cacheEnabled' },
            { id: 'tiandao_notifications', key: 'showNotifications' }
        ];

        checkboxes.forEach(({ id, key }) => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('change', (e) => {
                    state.config[key] = e.target.checked;
                    saveConfig();
                });
            }
        });

        // API Endpoint
        const endpointInput = document.getElementById('tiandao_api_endpoint');
        if (endpointInput) {
            endpointInput.addEventListener('change', (e) => {
                state.config.apiEndpoint = e.target.value;
                saveConfig();
            });
        }

        // Analysis Depth
        const depthSelect = document.getElementById('tiandao_depth');
        if (depthSelect) {
            depthSelect.addEventListener('change', (e) => {
                state.config.analysisDepth = e.target.value;
                saveConfig();
            });
        }

        // Clear Cache button
        const clearCacheBtn = document.getElementById('tiandao_clear_cache');
        if (clearCacheBtn) {
            clearCacheBtn.addEventListener('click', () => {
                state.characterProfiles.clear();
                showNotification('Profile cache cleared');
            });
        }

        // Test Connection button
        const testBtn = document.getElementById('tiandao_test_connection');
        if (testBtn) {
            testBtn.addEventListener('click', async () => {
                testBtn.disabled = true;
                testBtn.textContent = 'Testing...';
                
                const connected = await testConnection();
                
                testBtn.disabled = false;
                testBtn.textContent = 'Test API Connection';
                
                if (connected) {
                    showNotification('API connection successful');
                } else {
                    showNotification('API connection failed', true);
                }
            });
        }
    }

    function updateSettingsUI() {
        // Update UI elements with current config
        const checkboxes = [
            { id: 'tiandao_auto_analyze', key: 'autoAnalyze' },
            { id: 'tiandao_inject_context', key: 'injectContext' },
            { id: 'tiandao_debug_mode', key: 'debugMode' },
            { id: 'tiandao_cache', key: 'cacheEnabled' },
            { id: 'tiandao_notifications', key: 'showNotifications' }
        ];

        checkboxes.forEach(({ id, key }) => {
            const element = document.getElementById(id);
            if (element) {
                element.checked = state.config[key];
            }
        });

        const endpointInput = document.getElementById('tiandao_api_endpoint');
        if (endpointInput) {
            endpointInput.value = state.config.apiEndpoint;
        }

        const depthSelect = document.getElementById('tiandao_depth');
        if (depthSelect) {
            depthSelect.value = state.config.analysisDepth;
        }
    }

    // ============================================
    // Notifications
    // ============================================

    function showNotification(message, isError = false) {
        if (!state.config.showNotifications) return;

        let notification = document.getElementById('tiandao-notification');
        
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'tiandao-notification';
            document.body.appendChild(notification);
        }

        notification.textContent = `${PLUGIN_PREFIX} ${message}`;
        notification.style.borderColor = isError ? '#ff4d4d' : '#4a9eff';
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    // ============================================
    // Logging Utilities
    // ============================================

    function log(...args) {
        if (state.config.debugMode) {
            console.log(`${PLUGIN_PREFIX}`, ...args);
        }
    }

    function logError(message, error) {
        console.error(`${PLUGIN_PREFIX} ${message}:`, error);
    }

    // ============================================
    // Plugin API Export
    // ============================================

    const pluginAPI = {
        // Initialization
        init,
        
        // Plugin info
        getPluginInfo() {
            return {
                name: PLUGIN_NAME,
                version: PLUGIN_VERSION,
                id: PLUGIN_ID,
                initialized: state.initialized
            };
        },
        
        // Configuration
        updateConfig,
        getConfig() {
            return { ...state.config };
        },
        
        // Character analysis
        analyzeCharacter,
        getCharacterPsychology,
        getCurrentProfile() {
            const characterId = getCurrentCharacterId();
            return state.characterProfiles.get(characterId);
        },
        
        // Message analysis
        analyzeMessage,
        calculateEmotionalState,
        
        // Context injection
        injectCharacterContext,
        formatCharacterContext,
        
        // Cache management
        clearCache() {
            state.characterProfiles.clear();
        },
        getCacheSize() {
            return state.characterProfiles.size;
        },
        
        // Event emission
        emit,
        
        // Settings
        showSettings() {
            const settings = state.uiElements.get('settings');
            if (settings) {
                settings.style.display = settings.style.display === 'none' ? 'block' : 'none';
            }
        }
    };

    // Expose to global scope
    window.tiandaoPlugin = pluginAPI;

    // Also expose as module if available
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = pluginAPI;
    }

    // ============================================
    // Auto-initialization
    // ============================================

    // Try to initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        // DOM already loaded, init immediately
        init();
    }

    // Also listen for SillyTavern ready event
    document.addEventListener('st-ready', init);
    window.addEventListener('load', init);

})();
