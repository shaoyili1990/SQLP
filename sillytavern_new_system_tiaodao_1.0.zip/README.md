# Tiandao System for SillyTavern

A comprehensive character psychology and personality analysis system that integrates with [SillyTavern](https://github.com/SillyTavern/SillyTavern) to provide:

- **MBTI Personality Analysis** - Automatically detect character personality types
- **Big Five Trait Analysis** - Analyze Openness, Conscientiousness, Extraversion, Agreeableness, Neuroticism
- **Emotional State Tracking** - Monitor character emotional states during conversations
- **Prompt Context Injection** - Enhance AI responses with consistent character psychology
- **Character Profile Caching** - Fast repeated analysis with intelligent caching

## Features

### Character Psychology Analysis
- MBTI type detection based on character description
- Big Five personality trait analysis
- Core motivation and fear identification
- Attachment style determination
- Confidence scoring for analysis accuracy

### Real-time Analysis
- Message-by-message psychological analysis
- Emotional state calculation from conversation context
- Profile consistency checking
- Sentiment detection

### Context Injection
- Automatic psychology context in prompts
- Customizable injection depth
- Compact and full context formats
- Token-efficient formatting options

### Integration
- Seamless SillyTavern plugin integration
- RESTful backend API
- Event-driven architecture
- Comprehensive settings UI

## Quick Start

### Backend Installation

```bash
cd backend
pip install -r requirements.txt
python server.py
```

### Plugin Installation

Copy `sillytavern_plugin/tiandao_plugin.js` to your SillyTavern plugins directory.

See [INSTALL.md](INSTALL.md) for detailed installation instructions.

## Architecture

```
sillytavern_new_system_tiaodao/
├── sillytavern_plugin/
│   └── tiandao_plugin.js    # SillyTavern client plugin
├── backend/
│   ├── server.py            # Flask API server
│   ├── psychology_api.py    # Personality analysis endpoints
│   ├── character_card_parser.py  # Character card parsing
│   ├── message_formatter.py # Message formatting utilities
│   └── config.py            # Configuration management
├── tests/                   # Test files
└── examples/                # Usage examples
```

## API Endpoints

### Health & Status
- `GET /api/health` - Health check
- `GET /api/status` - Detailed status

### Character Analysis
- `POST /api/characters` - Parse character card
- `POST /api/characters/validate` - Validate character card
- `POST /api/characters/extract` - Extract characteristics

### Psychology
- `POST /api/psychology/analyze` - Analyze personality
- `POST /api/psychology/analyze-message` - Analyze message
- `GET /api/psychology/moods` - Available moods
- `POST /api/psychology/emotional-state` - Calculate emotional state

### Message Formatting
- `POST /api/format-message` - Format single message
- `POST /api/format-conversation` - Format conversation

### Context Generation
- `POST /api/context/generate` - Generate character context

See [CONFIG.md](CONFIG.md) for configuration options.

## Plugin Usage

```javascript
// Initialize (auto-initializes on load)
tiandaoPlugin.init();

// Get plugin info
const info = tiandaoPlugin.getPluginInfo();

// Analyze a character
const profile = await tiandaoPlugin.analyzeCharacter(characterId);

// Get current character's psychology
const psychology = await tiandaoPlugin.getCharacterPsychology(characterId);

// Analyze a message
const analysis = await tiandaoPlugin.analyzeMessage(message);

// Calculate emotional state
const emotionalState = await tiandaoPlugin.calculateEmotionalState(messages, characterId);

// Clear cache
tiandaoPlugin.clearCache();
```

## Configuration

### Backend Environment Variables

```bash
HOST=0.0.0.0
PORT=5000
DEBUG=False
PSYCHOLOGY_ENABLED=True
CORS_ORIGINS=*
```

### Plugin Settings

Access via SillyTavern Settings > Extensions > Plugins > Tiandao System:

- API Endpoint configuration
- Auto-analyze on load
- Context injection toggle
- Debug mode
- Analysis depth (basic/standard/deep)
- Cache management

## Development

### Running Tests

```bash
npm test
```

### Linting

```bash
npm run lint
```

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions are welcome! Please read our contributing guidelines before submitting PRs.

## Support

- Open an issue for bugs or feature requests
- Check the documentation in the `docs/` directory
- Review example code in the `examples/` directory
