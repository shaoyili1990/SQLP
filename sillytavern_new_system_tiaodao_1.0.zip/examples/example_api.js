/**
 * Example: Direct API Usage
 * Demonstrates how to use the backend API endpoints directly
 */

const API_BASE = 'http://localhost:5000/api';

// ============================================
// API Helper Functions
// ============================================

const api = {
    async get(endpoint) {
        const response = await fetch(`${API_BASE}${endpoint}`);
        return response.json();
    },
    
    async post(endpoint, data) {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return response.json();
    }
};

// ============================================
// Health & Status Endpoints
// ============================================

async function healthCheck() {
    const result = await api.get('/health');
    console.log('Health:', result);
    return result;
}

async function statusCheck() {
    const result = await api.get('/status');
    console.log('Status:', result);
    return result;
}

// ============================================
// Character Card Endpoints
// ============================================

async function parseCharacterCard(cardData) {
    const result = await api.post('/characters', cardData);
    
    if (result.success) {
        console.log('Parsed character:', result.data);
        return result.data;
    }
    
    throw new Error(result.error);
}

async function validateCharacterCard(cardData) {
    const result = await api.post('/characters/validate', cardData);
    
    console.log(`Valid: ${result.valid}`);
    if (result.errors?.length) {
        console.log('Errors:', result.errors);
    }
    
    return result;
}

async function extractCharacteristics(description) {
    const result = await api.post('/characters/extract', {
        description: description
    });
    
    if (result.success) {
        console.log('Characteristics:', result.data);
        return result.data;
    }
    
    throw new Error(result.error);
}

// ============================================
// Message Formatting Endpoints
// ============================================

async function formatMessage(messageData) {
    const result = await api.post('/format-message', messageData);
    
    if (result.success) {
        return result.data;
    }
    
    throw new Error(result.error);
}

async function formatConversation(messages) {
    const result = await api.post('/format-conversation', {
        messages: messages
    });
    
    if (result.success) {
        console.log(`Formatted ${result.data.count} messages`);
        return result.data.messages;
    }
    
    throw new Error(result.error);
}

// ============================================
// Context Generation Endpoints
// ============================================

async function generateCharacterContext(characterId, profile, format = 'default') {
    const result = await api.post('/context/generate', {
        character_id: characterId,
        profile: profile,
        format: format
    });
    
    if (result.success) {
        console.log('Generated context:');
        console.log(result.data.context);
        return result.data.context;
    }
    
    throw new Error(result.error);
}

// ============================================
// Psychology Endpoints
// ============================================

async function analyzeCharacterPsychology(characterData, depth = 'standard') {
    const result = await api.post('/psychology/analyze', {
        name: characterData.name,
        description: characterData.description,
        personality: characterData.personality,
        scenario: characterData.scenario,
        depth: depth
    });
    
    if (result.success) {
        return result.data;
    }
    
    throw new Error(result.error);
}

async function analyzePsychologyMessage(message, profile) {
    const result = await api.post('/psychology/analyze-message', {
        message: message,
        profile: profile
    });
    
    if (result.success) {
        return result.data;
    }
    
    throw new Error(result.error);
}

async function getPsychologyMoods() {
    const result = await api.get('/psychology/moods');
    
    if (result.success) {
        console.log('Available moods:');
        result.data.forEach(mood => {
            console.log(`  ${mood.emoji} ${mood.name} (valence: ${mood.valence})`);
        });
        return result.data;
    }
    
    throw new Error(result.error);
}

async function getEmotionalState(messages, character, depth = 'standard') {
    const result = await api.post('/psychology/emotional-state', {
        messages: messages,
        character: character,
        depth: depth
    });
    
    if (result.success) {
        return result.data;
    }
    
    throw new Error(result.error);
}

async function getMBTIData(typeCode = null) {
    if (typeCode) {
        const result = await api.get(`/psychology/mbti/${typeCode}`);
        if (result.success) {
            console.log(`MBTI ${typeCode}:`, result.data);
            return result.data;
        }
    } else {
        const result = await api.get('/psychology/mbti');
        if (result.success) {
            console.log('All MBTI types:', Object.keys(result.data));
            return result.data;
        }
    }
    
    throw new Error(result.error);
}

// ============================================
// Complete Workflow Example
// ============================================

async function fullCharacterAnalysisWorkflow() {
    console.log('=== Full Character Analysis Workflow ===\n');
    
    // 1. Health check
    console.log('1. Checking API health...');
    await healthCheck();
    
    // 2. Parse character card
    console.log('\n2. Parsing character card...');
    const characterCard = {
        name: 'Mysterious Stranger',
        description: 'A mysterious figure who speaks in riddles and observes everything. ' +
                     'They are highly intelligent and analytical, always thinking several steps ahead. ' +
                     'Despite their cold exterior, they have a strong sense of loyalty to those they trust.',
        personality: 'Mysterious, intelligent, analytical, guarded, loyal',
        scenario: 'Meeting in a dimly lit tavern'
    };
    
    const parsed = await parseCharacterCard(characterCard);
    console.log(`Parsed: ${parsed.name} (${parsed.version})`);
    
    // 3. Extract characteristics
    console.log('\n3. Extracting characteristics...');
    const characteristics = await extractCharacteristics(characterCard.description);
    console.log(`Speech pattern: ${characteristics.speech_pattern}`);
    console.log(`Traits: ${characteristics.traits.join(', ')}`);
    console.log(`Interests: ${characteristics.interests.join(', ')}`);
    
    // 4. Analyze psychology
    console.log('\n4. Analyzing psychology...');
    const psychology = await analyzeCharacterPsychology(characterCard, 'deep');
    console.log(`MBTI: ${psychology.mbti.type}`);
    console.log(`Motivation: ${psychology.motivation.primary}`);
    console.log(`Fears: ${psychology.fears.join(', ')}`);
    console.log(`Attachment: ${psychology.attachment_style}`);
    console.log(`Confidence: ${Math.round(psychology.confidence * 100)}%`);
    
    // 5. Generate context
    console.log('\n5. Generating context for injection...');
    await generateCharacterContext('mysterious-stranger', psychology, 'full');
    
    // 6. Get moods
    console.log('\n6. Available moods:');
    await getPsychologyMoods();
    
    console.log('\n=== Workflow Complete ===');
    return psychology;
}

// ============================================
// Conversation Analysis Workflow
// ============================================

async function conversationAnalysisWorkflow() {
    console.log('=== Conversation Analysis Workflow ===\n');
    
    // Sample character
    const character = {
        mbti: { type: 'ENFP' },
        traits: {
            openness: 0.8,
            conscientiousness: 0.5,
            extraversion: 0.9,
            agreeableness: 0.7,
            neuroticism: 0.4
        },
        motivation: { primary: 'affiliation' }
    };
    
    // Sample conversation
    const conversation = [
        { role: 'user', content: "Hey! How's your day going?" },
        { role: 'assistant', content: "It's going great! I just had the most amazing coffee. Want to hear about it?" },
        { role: 'user', content: "Sure, tell me everything!" },
        { role: 'assistant', content: "So there was this barista who remembered my name, and they made this beautiful latte art!" },
        { role: 'user', content: "That sounds lovely. Did you get any work done today?" },
        { role: 'assistant', content: "Oh, I tried! But then my friend texted me about a movie night and now I'm SO excited!" }
    ];
    
    // Analyze emotional state
    console.log('Analyzing emotional state...');
    const emotionalState = await getEmotionalState(conversation, character, 'deep');
    
    console.log(`Current mood: ${emotionalState.current_mood}`);
    console.log(`Intensity: ${Math.round(emotionalState.intensity * 100)}%`);
    console.log(`Valence: ${emotionalState.valence}`);
    
    if (emotionalState.triggers?.length) {
        console.log(`Triggers: ${emotionalState.triggers.join(', ')}`);
    }
    
    if (emotionalState.mood_history) {
        console.log(`Mood trend: ${emotionalState.mood_history.trend}`);
    }
    
    if (emotionalState.recommendations?.length) {
        console.log('\nRecommendations for response:');
        emotionalState.recommendations.forEach((rec, i) => {
            console.log(`  ${i + 1}. ${rec}`);
        });
    }
    
    return emotionalState;
}

// ============================================
// Error Handling Example
// ============================================

async function handleApiErrors() {
    try {
        // Try to get invalid MBTI type
        await getMBTIData('INVALID');
    } catch (error) {
        console.log('Expected error caught:', error.message);
    }
    
    try {
        // Try to parse invalid data
        await validateCharacterCard({});
    } catch (error) {
        console.log('Expected error caught:', error.message);
    }
}

// Export for console use
window.apiExamples = {
    // Helpers
    api,
    
    // Health
    healthCheck,
    statusCheck,
    
    // Characters
    parseCharacterCard,
    validateCharacterCard,
    extractCharacteristics,
    
    // Messages
    formatMessage,
    formatConversation,
    
    // Context
    generateCharacterContext,
    
    // Psychology
    analyzeCharacterPsychology,
    analyzePsychologyMessage,
    getPsychologyMoods,
    getEmotionalState,
    getMBTIData,
    
    // Workflows
    fullCharacterAnalysisWorkflow,
    conversationAnalysisWorkflow,
    handleApiErrors
};

console.log('API examples loaded. Access via: apiExamples');
