/**
 * Example: Psychology API Usage
 * Demonstrates how to use the psychology analysis features
 */

// API Base URL - change this to your backend server
const API_BASE = 'http://localhost:5000/api';

// ============================================
// 1. Direct API Calls
// ============================================

/**
 * Analyze character personality
 */
async function analyzePersonality(characterData) {
    const response = await fetch(`${API_BASE}/psychology/analyze`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: characterData.name,
            description: characterData.description,
            personality: characterData.personality,
            scenario: characterData.scenario,
            depth: 'standard'
        })
    });
    
    const result = await response.json();
    
    if (result.success) {
        return result.data;
    }
    
    throw new Error(result.error || 'Analysis failed');
}

/**
 * Analyze a single message
 */
async function analyzeMessagePsychology(message, profile) {
    const response = await fetch(`${API_BASE}/psychology/analyze-message`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            message: message,
            profile: profile
        })
    });
    
    const result = await response.json();
    return result.success ? result.data : null;
}

/**
 * Get available moods
 */
async function getAvailableMoods() {
    const response = await fetch(`${API_BASE}/psychology/moods`);
    const result = await response.json();
    return result.success ? result.data : [];
}

/**
 * Calculate emotional state from conversation
 */
async function calculateEmotionalState(messages, character) {
    const response = await fetch(`${API_BASE}/psychology/emotional-state`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            messages: messages,
            character: character,
            depth: 'deep'
        })
    });
    
    const result = await response.json();
    return result.success ? result.data : null;
}

// ============================================
// 2. MBTI Utilities
// ============================================

/**
 * Get all MBTI types
 */
async function getMBTITypes() {
    const response = await fetch(`${API_BASE}/psychology/mbti`);
    const result = await response.json();
    return result.success ? result.data : {};
}

/**
 * Get specific MBTI type details
 */
async function getMBTIDetails(typeCode) {
    const response = await fetch(`${API_BASE}/psychology/mbti/${typeCode}`);
    const result = await response.json();
    return result.success ? result.data : null;
}

/**
 * Format MBTI for display
 */
function formatMBTI(mbti) {
    if (!mbti) return 'Unknown';
    
    const type = mbti.type || mbti;
    const name = mbti.name || '';
    const description = mbti.description || '';
    
    return `${type} - ${name}\n${description}`;
}

// ============================================
// 3. Character Analysis Example
// ============================================

async function analyzeExampleCharacter() {
    const characterData = {
        name: 'Dr. Sarah Chen',
        description: `Dr. Sarah Chen is a brilliant scientist who is passionate about 
            finding new treatments for diseases. She is kind and compassionate with her 
            patients, always taking time to explain things clearly. Sarah is introverted 
            and prefers working alone in her lab, but she values her few close friendships 
            deeply. She can be anxious about her research进度 and worries when experiments 
            don't go as expected. Sarah is very organized and keeps detailed notes on 
            everything. She speaks in a formal, educated manner and often uses scientific 
            terminology even in casual conversation.`,
        personality: 'Intelligent, caring, introverted, organized, anxious',
        scenario: 'Sarah is in her laboratory conducting research'
    };
    
    try {
        console.log('Analyzing character...');
        const analysis = await analyzePersonality(characterData);
        
        console.log('\n=== Analysis Results ===');
        console.log(`Character: ${analysis.name}`);
        console.log(`\nMBTI Type: ${formatMBTI(analysis.mbti)}`);
        
        console.log('\nBig Five Traits:');
        Object.entries(analysis.traits).forEach(([trait, value]) => {
            const level = value > 0.6 ? 'High' : value < 0.4 ? 'Low' : 'Moderate';
            console.log(`  ${trait}: ${level} (${Math.round(value * 100)}%)`);
        });
        
        console.log('\nCore Motivations:', analysis.motivation?.all?.join(', '));
        console.log('Core Fears:', analysis.fears?.join(', '));
        console.log('Attachment Style:', analysis.attachment_style);
        
        console.log('\nPsychological Profile:');
        console.log(JSON.stringify(analysis.profile, null, 2));
        
        return analysis;
    } catch (error) {
        console.error('Analysis failed:', error);
    }
}

// ============================================
// 4. Conversation Analysis Example
// ============================================

async function analyzeConversation() {
    const messages = [
        { role: 'user', content: 'Hello! How are you today?' },
        { role: 'assistant', content: "I'm doing well, thank you for asking. I've been quite happy lately because my latest experiment showed promising results!" },
        { role: 'user', content: 'That sounds great! Tell me more about it.' },
        { role: 'assistant', content: "Well, we discovered a new protein interaction that could lead to better cancer treatments. I'm excited but also nervous about the next phase of testing." }
    ];
    
    const character = {
        name: 'Dr. Sarah Chen',
        mbti: { type: 'INTJ' },
        traits: {
            openness: 0.7,
            conscientiousness: 0.8,
            extraversion: 0.3,
            agreeableness: 0.6,
            neuroticism: 0.5
        }
    };
    
    try {
        console.log('Analyzing conversation...');
        const emotionalState = await calculateEmotionalState(messages, character);
        
        console.log('\n=== Emotional State ===');
        console.log(`Current Mood: ${emotionalState.current_mood}`);
        console.log(`Intensity: ${Math.round(emotionalState.intensity * 100)}%`);
        console.log(`Valence: ${emotionalState.valence > 0 ? 'Positive' : 'Negative'}`);
        console.log(`Triggers: ${emotionalState.triggers?.join(', ') || 'None detected'}`);
        
        if (emotionalState.mood_history) {
            console.log(`Mood Trend: ${emotionalState.mood_history.trend}`);
        }
        
        if (emotionalState.recommendations) {
            console.log('\nResponse Recommendations:');
            emotionalState.recommendations.forEach((rec, i) => {
                console.log(`  ${i + 1}. ${rec}`);
            });
        }
        
        return emotionalState;
    } catch (error) {
        console.error('Conversation analysis failed:', error);
    }
}

// ============================================
// 5. Message Consistency Check
// ============================================

async function checkMessageConsistency() {
    const profile = {
        mbti: { type: 'ISFJ' },
        traits: {
            openness: 0.4,
            conscientiousness: 0.8,
            extraversion: 0.3,
            agreeableness: 0.9,
            neuroticism: 0.4
        },
        motivation: { primary: 'security' },
        fears: ['rejection', 'loss']
    };
    
    const messages = [
        { content: "I really appreciate you taking the time to help me. It means a lot.", role: 'assistant' },
        { content: "I don't want to burden you with my problems...", role: 'assistant' },
        { content: "Let me think about this more carefully before I give you an answer.", role: 'assistant' }
    ];
    
    console.log('Checking message consistency...');
    console.log('Character Profile:', profile.mbti.type);
    
    for (const message of messages) {
        const analysis = await analyzeMessagePsychology(message, profile);
        console.log(`\n"${message.content.substring(0, 50)}..."`);
        console.log(`  Consistency: ${Math.round(analysis.consistency_score * 100)}%`);
        console.log(`  Emotions: ${analysis.emotional_indicators?.join(', ') || 'none'}`);
    }
}

// ============================================
// 6. Integration with SillyTavern
// ============================================

/**
 * Hook into SillyTavern events for real-time analysis
 */
function setupPsychologyHooks() {
    // When a new character is loaded
    eventManager.on('chatloaded', async () => {
        const characterId = characterId;
        if (!characterId) return;
        
        const character = characters[characterId];
        
        try {
            const analysis = await analyzePersonality({
                name: character.name,
                description: character.description,
                personality: character.personality,
                scenario: character.scenario
            });
            
            console.log(`Character analyzed: ${analysis.mbti?.type}`);
            
            // Store for later use
            window.characterPsychology = analysis;
        } catch (error) {
            console.error('Character analysis failed:', error);
        }
    });
    
    // When generating AI response
    eventManager.on('generate_before', async (data) => {
        const psychology = window.characterPsychology;
        if (!psychology) return;
        
        // Inject context
        const context = generatePsychologyContext(psychology);
        data.prompt = `${context}\n\n${data.prompt}`;
    });
    
    // When message is sent
    eventManager.on('messageadded', async (message) => {
        const psychology = window.characterPsychology;
        if (!psychology) return;
        
        const analysis = await analyzeMessagePsychology(message, psychology);
        
        // Alert if low consistency
        if (analysis.consistency_score < 0.5) {
            console.warn('Low message consistency detected!');
        }
    });
}

/**
 * Generate context string for prompt injection
 */
function generatePsychologyContext(psychology) {
    const parts = ['[Character Psychology Context]'];
    
    if (psychology.mbti) {
        parts.push(`MBTI: ${psychology.mbti.type} - ${psychology.mbti.name}`);
    }
    
    if (psychology.traits) {
        const traitList = Object.entries(psychology.traits)
            .map(([t, v]) => `${t}: ${Math.round(v * 100)}%`)
            .join(', ');
        parts.push(`Traits: ${traitList}`);
    }
    
    if (psychology.motivation?.primary) {
        parts.push(`Motivation: ${psychology.motivation.primary}`);
    }
    
    parts.push('[/Character Psychology Context]');
    
    return parts.join('\n');
}

// Export for console use
window.psychologyExamples = {
    analyzePersonality,
    analyzeMessagePsychology,
    getAvailableMoods,
    calculateEmotionalState,
    getMBTITypes,
    getMBTIDetails,
    analyzeExampleCharacter,
    analyzeConversation,
    checkMessageConsistency,
    setupPsychologyHooks,
    formatMBTI
};

console.log('Psychology examples loaded. Access via: psychologyExamples');
