/**
 * Example: Basic Usage of Tiandao Plugin
 * Demonstrates core functionality for character analysis
 */

// This example shows how to use the Tiandao plugin in SillyTavern

// Access the plugin API (available after plugin loads)
const tiandao = window.tiandaoPlugin;

if (!tiandao) {
    console.error('Tiandao plugin not loaded!');
}

// ============================================
// 1. Initialize and Check Status
// ============================================

async function checkPluginStatus() {
    const info = tiandao.getPluginInfo();
    
    console.log(`Plugin: ${info.name} v${info.version}`);
    console.log(`Initialized: ${info.initialized}`);
    
    return info.initialized;
}

// ============================================
// 2. Analyze a Character
// ============================================

async function analyzeCurrentCharacter() {
    // Get the current character ID from SillyTavern
    const characterId = characterId; // SillyTavern global
    
    if (!characterId && characters[characterId]) {
        console.log('No character loaded');
        return;
    }
    
    console.log(`Analyzing character: ${characters[characterId].name}`);
    
    try {
        // Analyze the character
        const profile = await tiandao.analyzeCharacter(characterId);
        
        if (profile) {
            console.log('Analysis complete!');
            console.log(`MBTI: ${profile.mbti?.type || 'Unknown'}`);
            console.log(`Core Motivation: ${profile.motivation?.primary || 'Unknown'}`);
            
            return profile;
        }
    } catch (error) {
        console.error('Analysis failed:', error);
    }
}

// ============================================
// 3. Get Character Psychology
// ============================================

async function getCharacterPsychology() {
    const characterId = characterId;
    
    try {
        const psychology = await tiandao.getCharacterPsychology(characterId);
        
        if (psychology) {
            // Display in console
            console.log('=== Character Psychology ===');
            console.log(`MBTI: ${psychology.mbti?.type || 'Unknown'}`);
            console.log(`Motivation: ${psychology.motivation}`);
            console.log(`Attachment: ${psychology.attachment_style}`);
            
            if (psychology.traits) {
                console.log('Big Five Traits:');
                Object.entries(psychology.traits).forEach(([trait, value]) => {
                    const level = value > 0.6 ? 'High' : value < 0.4 ? 'Low' : 'Moderate';
                    console.log(`  ${trait}: ${level} (${Math.round(value * 100)}%)`);
                });
            }
            
            return psychology;
        }
    } catch (error) {
        console.error('Failed to get psychology:', error);
    }
}

// ============================================
// 4. Analyze a Message
// ============================================

async function analyzeUserMessage(messageContent) {
    const message = {
        role: 'user',
        content: messageContent,
        timestamp: new Date().toISOString()
    };
    
    try {
        const analysis = await tiandao.analyzeMessage(message);
        
        if (analysis) {
            console.log('Message Analysis:');
            console.log(`  Sentiment: ${analysis.sentiment?.label || 'neutral'}`);
            console.log(`  Consistency: ${Math.round(analysis.consistency_score * 100)}%`);
            console.log(`  Emotions: ${analysis.emotional_indicators?.join(', ') || 'none'}`);
            
            return analysis;
        }
    } catch (error) {
        console.error('Message analysis failed:', error);
    }
}

// ============================================
// 5. Calculate Emotional State
// ============================================

async function getEmotionalState(conversationHistory) {
    const characterId = characterId;
    
    try {
        const state = await tiandao.calculateEmotionalState(
            conversationHistory,
            characterId
        );
        
        if (state) {
            console.log('=== Emotional State ===');
            console.log(`Current Mood: ${state.current_mood}`);
            console.log(`Intensity: ${Math.round(state.intensity * 100)}%`);
            console.log(`Valence: ${state.valence > 0 ? 'Positive' : state.valence < 0 ? 'Negative' : 'Neutral'}`);
            
            if (state.triggers?.length > 0) {
                console.log(`Triggers: ${state.triggers.join(', ')}`);
            }
            
            return state;
        }
    } catch (error) {
        console.error('Emotional state calculation failed:', error);
    }
}

// ============================================
// 6. Inject Context into Prompts
// ============================================

function injectContextToPrompt(originalPrompt) {
    const characterId = characterId;
    
    // Get the cached profile
    const profile = tiandaoPlugin?.getCurrentProfile();
    
    if (!profile) {
        console.log('No profile cached. Analyzing character first...');
        // You may want to analyze first
        return originalPrompt;
    }
    
    // Format the context
    const context = tiandaoPlugin.formatCharacterContext(profile);
    
    // Inject at the beginning of the prompt
    return `${context}\n\n${originalPrompt}`;
}

// ============================================
// 7. Configuration
// ============================================

function configurePlugin() {
    // Get current configuration
    const config = tiandao.getConfig();
    
    console.log('Current Configuration:');
    console.log(`  API Endpoint: ${config.apiEndpoint}`);
    console.log(`  Auto-analyze: ${config.autoAnalyze}`);
    console.log(`  Context injection: ${config.injectContext}`);
    console.log(`  Analysis depth: ${config.analysisDepth}`);
    console.log(`  Debug mode: ${config.debugMode}`);
    
    // Update configuration
    tiandao.updateConfig({
        debugMode: true,
        analysisDepth: 'deep',
        injectContext: true
    });
    
    console.log('Configuration updated!');
}

// ============================================
// 8. Cache Management
// ============================================

function manageCache() {
    // Check cache size
    const cacheSize = tiandao.getCacheSize();
    console.log(`Cached profiles: ${cacheSize}`);
    
    // Clear cache if needed
    if (cacheSize > 50) {
        tiandao.clearCache();
        console.log('Cache cleared');
    }
}

// ============================================
// Example Usage in SillyTavern
// ============================================

// Hook into message sending
eventManager.on('message_send', async (message) => {
    // Analyze the message
    await analyzeUserMessage(message.content);
});

// Hook into chat loaded
eventManager.on('chatloaded', async () => {
    // Analyze the character
    await analyzeCurrentCharacter();
});

// Export functions for console use
window.tiandaoExamples = {
    checkStatus: checkPluginStatus,
    analyzeCharacter: analyzeCurrentCharacter,
    getPsychology: getCharacterPsychology,
    analyzeMessage: analyzeUserMessage,
    getEmotionState: getEmotionalState,
    injectContext: injectContextToPrompt,
    configure: configurePlugin,
    manageCache: manageCache
};

console.log('Tiandao examples loaded. Access via: tiandaoExamples');
