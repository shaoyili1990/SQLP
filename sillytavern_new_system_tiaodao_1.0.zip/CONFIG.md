# Tiandao System Configuration Guide

## Configuration Files

### Backend Configuration

The backend uses environment variables for configuration. Create a `.env` file in the `backend/` directory:

```bash
cp backend/.env.example backend/.env
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `HOST` | Server bind address | `0.0.0.0` |
| `PORT` | Server port | `5000` |
| `DEBUG` | Enable debug mode | `True` |
| `FLASK_ENV` | Environment (development/production) | `development` |
| `PSYCHOLOGY_ENABLED` | Enable psychology analysis | `True` |
| `PERSONALITY_MODEL` | Analysis model (keyword/ml/hybrid) | `keyword` |
| `ANALYSIS_DEPTH_DEFAULT` | Default analysis depth | `standard` |
| `MAX_CONTENT_LENGTH` | Max request size (bytes) | `16777216` (16MB) |
| `CORS_ORIGINS` | Allowed CORS origins | `*` |
| `LOG_LEVEL` | Logging level | `INFO` |

### Plugin Configuration

The SillyTavern plugin stores its configuration in localStorage. Access via the Settings UI in SillyTavern.

| Setting | Description | Default |
|---------|-------------|---------|
| `apiEndpoint` | Backend API URL | `http://localhost:5000/api` |
| `debugMode` | Enable console logging | `false` |
| `autoAnalyze` | Analyze characters on load | `true` |
| `cacheEnabled` | Cache analysis results | `true` |
| `injectContext` | Inject context into prompts | `true` |
| `showNotifications` | Show UI notifications | `true` |
| `analysisDepth` | Analysis depth (basic/standard/deep) | `standard` |
| `maxCacheSize` | Max cached profiles | `100` |
| `requestTimeout` | API request timeout (ms) | `10000` |

## Advanced Configuration

### Custom MBTI Descriptions

Edit `backend/psychology_api.py` to customize MBTI type descriptions:

```python
MBTI_TYPES = {
    'INTJ': {
        'name': 'The Mastermind',
        'traits': ['Strategic', 'Analytical', ...],
        'description': 'Your custom description...'
    },
    ...
}
```

### Custom Trait Keywords

Modify the trait analysis keywords in `psychology_api.py`:

```python
TRAIT_KEYWORDS = {
    'openness': {
        'high': ['creative', 'artistic', ...],  # Add your keywords
        'low': ['traditional', 'conventional', ...]
    },
    ...
}
```

### Custom Speech Patterns

Extend `character_card_parser.py` for additional speech pattern detection:

```python
self.speech_indicators = {
    'formal': [...],
    'casual': [...],
    'your_custom_pattern': [...]  # Add new patterns
}
```

### Rate Limiting

Configure rate limits in environment:

```bash
ENABLE_RATE_LIMITING=True
RATE_LIMIT_PER_MINUTE=60
RATE_LIMIT_PER_HOUR=1000
```

### Redis Cache (Production)

For production caching with Redis:

```bash
CACHE_TYPE=redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=your_password
```

## Testing Configuration

Create a `backend/.env.test` for test environment:

```bash
FLASK_ENV=test
DEBUG=True
ENABLE_CACHING=False
ENABLE_RATE_LIMITING=False
```

## Production Checklist

Before deploying to production:

- [ ] Set `DEBUG=False`
- [ ] Configure proper `SECRET_KEY`
- [ ] Enable `SESSION_COOKIE_SECURE=True`
- [ ] Set appropriate `CORS_ORIGINS`
- [ ] Configure rate limiting
- [ ] Set up proper logging
- [ ] Enable Redis cache for scaling
- [ ] Configure database if needed
- [ ] Set up monitoring/alerting
- [ ] Enable HTTPS on backend server

## Environment Examples

### Development

```bash
DEBUG=True
FLASK_ENV=development
LOG_LEVEL=DEBUG
ENABLE_RATE_LIMITING=False
CORS_ORIGINS=*
```

### Production

```bash
DEBUG=False
FLASK_ENV=production
LOG_LEVEL=WARNING
ENABLE_RATE_LIMITING=True
RATE_LIMIT_PER_MINUTE=60
CORS_ORIGINS=https://your-sillytavern-domain.com
SECRET_KEY=your-secure-random-key-here
SESSION_COOKIE_SECURE=True
```
